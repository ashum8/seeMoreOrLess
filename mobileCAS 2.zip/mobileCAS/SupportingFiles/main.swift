//
//  main.swift
//  mCAS
//
//  Created by Mac on 19/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

UIApplicationMain(CommandLine.argc, CommandLine.unsafeArgv, NSStringFromClass(TIMERUIApplication.self), NSStringFromClass(AppDelegate.self))
