//
//  CameraOverlayView.swift
//  mCAS
//
//  Created by iMac on 07/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

protocol CameraOverlayViewDelegate {
    func closeButtonAction()
    func finishButtonAction()
    func takePictureButtonAction()
}

class CameraOverlayView: UIView {
    
    var delegate: CameraOverlayViewDelegate?
    
    @IBOutlet weak var capturedImageView: UIImageView!
    @IBOutlet weak var totalDocumentsCount: UILabel!
    @IBOutlet weak var finishButton: UIButton!
    @IBOutlet weak var takePictureButton: UIButton!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        
        Bundle.main.loadNibNamed("CameraOverlayView", owner: self, options: nil)
        self.fixInView(self)
    }
    
    func setTakePictureButtonEnabled(isEnabled: Bool) {
        
        self.takePictureButton.alpha = isEnabled ? 1.0 : 0.4
        self.takePictureButton.isEnabled = isEnabled
    }
    
    func setFinishButtonEnabled(isEnabled: Bool) {
        
        self.finishButton.alpha = isEnabled ? 1.0 : 0.4
        self.finishButton.isEnabled = isEnabled
    }
    
    @IBAction func finishButtonAction(_ sender: UIButton) {
        self.delegate?.finishButtonAction()
    }
    
    @IBAction func takePictureButtonAction(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.2, delay: 0.0, options: .curveEaseOut, animations: {
            self.backgroundColor = .white
            self.alpha = 0.2
            sender.transform = CGAffineTransform(scaleX: 1.5,y: 1.5)
        }) { (finished) in
            self.backgroundColor = .clear
            self.alpha = 1.0
            UIView.animate(withDuration: 0.1, delay: 0.0, options: .curveEaseOut, animations: {
                sender.transform = CGAffineTransform(scaleX: 1,y: 1);
            }, completion: nil)
        }
        
        self.delegate?.takePictureButtonAction()
    }
    
    @IBAction func closeCameraButtonAction(_ sender: UIButton) {
        self.delegate?.closeButtonAction()
    }
    
    
}
