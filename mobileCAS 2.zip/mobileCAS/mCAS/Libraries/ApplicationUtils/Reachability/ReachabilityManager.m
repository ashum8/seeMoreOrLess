//
//  ReachabilityManager.m
//  Rating
//
//  Created by amit.swami on 17/07/14.
//  Copyright (c) 2014 Nucleus. All rights reserved.
//

#import "ReachabilityManager.h"

@implementation ReachabilityManager

#pragma mark -
#pragma mark - Default Manager
+ (ReachabilityManager*) sharedManager
{
    static ReachabilityManager *_sharedManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedManager = [[self alloc] init];
    });
    return _sharedManager;
}


#pragma mark -
#pragma mark - Memory Managment
 - (void)dealloc
{
    if(_reachability){
        [_reachability stopNotifier];
    }
}


#pragma mark - Class Methods

+ (BOOL) isReachable
{
    return [[[ReachabilityManager sharedManager] reachability] isReachable];
    return YES;
}

+ (BOOL) isUnReachable
{
    return ![[[ReachabilityManager sharedManager] reachability] isReachable];
}

+ (BOOL) isReachableViaWWAN
{
    return [[[ReachabilityManager sharedManager] reachability] isReachableViaWWAN];
}

+ (BOOL) isReachableViaWiFi
{
    return [[[ReachabilityManager sharedManager] reachability] isReachableViaWiFi];
}

#pragma mark - 
#pragma mark - Private Initialization

- (id) init
{
    self = [super init];
    
    if(self){
        self.reachability = [Reachability reachabilityForInternetConnection];

        [self.reachability startNotifier];
    }
    return self;
}
@end
