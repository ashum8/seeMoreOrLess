//
//  CustomDateFormatter.swift
//  mCAS
//
//  Created by Mac on 17/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation

class CustomDateFormatter {
    
    private static var instance: CustomDateFormatter?
    
    static func shared() -> CustomDateFormatter{
        if instance == nil {
            instance = CustomDateFormatter()
        }
        return instance!
    }
    
    func getFormatedDateStringFromString(inputString: String, outputFormat: String = Constants.DATE_FORMAT_VIEW) -> String  {
        
        if let date = getRespectiveDateFromString(inputString: inputString) {
            return date.getFormatedDateString(outputFormat: outputFormat)
        }
        else {
            return inputString
        }
    }
    
    func getRespectiveDateFromString(inputString: String) -> Date? {
        do {
            let detector = try NSDataDetector.init(types: NSTextCheckingResult.CheckingType.date.rawValue)
            
            let matches = detector.matches(in: inputString, options: [], range: NSRange(location: 0, length: inputString.utf16.count))
            
            for match in matches {
                if match.resultType == .date, let components = match.date {
                    return components
                }
            }
        }
        catch {}
        
        return nil
    }
    
}

extension Date {
    
    func getFormatedDateString(outputFormat: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = outputFormat
        return dateFormatter.string(from: self)
    }
    
    func timeDifferenceInSeconds(toDate: Date) -> Int {
        let difference = Calendar.current.dateComponents([.second], from: self, to: toDate)
        return difference.second!
    }
    
    func getDaysDifference(toDate: Date) -> Int {
        let difference = Calendar.current.dateComponents([.day], from: Calendar.current.startOfDay(for: self), to: Calendar.current.startOfDay(for: toDate))
        return difference.day!
    }
    
    func timeStamp() -> String {
        return String("\(self.timeIntervalSince1970 * 1000)".prefix(13))
    }
    
    func isBetween(startDate:Date, endDate:Date)->Bool
    {
        return ((startDate.compare(self) == .orderedAscending) && (endDate.compare(self) == .orderedDescending)) || (startDate.compare(self) == .orderedSame) || (endDate.compare(self) == .orderedSame)
    }
    
    func getDaysInMonth() -> Int {
        let calendar = Calendar.current
        
        let dateComponents = DateComponents(year: calendar.component(.year, from: self), month: calendar.component(.month, from: self))
        let date = calendar.date(from: dateComponents)!
        
        let range = calendar.range(of: .day, in: .month, for: date)!
        let numDays = range.count
        
        return numDays
    }
}
