//
//  GenericTableViewCell.swift
//  mCAS
//
//  Created by iMac on 06/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class GenericTableViewCell: UITableViewCell {
    
    func getViewController() -> UIViewController {
        
        var nextResponderView = next
        while !(nextResponderView is UIViewController) {
            nextResponderView = nextResponderView?.next
            if nil == nextResponderView {
                break
            }
        }
        return nextResponderView as! UIViewController
    }
}
