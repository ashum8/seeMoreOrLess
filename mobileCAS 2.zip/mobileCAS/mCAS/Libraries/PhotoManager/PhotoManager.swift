//
//  PhotoManager.swift
//  mCAS
//
//  Created by iMac on 07/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//
import UIKit
import Photos

@objc protocol PhotoManagerDelegate {
    
    func didFinishPickingImage(image: UIImage)
   @objc optional func didFinishPickingMediaArray(mediaArray: [Any])
}


class PhotoManager: NSObject, ELCImagePickerControllerDelegate {
    
    var delegate: PhotoManagerDelegate?
    var isMultiUploading: Bool = false
    var fromCamera: Bool?
    var totalCount: Int?
    var baseVC: UIViewController?
    var imagePickerController: UIImagePickerController?
    var overlayView: CameraOverlayView?
    
    func showImageUploadDialogWithViewController(vc: UIViewController) {
        
        self.baseVC = vc
        
        if Constants.SHOW_GALLERY_WITH_CAMERA {
            
            self.baseVC?.view.endEditing(true)
            
            let alert = UIAlertController(title: NSLocalizedString("", comment: ""), message: NSLocalizedString("Capture Photo", comment: ""), preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: NSLocalizedString("Gallery", comment: ""), style: .default, handler: { action in
                                self.checkPhotoLibraryPermission()
            }))
            
            alert.addAction(UIAlertAction(title: NSLocalizedString("Camera", comment: ""), style: .default, handler: { action in
                self.imageUsingCameraWithViewController(vc: self.baseVC!)
            }))
            alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel, handler: nil))
            
            vc.present(alert, animated: true)
        }
        else {
            self.imageUsingCameraWithViewController(vc: vc)
        }
    }
    
    
    //   MARK:- Taking Image Using Photo Library
    func imageUsingPhotoLibraryWithViewController(vc: UIViewController) {
        
        self.baseVC = vc
        
        let elcPicker = ELCImagePickerController.init(imagePicker: ())
        elcPicker?.maximumImagesCount = self.isMultiUploading ? 5 : 1  //Set the maximum number of images to select
        
        elcPicker?.returnsOriginalImage = true //Only return the fullScreenImage, not the fullResolutionImage
        elcPicker?.returnsImage = true //Return UIimage if YES. If NO, only return asset location information
        elcPicker?.onOrder = true //For multiple image selection, display and return order of selected images
        elcPicker?.mediaTypes = [kCIAttributeTypeImage as String]
        //        elcPicker.mediaTypes = @[(NSString *)kUTTypeImage]; //Supports image
        elcPicker?.imagePickerDelegate = self
        self.baseVC?.present(elcPicker!, animated: true, completion: nil)
    }
    
    func openCameraAnimated(animated:Bool) {
        
        self.totalCount = 0
        
        self.imagePickerController = UIImagePickerController()
        self.imagePickerController?.delegate = self
        self.imagePickerController?.allowsEditing = true
        self.imagePickerController?.sourceType = .camera
        self.imagePickerController?.showsCameraControls = true
        
        if self.isMultiUploading {
            self.overlayView = CameraOverlayView(frame: self.baseVC!.view.frame)
            self.overlayView?.delegate = self
            self.imagePickerController?.cameraOverlayView = self.overlayView
            self.imagePickerController?.showsCameraControls = false
            
            let screenSize = UIScreen.main.bounds.size
            let cameraAspectRatio = 4.0 / 3.0
            let imageWidth = floorf(Float(screenSize.width) * Float(cameraAspectRatio));
            let scale = ceilf((Float(screenSize.height) / imageWidth) * 10.0) / 10.0;
            self.imagePickerController?.cameraViewTransform = CGAffineTransform(scaleX: CGFloat(scale), y: CGFloat(scale));
        }
        self.baseVC?.present(self.imagePickerController!, animated: animated, completion: nil)
        
    }
    
    func checkPhotoLibraryPermission() {
        
        let status = PHPhotoLibrary.authorizationStatus()
        
        switch status {
        case .authorized:
                self.imageUsingPhotoLibraryWithViewController(vc: self.baseVC!)
        case .notDetermined:
            PHPhotoLibrary.requestAuthorization { (authorizationStatus) in
                if authorizationStatus == .authorized {
                        self.imageUsingPhotoLibraryWithViewController(vc: self.baseVC!)
                }
                else {
                    DispatchQueue.main.async {
                        CommonAlert.shared().showPhotosPermissionAlert()
                    }
                }
            }
            
        default:
            DispatchQueue.main.async {
                CommonAlert.shared().showPhotosPermissionAlert()
            }
        }
    }
    
    func checkCameraPermission() {
        
        let authStatus = AVCaptureDevice.authorizationStatus(for: .video)
        
        if authStatus == .authorized {
            DispatchQueue.global().async {
                //load your data here.
                DispatchQueue.main.async {
                    self.openCameraAnimated(animated: true)
                }
            }
        }
        else {
            AVCaptureDevice.requestAccess(for: .video) { (granted) in
                if granted {
                    DispatchQueue.global().async {
                        //load your data here.
                        DispatchQueue.main.async {
                            self.openCameraAnimated(animated: true)
                        }
                    }
                }
                else {
                    DispatchQueue.global().async {
                        //load your data here.
                        DispatchQueue.main.async {
                            CommonAlert.shared().showCameraPermissionAlert()
                        }
                    }
                }
            }
        }
    }
    
    func imageUsingCameraWithViewController(vc: UIViewController) {
        
        self.baseVC = vc
        
        if !UIImagePickerController.isSourceTypeAvailable(.camera) {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Sorry camera not available on device", comment: ""))
        }
        else {
            self.checkCameraPermission()
        }
    }
    
    func elcImagePickerController(_ picker: ELCImagePickerController!, didFinishPickingMediaWithInfo info: [Any]!) {
        
        if (self.isMultiUploading) {
            self.delegate?.didFinishPickingMediaArray?(mediaArray: info)
        }
        else {
            for dict in info {
                if let data = dict as? NSDictionary {
                    if data[UIImagePickerController.InfoKey.mediaType] as! String == "ALAssetTypePhoto" {
                        self.delegate?.didFinishPickingImage(image: data[UIImagePickerController.InfoKey.originalImage] as! UIImage)
                        break
                    }
                }
            }
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    func elcImagePickerControllerDidCancel(_ picker: ELCImagePickerController!) {
        picker.dismiss(animated: true, completion: nil)
    }
    
}

//extension PhotoManager: ELCImagePickerControllerDelegate {
//    func elcImagePickerController(_ picker: ELCImagePickerController!, didFinishPickingMediaWithInfo info: [Any]!) {
//
//        if (self.isMultiUploading) {
//            self.delegate?.didFinishPickingMediaArray?(mediaArray: info)
//        }
//        else {
//            for dict in info {
//                if let data = dict as? NSDictionary {
//                    if data[UIImagePickerController.InfoKey.mediaType] as? String == "public.image" {
//                        self.delegate?.didFinishPickingImage(image: data[UIImagePickerController.InfoKey.originalImage] as! UIImage)
//                        break
//                    }
//                }
//            }
//        }
//        picker.dismiss(animated: true, completion: nil)
//    }
//
//    func elcImagePickerControllerDidCancel(_ picker: ELCImagePickerController!) {
//        picker.dismiss(animated: true, completion: nil)
//    }
//
//
//}
extension PhotoManager: UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        var image = UIImage()
        
        if (picker.isEditing)   { image = info[.editedImage] as! UIImage }
        else                    { image = info[.originalImage] as! UIImage }
        
        
        if self.isMultiUploading {
            
            UIView.animate(withDuration: 0.05, delay: 0.0, options: .curveEaseOut, animations: {
                self.overlayView?.capturedImageView.alpha = 0.2
            }) { (finished) in
                self.overlayView?.totalDocumentsCount.text = "\(self.totalCount!)"
                self.overlayView?.capturedImageView.alpha = 1.0
                self.overlayView?.capturedImageView.image = image
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                self.overlayView?.setTakePictureButtonEnabled(isEnabled: true)
            }
            
            self.delegate?.didFinishPickingImage(image: image)
            
        }
        else {
            picker.dismiss(animated: true) {
                self.delegate?.didFinishPickingImage(image: image)
            }
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}

extension PhotoManager: CameraOverlayViewDelegate {
    func closeButtonAction() {
        self.totalCount = 0
        self.imagePickerControllerDidCancel(self.imagePickerController!)
    }
    
    func finishButtonAction() {
        self.imagePickerControllerDidCancel(self.imagePickerController!)
    }
    
    func takePictureButtonAction() {
        self.overlayView?.setTakePictureButtonEnabled(isEnabled: false)
        self.imagePickerController?.takePicture()
    }
}
