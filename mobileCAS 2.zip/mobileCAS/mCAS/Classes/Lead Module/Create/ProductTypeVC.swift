//
//  ProductTypeVC.swift
//  mCAS
//
//  Created by iMac on 12/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


protocol ProductTypeVCDelegate {
    func selected(productType: LoanType, currentStep: Int, totalStep: Int)
}

class ProductTypeVC: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!
    fileprivate var collectionArray: [LoanType] = []
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private var productCat: LoanType?
    private var tileCount: CGFloat = 3
    private var delegate: ProductTypeVCDelegate?
    private var currentStep: Int = 0
    private var totalStep: Int = 0
    private var notAllowedProductTypes: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if UIDevice.current.userInterfaceIdiom == .pad {
            tileCount = 4
        }
        
        collectionView.register(UINib(nibName: String(describing: ProductTypeCell.self), bundle: Bundle.main), forCellWithReuseIdentifier: "ProductTypeCell")
        
        buttonView.setProperties(showBack: true, showNext: false, delegate: self)
        setCollectionViewData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            if totalStep > 0 {
                //When coming from lead list - landing page already set
                headerView.showHideStepHeader(isHide: false, title: "Product Type", step: "("+"\(currentStep)"+"/"+"\(totalStep)"+")")
            }
            else {
                //When coming from sourcing list - set landing page
                let navArray = AppDelegate.instance.applicationNavController.viewControllers
                let lastVC = navArray[navArray.count-2]
                headerView.showHideStepHeader(isHide: false, title: "Select Product Category", landingPage: lastVC)
            }
        }
    }
    
    func setData(notAllowedProductList: [String]? = [], delegate: ProductTypeVCDelegate, currentStep: Int? = 0, totalStep: Int? = 0) {
        self.notAllowedProductTypes = notAllowedProductList!
        self.delegate = delegate
        self.currentStep = currentStep!
        self.totalStep = totalStep!
    }
    
    func setCollectionViewData() {
        
        // fetch the dropdownList according to master name
        CoreDataOperations.shared().fetchRecordsForMaster(masterName: Entity.PRODUCT_CATEGORY) { (records) in
            
            if let records = records {
                self.collectionArray = records.map({ (dd) -> LoanType in
                    LoanType(code: dd.code, name: dd.name)
                })
            }
        }
    }
}

extension ProductTypeVC: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return collectionArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProductTypeCell", for: indexPath) as! ProductTypeCell
        cell.setData(obj: collectionArray[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.bounds.width/tileCount
        return CGSize(width: width, height: width)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let obj = collectionArray[indexPath.row]
        
        if !notAllowedProductTypes.isEmpty, notAllowedProductTypes.contains(obj.code) {
            CommonAlert.shared().showAlert(message: "\(obj.name) is not allowed for non-individual customer")
        }
        else {
            collectionArray = collectionArray.map({ (item) -> LoanType in
                var dataObj = item
                dataObj.isSelectedFlag = (obj.name == dataObj.name)
                return dataObj
            })
            
            collectionView.reloadData()
            
            self.delegate?.selected(productType: obj, currentStep: currentStep+1, totalStep: totalStep)
        }
    }
}

extension ProductTypeVC: NextBackButtonDelegate {
    
    func backButtonAction() {
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideStepHeader(isHide: true)
        }
        
        self.navigationController?.popViewController(animated: true)
    }
}
