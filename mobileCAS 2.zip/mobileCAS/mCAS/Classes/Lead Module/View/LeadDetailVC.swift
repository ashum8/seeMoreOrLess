//
//  LeadDetailVC.swift
//  mCAS
//
//  Created by iMac on 19/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class LeadDetailVC: UIViewController {
    @IBOutlet weak var btnLoanType: UIButton!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var leadIDLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var offlineImageView: UIImageView!
    
    var model: LeadModelClasses.LeadModel!
    private var listModelArray: [KeyValueModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpView()
        setUpTableViewData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.isHidden = true
        }
    }
    
    private func setUpView() {
        btnLoanType.layer.cornerRadius = 30
        btnLoanType.layer.borderWidth = 1
        btnLoanType.layer.borderColor = UIColor.gray.cgColor
        btnLoanType.setImage(UIImage.init(named: CommonUtils.shared().getIconFor(productTypeCode: (model.loanDetail?.productType?.code)!)), for: .normal)
        
        nameLabel.font = CustomFont.shared().GETFONT_MEDIUM(17)
        leadIDLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
        
        backgroundView.setShadow()
        
        if let code = model.primaryApplicant?.applicantType?.code, code == Constants.CUSTOMER_TYPE_INDV {
            nameLabel.text = model.primaryApplicant!.firstName! + " " + model.primaryApplicant!.lastName!
        }
        else {
            nameLabel.text = model.primaryApplicant!.companyName
        }
        
        leadIDLabel.text = "\(model.leadReferenceId ?? "") \(Constants.SEPERATOR) \(model.primaryApplicant!.isdCode!.name!)-\(model.primaryApplicant!.mobileNumber!)"
        
        if let offline = model.isOffline, offline == true {
            offlineImageView.isHidden = false
            buttonView.setProperties(showBack: true, backBtnTitle: "Close", nextBtnTitle: "Sync Online", delegate: self)
        }
        else {
            offlineImageView.isHidden = true
            buttonView.setProperties(showBack: true, backBtnTitle: "Close", nextBtnTitle: "Done", delegate: self)
        }
    }
    
    func setUpTableViewData() {
        tableView.register(UINib.init(nibName: "KeyValueCell", bundle: Bundle.main), forCellReuseIdentifier: "KeyValueCell")
        
        if let createdDate = model.createdDate {
            listModelArray.append(KeyValueModel(fieldName: "Created on", fieldValue: CustomDateFormatter.shared().getFormatedDateStringFromString(inputString: createdDate)))
        }
        
        listModelArray.append(KeyValueModel(fieldName: "Customer Type", fieldValue: model.primaryApplicant?.applicantType?.code ?? ""))
        
        if let code = model.primaryApplicant?.applicantType?.code, code == Constants.CUSTOMER_TYPE_INDV {
            
            if let dateOfBirth = model.primaryApplicant?.dateOfBirth {
                listModelArray.append(KeyValueModel(fieldName: "Date of Birth", fieldValue: CustomDateFormatter.shared().getFormatedDateStringFromString(inputString: dateOfBirth)))
            }
        }
        else {
            listModelArray.append(KeyValueModel(fieldName: "Contact Person", fieldValue: model.primaryApplicant!.firstName! + " " + model.primaryApplicant!.lastName!))
            
            if let designation = model.primaryApplicant?.designation {
                listModelArray.append(KeyValueModel(fieldName: "Designation", fieldValue: designation))
            }
        }
        
        listModelArray.append(KeyValueModel(fieldName: "Email", fieldValue: model.primaryApplicant?.emailAddress ?? ""))
        listModelArray.append(KeyValueModel(fieldName: "City", fieldValue: model.city?.name ?? ""))
        listModelArray.append(KeyValueModel(fieldName: "Product Type", fieldValue:  model.loanDetail?.productType?.name ?? ""))
        listModelArray.append(KeyValueModel(fieldName: "Product", fieldValue: model.loanDetail?.product?.name ?? ""))
        
        if let code = model.loanDetail?.productType?.code, code != ConstantCodes.PRODUCT_TYPE_CC, code != ConstantCodes.PRODUCT_TYPE_KCC, let loanAmount = model.loanDetail?.loanAmount {
            listModelArray.append(KeyValueModel(fieldName: "Loan Amount Requeted", fieldValue: String(loanAmount).formatCurrency))
        }
        
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }    
}

extension LeadDetailVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listModelArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let model = listModelArray[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "KeyValueCell") as! KeyValueCell
        cell.setProperties(key: model.fieldName, value: model.fieldValue)
        return cell
    }
}

extension LeadDetailVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        
        if let offline = model.isOffline, offline == true {
            LeadWS.shared().saveLead(model: model, deleteOfflineRecord: true, completion: { (leadID) in
                
                CommonAlert.shared().showAlert(message: "Lead synced successfully. Lead id is \(leadID)", okAction: { _ in
                    
                    let viewContrlls = (self.navigationController?.viewControllers)!
                    
                    for vc in viewContrlls {
                        if vc.isKind(of: LeadsListVC.self), let obj = vc as? LeadsListVC {
                            obj.refreshList()
                            self.navigationController?.popToViewController(obj, animated: true)
                            break
                        }
                    }
                })
            })
        }
        else {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
    
    
}
