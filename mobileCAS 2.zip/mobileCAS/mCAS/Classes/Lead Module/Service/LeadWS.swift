//
//  Webservices.swift
//  mCAS
//
//  Created by Mac on 20/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


class LeadWS {
    
    private static var instance: LeadWS?
    
    static func shared() -> LeadWS {
        if instance == nil {
            instance = LeadWS()
        }
        return instance!
    }
    
    func saveLead(model: LeadModelClasses.LeadModel, deleteOfflineRecord: Bool = false, completion:@escaping (_ leadID: String) -> Void) {
        
        if let primaryApplicant = model.primaryApplicant, let firstName = primaryApplicant.firstName, let lastName = primaryApplicant.lastName, let mobileNumber = primaryApplicant.mobileNumber, let emailAddress = primaryApplicant.emailAddress, let designation = primaryApplicant.designation, let dateOfBirth = primaryApplicant.dateOfBirth, let companyName = primaryApplicant.companyName, let applicantType = primaryApplicant.applicantType, let isdCode = primaryApplicant.isdCode, let loanDetail = model.loanDetail, let cityCode = model.city?.code, let leadID = model.leadReferenceId {
            
            var loanAmountString = ""
            if let loanAmount = loanDetail.loanAmount {
                loanAmountString = "\(loanAmount)"
            }
            
            let param: [String : Any] = ["lead": ["primaryApplicant"    : ["firstName"      : firstName,
                                                                           "lastName"       : lastName,
                                                                           "middleName"     : "",
                                                                           "mobileNumber"   : mobileNumber,
                                                                           "emailAddress"   : emailAddress,
                                                                           "designation"    : designation,
                                                                           "dateOfBirth"    : CustomDateFormatter.shared().getFormatedDateStringFromString(inputString: dateOfBirth, outputFormat: Constants.DATE_FORMAT_SERVICE),
                                                                           "companyName"    : companyName,
                                                                           "applicantType"  : ["code"   : applicantType.code],
                                                                           "isdCode"        : ["code"   : isdCode.code,
                                                                                               "name"   : isdCode.name]],
                                                  "loanDetail"          : ["loanAmount"     : loanAmountString,
                                                                           "productType"    : ["code"   : loanDetail.productType?.code],
                                                                           "product"        : ["code"   : loanDetail.product?.code]],
                                                  "city"                : ["code"           : cityCode]]]
            
            
            Webservices.shared().POST(urlString: ServiceUrl.CREATE_LEAD_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
                
                if let response = responseObj as? [String : Any], let success = response["completed"] as? Bool, success == true, let leadNumber = response["leadReferenceNumber"] as? String {
                    
                    self.deleteOfflineRecord(deleteOfflineRecord: deleteOfflineRecord, leadID: leadID)
                    completion(leadNumber)
                }
                
            }, failure: { (error) in
                
                if let error = error {
                    if error.contains("duplicate") {
                        self.deleteOfflineRecord(deleteOfflineRecord: deleteOfflineRecord, leadID: leadID)
                    }
                    CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
                }
                
            }, noNetwork: { (error) in
            })
        }
    }
    
    func deleteOfflineRecord(deleteOfflineRecord: Bool = false, leadID: String) {
        //Delete offline record on sync successfull or duplicate lead
        if deleteOfflineRecord, let userData = AppDelegate.instance.currentLoggedInUser {
            let predicate = NSPredicate(format: "(\(CDLeadSaveRelationships.loginUser) == %@) AND (\(CDLeadSaveAttributes.tempLeadID) == %@)", userData, leadID)
            let entityName = String(describing: CDLeadSave.self)
            
            CoreDataOperations.shared().deleteAllRecords(predicate: predicate, entityName: entityName)
        }
    }
}
