//
//  CasesCell.swift
//  mCAS
//
//  Created by Mac on 27/08/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


@objc protocol CaseCellDelegate {
    @objc optional func selectedIndex(index: Int, cellIndex: Int)
    @objc optional func syncButtonAction(cellIndex: Int)
}

class CasesCell: UITableViewCell {
    
    @IBOutlet private weak var bgView: UIView!
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label3: EdgeInsetLabel!
    @IBOutlet weak var label4: UILabel!
    @IBOutlet weak var loanTypeLabel: UILabel!
    @IBOutlet weak var loanIcon: UIImageView!
    @IBOutlet weak var customerTypeIcon: UIImageView!
    @IBOutlet weak var arrowIcon: UIImageView!
    @IBOutlet weak var optionButton: UIButton!
    @IBOutlet weak var syncButton: UIButton!
    @IBOutlet weak var syncButtonHeight: NSLayoutConstraint!
    @IBOutlet weak var offlineTagImage: UIImageView!
    @IBOutlet weak var customerTypeIconWidth: NSLayoutConstraint!
    
    private var cellTag: Int!
    private var optionArray: [String] = []
    private var optionsWidth: CGFloat!
    private var delegate: CaseCellDelegate?
    
    func setProperties(showSyncButton: Bool = false, showStatus: Bool = false, cellIndex: Int, customerType: String? = nil, showArrow: Bool = false, showOption: Bool = false, productTypeCode: String?, showOfflineFlag: Bool = false, delegate: CaseCellDelegate? = nil, optionArray: [String]? = [], optionsWidth: CGFloat? = 180) {
        
        self.contentView.backgroundColor = .clear
        self.backgroundColor = .clear
        
        self.optionArray = optionArray!
        self.delegate = delegate
        self.optionsWidth = optionsWidth!
        cellTag = cellIndex
        bgView.setCornerRadius()
        bgView.setShadow()
        
        syncButtonHeight.constant = showSyncButton ? 30 : 0
        arrowIcon.isHidden = !showArrow
        optionButton.isHidden = !showOption
        offlineTagImage.isHidden = !showOfflineFlag
        
        label1.font = CustomFont.shared().GETFONT_MEDIUM(19)
        label2.font = CustomFont.shared().GETFONT_REGULAR(16)
        label3.font = CustomFont.shared().GETFONT_REGULAR(16)
        label4.font = CustomFont.shared().GETFONT_REGULAR(16)
        loanTypeLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        
        if let productTypeCode = productTypeCode {
            loanIcon.image = UIImage(named: CommonUtils.shared().getIconFor(productTypeCode: productTypeCode))
        }
        
        if let custType = customerType {
            customerTypeIconWidth.constant = 15
            
            if custType == Constants.CUSTOMER_TYPE_CORP {
                customerTypeIcon.image = UIImage.init(named: "corporate_icon")
            }
            else {
                customerTypeIcon.image = UIImage.init(named: "individual_icon")
            }
        }
        else {
            customerTypeIconWidth.constant = 0
        }
        
        if showStatus {
            label3.setStatusLabelProperties(borderColor: .green)
        }
    }
    
    @IBAction func optionButtonAction(_ sender: Any) {
        
        let obj = SimpleListVC.init(nibName: "SimpleListVC", bundle: nil)
        obj.setData(listArray: optionArray, delegate: self, width: self.optionsWidth)
        
        if let popoverPresentationController = obj.popoverPresentationController {
            if let vc = AppDelegate.instance.applicationNavController.viewControllers.last {
                AppDelegate.instance.headerView?.searchView.searchBar.resignFirstResponder()
                vc.view.endEditing(true)
            }
            
            popoverPresentationController.permittedArrowDirections = .up
            popoverPresentationController.sourceView = self.optionButton
            popoverPresentationController.sourceRect = self.optionButton.bounds
            popoverPresentationController.delegate = self
            AppDelegate.instance.applicationNavController.present(obj, animated: true, completion: nil)
        }
    }
    
    @IBAction func syncButtonAction(_ sender: Any) {
        self.delegate?.syncButtonAction?(cellIndex: self.cellTag)
    }
}

extension CasesCell : SimpleListVCDelegate {
    
    func selectedListOption(index: Int) {
        
        DispatchQueue.main.async {
            AppDelegate.instance.applicationNavController.dismiss(animated: true) {
                self.delegate?.selectedIndex?(index: index, cellIndex: self.cellTag)
            }
        }
    }
}

extension CasesCell: UIPopoverPresentationControllerDelegate {
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }
    
    func popoverPresentationControllerDidDismissPopover(_ popoverPresentationController: UIPopoverPresentationController) {
        popoverPresentationController.delegate = nil
    }
    
    func popoverPresentationControllerShouldDismissPopover(_ popoverPresentationController: UIPopoverPresentationController) -> Bool {
        return true
    }
}
