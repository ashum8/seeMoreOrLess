//
//  CommonAlert.swift
//  Nuco
//
//  Created by Mac on 12/12/19.
//  Copyright © 2019 Nucleus Software Exports Ltd. All rights reserved.
//

import Foundation

class CommonAlert: NSObject {
    
    private static var instance: CommonAlert?
    
    static func shared() -> CommonAlert{
        if instance == nil {
            instance = CommonAlert()
        }
        return instance!
    }
    
    func showAlert(title: String? = nil, message: String, okTitle: String? = nil, cancelTitle: String? = nil, dismissTitle: String? = nil, okAction: ((_: UIAlertAction) -> Void)? = nil, cancelAction: ((_: UIAlertAction) -> Void)? = nil) {
        
        if let vc = AppDelegate.instance.applicationNavController.viewControllers.last {
            vc.view.endEditing(true)
            
            var okHandler = okAction
            var cancelHandler = cancelAction
            
            var titleString = title
            var okTitleString = okTitle
            
            if okHandler == nil { okHandler = {_ in } }
            if cancelHandler == nil { cancelHandler = {_ in } }
            
            if titleString == nil { titleString = "" }
            if okTitleString == nil { okTitleString = "OK" }
            
            let alertView = UIAlertController(title: titleString, message: message, preferredStyle: UIAlertController.Style.alert)
            alertView.addAction(UIAlertAction(title: okTitleString, style: .default, handler: okHandler))
            
            if let cancelTitleString = cancelTitle {
                alertView.addAction(UIAlertAction(title: cancelTitleString, style: .default, handler: cancelHandler))
            }
            
            if let dismissTitleString = dismissTitle {
                alertView.addAction(UIAlertAction(title: dismissTitleString, style: .default))
            }
            
            vc.present(alertView, animated: true, completion: nil)
        }
    }    
    
    
    func showCameraPermissionAlert() {
        showAlert(message: "Please allow mCAS application to access camera in privacy settings.")
    }
    
    func showPhotosPermissionAlert() {
        showAlert(message: "Please allow mCAS application to access photos in privacy settings.")
    }
    
    func showOfflineAlert() {
        showAlert(message: "This functionality is not available in offline mode. Please try when internet is working")
    }
    
    func showAlertForInvalidSession()
    {
        if (AppDelegate.instance.isLoggedin)
        {
            showAlert(title: NSLocalizedString("INVALID SESSION", comment: ""), message: NSLocalizedString("Your session has been expired. Kindly login again.", comment: ""), okAction: { _ in
                AppDelegate.instance.presentLoginViewController()
            })
        }
    }
    
}
