//
//  CommonUtils.swift
//  mCAS
//
//  Created by Mac on 06/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import Foundation

class CommonUtils: NSObject {
    
    private static var instance: CommonUtils?
    
    static func shared() -> CommonUtils{
        if instance == nil {
            instance = CommonUtils()
        }
        return instance!
    }
    
    func JSONtoData(jsonObject: [String: AnyObject], completion: (_ data: Data) -> Void) {
        do {
            let data = try JSONSerialization.data(withJSONObject: jsonObject, options: [])
            completion(data)
        }
        catch { debugPrint(error) }
    }
    
    func dataToJSON(data: Data, completion: (_ json: AnyObject) -> Void) {
        do {
            let nsJSON = try JSONSerialization.jsonObject(with: data, options: [])
            completion(nsJSON as AnyObject)
        }
        catch { debugPrint(error) }
    }
    
    func JSONToString(jsonObject: Any) -> String{
        do {
            let data =  try JSONSerialization.data(withJSONObject: jsonObject, options: .fragmentsAllowed)
            return String(data: data, encoding: String.Encoding.utf8) ?? ""
        }
        catch { return "" }
    }
    
    func JSONtoModel<T>(jsonObject: Any, type: T.Type, completion: (_ list: T) -> Void) where T : Decodable {
        do {
            let jsonData = try JSONSerialization.data(withJSONObject:jsonObject, options:[])
            let list = try JSONDecoder().decode(type.self, from: jsonData)
            completion(list)
        }
        catch { debugPrint(error) }
    }
    
    func modelToData<T: Encodable>(_ object: T, completion: (_ data: Data) -> Void) {
        do {
            let data = try JSONEncoder().encode(object)
            completion(data)
        }
        catch { debugPrint(error) }
    }
    
    func dataToModel<T: Decodable>(data: Data, type: T.Type, completion: (_ type: T) -> Void) {
        do {
            let model = try JSONDecoder().decode(type, from: data)
            completion(model)
        }
        catch { debugPrint(error) }
    }

    
    func checkForReachabilityMode() -> Bool {
        if !ReachabilityManager.isReachable() {
            CommonAlert.shared().showOfflineAlert()
            return false
        }
        return true
    }
    
    func saveData(value: Any, key: String) {
        UserDefaults.standard.setSecretObject(value, forKey: key)
    }
    
    func getDataFromSecretUserDefault(key: String) -> Any? {
        return UserDefaults.standard.secretObject(forKey: key)
    }
    
    func getIconFor(productTypeCode: String) -> String {
        switch productTypeCode {
        case ConstantCodes.PRODUCT_TYPE_CON_VEH:
            return "loan_icon_auto"
        case ConstantCodes.PRODUCT_TYPE_PF:
            return "loan_icon_personal"
        case ConstantCodes.PRODUCT_TYPE_CL:
            return "loan_icon_auto"
        case ConstantCodes.PRODUCT_TYPE_HL:
            return "loan_icon_home"
        case ConstantCodes.PRODUCT_TYPE_LAP:
            return "loan_icon_auto"
        case ConstantCodes.PRODUCT_TYPE_CC:
            return "loan_icon_creditcard"
        case ConstantCodes.PRODUCT_TYPE_CV:
            return "loan_icon_auto"
        case ConstantCodes.PRODUCT_TYPE_EQUIPMNT:
            return "loan_icon_auto"
        case ConstantCodes.PRODUCT_TYPE_MHL:
            return "loan_icon_auto"
        case ConstantCodes.PRODUCT_TYPE_FE:
            return "loan_icon_auto"
        case ConstantCodes.PRODUCT_TYPE_EDU:
            return "loan_icon_education"
        case ConstantCodes.PRODUCT_TYPE_AGRL:
            return "loan_icon_agriculture"
        case ConstantCodes.PRODUCT_TYPE_KCC:
            return "loan_icon_creditcard"
        default:
            return "loan_icon_auto"
        }
    }
    
    func fetchFromDateAndToDateForDayFilter(from: String, to: String, selectedDay: DAYFILTER) -> (String, String) {
        
        var fromDate = ""
        var toDate = ""
        
        if selectedDay == .Range {
            fromDate = CustomDateFormatter.shared().getFormatedDateStringFromString(inputString: from, outputFormat: Constants.DATE_FORMAT_SERVICE)
            toDate = CustomDateFormatter.shared().getFormatedDateStringFromString(inputString: to, outputFormat: Constants.DATE_FORMAT_SERVICE)
        }
        else {
            var dayDiff: Double = 7
            
            switch selectedDay {
            case .FifteenDay:
                dayDiff = 15
            case .ThirtyDay:
                dayDiff = 30
            default:
                dayDiff = 7
            }
            
            toDate = Date().getFormatedDateString(outputFormat: Constants.DATE_FORMAT_SERVICE)
            fromDate = Date().addingTimeInterval(-dayDiff*24*60*60).getFormatedDateString(outputFormat: Constants.DATE_FORMAT_SERVICE)
        }
        
        return (fromDate, toDate)
    }
    
    func makingDynamicFormFields() -> UIView {
        
        return UIView()
    }
    
//    func calculateCellTextHeight(text: String, rect: CGSize, font: UIFont, height: Float) -> Float {
//        var frame: CGRect? = nil
//        
//        frame = text.boundingRect(with: rect, options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: [
//            NSAttributedString.Key.font: font], context: nil)
//        
//        return Float(max(frame!.size.height, CGFloat(height)))
//    }
//    
//    func textfieldIsEmpty(textField: UITextField?) -> Bool {
//        var text = textField?.text
//        text = text?.trimmingCharacters(in: CharacterSet.whitespaces)
//        if (text?.count ?? 0) == 0 {
//            return true
//        }
//        return false
//    }
//    
//    func isApplicationLanguageArabic() -> Bool {
//        return NSLocale.preferredLanguages[0].hasPrefix("ar")
//    }
//    
//    func setLOVButtonProperties(lovButton: UIButton, dropDownImage: UIImage) {
//        
//        lovButton.setTitle(Constants.LOV_DEFAULT_TITLE, for: .normal)
//        lovButton.backgroundColor = .clear
//        lovButton.contentHorizontalAlignment = .left
//        lovButton.setTitleColor(UIColor.black, for: .normal)
//        lovButton.setTitleColor(.lightGray, for: .disabled)
//        lovButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(15)
//        lovButton.titleEdgeInsets = UIEdgeInsets(top: 0, left: 8, bottom: 0, right: 0)
//        lovButton.setBackgroundImage(dropDownImage, for: .normal)
//        
//    }
//    
//    func setFormTextFieldProperties(textField: UITextField, rowType: String, placeholderText: String, isRowDisabled: String) {
//        
//        textField.borderStyle = .roundedRect
//        textField.font = CustomFont.shared().GETFONT_REGULAR(15)
//        textField.textColor = .black
//        textField.autocorrectionType = .no
//        textField.returnKeyType = .default
//        textField.contentVerticalAlignment = .center
//        textField.placeholder = placeholderText
//        
//        if rowType == Constants.FIELD_TYPE_NUMBER {
//            textField.keyboardType = .numberPad
//        }
//        else if rowType == Constants.FIELD_TYPE_DECIMAL {
//            textField.keyboardType = .decimalPad
//        }
//        else {
//            textField.keyboardType = .default
//        }
//        
//        if isRowDisabled == "Y" {
//            textField.textColor = .lightGray
//            textField.isEnabled = false
//        }
//    }
//    
//    func setFormMandatoryLabelProperties(mandatoryLabel: UILabel, isRowRequired: String) {
//        
//        mandatoryLabel.font = CustomFont.shared().GETFONT_REGULAR(15)
//        mandatoryLabel.numberOfLines = 1
//        mandatoryLabel.baselineAdjustment = .alignBaselines
//        mandatoryLabel.adjustsFontSizeToFitWidth = true
//        mandatoryLabel.minimumScaleFactor = 10.0/12.0
//        mandatoryLabel.clipsToBounds = true
//        mandatoryLabel.backgroundColor = .clear
//        mandatoryLabel.textColor = .red
//        if isRowRequired == "Y" {
//            mandatoryLabel.text = "*"
//        }
//        else {
//            mandatoryLabel.text = ""
//        }
//        
//    }
//    
//    func setFormTitleLabelProperties(titleLabel: UILabel, title: String) {
//        
//        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(15)
//        titleLabel.numberOfLines = 1
//        titleLabel.baselineAdjustment = .alignBaselines
//        titleLabel.adjustsFontSizeToFitWidth = true
//        titleLabel.minimumScaleFactor = 10.0/12.0
//        titleLabel.clipsToBounds = true
//        titleLabel.backgroundColor = .clear
//        titleLabel.textColor = .black
//        titleLabel.text = title
//    }
//    
//    func setMandatoryRedStarOnLabel(lbl: UILabel) {
//        
//        let selectedString = NSMutableAttributedString(string: lbl.text!)
//        selectedString.addAttributes([.foregroundColor: UIColor.red,], range: NSRange(location: selectedString.length - 1, length: 1))
//        lbl.attributedText = selectedString
//    }
//    
//    func setButtonProperties(btn: UIButton) {
//        btn.layer.cornerRadius = 3
//        btn.layer.borderWidth = 1
//        btn.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(18)
//        btn.setTitleColor(.white, for: .normal)
//        btn.layer.borderColor = UIColor.clear.cgColor
//        btn.backgroundColor = Color.BLUE
//    }
}
