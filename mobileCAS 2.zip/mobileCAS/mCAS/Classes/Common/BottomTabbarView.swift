//
//  BottomTabbarView.swift
//  mCAS
//
//  Created by Mac on 19/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class BottomTabbarView: UIView, TabMenuButtonDelegate {
    
    private var lastSelectedTab: TabMenuButton!
    private var tabsArray: [TabMenuButton] = []
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let tabsData = [
            UserRoles.HOME_DASHBOARD    : ButtonModel(buttonText: "Home", buttonID: UserRoles.HOME_DASHBOARD, buttonImage: "tab_icon_home", order: 1),
            UserRoles.SOURCING          : ButtonModel(buttonText: "Applications", buttonID: UserRoles.SOURCING, buttonImage: "tab_icon_applications", order: 2),
            UserRoles.CAPTURE_LEAD      : ButtonModel(buttonText: "Leads", buttonID: UserRoles.VIEW_LEAD, buttonImage: "tab_icon_leads", order: 3),
            UserRoles.FIELD_VERIFY      : ButtonModel(buttonText: "FI", buttonID: UserRoles.FIELD_VERIFY, buttonImage: "tab_icon_fi", order: 4),
            UserRoles.MORE              : ButtonModel(buttonText: "More", buttonID: UserRoles.MORE, buttonImage: "tab_icon_more_options", order: 5),
//            UserRoles.QUERY_MODULE     : ButtonModel(buttonText: "Query", buttonID: UserRoles.QUERY_MODULE, buttonImage: "tab_icon_reports", order: 6),
            UserRoles.STATUS_ENQUIRY    : ButtonModel(buttonText: "File Status", buttonID: UserRoles.STATUS_ENQUIRY, buttonImage: "tab_icon_reports", order: 6),
            UserRoles.CALC              : ButtonModel(buttonText: "EMI Calculator", buttonID: UserRoles.CALC, buttonImage: "tab_icon_emi_calculator", order: 7),
            UserRoles.RATE_INITIATION   : ButtonModel(buttonText: "Rate Initiation", buttonID: UserRoles.RATE_INITIATION, buttonImage: "tab_icon_status_enquiry", order: 8),
            UserRoles.RATE_APPROVAL     : ButtonModel(buttonText: "Rate Approval", buttonID: UserRoles.RATE_APPROVAL, buttonImage: "tab_icon_status_enquiry", order: 9),
            UserRoles.EXISTING_LOANS    : ButtonModel(buttonText: "Loan Enquiry", buttonID: UserRoles.EXISTING_LOANS, buttonImage: "tab_icon_loan_enquiry", order: 10),
            UserRoles.CHANGE_PASSWORD   : ButtonModel(buttonText: "Change Password", buttonID: UserRoles.CHANGE_PASSWORD, buttonImage: "tab_icon_change_password", order: 11)]
        
        AppDelegate.instance.mainMenuArray = []
        AppDelegate.instance.mainMenuArray.append(contentsOf: getTabs(tabsData: tabsData))
        
        var width = frame.size.width/Constants.bottomTabsCount
        let tabcount = AppDelegate.instance.mainMenuArray.count
        
        if tabcount < Int(Constants.bottomTabsCount) {
            width = frame.size.width/CGFloat(tabcount)
        }
        
        let lineView = UIView(frame: CGRect(x: 0, y: 0, width: self.frame.size.width, height: 0.5))
        
        for (index, btnModel) in AppDelegate.instance.mainMenuArray.enumerated()
        {
            if index < Int(Constants.bottomTabsCount)
            {
                let yCord = lineView.frame.size.height
                let height = self.frame.size.height - yCord - AppDelegate.instance.getBottomPadding()
                
                let frame = CGRect(x: CGFloat((Float(width))*(Float(index))), y: yCord, width: width, height: height)
                
                let tabButton = TabMenuButton(frame: frame, btnModel: btnModel, delegate: self)
                self.addSubview(tabButton)
                self.tabsArray.append(tabButton)
                
                if index == 0 {
                    self.lastSelectedTab = tabButton
                }
            }
        }
        
        if self.lastSelectedTab != nil {
            self.backgroundColor = .white
            
            lineView.backgroundColor = .lightGray
            self.addSubview(lineView)
            
            AppDelegate.instance.createHeaderView()
            self.lastSelectedTab.tabButtonAction()
        }
        else {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Please login first in GPRS zone to validate login credentials.", comment: ""))
        }
    }
    
    private func getTabs(tabsData: [String: ButtonModel]) -> [ButtonModel] {
        var tabsArray: [ButtonModel] = []
        
        if let userData = AppDelegate.instance.currentLoggedInUser
        {
            if let rolesInDB = userData.getUserRoles()
            {
                for role in rolesInDB
                {
                    if var roleID = role.roleID
                    {
                        if roleID == UserRoles.RATE_RECOMMEND { roleID = UserRoles.RATE_APPROVAL }
                        
                        if let btnModel = tabsData[roleID] {
                            let arr = tabsArray.filter{($0.buttonID == btnModel.buttonID)}
                            if arr.isEmpty {
                                tabsArray.append(btnModel)
                            }
                        }
                    }
                }
            }
        }
        
        tabsArray.insert(tabsData[UserRoles.HOME_DASHBOARD]!, at: 0)
        tabsArray.append(tabsData[UserRoles.CHANGE_PASSWORD]!)
        
        tabsArray.sort { $0.order < $1.order }
        
        if tabsArray.count > Int(Constants.bottomTabsCount) {
            tabsArray.insert(tabsData[UserRoles.MORE]!, at: Int(Constants.bottomTabsCount)-1)
        }
        
        return tabsArray
    }
    
    func changeTabButtonSelection(id: String) {
        if let tabButton = self.tabsArray.first(where: { $0.btnModel.buttonID == id }) {
            if let lastTab = self.lastSelectedTab {
                lastTab.isSelected = false
            }
            
            tabButton.isSelected = true
            self.lastSelectedTab = tabButton
        }
    }
}
