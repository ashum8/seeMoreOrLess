//
//  CustomNoDataView.swift
//  mCAS
//
//  Created by iMac on 06/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class CustomNoDataView: UIView {

    @IBOutlet var containerView: UIView!
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var titleLabel: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("CustomNoDataView", owner: self, options: nil)
        containerView.fixInView(self)
    }
    
    func setProperties(title: String? = "No Data Captured", image: String? = "no_lead_icon") {
        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(19)
        titleLabel.text = title!
        imageView.image = UIImage(named: image!)
    }
}
