//
//  CustomMobileNumberView.swift
//  mCAS
//
//  Created by iMac on 22/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class CustomMobileNumberView: UIView {
    @IBOutlet weak var countryCodeLOV: LOVFieldView!
    @IBOutlet weak var mobileNoTFView: CustomTextFieldView!
    @IBOutlet var containerView: UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("CustomMobileNumberView", owner: self, options: nil)
        containerView.fixInView(self)
    }
    
    func setProperties(tag:Int, delegate: SelectedLOVDelegate) {
        
        mobileNoTFView.setProperties(placeHolder: "Mobile Number", type: .Mobile)
        
        countryCodeLOV.setLOVProperties(masterName: Entity.PHONE_COUNTRYCODE, title: "Country Code", tag: tag, autoFillValue: Constants.DEFAULT_COUNTRY_CODE, delegate: delegate)
    }
}

