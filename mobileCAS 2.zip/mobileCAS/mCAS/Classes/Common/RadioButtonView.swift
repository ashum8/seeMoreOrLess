//
//  RadioButtonView.swift
//  mCAS
//
//  Created by iMac on 20/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

protocol RadioButtonDelegate {
    func selectedRadioButton(view: RadioButtonView)
}

class RadioButtonView: UIView {
    
    @IBOutlet var customContainerVw: UIView!
    @IBOutlet weak var radioButton: UIButton!
    @IBOutlet weak var titleLabel: UILabel!
    
    private var delegate:RadioButtonDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("RadioButtonView", owner: self, options: nil)
        customContainerVw.fixInView(self)
        self.layer.masksToBounds = true
    }
    
    func setProperties(title: String, delegate: RadioButtonDelegate) {
        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        titleLabel.text = title
        self.delegate = delegate
    }
    
    func setButtonState(isSelected: Bool) {
        radioButton.isSelected = isSelected
    }
    
    @IBAction func radioButtonAction(_ sender: UIButton) {
        
        delegate?.selectedRadioButton(view: self)
    }
}
