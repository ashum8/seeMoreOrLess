//
//  swift
//  mCAS
//
//  Created by Mac on 31/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import Foundation

struct PageInfo: Codable {
    let requestPageSize: Int
    let responseStartIndex: Int
}

struct LoanType {
    var code = ""
    var name = ""
    var normalIcon = ""
    var activeIcon = ""
    var isSelectedFlag = false
    
    init(code: String, name: String) {
        self.code = code
        self.name = name
        self.normalIcon = CommonUtils.shared().getIconFor(productTypeCode: code)
        self.activeIcon = "\(normalIcon)_active"
    }
}

struct MenuModel {
    var title: String!
    var menuID: String!
    var imageName: String!
    var visible: Bool!
    
    init(title: String, menuID: String, imageName: String? = nil, visible: Bool? = false) {
        self.title = title
        self.menuID = menuID
        self.imageName = imageName
        self.visible = visible
    }
}

struct ButtonModel {
    
    var buttonText: String!
    var buttonID: String!
    var buttonImage: String!
    var activeIcon: String!
    var mediumIcon: String!
    var order: Int!
    
    init(buttonText: String?, buttonID: String?, buttonImage: String?, order: Int?) {
        self.buttonText = buttonText
        self.buttonID = buttonID
        self.buttonImage = buttonImage
        self.order = order
        self.mediumIcon = buttonImage?.appendingFormat("%-12@","_medium")
        self.activeIcon = buttonImage?.appendingFormat("%-12@","_active")
    }
}

struct KeyValueModel {
    var fieldName: String
    var fieldValue: String
    var isStatus: Bool = false
    var isHeading: Bool = false
}

class DropDown: NSObject, NSCopying {
    var id: String!
    var code: String!
    var name: String!
    var parentKey: String!
    var displayValue: String!
    var isSelectedFlag: Bool!
    
    init(id: String? = "", code: String, name: String, parentKey: String? = "", displayValue: String? = nil, isSelectedFlag: Bool? = false) {
        self.id = id!
        self.code = code
        self.name = name
        self.parentKey = parentKey!
        self.isSelectedFlag = isSelectedFlag!
        
        if let displayValue = displayValue {
            self.displayValue = displayValue
        }
        else {
            self.displayValue = name
        }
    }
    
    func copy(with zone: NSZone? = nil) -> Any {
        return DropDown(id: id, code: code, name: name, parentKey: parentKey, displayValue: displayValue, isSelectedFlag: isSelectedFlag)
    }
}

enum DAYFILTER: String {
    case SevenDay = "7 Days"
    case FifteenDay = "15 Days"
    case ThirtyDay = "30 Days"
    case Range = "Change Range"
}

