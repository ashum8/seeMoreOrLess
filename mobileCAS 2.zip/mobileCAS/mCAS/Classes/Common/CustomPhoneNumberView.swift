//
//  CustomPhoneNumberView.swift
//  mCAS
//
//  Created by iMac on 22/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class CustomPhoneNumberView: UIView {
    @IBOutlet weak var countryCodeLOV: LOVFieldView!
    @IBOutlet weak var stdCodeView: CustomTextFieldView!
    @IBOutlet weak var phoneNumberTFView: CustomTextFieldView!
    @IBOutlet var containerView: UIView!
    
    private let TAG_STD_CODE = 1001
    private let TAG_PHONE_NUMER = 1002
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("CustomPhoneNumberView", owner: self, options: nil)
        containerView.fixInView(self)
    }
    
    func setProperties(tag: Int, delegate: SelectedLOVDelegate) {
        stdCodeView.setProperties(placeHolder: "STD Code",type: .Number, delegate: self, tag: TAG_STD_CODE)
        phoneNumberTFView.setProperties(placeHolder: "Phone Number", type: .Number, delegate: self, tag: TAG_PHONE_NUMER)
        
        countryCodeLOV.setLOVProperties(masterName: Entity.PHONE_COUNTRYCODE, title: "Country Code", tag: tag, autoFillValue: Constants.DEFAULT_COUNTRY_CODE, delegate: delegate)
    }
}

extension CustomPhoneNumberView: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        print(btntag)
    }
}

extension CustomPhoneNumberView: CustomTFViewDelegate {
    func validateFields() {
        
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        switch tag {
        case TAG_PHONE_NUMER:
            return text.count <= 6
            
        case TAG_STD_CODE:
            return text.count <= 4
            
        default:
            return true
        }
    }
}
