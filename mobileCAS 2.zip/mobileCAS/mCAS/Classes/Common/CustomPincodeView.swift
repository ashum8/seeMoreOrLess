//
//  CustomPincodeView.swift
//  mCAS
//
//  Created by iMac on 05/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class CustomPincodeView: UIView {
    @IBOutlet var containerView: UIView!
    @IBOutlet weak var textField: JVFloatLabeledTextField!
    @IBOutlet weak var searchButton: UIButton!
    @IBOutlet weak var textFieldView: UIView!
    
    private var arrList = [DropDown]()
    private var cityCode: String!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("CustomPincodeView", owner: self, options: nil)
        containerView.fixInView(self)
    }
    
    func setProperties(city: String? = "") {
        
        textFieldView.setTextFieldViewProperties()
        textField.placeholder = "Pincode"
        textField.text = ""
        textField.delegate = self
        textField.keyboardType = .numberPad
        self.cityCode = city
        
        arrList.removeAll()
    }
    
    func getFieldValue() -> String {
        return textField.text!
    }
    
    func setFieldValue(text: String? = "") {
        textField.text = text
    }
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        
        if cityCode.isEmpty {
            CommonAlert.shared().showAlert(message: "Please select city first.")
            return
        }
        
        let param = ["city" : cityCode]
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_PINCODE_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [[String: Any]]
            {
                self.arrList = response.map {
                    if let code = $0["code"] as? String, let name = $0["name"] as? String {
                       return DropDown(code: code, name: name, displayValue: "\(name) (\(code))")
                    }
                    return DropDown(code: "", name: "")
                }

                self.moveToLOVList()
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
            
        })
    }
    
    private func moveToLOVList() {
        DispatchQueue.main.async {
            let storyboard = UIStoryboard.init(name: Storyboard.LOV_LIST, bundle: nil)
            
            if let vc = storyboard.instantiateViewController(withIdentifier: "LOVListVC") as? LOVListVC {
                vc.setData(dropDownList: self.arrList, delegate: self, title: "Pincode")
                AppDelegate.instance.applicationNavController.pushViewController(vc, animated: true)
            }
        }
    }
}

extension CustomPincodeView: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textFieldView.layer.borderColor = Color.BLUE.cgColor
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        textFieldView.layer.borderColor = UIColor.lightGray.cgColor
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let stringValue = (textField.text ?? "") + string
        
        return stringValue.isNumeric && stringValue.count <= 6
        
    }
}

extension CustomPincodeView: LOVListDelegate {
    
    func selectedLOV(selectedObj: DropDown) {
        textField.text = selectedObj.code
    }
    
}
