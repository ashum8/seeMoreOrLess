//
//  StepsHeaderView.swift
//  mCAS
//
//  Created by iss on 26/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


class StepsHeaderView: UIView {
    private var titleLabel: UILabel!
    private var landingVC: UIViewController?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let view: UIView = UIView(frame: CGRect(x: 0, y: 0, width: self.frame.size.width, height: self.frame.size.height))
        view.backgroundColor = Color.BLUE
        self.addSubview(view)
        
        let yCord = AppDelegate.instance.getTopPadding()
        let buttonWidth = view.frame.size.height-yCord
        let margin: CGFloat = 5
        
        let closeButton = UIButton(frame: CGRect(x:  view.frame.size.width - (buttonWidth+margin), y: yCord, width: buttonWidth, height: buttonWidth))
        closeButton.setImage(UIImage(named: "close_white_icon"), for: .normal)
        closeButton.addTarget(self, action:#selector(closeButtonAction(_:)), for: .touchUpInside)
        view.addSubview(closeButton)
        
        let xCord: CGFloat = 10
        
        titleLabel = UILabel(frame: CGRect(x: xCord, y: yCord, width: closeButton.frame.origin.x-xCord-margin, height: buttonWidth))
        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(19)
        titleLabel.textColor = .white
        view.addSubview(titleLabel)
    }
    
    func setData(isHide: Bool, title: String, step: String, landingPage: UIViewController? = nil) {
        
        self.isHidden = isHide
        
        if !isHide, let vc = landingPage {
            //In case of flow start - set the landing page so that on each step of flow we don't need to set landing page
            self.landingVC = vc
        }
        
        let text = title + " " + step
        let range = (text as NSString).range(of: step, options: .caseInsensitive)
        
        let myMutableString = NSMutableAttributedString(string: text)
        myMutableString.addAttribute(NSAttributedString.Key.font, value: CustomFont.shared().GETFONT_REGULAR(13) as UIFont, range: range)
        myMutableString.addAttribute(NSAttributedString.Key.foregroundColor, value: Color.LIGHTER_BLUE, range: range)
        titleLabel.attributedText = myMutableString
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func closeButtonAction(_ sender: Any) {
        
        CommonAlert.shared().showAlert(title: "Exit Process", message: "Do you really want to exit this process? If yes, you will discard your entered details.", okTitle: "Yes", cancelTitle: "No", dismissTitle: nil, okAction: { _ in
            
            self.navigateToFlow(landingPage: self.landingVC)
        })
    }
    
    func navigateToFlow(landingPage: UIViewController? = nil) {
        self.isHidden = true
        self.landingVC = nil
        
        let navArray = AppDelegate.instance.applicationNavController.viewControllers.reversed()
        
        for controller in navArray {
            if let vc = landingPage, controller == vc {
                AppDelegate.instance.applicationNavController.popToViewController(vc, animated: false)
                break
            }
            else if controller.isKind(of: DashboardViewController.self) {
                AppDelegate.instance.applicationNavController.popToViewController(controller, animated: false)
                break
            }
        }
    }
}
