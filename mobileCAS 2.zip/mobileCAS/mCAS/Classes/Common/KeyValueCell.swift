//
//  KeyValueCell.swift
//  mCAS
//
//  Created by Mac on 27/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class KeyValueCell: UITableViewCell {
    
    @IBOutlet weak var keyLabel: UILabel!
    @IBOutlet weak var valueLabel: EdgeInsetLabel!
    @IBOutlet weak var keyLabelWidth: NSLayoutConstraint!
    @IBOutlet weak var separatorView: UIView!
    
    func setProperties(key: String, value: String, showStatus: Bool = false, showHeading: Bool = false) {
        self.backgroundColor = .clear
        self.contentView.backgroundColor = .clear
        self.selectionStyle = .none
        
        self.keyLabel.textColor = .gray
        self.valueLabel.textColor = .black
        
        self.keyLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        self.valueLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        
        if showStatus {
            self.valueLabel.setStatusLabelProperties(borderColor: .green)
        }
        else {
            self.valueLabel.layer.sublayers?.removeAll()
            self.valueLabel.backgroundColor = .clear
        }
        
        if showHeading {
            keyLabelWidth = keyLabelWidth.changeMultiplier(multiplier: 0.0)
            self.valueLabel.font = CustomFont.shared().GETFONT_MEDIUM(18)
	    separatorView.backgroundColor = Color.LIGHTER_GRAY
        }
        else {
            keyLabelWidth = keyLabelWidth.changeMultiplier(multiplier: 0.4)
            self.valueLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
            separatorView.backgroundColor = .clear
        }
        
        
        keyLabel.text = key
        valueLabel.text = value
    }
}
