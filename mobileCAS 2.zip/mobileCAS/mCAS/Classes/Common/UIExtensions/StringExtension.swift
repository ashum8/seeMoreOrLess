//
//  AttributedStringExtension.swift
//  mCAS
//
//  Created by Mac on 29/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation

extension NSMutableAttributedString {
    
    @discardableResult func attributedText(_ text: String, color: UIColor = .black, font: UIFont = CustomFont.shared().GETFONT_REGULAR(16)) -> NSMutableAttributedString {
        let attrs: [NSAttributedString.Key: Any] = [.foregroundColor: color, .font: font]
        let boldString = NSMutableAttributedString(string:text, attributes: attrs)
        append(boldString)
        return self
    }
    
    func getLOVAttributedText(line1: String, line2: String) -> NSMutableAttributedString {
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.minimumLineHeight = 28
        
        var attrs: [NSAttributedString.Key: Any] = [.font: CustomFont.shared().GETFONT_REGULAR(14), .foregroundColor: UIColor.gray]
        var normalString = NSMutableAttributedString(string:"\(line1)\n", attributes: attrs)
        self.append(normalString)
        
        attrs = [.font: CustomFont.shared().GETFONT_REGULAR(19), .foregroundColor: UIColor.darkGray, NSAttributedString.Key.paragraphStyle: paragraphStyle]
        normalString = NSMutableAttributedString(string:"\(line2)", attributes: attrs)
        self.append(normalString)
        
        return self
    }
}

extension NSAttributedString {
    
    func widthOfString() -> CGFloat {
        return self.size().width
    }
}

extension String {
    
    func isBetweenDate(startDate:String, endDate:String)->Bool
    {
        if let date = CustomDateFormatter.shared().getRespectiveDateFromString(inputString: self), let start = CustomDateFormatter.shared().getRespectiveDateFromString(inputString: startDate), let end = CustomDateFormatter.shared().getRespectiveDateFromString(inputString: endDate)
        {
            return date.isBetween(startDate: start, endDate: end)
        }
        else {
            return false
        }
    }
    
    func widthOfString(usingFont font: UIFont) -> CGFloat {
        let fontAttributes = [NSAttributedString.Key.font: font]
        let size = self.size(withAttributes: fontAttributes)
        return size.width
    }
    
    func heightOfStringWithWidth(width: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingBox = self.boundingRect(with: constraintRect, options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: [NSAttributedString.Key.font: font], context: nil)
        return boundingBox.height
    }
    
    
    var isValidPhone: Bool {
        let phone = NSPredicate(format:"SELF MATCHES %@", "^[6-9]\\d{9}$")
        return phone.evaluate(with: self)
    }
    
    var isValidEmail: Bool {
        let email = NSPredicate(format:"SELF MATCHES %@", "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}")
        return email.evaluate(with: self)
    }
    
    var isNumeric: Bool {
        let allowedCharacters = CharacterSet(charactersIn:"0123456789")
        let characterSet = CharacterSet(charactersIn: self)
        return allowedCharacters.isSuperset(of: characterSet)
    }
    
    func validateStringWithRegex(regx: String) ->Bool {
        do {
            let regex = try NSRegularExpression(pattern: regx, options: .caseInsensitive)
            let matches = regex.numberOfMatches(in: self, options: [], range: NSRange(location: 0, length: self.count))
            return matches > 0
        }
        catch {
            return false
        }
    }
    
    var validateName: Bool {
        let str = NSPredicate(format:"SELF MATCHES %@", "^[a-zA-Z .]{1,100}$")
        return str.evaluate(with: self)
    }
    
    var validateAmountString: Bool {
        let str = NSPredicate(format:"SELF MATCHES %@", "^[0-9]*((\\.|,)[0-9]{0,2})?$")
        return str.evaluate(with: self)
    }
    
    var getReverseString: String {
        return String(self.reversed())
    }
    
    var formatCurrency: String {
        
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencySymbol = Constants.CURRENCY_SYMBOL
        
        if let number = Double(self) {
            return formatter.string(from: number as NSNumber) ?? ""
        }
        return ""
    }
    
    var isUrl: Bool {
        return self.validateStringWithRegex(regx: "https?:\\/\\/[\\S]+")
    }
    
    func isMinLength(length: Int)-> Bool {
        return self.count >= length
    }
    
    func isMaxLength(length: Int)-> Bool {
        return self.count <= length
    }
    
    func isMinLength(min: Int, max: Int)-> Bool {
        return isMinLength(length: min) && isMaxLength(length: max)
    }
    
    var isAlphanumeric: Bool {
        return self.validateStringWithRegex(regx: "^[a-zA-Z0-9]*$")
    }
    
    var validatePAN: Bool {
        return self.validateStringWithRegex(regx: "^[A-Za-z]{5}[0-9]{4}[A-Za-z]$")
    }
    
    var validateTAN: Bool {
        return self.validateStringWithRegex(regx: "^[A-Z]{4}[0-9]{5}[A-Z]$")
    }
    
    var isCapsAlphabetic: Bool {
        return self.validateStringWithRegex(regx: "^[A-Z ]*$")
    }
    
    var isAlphabetic: Bool {
        return self.validateStringWithRegex(regx: "^[a-zA-Z]*$")
    }
    
    var isAlphabeticAndSpace: Bool {
        return self.validateStringWithRegex(regx: "^[a-zA-Z ]*$")
    }
    
    //Note - If you want to allow - put it in last as it represents range while used in middle
    var isCharSpecial: Bool {
        return self.validateStringWithRegex(regx: "^[a-zA-Z ,/()@*^%$#.!_=+{}\\[]:;'?&amp;-]*$")
    }
    
    var isAlphanumericAndSpace: Bool {
        return self.validateStringWithRegex(regx: "^[a-zA-Z0-9 ]*$")
    }
    
    var isAlphanumericSpecial: Bool {
        return self.validateStringWithRegex(regx: "^[\\ _.a-zA-Z0-9-]*$")
    }
    
    var hasBothCases: Bool {
        return self.validateStringWithRegex(regx: "^.*(?=.*?[a-z])(?=.*?[A-Z]).+$")
    }
    
    var isPhoneNumber: Bool {
        let types: NSTextCheckingResult.CheckingType = [.phoneNumber]
        do {
            let detector = try NSDataDetector(types: types.rawValue)
            
            return detector.numberOfMatches(in: self, options: [], range: NSRange(location: 0, length: self.count)) > 0
        }
        catch {
            return false
        }
    }
    
    var isDigit: Bool {
        let alphaNums = CharacterSet.decimalDigits
        let inStringSet = CharacterSet.init(charactersIn: self)
        return alphaNums.isSuperset(of: inStringSet)
    }
    
    var formatString: String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.groupingSeparator = NSLocale.current.groupingSeparator
        formatter.groupingSize = 3
        formatter.alwaysShowsDecimalSeparator = false
        formatter.usesGroupingSeparator = true
        
        if let number = Double(self) {
            return formatter.string(from: number as NSNumber) ?? ""
        }
        return ""
    }
}


