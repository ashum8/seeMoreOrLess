//
//  ImageExtension.swift
//  mCAS
//
//  Created by Mac on 21/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation

extension UIView {
    class func fromNib<T: UIView>() -> T {
        return Bundle.main.loadNibNamed(String(describing: T.self), owner: nil, options: nil)![0] as! T
    }
    
    func fixInView(_ container: UIView!) -> Void {
        self.translatesAutoresizingMaskIntoConstraints = false
        self.frame = container.frame
        container.addSubview(self)
        NSLayoutConstraint(item: self, attribute: .leading, relatedBy: .equal, toItem: container, attribute: .leading, multiplier: 1.0, constant: 0).isActive = true
        NSLayoutConstraint(item: self, attribute: .trailing, relatedBy: .equal, toItem: container, attribute: .trailing, multiplier: 1.0, constant: 0).isActive = true
        NSLayoutConstraint(item: self, attribute: .top, relatedBy: .equal, toItem: container, attribute: .top, multiplier: 1.0, constant: 0).isActive = true
        NSLayoutConstraint(item: self, attribute: .bottom, relatedBy: .equal, toItem: container, attribute: .bottom, multiplier: 1.0, constant: 0).isActive = true
    }
    
    func fadeInOut(duration: TimeInterval = 0.45, alpha: CGFloat) {
        UIView.animate(withDuration: duration, animations: {
            self.alpha = alpha
        })
    }
    
    func setShadow() {
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOpacity = 0.5
        self.layer.shadowRadius = 3
        self.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
    }
    
    func setCornerRadius() {
        self.layer.cornerRadius = 3
    }
    
    func setMainViewProperties(borderColor: UIColor = .lightGray) {
        self.setCornerRadius()
        self.layer.borderWidth = 1
        self.layer.borderColor = borderColor.cgColor
    }
    
    func setTextFieldViewProperties(autoCapitalize: Bool = true) {
        self.setCornerRadius()
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor.lightGray.cgColor
        
        let tf = self.viewWithTag(100) as? UITextField
        tf?.font = CustomFont.shared().GETFONT_REGULAR(19)
        tf?.autocorrectionType = .no
        
        if autoCapitalize {
            tf?.autocapitalizationType = .allCharacters
        }
    }
    
    func removeAllConstraints() {
        var _superview = self.superview
        
        while let superview = _superview {
            for constraint in superview.constraints {
                
                if let first = constraint.firstItem as? UIView, first == self {
                    superview.removeConstraint(constraint)
                }
                
                if let second = constraint.secondItem as? UIView, second == self {
                    superview.removeConstraint(constraint)
                }
            }
            
            _superview = superview.superview
        }
        
        self.removeConstraints(self.constraints)
        self.translatesAutoresizingMaskIntoConstraints = true
    }
}

extension UIScrollView {
    func scrollToBottom(animated: Bool) {
        if self.contentSize.height < self.bounds.size.height { return }
        let bottomOffset = CGPoint(x: 0, y: self.contentSize.height - self.bounds.size.height)
        self.setContentOffset(bottomOffset, animated: animated)
    }
}

extension UISearchBar {
    
    func setProperties() {
        let textFieldInsideUISearchBar = self.value(forKey: "searchField") as? UITextField
        textFieldInsideUISearchBar?.font = CustomFont.shared().GETFONT_REGULAR(18)
        //textFieldInsideUISearchBar?.leftViewMode = .never
        
        let textFieldInsideUISearchBarLabel = textFieldInsideUISearchBar!.value(forKey: "placeholderLabel") as? UILabel
        textFieldInsideUISearchBarLabel?.font = CustomFont.shared().GETFONT_REGULAR(17)
    }
}

extension UITextView {
    
    func setRemarksTextView() {
        self.textColor = .darkGray
        self.font = CustomFont.shared().GETFONT_REGULAR(20)
    }
}

extension UIButton {
    
    func setAddButtonProperties() {
        self.layer.cornerRadius = 15
        self.layer.borderWidth = 1.0
        self.layer.borderColor = Color.BLUE.cgColor
        self.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(25)
        self.setTitleColor(Color.BLUE, for: .normal)
    }
    
    func setPlusButtonProperties() {
        self.layer.cornerRadius = 28
        self.backgroundColor = Color.BLUE
        self.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(48)
        self.setButtonShadow()
    }
    
    func setButtonShadow() {
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOpacity = 0.5
        self.layer.shadowRadius = 3
        self.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
    }
    
    func setEnableDisableButtonColor(isEnable: Bool) {
        self.isEnabled = isEnable
        self.backgroundColor = isEnabled ? Color.BLUE : .gray
    }
    
    func setCheckboxProperties(title: String, isSelected: Bool = false) {
        self.setImage(UIImage(named: "unchecked"), for: .normal)
        self.setImage(UIImage(named: "checked"), for: .selected)
        self.setTitleColor(.darkGray, for: .normal)
        self.setTitleColor(Color.BLUE, for: .selected)
        self.isSelected = isSelected
        self.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(17)
        self.titleLabel?.numberOfLines = 2
        self.imageEdgeInsets = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 0)
        self.titleEdgeInsets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 0)
        self.setTitle(title, for: .normal)
    }
    
    func setSelectedSegmentButtonProperties() {
        self.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(17)
        self.layer.cornerRadius = 1
        self.layer.borderWidth = 1
        self.layer.borderColor = Color.BLUE.cgColor
        self.isSelected = true
    }
    
    func resetSegmentButtonProperties() {
        self.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(17)
        self.layer.cornerRadius = 1
        self.layer.borderWidth = 0.5
        self.layer.borderColor = UIColor.lightGray.cgColor
        self.isSelected = false
    }
    
    func setButtonProperties() {
        self.setCornerRadius()
        self.layer.borderWidth = 1
        self.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(18)
        self.setTitleColor(.white, for: .normal)
        self.layer.borderColor = UIColor.clear.cgColor
        self.backgroundColor = Color.BLUE
    }
    
    func setBackButtonProperties() {
        self.setCornerRadius()
        self.layer.borderWidth = 1
        self.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(18)
        self.setTitleColor(Color.BLUE, for: .normal)
        self.layer.borderColor = Color.BLUE.cgColor
        self.backgroundColor = .white
    }
    
    func setButtonTextAndRightIcon(title: String, image: String) {
        self.setTitle(title, for: .normal)
        self.setImage(UIImage(named: image), for: .normal)
        self.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(17)
        self.semanticContentAttribute = .forceRightToLeft
    }
    
    func setLOVSelectedText(line1: String, line2: String) {
        self.setAttributedTitle(NSMutableAttributedString().getLOVAttributedText(line1: line1, line2: line2), for: .normal)
    }
    
    func setAlignmentOfButton(isTab: Bool) {
        // the space between the image and text
        var spacing: CGFloat = 2.0
        if !isTab {
            spacing = 10.0
        }
        
        // lower the text and push it left so it appears centered below the image
        let imageSize = self.imageView?.image?.size
        self.titleEdgeInsets = UIEdgeInsets(top: 0.0, left: -(imageSize?.width ?? 0.0), bottom: -((imageSize?.height ?? 0.0) + spacing), right: 0.0)
        
        // raise the image and push it right so it appears centered above the text
        var titleSize: CGSize? = nil
        if let font = self.titleLabel?.font {
            titleSize = self.titleLabel?.text?.size(withAttributes: [
                NSAttributedString.Key.font: font
            ])
        }
        self.imageEdgeInsets = UIEdgeInsets(top: -((titleSize?.height ?? 0.0) + spacing), left: 0.0, bottom: 0.0, right: -(titleSize?.width ?? 0.0))
    }
    
    func centerImageAndButton() {
        
        let imageSize = self.imageView?.frame.size
        let titleSize = self.titleLabel?.frame.size
        let spacing: CGFloat = 10.0
        
        let totalHeight = ((imageSize?.height ?? 0.00) + (titleSize?.height ?? 0.0) + spacing)
        
        self.imageEdgeInsets = UIEdgeInsets(top: -(totalHeight - (imageSize?.height ?? 0.0) - spacing), left: ((imageSize?.width ?? 0.0) / 2 + spacing), bottom: 0.0, right: -(titleSize?.width ?? 0.0))
        
        self.titleEdgeInsets = UIEdgeInsets(top: 0.0, left: -(imageSize?.width ?? 0.0), bottom: -(totalHeight - (titleSize?.height ?? 0.0)), right: 0.0)
    }
    
}

extension UILabel {
    
    func setMultiSelectLOVLabelProperties() {
        self.textColor = .darkGray
        self.font = CustomFont.shared().GETFONT_REGULAR(20)
    }
    
    func setRemarks(title: String) {
        self.text = title
        self.textColor = .darkGray
        self.font = CustomFont.shared().GETFONT_REGULAR(15)
    }
    
    func resetSingleSelectLOV(line1: String) {
        let line2 = "Select"
        self.attributedText = attributedString(from: "\(line1)\n\(line2)",
            range2: NSMakeRange(line1.count, line2.count+1),
            line1Color: .darkGray,
            line2Color: .lightGray,
            line1Font: CustomFont.shared().GETFONT_REGULAR(15),
            line2Font: CustomFont.shared().GETFONT_REGULAR(20))
    }
    
    func setSingleSelectLOV(line1: String, line2: String) {
        self.attributedText = attributedString(from: "\(line1)\n\(line2)",
            range2: NSMakeRange(line1.count, line2.count+1),
            line1Color: .darkGray,
            line2Color: .darkGray,
            line1Font: CustomFont.shared().GETFONT_REGULAR(15),
            line2Font: CustomFont.shared().GETFONT_REGULAR(20))
    }
    
    func setLOVSelectedText(line1: String, line2: String) {
        self.attributedText = NSMutableAttributedString().getLOVAttributedText(line1: line1, line2: line2)
    }
    
    func setHeaderTitleOnWhiteBG(line1: String, line2: String) {
        self.attributedText = attributedString(from: "\(line1)\n\(line2)",
            range2: NSMakeRange(line1.count, line2.count+1),
            line1Color: .black,
            line2Color: .darkGray,
            line1Font: CustomFont.shared().GETFONT_MEDIUM(19),
            line2Font: CustomFont.shared().GETFONT_REGULAR(15))
    }
    
    func setHeaderTitleOnBlueBG(line1: String, line2: String) {
        self.attributedText = attributedString(from: "\(line1)\n\(line2)",
            range2: NSMakeRange(line1.count, line2.count+1),
            line1Color: .white,
            line2Color: Color.LIGHTER_BLUE,
            line1Font: CustomFont.shared().GETFONT_REGULAR(19),
            line2Font: CustomFont.shared().GETFONT_REGULAR(15))
    }
    
    private func attributedString(from string: String, range2: NSRange?, line1Color: UIColor, line2Color: UIColor, line1Font: UIFont, line2Font: UIFont) -> NSAttributedString {
        
        let attrs1: [NSAttributedString.Key: Any] = [.font: line1Font, .foregroundColor: line1Color]
        let attrs2: [NSAttributedString.Key: Any] = [.font: line2Font, .foregroundColor: line2Color]
        
        let attrStr = NSMutableAttributedString(string: string, attributes: attrs1)
        if let range = range2 {
            attrStr.setAttributes(attrs2, range: range)
        }
        return attrStr
    }
}

extension EdgeInsetLabel {
    
    func setEdgeInsets() {
        self.leftTextInset = 5
        self.rightTextInset = 5
        self.topTextInset = 2
        self.bottomTextInset = 2
    }
    
    func setStatusLabelProperties(borderColor: UIColor) {
        self.setEdgeInsets()
        self.setCornerRadius()
        self.layer.borderWidth = 1
        self.layer.borderColor = borderColor.cgColor
        self.backgroundColor = borderColor.withAlphaComponent(0.1)
    }  
}

extension UIImage {
    
    func maskWithColor(color: UIColor) -> UIImage? {
        let maskImage = cgImage!
        
        let width = size.width
        let height = size.height
        let bounds = CGRect(x: 0, y: 0, width: width, height: height)
        
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let bitmapInfo = CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue)
        let context = CGContext(data: nil, width: Int(width), height: Int(height), bitsPerComponent: 8, bytesPerRow: 0, space: colorSpace, bitmapInfo: bitmapInfo.rawValue)!
        
        context.clip(to: bounds, mask: maskImage)
        context.setFillColor(color.cgColor)
        context.fill(bounds)
        
        if let cgImage = context.makeImage() {
            let coloredImage = UIImage(cgImage: cgImage)
            return coloredImage
        } else {
            return self
        }
    }
}

extension UIImageView {
    
    func setCircleImageProperty() {
        
        self.clipsToBounds = true
        self.layer.cornerRadius = self.frame.height / 2
    }
}

extension UITextField {
    
    func setTextFieldProperties() {
        self.setCornerRadius()
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor.lightGray.cgColor
        self.font = CustomFont.shared().GETFONT_REGULAR(19)
        
        // Padding
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 8, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
    
}

extension NSLayoutConstraint {
    
    func changeMultiplier(multiplier: CGFloat) -> NSLayoutConstraint {
        let newConstraint = NSLayoutConstraint(
            item: firstItem as Any,
            attribute: firstAttribute,
            relatedBy: relation,
            toItem: secondItem,
            attribute: secondAttribute,
            multiplier: multiplier,
            constant: constant)
        newConstraint.priority = priority
        
        NSLayoutConstraint.deactivate([self])
        NSLayoutConstraint.activate([newConstraint])
        
        return newConstraint
    }
    
}

extension UIStackView {
    
    func removeAllSubviews() {
        self.arrangedSubviews.forEach { $0.removeFromSuperview() }
    }
}

final class ContentSizedTableView: UITableView {
    override var contentSize:CGSize {
        didSet {
            invalidateIntrinsicContentSize()
        }
    }

    override var intrinsicContentSize: CGSize {
        layoutIfNeeded()
        return CGSize(width: UIView.noIntrinsicMetric, height: contentSize.height)
    }
}

extension Array where Element: Hashable {
    var distinctElements: Array {
        var array = Array()
        var added = Set<Element>()
        for elem in self {
            if !added.contains(elem) {
                array.append(elem)
                added.insert(elem)
            }
        }
        return array
    }
}
