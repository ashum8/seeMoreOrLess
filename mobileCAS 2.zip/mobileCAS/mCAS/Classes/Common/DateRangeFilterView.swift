//
//  DateRangeFilterView.swift
//  mCAS
//
//  Created by iMac on 16/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

protocol DateRangeViewDelegate {
    func dateRangeFilterCall(fromDate: String, toDate: String)
}

class DateRangeFilterView: UIView {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var doneButton: UIButton!
    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet var dateRangeView: UIView!
    
    @IBOutlet weak var dateFromView: CustomTextFieldView!
    @IBOutlet weak var dateToView: CustomTextFieldView!
    
    private var delegate: DateRangeViewDelegate?
    
    func setProperties(width: CGFloat, height: CGFloat, delegate: DateRangeViewDelegate) {
        self.frame = CGRect(x: 0, y: 0, width: width, height: height)
        
        // Do any additional setup after loading the view.
        
        dateRangeView.layer.cornerRadius = 8
        
        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(19)
        
        closeButton.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(25)
        doneButton.setButtonProperties()
        
        dateFromView.setProperties(placeHolder: "From", type: .DATE, delegate: self)
        dateToView.setProperties(placeHolder: "To", type: .DATE, delegate: self)
        
        self.delegate = delegate
        validateFields()
    }
    
    @IBAction func closeButtonAction(_ sender: Any) {
        self.alpha = 0
    }
    
    @IBAction func doneButtonClicked(_ sender: Any) {
        
        if let fromDate = CustomDateFormatter.shared().getRespectiveDateFromString(inputString: dateFromView.getFieldValue()),
            let toDate = CustomDateFormatter.shared().getRespectiveDateFromString(inputString: dateToView.getFieldValue())
        {
            if fromDate.timeDifferenceInSeconds(toDate: toDate) < 0 {
                CommonAlert.shared().showAlert(message: "To date must be greater than from date")
                return
            }
            else if fromDate.getDaysDifference(toDate: toDate) > 30 {
                CommonAlert.shared().showAlert(message: "Date range can not be greater than 30 days")
                return
            }
        }
        
        self.closeButtonAction(closeButton!)
        
        delegate?.dateRangeFilterCall(fromDate: dateFromView.getFieldValue(), toDate: dateToView.getFieldValue())
    }
}

extension DateRangeFilterView: CustomTFViewDelegate {
    
    func validateFields() {
        var isEnabled = true
        
        if dateFromView.getFieldValue().isEmpty || dateToView.getFieldValue().isEmpty {
            isEnabled = false
        }
        
        doneButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
}
