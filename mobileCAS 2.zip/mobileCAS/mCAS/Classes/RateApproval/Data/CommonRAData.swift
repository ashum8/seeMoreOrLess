//
//  CommonRAData.swift
//  mCAS
//
//  Created by Mac on 16/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation

class CommonRAData{
    //Initializer access level change now
    private static var instance: CommonRAData?
    
    static func shared() -> CommonRAData{
        if instance == nil {
            instance = CommonRAData()
        }
        return instance!
    }
    
    var reasonMasterArray: [[String : String]] = []
    var approverMasterModelArray: [RAModelClasses.User] = []
    var recommenderMasterModelArray: [RAModelClasses.User] = []
}
