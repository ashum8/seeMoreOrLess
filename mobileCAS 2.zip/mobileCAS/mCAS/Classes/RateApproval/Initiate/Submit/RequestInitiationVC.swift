//
//  RequestInitiationVC.swift
//  mCAS
//
//  Created by Mac on 02/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


enum MASTERTYPE: String {
    case Approver = "Approver"
    case Recommender = "Recommender"
    case Reason = "Reason"
}

class RequestInitiationVC: UIViewController {
    
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    @IBOutlet weak var recommenderView: UIView!
    @IBOutlet weak var rcmdrTitleLabel: UILabel!
    @IBOutlet weak var rcmdrAddButton: UIButton!
    @IBOutlet weak var rcmdrTagsListView: TagListView!
    @IBOutlet weak var rcdmrBottomView: UIView!
    @IBOutlet weak var rcdmrBottomViewHeight: NSLayoutConstraint!
    @IBOutlet weak var rcdmrTagsListHeight: NSLayoutConstraint!
    
    @IBOutlet weak var approverView: UIView!
    @IBOutlet weak var aprvrTitleLabel: UILabel!
    @IBOutlet weak var aprvrAddButton: UIButton!
    @IBOutlet weak var aprvrTagsListView: TagListView!
    @IBOutlet weak var aprvrBottomView: UIView!
    @IBOutlet weak var aprvrBottomViewHeight: NSLayoutConstraint!
    @IBOutlet weak var aprvrTagsListHeight: NSLayoutConstraint!
    
    @IBOutlet weak var reasonView: UIView!
    @IBOutlet weak var reasonButton: UIButton!
    @IBOutlet weak var reasonTitleLabel: UILabel!
    
    @IBOutlet weak var descriptionViewTop: NSLayoutConstraint!
    @IBOutlet weak var descriptionViewHeight: NSLayoutConstraint!
    @IBOutlet weak var descriptionView: UIView!
    @IBOutlet weak var descriptionTitleLabel: UILabel!
    @IBOutlet weak var descriptionTextView: UITextView!
    
    @IBOutlet weak var remarksView: UIView!
    @IBOutlet weak var remarksTitleLabel: UILabel!
    @IBOutlet weak var remarksTextView: UITextView!
    
    private var aprvrListArray: [RAModelClasses.Approver] = []
    private var rcmdrListArray: [RAModelClasses.Recommender] = []
    private var reasonListArray: [RAModelClasses.RequestReason] = []
    
    var ratesDataArray: [[String : Any]]!
    var chargesDataArray: [[String : Any]]!
    var activeCrossSellFlag: String!
    var caseData: RAModelClasses.RateApprovalRecord!
    var caseDetailsData: RAModelClasses.RateApprovalRecord!
    var caseType: CASETYPE?
    
    var applicationID = ""
    var customerName = ""
    var wirr = ""
    var externalBank = ""
    
    private let RA_MAX_APPROVER_COUNT   = 10
    private let RA_MAX_RECOMMENDER_COUNT   = 10
    private let RA_APPROVER_MANADTORY_TO_SUBMIT = true
    private let RA_RECOMMENDER_MANADTORY_TO_SUBMIT = false
    private let RA_REASON_MANADTORY_TO_SUBMIT = true
    private let RA_REMARKS_MANADTORY_TO_SUBMIT = true
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        recommenderView.setMainViewProperties()
        approverView.setMainViewProperties()
        reasonView.setMainViewProperties()
        remarksView.setMainViewProperties()
        descriptionView.setMainViewProperties()
        
        rcmdrTitleLabel.setMultiSelectLOVLabelProperties()
        aprvrTitleLabel.setMultiSelectLOVLabelProperties()
        
        rcmdrAddButton.setAddButtonProperties()
        aprvrAddButton.setAddButtonProperties()
        
        setTagsViewProperties(tagsView: rcmdrTagsListView)
        setTagsViewProperties(tagsView: aprvrTagsListView)
        
        reframeRecommenderTagsViewHeight()
        reframeApproverTagsViewHeight()
        
        reasonTitleLabel.resetSingleSelectLOV(line1: "Reason")
        
        remarksTitleLabel.setRemarks(title: "Remarks")
        descriptionTitleLabel.setRemarks(title: "Description(Other)")
        
        remarksTextView.setRemarksTextView()
        descriptionTextView.setRemarksTextView()
        
        buttonView.setProperties(nextBtnTitle: "Initiate Request", delegate: self)
        
        showHideDesciption(hide: true)
        
        applicationID = caseData.application.externalRefNumber
        customerName = caseData.application.applicant.fullName.uppercased()
        
        CommonRAData.shared().approverMasterModelArray.removeAll()
        CommonRAData.shared().recommenderMasterModelArray.removeAll()
        
        setScreenData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            if self.caseType == .ToInitiate {
                headerView.setTitleWith(line1: "Initiate Request", line2: "\(applicationID) \(Constants.SEPERATOR) \(customerName)", showBack: true)
            }
            else {
                headerView.setTitleWith(line1: "Request Initiated", line2: "\(applicationID) \(Constants.SEPERATOR) \(customerName)", showBack: true)
            }
        }
    }
    
    private func setApproverView() {
        
        for obj in aprvrListArray {
            aprvrTagsListView.addTag(obj.name!)
        }
        reframeApproverTagsViewHeight()
    }
    
    private func setRecommenderView() {
        
        for obj in rcmdrListArray {
            rcmdrTagsListView.addTag(obj.name!)
        }
        reframeRecommenderTagsViewHeight()
    }
    
    private func setReasonView() {
        
        if reasonListArray.isEmpty {
            reasonTitleLabel.resetSingleSelectLOV(line1: "Reason")
        }
        else {
            reasonTitleLabel.setSingleSelectLOV(line1: "Reason", line2: "\(reasonListArray.count) Reason Selected")
        }
        
        let filterList = reasonListArray.filter { $0.code?.lowercased() == "other" }
        
        if let item = filterList.first {
            descriptionTextView.text = item.name!
            showHideDesciption(hide: false)
        }
        else {
            showHideDesciption(hide: true)
        }
    }
    
    private func setScreenData() {
        
        if self.caseType == .Initiated {
            fillData()
            
            buttonView.nextButton.setTitle("Cancel Request", for: .normal)
        }
        else if self.caseType == .Approved || self.caseType == .Rejected  || self.caseType == .Cancelled {
            buttonView.nextButton.setTitle("Re-Initiate Request", for: .normal)
            setNextButtonProperties()
        }
        else if self.caseType == .Approval {
            buttonView.nextButton.isHidden = true
            
            let bottomView: ApproveRejectBottomView!
            bottomView = .fromNib()
            bottomView.delegate = self
            bottomView.frame = CGRect(x: 0, y: self.view.frame.size.height - 80, width: self.view.frame.size.width, height: 80)
            bottomView.setProperties(showEdit: false, showForword: true)
            view.addSubview(bottomView)
            
            fillData()
        }
        else {
            buttonView.nextButton.setTitle("Initiate Request", for: .normal)
            setNextButtonProperties()
        }
    }
    
    private func fillData() {
        
        if let approverList = caseDetailsData.approvers {
            aprvrListArray = approverList
            setApproverView()
        }
        
        if let remarks = caseDetailsData.requestComments {
            self.remarksTextView.text = remarks
        }
        
        if let recommenderList = caseDetailsData.recommenders {
            rcmdrListArray = recommenderList
            setRecommenderView()
        }
        
        if let reasonList = caseDetailsData.requestReasons {
            reasonListArray = reasonList
            setReasonView()
        }
        
        rcmdrAddButton.isHidden = true
        aprvrAddButton.isHidden = true
        reasonButton.isHidden = true
        descriptionTextView.isUserInteractionEnabled = false
        remarksTextView.isUserInteractionEnabled = false
        rcmdrTagsListView.enableRemoveButton = false
        aprvrTagsListView.enableRemoveButton = false
    }
    
    private func showHideDesciption(hide: Bool) {
        
        if hide {
            descriptionViewTop.constant = 0
            descriptionViewHeight.constant = 0
            descriptionView.isHidden = true
        }
        else {
            descriptionViewTop.constant = 15
            descriptionViewHeight.constant = 80
            descriptionView.isHidden = false
        }
    }
    
    private func setTagsViewProperties(tagsView: TagListView) {
        tagsView.textFont = CustomFont.shared().GETFONT_REGULAR(15)
        tagsView.textColor = .darkGray
        tagsView.tagBackgroundColor = Color.LIGHTER_GRAY
        tagsView.alignment = .left
        tagsView.enableRemoveButton = true
        tagsView.removeButtonIconSize = 10
        tagsView.removeIconLineWidth = 2
        tagsView.removeIconLineColor = .darkGray
        tagsView.cornerRadius = 15
        tagsView.paddingX = 10
        tagsView.paddingY = 10
        tagsView.marginX = 10
        tagsView.marginY = 10
        tagsView.borderWidth = 1
        tagsView.borderColor = .lightGray
        tagsView.delegate = self
    }
    
    private func reframeRecommenderTagsViewHeight() {
        if let lastView = rcmdrTagsListView.rowViews.last {
            rcdmrTagsListHeight.constant = lastView.frame.origin.y + lastView.frame.size.height
            rcdmrBottomViewHeight.constant = 21 + rcdmrTagsListHeight.constant
            rcmdrTitleLabel.text = "\(rcmdrTagsListView.tagViews.count) Recommenders Selected"
            rcdmrBottomView.isHidden = false
        }
        else {
            rcdmrTagsListHeight.constant = 0
            rcdmrBottomViewHeight.constant = 0
            rcmdrTitleLabel.text = "Select Recommender(s)"
            rcdmrBottomView.isHidden = true
        }
    }
    
    private func reframeApproverTagsViewHeight() {
        if let lastView = aprvrTagsListView.rowViews.last {
            aprvrTagsListHeight.constant = lastView.frame.origin.y + lastView.frame.size.height
            aprvrBottomViewHeight.constant = 21 + aprvrTagsListHeight.constant
            aprvrTitleLabel.text = "\(aprvrTagsListView.tagViews.count) Approvers Selected"
            aprvrBottomView.isHidden = false
        }
        else {
            aprvrTagsListHeight.constant = 0
            aprvrBottomViewHeight.constant = 0
            aprvrTitleLabel.text = "Select Approver(s)"
            aprvrBottomView.isHidden = true
        }
    }
    
    @IBAction func rcmdrAddButtonAction(_ sender: Any) {
        
        if rcmdrListArray.count < RA_MAX_RECOMMENDER_COUNT {
            let preSelectedArray = rcmdrListArray.map({ $0.code ?? "" })
            
            let st = UIStoryboard.init(name: Storyboard.RATE_APPROVAL, bundle: nil)
            let vc = st.instantiateViewController(withIdentifier: "MultiSelectLOVVC") as! MultiSelectLOVVC
            vc.setData(delegate: self, masterType: .Recommender, preSelectedArray: preSelectedArray)
            self.navigationController?.pushViewController(vc, animated: false)
        }
        else {
            CommonAlert.shared().showAlert(message: NSLocalizedString("You can not select more than \(RA_MAX_RECOMMENDER_COUNT) users", comment: ""))
        }
    }
    
    
    @IBAction func aprvrAddButtonAction(_ sender: Any) {
        
        if aprvrListArray.count < RA_MAX_APPROVER_COUNT {
            let preSelectedArray = aprvrListArray.map({ $0.code ?? "" })
            
            let st = UIStoryboard.init(name: Storyboard.RATE_APPROVAL, bundle: nil)
            let vc = st.instantiateViewController(withIdentifier: "MultiSelectLOVVC") as! MultiSelectLOVVC
            vc.setData(delegate: self, masterType: .Approver, preSelectedArray: preSelectedArray)
            self.navigationController?.pushViewController(vc, animated: false)
        }
        else {
            CommonAlert.shared().showAlert(message: NSLocalizedString("You can not select more than \(RA_MAX_APPROVER_COUNT) users", comment: ""))
        }
    }
    
    @IBAction func reasonAddButtonAction(_ sender: Any) {
        
        let preSelectedArray = reasonListArray.map({ $0.code ?? "" })
        
        let st = UIStoryboard.init(name: Storyboard.RATE_APPROVAL, bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "MultiSelectLOVVC") as! MultiSelectLOVVC
        vc.setData(delegate: self, masterType: .Reason, preSelectedArray: preSelectedArray)
        self.navigationController?.pushViewController(vc, animated: false)
    }
    
    func setNextButtonProperties() {
        
        var isEnabled = true
        
        if self.caseType == .Approved || self.caseType == .Rejected || self.caseType == .Cancelled || self.caseType == .ToInitiate {
            if (RA_APPROVER_MANADTORY_TO_SUBMIT && aprvrListArray.isEmpty) || (RA_RECOMMENDER_MANADTORY_TO_SUBMIT && rcmdrListArray.isEmpty){
                isEnabled = false
            }
        }
        
        if (RA_REASON_MANADTORY_TO_SUBMIT && reasonListArray.isEmpty) || (descriptionView.isHidden == false && descriptionTextView.text.isEmpty) || (RA_REMARKS_MANADTORY_TO_SUBMIT && remarksTextView.text.isEmpty) {
            isEnabled = false
        }
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
}

extension RequestInitiationVC: RatePopupViewDelegate {
    func approveCaseServiceCall(remarks: String, reasonArray: [RAModelClasses.RequestReason], otherDescription: String) {
        submitCaseServiceCall(casType: .ToApprove, remarks: remarks, reasonArray: reasonArray, otherDescription: otherDescription)
    }
    
    func rejectCaseServiceCall(remarks: String, reasonArray: [RAModelClasses.RequestReason], otherDescription: String) {
        submitCaseServiceCall(casType: .ToReject, remarks: remarks, reasonArray: reasonArray, otherDescription: otherDescription)
    }
    
    func referCaseServiceCall(userArray: [RAModelClasses.Approver]) {
        submitCaseServiceCall(casType: .ToForward, userArray: userArray)
    }
    
    
    private func getDefaultParams(code: String, actionType: String) -> [String:Any] {
        var formDataObj = ["wirr" : wirr, "external_bank" : externalBank, "active_cross_sell_charge" : ""]
        
        if !chargesDataArray.isEmpty {
            formDataObj["active_cross_sell_charge"] = activeCrossSellFlag
        }
        
        let aprvrCodeArray = aprvrListArray.map({ (item) -> [String : String] in ["code" : item.code ?? ""] })
        let rcmdrCodeArray = rcmdrListArray.map({ (item) -> [String : String] in ["code" : item.code ?? ""] })
        var reasonCodeArray: [[String : String]] = []
        
        for obj in reasonListArray {
            if let code = obj.code {
                if code.lowercased() == "other" {
                    reasonCodeArray.append(["code" : code, "name" : descriptionTextView.text])
                }
                else {
                    reasonCodeArray.append(["code" : code])
                }
            }
        }
        
        return ["stage"                : ["code" : code],
                "rateApprovalAction"   : ["comment"        : remarksTextView.text!,
                                          "actionType"     : actionType,
                                          "reason"         : reasonCodeArray,
                                          "recommenders"   : rcmdrCodeArray,
                                          "approvers"      : aprvrCodeArray,
                                          "rates"          : ratesDataArray ?? [],
                                          "charges"        : chargesDataArray ?? [],
                                          "dynamicFormName": "\(caseDetailsData.dynamicFormName ?? "")",
                    "dynamicFormData": CommonUtils.shared().JSONToString(jsonObject: formDataObj),
                    "application"    : ["externalRefNumber" : applicationID]]]
    }
    
    private func getApproveRejectParams(code: String, actionType: String, comment: String, reasonArray: [RAModelClasses.RequestReason], otherDescription: String) -> [String:Any] {
        
        var reasonCodeArray: [[String : String]] = []
        
        for obj in reasonArray {
            if let code = obj.code {
                if code.lowercased() == "other" {
                    reasonCodeArray.append(["code" : code, "name" : otherDescription])
                }
                else {
                    reasonCodeArray.append(["code" : code])
                }
            }
        }
        
        return ["stage"                : ["code" : code],
                "taskId"               : caseData.taskId ?? "",
                "rateApprovalAction"   : ["comment"        : comment,
                                          "actionType"     : actionType,
                                          "reason"         : reasonCodeArray,
                                          "rates"          : ratesDataArray ?? [],
                                          "charges"        : chargesDataArray ?? [],
                                          "taskType"       : caseData.taskType ?? "",
                                          "application"    : ["externalRefNumber" : applicationID]]]
    }
    
    private func getReferToParams(code: String, actionType: String, userArray: [RAModelClasses.Approver]) -> [String:Any] {
        
        let aprvrCodeArray = userArray.map({ (item) -> [String : String] in ["code" : item.code ?? ""] })
        
        return ["stage"                : ["code" : code],
                "taskId"               : caseData.taskId ?? "",
                "rateApprovalAction"   : ["actionType"     : actionType,
                                          "referToUser"    : aprvrCodeArray.first ?? [],
                                          "rates"          : ratesDataArray ?? [],
                                          "charges"        : chargesDataArray ?? [],
                                          "taskType"       : caseData.taskType ?? "",
                                          "application"    : ["externalRefNumber" : applicationID]]]
    }
    
    private func submitCaseServiceCall(casType: CASETYPE, userArray: [RAModelClasses.Approver]? = nil, remarks: String? = nil, reasonArray: [RAModelClasses.RequestReason]? = nil, otherDescription: String? = nil) {
        
        var param: [String:Any]!
        
        if casType == .Initiated {
            param = getDefaultParams(code: "CANCEL", actionType: "")
        }
        else if casType == .Approved || casType == .Rejected || casType == .Cancelled || casType == .ToInitiate {
            param = getDefaultParams(code: "INITIATION", actionType: "INITIATE")
        }
        else if casType == .ToApprove {
            param = getApproveRejectParams(code: "APPROVAL", actionType: "APPROVE", comment: remarks!, reasonArray: reasonArray!, otherDescription: otherDescription!)
        }
        else if casType == .ToReject {
            param = getApproveRejectParams(code: "APPROVAL", actionType: "REJECT", comment: remarks!, reasonArray: reasonArray!, otherDescription: otherDescription!)
        }
        else if casType == .ToForward {
            param = getReferToParams(code: "SAVE_AND_FORWARD", actionType: "SAVE_AND_FORWARD", userArray: userArray!)
        }
        
        Webservices.shared().POST(urlString: ServiceUrl.SUBMIT_APPLICATION_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any]
            {
                if let isComplete = response["completed"] as? Bool, isComplete == true
                {
                    var message = ""
                    if casType == .Initiated {
                        message = "cancelled"
                    }
                    else if casType == .Approved || casType == .Rejected  || casType == .Cancelled {
                        message = "re-initiated"
                    }
                    else if casType == .ToInitiate {
                        message = "initiated"
                    }
                    else if casType == .ToApprove {
                        message = "approved"
                    }
                    else if casType == .ToReject {
                        message = "rejected"
                    }
                    else if casType == .ToForward {
                        message = "forwarded"
                    }
                    
                    CommonAlert.shared().showAlert(message: "Your request has been \(message) successfully", okAction: { _ in
                        
                        let viewContrlls = (self.navigationController?.viewControllers)!
                        
                        for vc in viewContrlls {
                            
                            if casType == .ToApprove || casType == .ToReject || casType == .ToForward {
                                if vc.isKind(of: RateApproveHomeVC.self), let obj = vc as? RateApproveHomeVC {
                                    obj.refreshList()
                                    self.navigationController?.popToViewController(obj, animated: true)
                                    break
                                }
                            }
                            else {
                                if vc.isKind(of: BaseListVC.self), let baseVC = vc as? BaseListVC, let obj = baseVC.children[baseVC.swipeMenuView.currentIndex] as? CaseListVC {
                                    obj.refreshList()
                                    self.navigationController?.popToViewController(baseVC, animated: true)
                                    break
                                }
                            }
                        }
                    })
                }
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: error, okAction: { _ in
                    //                    self.navigationController?.popViewController(animated: true)
                })
            }
            
        }, noNetwork: { (error) in })
    }
}

extension RequestInitiationVC: ARBottomViewDelegate {
    
    func editCaseAction() {}
    
    func approveCaseAction() {
        let popview: RatePopupView!
        popview = .fromNib()
        popview.viewType = .ForApproval
        popview.setProperties(width: self.view.frame.size.width, height: self.view.frame.size.height, delegate: self)
        popview.setData(item: caseDetailsData)
        self.view.addSubview(popview)
        popview.alpha = 1
    }
    
    func rejectCaseAction() {
        let popview: RatePopupView!
        popview = .fromNib()
        popview.viewType = .ForRejection
        popview.setProperties(width: self.view.frame.size.width, height: self.view.frame.size.height, delegate: self)
        popview.setData(item: caseDetailsData)
        self.view.addSubview(popview)
        popview.alpha = 1
    }
    
    func forwardCaseAction() {
        let popview: RatePopupView!
        popview = .fromNib()
        popview.viewType = .ForRefer
        popview.setProperties(width: self.view.frame.size.width, height: self.view.frame.size.height, delegate: self)
        popview.setData(item: caseDetailsData)
        self.view.addSubview(popview)
        popview.alpha = 1
    }
    
}


extension RequestInitiationVC: MultiselectLOVDelegate {
    
    func setRespectiveCodeArray(list : [DropDown], masterType: MASTERTYPE?) {
        
        if masterType == .Approver {
            
            aprvrTagsListView.removeAllTags()
            
            aprvrListArray = list.map({ (item) -> RAModelClasses.Approver in
                RAModelClasses.Approver(code: item.code, name: item.name)
            })
            
            setApproverView()
        }
        else if masterType == .Recommender {
            
            rcmdrTagsListView.removeAllTags()
            
            rcmdrListArray = list.map({ (item) -> RAModelClasses.Recommender in
                RAModelClasses.Recommender(code: item.code, name: item.name)
            })
            
            setRecommenderView()
        }
        else if masterType == .Reason {
            
            reasonListArray = list.map({ (item) -> RAModelClasses.RequestReason in
                RAModelClasses.RequestReason(code: item.code, name: "")
            })
            
            setReasonView()
        }
        
        setNextButtonProperties()
    }
}

extension RequestInitiationVC: TagListViewDelegate {
    
    func tagRemoveButtonPressed(_ title: String, tagView: TagView, sender: TagListView) {
        
        if sender == rcmdrTagsListView {
            rcmdrListArray.remove(at: rcmdrTagsListView.tagViews.firstIndex(of: tagView)!)
            rcmdrTagsListView.removeTagView(tagView)
            reframeRecommenderTagsViewHeight()
        }
        else if sender == aprvrTagsListView {
            aprvrListArray.remove(at: aprvrTagsListView.tagViews.firstIndex(of: tagView)!)
            aprvrTagsListView.removeTagView(tagView)
            reframeApproverTagsViewHeight()
        }
        
        setNextButtonProperties()
    }
}

extension RequestInitiationVC: UITextViewDelegate {
    
    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        textView.text = textView.text?.trimmingCharacters(in: .whitespaces)
        setNextButtonProperties()
        return true
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        let stringValue = (textView.text ?? "") + text
        return stringValue.count < Constants.REMARKS_LENGTH && stringValue.isAlphanumericAndSpace
    }
}

extension RequestInitiationVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        submitCaseServiceCall(casType: self.caseType!)
    }
}
