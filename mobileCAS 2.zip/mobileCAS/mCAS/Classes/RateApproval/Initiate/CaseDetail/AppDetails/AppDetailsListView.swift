//
//  AppDetailsListView.swift
//  mCAS
//
//  Created by Mac on 29/08/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

protocol AppDetailsListViewDelegate {
    func pullableViewStateChange(opened: Bool)
}


class AppDetailsListView: PullableView {
    
    let SECTION_APPLICATION = "SECTION_APPLICATION"
    let SECTION_APPLICANT = "SECTION_APPLICANT"
    let SECTION_SALES = "SECTION_SALES"
    let SECTION_ASSET = "SECTION_ASSET"
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var arrowImageView: UIImageView!

    var appDtldelegate: AppDetailsListViewDelegate?
    
    var tableSectionArray: [MenuModel] = []

    var applicationDetailArray: [KeyValueModel] = []
    var applicantDetailArray: [KeyValueModel] = []
    var salesDetailArray: [KeyValueModel] = []
    var assetDetailArray: [KeyValueModel] = []
    
    var caseDetail: RAModelClasses.RateApprovalRecord!
    
    func setProperties(width: CGFloat, height: CGFloat) {
        self.frame = CGRect(x: 0, y: 0, width: width, height: height)
        self.backgroundColor = Color.LIGHTER_GRAY
        
        //PullableView settings
        self.initializeView(self.frame)
        self.openedCenter = CGPoint(x: width/2, y: height/2)
        
        if UIDevice.current.userInterfaceIdiom == .pad {
            self.closedCenter = CGPoint(x: width/2, y: -310)
        }
        else {
            self.closedCenter = CGPoint(x: width/2, y: -130)
        }
        
        self.center = self.closedCenter
        self.delegate = self
        
        tableView.tableFooterView = UIView()
        tableView.register(UINib.init(nibName: "KeyValueCell", bundle: Bundle.main), forCellReuseIdentifier: "KeyValueCell")
        
        tableSectionArray.append(MenuModel(title: "Application Details", menuID: SECTION_APPLICATION))
        tableSectionArray.append(MenuModel(title: "Applicant Details", menuID: SECTION_APPLICANT))
//        tableSectionArray.append(MenuModel(title: "Sales Details", menuID: SECTION_SALES))
//        tableSectionArray.append(MenuModel(title: "Asset Details", menuID: SECTION_ASSET))
        
        setUpApplicationDetailsSection()
        setUpApplicantDetailsSection()
        setUpSalesDetailsSection()
        setUpAssetDetailsSection()
        
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    func setUpApplicationDetailsSection() {
        applicationDetailArray.append(KeyValueModel(fieldName: "Application Number", fieldValue: caseDetail.application.externalRefNumber))
        applicationDetailArray.append(KeyValueModel(fieldName: "Application Number", fieldValue : caseDetail.application.externalRefNumber))
        applicationDetailArray.append(KeyValueModel(fieldName: "Product", fieldValue : caseDetail.application.loanDetail?.product?.code ?? ""))
        applicationDetailArray.append(KeyValueModel(fieldName: "Product Category", fieldValue : caseDetail.application.loanDetail?.productType?.code ?? ""))
        applicationDetailArray.append(KeyValueModel(fieldName: "Scheme", fieldValue : caseDetail.application.loanDetail?.scheme?.code ?? ""))
        applicationDetailArray.append(KeyValueModel(fieldName: "Loan Amount", fieldValue : caseDetail.loanAmount!))
    }
    
    func setUpApplicantDetailsSection() {
        applicantDetailArray.append(KeyValueModel(fieldName: "Customer Name", fieldValue : caseDetail.application.applicant.fullName))
    }
    
    func setUpSalesDetailsSection() {
        salesDetailArray.append(KeyValueModel(fieldName: "Relationship Manager", fieldValue : caseDetail.application.relationshipManager?.code ?? ""))
    }
    
    func setUpAssetDetailsSection() {
        assetDetailArray.append(KeyValueModel(fieldName: "Manufacturer", fieldValue : "Honda Automobiles"))
        assetDetailArray.append(KeyValueModel(fieldName: "Model", fieldValue : "Honda Civic VXT"))
        
    }
}


extension AppDetailsListView: PullableViewDelegate {
    func pullableView(_ pView: PullableView!, didChangeState opened: Bool) {
        if opened {
            arrowImageView.image = UIImage(named: "list_arrow_up")
        }
        else {
            arrowImageView.image = UIImage(named: "list_arrow_down")
        }
        
        self.appDtldelegate?.pullableViewStateChange(opened: opened)
    }
}

extension AppDetailsListView: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return tableSectionArray.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let menu: MenuModel = tableSectionArray[section]
        
        if(menu.menuID == SECTION_APPLICATION) {
            return applicationDetailArray.count
        }
        else if(menu.menuID == SECTION_APPLICANT) {
            return applicantDetailArray.count
        }
        else if(menu.menuID == SECTION_SALES) {
            return salesDetailArray.count
        }
        else if(menu.menuID == SECTION_ASSET) {
            return assetDetailArray.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "KeyValueCell") as! KeyValueCell
        
        let menu: MenuModel = tableSectionArray[indexPath.section]
        var model = KeyValueModel(fieldName: "", fieldValue: "")
        
        if(menu.menuID == SECTION_APPLICATION) {
            model = applicationDetailArray[indexPath.row]
        }
        else if(menu.menuID == SECTION_APPLICANT) {
            model = applicantDetailArray[indexPath.row]
        }
        else if(menu.menuID == SECTION_SALES) {
            model = salesDetailArray[indexPath.row]
        }
        else if(menu.menuID == SECTION_ASSET) {
            model = assetDetailArray[indexPath.row]
        }
        
        cell.setProperties(key: model.fieldName, value: model.fieldValue)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let menu: MenuModel = tableSectionArray[section]
        return menu.title
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        if let header = view as? UITableViewHeaderFooterView {
            
            header.textLabel?.font = CustomFont.shared().GETFONT_MEDIUM(18)
            
            //set properties as we are using grouped table(to scroll section with rows) so that the title will not be shown in uppercase by default
            header.textLabel?.textColor = .black
            header.textLabel?.text = self.tableView(tableView, titleForHeaderInSection: section)
            
            if section != 0 {
                let line = UILabel(frame: CGRect(x: 0, y: 0, width: header.frame.size.width, height: 0.5))
                line.tag = 101
                line.backgroundColor = .lightGray
                header.addSubview(line)
            }
            else {
                if let line = header.viewWithTag(101) {
                    line.removeFromSuperview()
                }
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 35
    }
    
}
