//
//  CaseDetailVC.swift
//  mCAS
//
//  Created by Mac on 29/08/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class CaseDetailVC: UIViewController {
    
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var collectionViewTop: UICollectionView!
    
    @IBOutlet weak var roiTopView: CaseDetailTopHeaderView!
    @IBOutlet weak var chargeTopView: CaseDetailTopHeaderView!
    @IBOutlet weak var checkButton: UIButton!
    @IBOutlet weak var institutionTF: UITextField!
    
    @IBOutlet weak var chargeView: UIView!
    @IBOutlet weak var chargeTopViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var roiListView: UIView!
    @IBOutlet weak var chargeListView: UIView!
    
    @IBOutlet weak var roiListViewHeight: NSLayoutConstraint!
    @IBOutlet weak var chargeListViewHeight: NSLayoutConstraint!
    
    var ratesArray: [RAModelClasses.Rate] = []
    var chargesArray: [RAModelClasses.Charge] = []
    
    var caseData: RAModelClasses.RateApprovalRecord!
    var caseDetailsData: RAModelClasses.RateApprovalRecord!
    var caseType: CASETYPE?
    
    var applicationID = ""
    var customerName = ""
    var productCode = ""
    var collectionArray: [[String : String]]!
    
    private let rateRowBaseTag = 1000
    private let chargeRowBaseTag = 5000
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        let pullDownView: AppDetailsListView = .fromNib()
        pullDownView.setShadow()
        pullDownView.appDtldelegate = self
        pullDownView.caseDetail = caseData
        pullDownView.setProperties(width: view.frame.size.width, height: view.frame.size.height)
        view.addSubview(pullDownView)
        
        setProperties()
        
        applicationID = caseData.application.externalRefNumber
        customerName = caseData.application.applicant.fullName.uppercased()
        productCode = caseData.application.loanDetail?.product?.code ?? ""
        
        fetchCaseDetail()
        
        collectionArray = [["key" : "Customer Name", "value" : customerName],
                           ["key" : "Application Number", "value" : applicationID],
                           ["key" : "Loan Amount", "value" : caseData.loanAmount!],
                           ["key" : "Product", "value" : productCode],
                           ["key" : "Product Category", "value" : caseData.application.loanDetail?.productType?.code ?? ""],
                           ["key" : "Scheme", "value" : caseData.application.loanDetail?.scheme?.code ?? ""]]
    }
    
    private func setProperties() {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.itemSize = CGSize(width: (view.frame.size.width-30)/3, height: 42)
        flowLayout.scrollDirection = .vertical
        
        collectionViewTop.collectionViewLayout = flowLayout
        collectionViewTop.backgroundColor = Color.LIGHTER_GRAY
        view.bringSubviewToFront(collectionViewTop)
        
        roiTopView.setProperties()
        chargeTopView.setProperties()
        checkButton.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(15)
        institutionTF.font = CustomFont.shared().GETFONT_REGULAR(15)
        
        buttonView.setProperties(nextBtnTitle: "Next", delegate: self)
        
        self.chargeTopViewHeight.constant = 0
        self.chargeView.isHidden = true
    }
    
    @IBAction func checkButtonAction(_ sender: Any) {
        checkButton.isSelected = !checkButton.isSelected
        institutionTF.isHidden = !checkButton.isSelected
        institutionTF.text = ""
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.setTitleWith(line1: customerName, line2: "\(applicationID) \(Constants.SEPERATOR) \(productCode)", showBack: true)
        }
    }
    
    private func fetchCaseDetail() {
        
        let param : [String:[String:Any]] = ["applicationSearchCriteria"    : ["applicationNumber" : applicationID],
                                             "stage"                        : ["code" : "INITIATION"]]
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_CASE_DETAIL_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : AnyObject]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: RAModelClasses.RateApproverModel.self) { list in
                    
                    if let records = list.rateApprovalRecords, !records.isEmpty {
                        self.caseDetailsData = records.first!
                        self.fillData()
                    }
                }
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: error, okAction: { _ in
                    self.navigationController?.popViewController(animated: true)
                })
            }
            
        }, noNetwork: { (error) in
            
        })
    }
    
    private func fillData() {
        
        self.ratesArray = self.caseDetailsData.rates ?? []
        
        for (index, item) in self.ratesArray.enumerated() {
            let row = self.createRow(yCord: self.roiListViewHeight!.constant, width: self.roiListView.frame.size.width, tag: self.rateRowBaseTag+index)
            self.roiListViewHeight.constant += row.setRateData(item: item)
            self.roiListView.addSubview(row)
            
            switch self.caseType {
            case .Initiated:
                row.requestedTF.isEnabled = false
                
            default:
                row.requestedTF.isEnabled = true
            }
        }
        
        var crossSellFlags = ""
        
        if let string = self.caseDetailsData.dynamicFormData {
            
            do {
                let data = string.data(using: .utf8)!
                let jsonObject = try JSONSerialization.jsonObject(with: data, options: .mutableContainers)
                
                if let dictionary = jsonObject as? [String : Any] {
                    
                    if let wirr = dictionary["wirr"] {
                        if wirr is String {
                            self.roiTopView.wirrTF.text = "\(wirr)"
                        }
                        else if wirr is Double {
                            self.roiTopView.wirrTF.text = "\(wirr)"
                        }
                    }
                    
                    if let crossSell = dictionary["active_cross_sell_charge"] as? String {
                        crossSellFlags = crossSell
                    }
                    
                    if let bank = dictionary["external_bank"] as? String, !bank.isEmpty {
                        self.institutionTF.text = bank
                        self.checkButton.isSelected = true
                        self.institutionTF.isHidden = false
                    }
                    else {
                        self.checkButton.isSelected = false
                        self.institutionTF.isHidden = true
                    }
                }
                
            } catch { }
        }
        
        
        if let chargeArray = self.caseDetailsData.charges, !chargeArray.isEmpty {
            
            self.chargesArray = chargeArray
            
            self.chargeTopViewHeight.constant = 80
            self.chargeView.isHidden = false
            
            for (index, item) in chargeArray.enumerated() {
                let row = self.createRow(yCord: self.chargeListViewHeight!.constant, width: self.chargeListView.frame.size.width, tag: self.chargeRowBaseTag+index)
                self.chargeListViewHeight.constant += row.setChargeData(item: item, crossSellFlags: crossSellFlags)
                self.chargeListView.addSubview(row)
                
                switch self.caseType {
                case .Initiated:
                    row.requestedTF.isEnabled = false
                    row.checkButton.isUserInteractionEnabled = false
                    row.checkButton.alpha = 0.5
                    
                case .Approval:
                    row.requestedTF.isEnabled = true
                    row.checkButton.isUserInteractionEnabled = false
                    row.checkButton.alpha = 0.5
                    
                default:
                    row.requestedTF.isEnabled = true
                    row.checkButton.isUserInteractionEnabled = true
                    row.checkButton.alpha = 1.0
                }
            }
        }
        
        switch self.caseType {
        case .Initiated:
            self.roiTopView.wirrTF.isEnabled = false
            self.checkButton.isUserInteractionEnabled = false
            self.checkButton.alpha = 0.5
            self.institutionTF.isEnabled = false
            
        case .Approval:
            self.roiTopView.wirrTF.isEnabled = false
            self.checkButton.isUserInteractionEnabled = false
            self.checkButton.alpha = 0.5
            self.institutionTF.isEnabled = false
            
        default:
            self.roiTopView.wirrTF.isEnabled = true
            self.checkButton.isUserInteractionEnabled = true
            self.checkButton.alpha = 1.0
            self.institutionTF.isEnabled = true
        }
    }
    
    private func createRow(yCord: CGFloat, width: CGFloat, tag: Int) -> ROIRowView {
        let row: ROIRowView = .fromNib()
        row.backgroundColor = .clear
        row.frame = CGRect(x: 0, y: yCord, width: width, height: 40)
        row.tag = tag
        row.setProperties()
        return row
    }
    
}

extension CaseDetailVC : AppDetailsListViewDelegate {
    
    func pullableViewStateChange(opened: Bool) {
        if opened {
            self.collectionViewTop.fadeInOut(alpha: 0)
        }
        else {
            self.collectionViewTop.fadeInOut(alpha: 1)
        }
    }
    
}

extension CaseDetailVC : UICollectionViewDataSource {
    
    // MARK: - UICollectionViewDataSource protocol
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return collectionArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath as IndexPath) as! CaseDetailCell
        cell.backgroundColor = .clear
        
        let dic = collectionArray[indexPath.item]
        
        cell.keyLabel.text = dic["key"]
        cell.valueLabel.text = dic["value"]
        
        cell.keyLabel.textColor = .gray
        cell.valueLabel.textColor = .black
        
        cell.keyLabel.font = CustomFont.shared().GETFONT_MEDIUM(14)
        cell.valueLabel.font = CustomFont.shared().GETFONT_MEDIUM(15)
        
        return cell
    }
    
    @objc(collectionView:layout:insetForSectionAtIndex:)  func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets{
        return UIEdgeInsets(top: 5, left: 5, bottom: 0, right: 5)
    }
    
}

extension CaseDetailVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        
        if self.checkButton.isSelected, self.checkButton.isUserInteractionEnabled, self.institutionTF.text!.isEmpty {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Please enter institution name", comment: ""))
            return
        }
        
        var ratesDataArray: [[String : Any]] = []
        
        if let rateArray = self.caseDetailsData.rates, !rateArray.isEmpty {
            
            for (index, item) in rateArray.enumerated() {
                
                let row = self.roiListView.viewWithTag(self.rateRowBaseTag+index) as! ROIRowView
                
                if let requestedCharge = row.requestedTF.text, let value = Float(requestedCharge), value > 0  {
                    
                    if let code = item.type?.code, let initialRate = item.initialRate {
                        
                        let dic = ["type"           : ["code" : code],
                                   "waiverRate"     : String(format: "%.2f", row.waiverValue),
                                   "initialValue"   : "\(initialRate)",
                            "proposedValue"  : "\(requestedCharge)"] as [String : Any]
                        
                        ratesDataArray.append(dic)
                    }
                }
                else {
                    if let code = item.type?.code {
                        CommonAlert.shared().showAlert(message: NSLocalizedString("Please enter valid requested \(code) value", comment: ""))
                        return
                    }
                }
            }
        }
        
        
        var finalChargeList: [[String : Any]] = []
        var activeCrossSellArray: [String] = []
        
        for (index, item) in self.chargesArray.enumerated() {
            
            let row = self.chargeListView.viewWithTag(self.chargeRowBaseTag+index) as! ROIRowView
            
            if let requestedROI = row.requestedTF.text, let value = Float(requestedROI), value >= 0  {
                
                var initial = 0.0
                var waiverNotAllowed = false
                
                if let initialValue = item.initialValue {
                    initial = initialValue
                }
                if let waiverNotAllowedValue = item.waiverNotAllowed {
                    waiverNotAllowed = waiverNotAllowedValue
                }
                
                if let name = item.chargeDetails?.name, let id = item.chargeDetails?.id, let code = item.unitType?.code {
                    
                    let chargeObj = ["chargeDetails"    : ["id" : "\(id)"],
                                     "unitType"         : ["code" : "\(code)"],
                                     "waiverValue"      : "\(row.waiverValue)",
                                    "initialValue"      : "\(initial)",
                                    "proposedValue"     : "\(requestedROI)",
                                    "waiverNotAllowed"  : "\(waiverNotAllowed)"] as [String : Any]
                    
                    finalChargeList.append(chargeObj)
                    
                    if row.checkButton.isSelected {
                        activeCrossSellArray.append("\(name)(\(id))")
                    }
                }
            }
            else {
                if let name = item.chargeDetails?.name {
                    CommonAlert.shared().showAlert(message: NSLocalizedString("Please enter valid requested \(name) value", comment: ""))
                    return
                }
            }
        }
        
        let st = UIStoryboard.init(name: Storyboard.RATE_APPROVAL, bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "RequestInitiationVC") as! RequestInitiationVC
        vc.caseDetailsData = self.caseDetailsData
        vc.caseData = self.caseData
        vc.caseType = self.caseType
        vc.wirr = self.roiTopView.wirrTF.text!
        vc.externalBank = institutionTF.text!
        vc.ratesDataArray = ratesDataArray
        vc.chargesDataArray = finalChargeList
        vc.activeCrossSellFlag = activeCrossSellArray.joined(separator: ",")
        self.navigationController?.pushViewController(vc, animated: false)
    }
}
