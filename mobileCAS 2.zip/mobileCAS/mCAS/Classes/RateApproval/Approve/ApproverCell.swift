//
//  ApproverCell.swift
//  mCAS
//
//  Created by Mac on 06/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class ApproverCell: UITableViewCell {
    
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label3: UILabel!
    @IBOutlet weak var loanTypeButton: UIButton!
    
    func setProperties(dataObj: RAModelClasses.RateApprovalRecord) {
        self.contentView.backgroundColor = .clear
        self.backgroundColor = .clear
        
        bgView.setCornerRadius()
        bgView.setShadow()
        
        label1.font = CustomFont.shared().GETFONT_MEDIUM(19)
        label2.font = CustomFont.shared().GETFONT_REGULAR(16)
        label3.font = CustomFont.shared().GETFONT_REGULAR(16)
        
        loanTypeButton.layer.cornerRadius = 23
        loanTypeButton.layer.borderWidth = 1
        loanTypeButton.layer.borderColor = UIColor.gray.cgColor
        
        label1.text = dataObj.application.applicant.fullName.uppercased()
        label2.text = dataObj.application.externalRefNumber
        label3.text = dataObj.loanAmount!
        
        if let rate = dataObj.rates?[0]  {
            let calculatedVal: Double = rate.initialRate! - rate.proposedRate!
            let formattedString = NSMutableAttributedString()
            if calculatedVal > 0 {
                formattedString
                    .attributedText("\(dataObj.loanAmount!) \(Constants.SEPERATOR) \(rate.type?.code ?? "") \(rate.proposedRate!) ")
                    .attributedText("(\(String(format: "%.2f", calculatedVal))%) ", color: .red)
            }
            else {
                formattedString
                    .attributedText("\(dataObj.loanAmount!) \(Constants.SEPERATOR) \(rate.type?.code ?? "") \(rate.proposedRate!) ")
                    .attributedText("(\(String(format: "%.2f", calculatedVal))%) ", color: Color.GREEN)
            }
            label3.attributedText = formattedString
        }
    }
    
    @IBAction func loanTypeButtonAction(_ sender: UIButton) {
        
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationTransition(UIView.AnimationTransition.flipFromLeft, for: sender, cache: true)
        sender.isSelected = !sender.isSelected
        UIView.commitAnimations()
    }
    
}
