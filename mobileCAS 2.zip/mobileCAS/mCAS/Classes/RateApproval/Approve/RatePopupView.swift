//
//  RatePopupView.swift
//  mCAS
//
//  Created by Mac on 04/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


protocol RatePopupViewDelegate {
    func approveCaseServiceCall(remarks: String, reasonArray: [RAModelClasses.RequestReason], otherDescription: String)
    func rejectCaseServiceCall(remarks: String, reasonArray: [RAModelClasses.RequestReason], otherDescription: String)
    func referCaseServiceCall(userArray: [RAModelClasses.Approver])
}

class RatePopupView: UIView {
    
    @IBOutlet weak var popView: UIView!
    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var reasonView: UIView!
    @IBOutlet weak var reasonTitleLabel: UILabel!
    
    @IBOutlet weak var descriptionViewTop: NSLayoutConstraint!
    @IBOutlet weak var descriptionViewHeight: NSLayoutConstraint!
    @IBOutlet weak var descriptionView: UIView!
    @IBOutlet weak var descriptionTitleLabel: UILabel!
    @IBOutlet weak var descriptionTextView: UITextView!
    
    @IBOutlet weak var remarkHeightConst: NSLayoutConstraint!
    @IBOutlet weak var remarksView: UIView!
    @IBOutlet weak var remarksTitleLabel: UILabel!
    @IBOutlet weak var remarksTextView: UITextView!
    
    @IBOutlet weak var submitButton: UIButton!
    
    enum VIEWTYPE {
        case ForApproval
        case ForRejection
        case ForRefer
    }
    var viewType: VIEWTYPE!
    
    private var caseDetailsData: RAModelClasses.RateApprovalRecord!
    private var labelData: [String : String]!
    private var masterType: MASTERTYPE?
    private var reasonListArray: [RAModelClasses.RequestReason] = []
    private var aprvrListArray: [RAModelClasses.Approver] = []
    
    private var delegate: RatePopupViewDelegate?
    
    func setProperties(width: CGFloat, height: CGFloat, delegate: RatePopupViewDelegate? = nil) {
        self.frame = CGRect(x: 0, y: 0, width: width, height: height)
        
        // Do any additional setup after loading the view.
        popView.layer.cornerRadius = 8
        
        closeButton.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(25)
        
        reasonView.setMainViewProperties()
        remarksView.setMainViewProperties()
        descriptionView.setMainViewProperties()
        
        remarksTitleLabel.setRemarks(title: "Remarks")
        descriptionTitleLabel.setRemarks(title: "Description(Other)")
        
        descriptionTextView.setRemarksTextView()
        remarksTextView.setRemarksTextView()
        remarksView.layer.masksToBounds = true
        
        showHideDesciption(hide: true)
        
        self.delegate = delegate
        
        if viewType == .ForRefer {
            remarkHeightConst.constant = 0.0
            self.needsUpdateConstraints()
        }
        
        submitButton.setButtonProperties()
        setSubmitButtonProperties()
    }
    
    func setSubmitButtonProperties() {
        
        var isEnabled = true
        
        if viewType == .ForRefer {
            if aprvrListArray.isEmpty {
                isEnabled = false
            }
        }
        else {
            if reasonListArray.isEmpty || (descriptionView.isHidden == false && descriptionTextView.text.isEmpty) || remarksTextView.text.isEmpty {
                isEnabled = false
            }
        }
        
        submitButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    private func showHideDesciption(hide: Bool) {
        
        if hide {
            descriptionViewTop.constant = 0
            descriptionViewHeight.constant = 0
            descriptionView.isHidden = true
        }
        else {
            descriptionViewTop.constant = 15
            descriptionViewHeight.constant = 80
            descriptionView.isHidden = false
        }
    }
    
    func setData(item: RAModelClasses.RateApprovalRecord) {
        caseDetailsData = item
        
        if viewType == .ForRefer {
            if let taskType = caseDetailsData.taskType, taskType.lowercased() == "to" {
                masterType = .Approver
            }
            else {
                masterType = .Recommender
            }
            
            labelData = ["titleL1"        : "Refer",
                         "titleL2"        : "\(item.application.externalRefNumber) \(Constants.SEPERATOR) \(item.application.applicant.fullName)",
                         "reasonTitle"    : "Forward"]
        }
        else if viewType == .ForApproval {
            masterType = .Reason
            
            labelData = ["titleL1"        : "Reason For Approval",
                         "titleL2"        : "\(item.application.externalRefNumber) \(Constants.SEPERATOR) \(item.application.applicant.fullName)",
                         "reasonTitle"    : "Reason"]
            
        }
        else if viewType == .ForRejection {
            masterType = .Reason
            
            labelData = ["titleL1"        : "Reason For Rejection",
                         "titleL2"        : "\(item.application.externalRefNumber) \(Constants.SEPERATOR) \(item.application.applicant.fullName)",
                         "reasonTitle"    : "Reason"]
        }
        
        titleLabel.setHeaderTitleOnWhiteBG(line1: labelData["titleL1"] ?? "", line2: labelData["titleL2"] ?? "")
        reasonTitleLabel.resetSingleSelectLOV(line1: labelData["reasonTitle"] ?? "")
    }
    
    @IBAction func closeButtonAction(_ sender: Any) {
        self.alpha = 0
    }
    
    @IBAction func submitButtonAction(_ sender: Any) {
        
        if viewType == .ForRefer {
            if let delegate = delegate {
                delegate.referCaseServiceCall(userArray: aprvrListArray)
            }
            else {
                submitCaseServiceCall(userArray: aprvrListArray)
            }
        }
        else {
            if let delegate = delegate {
                if viewType == .ForApproval {
                    delegate.approveCaseServiceCall(remarks: remarksTextView.text, reasonArray: reasonListArray, otherDescription: descriptionTextView.text)
                }
                else {
                    delegate.rejectCaseServiceCall(remarks: remarksTextView.text, reasonArray: reasonListArray, otherDescription: descriptionTextView.text)
                }
            }
        }
    }
    
    private func submitCaseServiceCall(userArray: [RAModelClasses.Approver]) {
        
        let aprvrCodeArray = userArray.map({ (item) -> [String : String] in ["code" : item.code ?? ""] })
        
        let param = ["stage"                : ["code" : "FORWARD"],
                     "taskId"               : caseDetailsData.taskId ?? "",
                     "rateApprovalAction"   : ["actionType"     : "FORWARD",
                                               "referToUser"    : aprvrCodeArray.first!,
                                               "taskType"       : caseDetailsData.taskType ?? "",
                                               "application"    : ["externalRefNumber" : caseDetailsData.application.externalRefNumber]]] as [String : Any]
        
        Webservices.shared().POST(urlString: ServiceUrl.SUBMIT_APPLICATION_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any]
            {
                if let isComplete = response["completed"] as? Bool, isComplete == true
                {
                    CommonAlert.shared().showAlert(message: "Your request has been forwarded successfully", okAction: { _ in
                        self.closeButtonAction(self.closeButton!)
                        
                        let viewContrlls = AppDelegate.instance.applicationNavController.viewControllers
                        
                        for vc in viewContrlls {
                            if vc.isKind(of: RateApproveHomeVC.self), let obj = vc as? RateApproveHomeVC {
                                obj.refreshList()
                                break
                            }
                        }
                    })
                }
            }
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: error, okAction: { _ in
//                    self.navigationController?.popViewController(animated: true)
                })
            }
            
        }, noNetwork: { (error) in })
    }
    
    @IBAction func reasonAddButtonAction(_ sender: Any) {
        
        let st = UIStoryboard.init(name: Storyboard.RATE_APPROVAL, bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "MultiSelectLOVVC") as! MultiSelectLOVVC
        
        if self.masterType == .Reason {
            let preSelectedArray = reasonListArray.map({ $0.code ?? "" })
            vc.setData(delegate: self, masterType: self.masterType, preSelectedArray: preSelectedArray)
        }
        else {
            let preSelectedArray = aprvrListArray.map({ $0.code ?? "" })
            vc.setData(delegate: self, masterType: self.masterType, preSelectedArray: preSelectedArray, isMultiSelectionEnabled: false)
        }
        
        AppDelegate.instance.applicationNavController.pushViewController(vc, animated: false)
    }
    
}

extension RatePopupView: MultiselectLOVDelegate {
    
    func setRespectiveCodeArray(list: [DropDown], masterType: MASTERTYPE?) {
        
        if masterType == .Reason {
            reasonListArray = list.map({ (item) -> RAModelClasses.RequestReason in
                RAModelClasses.RequestReason(code: item.code, name: "")
            })
            
            reasonTitleLabel.setSingleSelectLOV(line1: labelData["reasonTitle"] ?? "", line2: "\(reasonListArray.count) Reason Selected")
            
            let filterList = reasonListArray.filter { $0.code?.lowercased() == "other" }
            
            showHideDesciption(hide: filterList.isEmpty)
        }
        else {
            aprvrListArray = list.map({ (item) -> RAModelClasses.Approver in
                RAModelClasses.Approver(code: item.code, name: item.name)
            })
            
            if aprvrListArray.isEmpty {
                reasonTitleLabel.resetSingleSelectLOV(line1: labelData["reasonTitle"] ?? "")
            }
            else {
                reasonTitleLabel.setSingleSelectLOV(line1: labelData["reasonTitle"] ?? "", line2: aprvrListArray[0].name ?? "")
            }
        }
        
        setSubmitButtonProperties()
    }
}

extension RatePopupView: UITextViewDelegate {
    
    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        textView.text = textView.text?.trimmingCharacters(in: .whitespaces)
        setSubmitButtonProperties()
        return true
    }
}

