//
//  LoanDetailTableViewCell.swift
//  mCAS
//
//  Created by iMac on 24/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


class LoanDetailTableViewCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var separatorView: UIView!
    @IBOutlet weak var containerView: UIView!
    
    private var listModelArray: [KeyValueModel] = []
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        tableView.register(UINib(nibName: "KeyValueCell", bundle: nil), forCellReuseIdentifier: "KeyValueCell")
    }
    
    func setProperties(title: String = "", arrList: [KeyValueModel]) {
        titleLabel.font = CustomFont.shared().GETFONT_MEDIUM(18)
        titleLabel.text = title
        separatorView.isHidden = (title == "")
        separatorView.backgroundColor = Color.LIGHTER_GRAY
        containerView.setCornerRadius()
        containerView.setShadow()
        
        self.listModelArray = arrList
    }
}


extension LoanDetailTableViewCell: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listModelArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let model = listModelArray[indexPath.row]

        let cell = tableView.dequeueReusableCell(withIdentifier: "KeyValueCell", for: indexPath) as! KeyValueCell
        cell.setProperties(key: model.fieldName, value: model.fieldValue, showStatus: model.isStatus, showHeading: model.isHeading)
        return cell
    }
}
