//
//  ApplicantDocSearchVC.swift
//  mCAS
//
//  Created by iMac on 14/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class ApplicantDocSearchVC: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var firstRadioView: RadioButtonView!
    @IBOutlet weak var secRadioView: RadioButtonView!
    @IBOutlet weak var applicantNameLOV: LOVFieldView!
    @IBOutlet weak var applicantNameLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var stageLOV: LOVFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private var selectedLOVDic: [String: DropDown] = [:]
    private var dataObj: SEModelClasses.StatusEnquiryRecords!
    
    private var stageArray = [DropDown]()
    private var applicantList = [DropDown]()
    
    private let TAG_APPLICANT  = 1000
    private let TAG_STAGE      = 1001
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            
            if let applicant = dataObj.applicants, !applicant.isEmpty {
                headerView.setTitleWith(line1: "\(applicant[0].firstName!) \(applicant[0].lastName!)".capitalized, line2: dataObj.neoReferenceNumber!, showBack: true)
            }
        }
    }
    
    private func setupView() {
        
        if let applicantObj = dataObj.applicants {
            applicantList = applicantObj.map {
                let name = "\($0.firstName!) \($0.middleName!) \($0.lastName!)".capitalized
                return DropDown(code: name, name: name)
            }
        }
        
        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
        titleLabel.text = "Documents of"
        firstRadioView.setProperties(title: "Application", delegate: self)
        secRadioView.setProperties(title: "Applicant", delegate: self)
        
        let stageCode = self.dataObj?.currentStage?.code ?? ""
        CoreDataOperations.shared().fetchRecordsForMaster(masterName: Entity.STAGE) { (records) in
            if let records = records {
                let pKey = records.filter({ $0.code == stageCode})
                if !pKey.isEmpty {
                    self.stageArray = records.filter { ( Int(pKey[0].parentKey!)! >= Int($0.parentKey!)! ) }
                }
            }
        }
                
        applicantNameLOV.setLOVProperties(title: "Applicant Name", tag: TAG_APPLICANT,delegate: self, optionArray: applicantList)
        stageLOV.setLOVProperties(masterName: "", title: "Stage", tag: TAG_STAGE, autoFillValue: stageCode, delegate: self, optionArray: stageArray)
        buttonView.setProperties(nextBtnTitle: "Show Documents", delegate: self)
        selectedRadioButton(view: firstRadioView)
    }

    func setDate(data: SEModelClasses.StatusEnquiryRecords) {
        self.dataObj = data
    }
    
    private func validateFields() {
        
        var isEnabled = true
        
        if firstRadioView.radioButton.isSelected {
            isEnabled = (selectedLOVDic["\(TAG_STAGE)"] != nil)
        }
        else {
            isEnabled = (selectedLOVDic["\(TAG_STAGE)"] != nil && selectedLOVDic["\(TAG_APPLICANT)"] != nil)
        }
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
}


extension ApplicantDocSearchVC: RadioButtonDelegate {
    
    //SK Change - test
    func selectedRadioButton(view: RadioButtonView) {
        
        if !view.radioButton.isSelected {
            view.radioButton.isSelected = true
                        
            if view == firstRadioView {
                secRadioView.setButtonState(isSelected: false)
                applicantNameLOVHeight.constant = 0
            }
            else {
                firstRadioView.setButtonState(isSelected: false)
                applicantNameLOVHeight.constant = 65
            }
            
            validateFields()
        }
    }
}

extension ApplicantDocSearchVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        validateFields()
    }
}

extension ApplicantDocSearchVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        
        let storyboard = UIStoryboard.init(name: Storyboard.STATUS_ENQUIRY, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "ApplicantDocSearchResultVC") as? ApplicantDocSearchResultVC {
            if secRadioView.radioButton.isSelected {
                vc.setData(applicantType: "0", applicationNumber: dataObj.neoReferenceNumber!, stage: "\(selectedLOVDic["\(TAG_STAGE)"]?.name ?? "")", fullName: "\(selectedLOVDic["\(TAG_APPLICANT)"]?.name ?? "")", referenceType: "Customer", optionArray: stageArray, data: dataObj)
            }
            else {
                vc.setData(applicantType: "0", applicationNumber: dataObj.neoReferenceNumber!, stage: "\(selectedLOVDic["\(TAG_STAGE)"]?.name ?? "")", fullName: "Select", referenceType: "Loan", optionArray: stageArray, data: dataObj)
            }
            AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
        }
    }
}
