//
//  ApplicantsCollectionViewCell.swift
//  mCAS
//
//  Created by iMac on 24/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class ApplicantsCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var viewDetailButton: UIButton!
    @IBOutlet weak var roleLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var imageButton: UIButton!
    
    private var data: SEModelClasses.StatusEnquiryRecords!
    
    func setProperties(data: SEModelClasses.StatusEnquiryRecords) {
        
        containerView.setMainViewProperties(borderColor: Color.LIGHTER_GRAY)
        containerView.backgroundColor = Color.EXTREME_LIGHT_GRAY
        nameLabel.font = CustomFont.shared().GETFONT_MEDIUM(17)
        roleLabel.font = CustomFont.shared().GETFONT_REGULAR(14)
        
        viewDetailButton.layer.borderWidth = 1
        viewDetailButton.layer.cornerRadius = 5
        viewDetailButton.layer.borderColor = Color.BLUE.cgColor
        viewDetailButton.setTitleColor(Color.BLUE, for: .normal)
        viewDetailButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(14)
        
        imageButton.layer.borderWidth = 1
        imageButton.layer.cornerRadius = 23
        imageButton.layer.borderColor = Color.LIGHTER_GRAY.cgColor
        
        self.data =  data
    }
    
    @IBAction func viewDetailButtonAction(_ sender: Any) {
        
        let storyboard = UIStoryboard.init(name: Storyboard.STATUS_ENQUIRY, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "UserDetailVC") as? UserDetailVC {
            vc.setDate(data: data)
            AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
        }        
    }
}
