//
//  ExternalSearchResultVC.swift
//  mCAS
//
//  Created by iMac on 14/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class ExternalSearchResultVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    
    private enum DetailOptions: String {
        case viewDetail = "View Details"
        case addDocument = "Add/View Documents"
    }
    
    private var listModelArray = [SEModelClasses.StatusEnquiryRecords]()
    private var cellOptionArray: [DetailOptions] = [.viewDetail, .addDocument]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.register(UINib(nibName: "CasesCell", bundle: nil), forCellReuseIdentifier: "CasesCell")
        resultLabel.font = CustomFont.shared().GETFONT_MEDIUM(17)
        noDataCapturedView.setProperties()
        setTableViewData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, title: "Search Result")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: true)
        }
    }
    
    func setData(arr:[SEModelClasses.StatusEnquiryRecords]) {
        self.listModelArray = arr
    }
    
    private func setTableViewData() {
        
        resultLabel.text = listModelArray.isEmpty ? "" : "\(listModelArray.count) RESULT FOUND"
        tableView.isHidden = listModelArray.isEmpty
        noDataCapturedView.isHidden = !tableView.isHidden
        tableView.reloadData()
    }
    
}

extension ExternalSearchResultVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listModelArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CasesCell") as! CasesCell
        
        var productTypeCode = ""
        var customerType = ""
        if let applicant = listModelArray[indexPath.row].applicants, !applicant.isEmpty {
            cell.label1.text = "\(applicant[0].firstName!) \(applicant[0].lastName!)".capitalized
            customerType = applicant[0].customerType?.code ?? ""
        }
       
        if let loanDetail = listModelArray[indexPath.row].loanDetail, let productType = loanDetail.productType {
            cell.label2.text = "\(listModelArray[indexPath.row].neoReferenceNumber!) \(Constants.SEPERATOR) " + "\(loanDetail.loanAmount!)".formatCurrency
            cell.loanTypeLabel.text = productType.name
            productTypeCode = productType.code ?? ""
        }
        if let currentStage = listModelArray[indexPath.row].currentStage {
            cell.label3.text = currentStage.name
        }
        
        cell.setProperties(cellIndex: indexPath.row, customerType: customerType, showOption: true, productTypeCode: productTypeCode, delegate: self, optionArray: cellOptionArray.map({ $0.rawValue }), optionsWidth: 200)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        self.selectedIndex(index: 0, cellIndex: indexPath.row)
    }
}

extension ExternalSearchResultVC: CaseCellDelegate {
    
    func selectedIndex(index: Int, cellIndex: Int) {
        let item = self.cellOptionArray[index]
        if item == .viewDetail {
            let storyboard = UIStoryboard.init(name: Storyboard.STATUS_ENQUIRY, bundle: nil)
            
            if let vc = storyboard.instantiateViewController(withIdentifier: "LoanApplicationDetailVC") as? LoanApplicationDetailVC {
                vc.setDate(data: listModelArray[cellIndex])
                AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
            }
        }
        else if item == .addDocument {
            let storyboard = UIStoryboard.init(name: Storyboard.STATUS_ENQUIRY, bundle: nil)
            
            if let vc = storyboard.instantiateViewController(withIdentifier: "ApplicantDocSearchVC") as? ApplicantDocSearchVC {
                vc.setDate(data: listModelArray[cellIndex])
                AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
            }
        }
    }
}
