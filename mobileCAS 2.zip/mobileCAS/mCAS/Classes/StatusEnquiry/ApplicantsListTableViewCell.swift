//
//  ApplicantsListTableViewCell.swift
//  mCAS
//
//  Created by iMac on 24/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class ApplicantsListTableViewCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var separatorView: UIView!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var collectionView: UICollectionView!
    
    private var listModelArray = [SEModelClasses.ApplicantDetailModel]()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        collectionView.register(UINib(nibName: "ApplicantsCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "ApplicantsCollectionViewCell")
    }
    
    func setProperties(title: String, list: [SEModelClasses.ApplicantDetailModel]) {
        listModelArray = list
        titleLabel.font = CustomFont.shared().GETFONT_MEDIUM(18)
        titleLabel.text = title
        separatorView.backgroundColor = Color.LIGHTER_GRAY
        containerView.setCornerRadius()
        containerView.setShadow()
    }
}

extension ApplicantsListTableViewCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listModelArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ApplicantsCollectionViewCell", for: indexPath) as! ApplicantsCollectionViewCell
        cell.setProperties(data: listModelArray[indexPath.row].data)
        cell.nameLabel.text = listModelArray[indexPath.row].name
        
        if listModelArray[indexPath.row].role == Constants.APPLICANT_ROLE_CODE_PRIMARY {
            cell.roleLabel.text = Constants.APPLICANT_ROLE_NAME_PRIMARY
        }
        else if listModelArray[indexPath.row].role == Constants.APPLICANT_ROLE_CODE_COAPPL {
            cell.roleLabel.text = Constants.APPLICANT_ROLE_NAME_COAPPL
        }
        else if listModelArray[indexPath.row].role == Constants.APPLICANT_ROLE_CODE_GUARANTOR {
            cell.roleLabel.text = Constants.APPLICANT_ROLE_NAME_GUARANTOR
        }
        
        return cell
    }
}
