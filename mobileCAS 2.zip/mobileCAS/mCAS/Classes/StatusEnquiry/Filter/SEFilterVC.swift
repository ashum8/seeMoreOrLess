//
//  SEFilterVC.swift
//  mCAS
//
//  Created by iMac on 14/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

protocol FilterVCDelegate {
    func selectedFilters(selectedFilterArray: [DropDown])
}

class SEFilterVC: UIViewController {
    
    @IBOutlet weak var tagView: TagListView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var titleLabel: UILabel!
    
    private var dropDownList: [DropDown] = []
    private var selectedTags: [String] = []

    private var delegate: FilterVCDelegate?
    private var masterName: String!
    private var filterTitle: String!
    private var selectedTagsFromBack: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        buttonView.setProperties(showBack: true, backBtnTitle: "Back", showNext: true, nextBtnTitle: "Continue", delegate: self)
        titleLabel.font = CustomFont.shared().GETFONT_MEDIUM(17)
        titleLabel.text = filterTitle
        
        setTagsViewProperties()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            headerView.showHideWhiteHeader(isHide: false, title: "Filter")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: true)
        }
    }
    
    func setData(title: String, masterName: String, delegate: FilterVCDelegate, width: CGFloat? = 180, selectedTags: [String] = []) {
        self.delegate = delegate
        self.filterTitle = title
        self.masterName = masterName
        self.selectedTagsFromBack = selectedTags
    }
    
    private func setTagsViewProperties() {
        tagView.textFont = CustomFont.shared().GETFONT_REGULAR(15)
        tagView.textColor = .darkGray
        tagView.tagBackgroundColor = Color.LIGHTER_GRAY
        tagView.alignment = .left
        tagView.cornerRadius = 15
        tagView.paddingX = 10
        tagView.paddingY = 10
        tagView.marginX = 10
        tagView.marginY = 10
        tagView.borderWidth = 1
        tagView.borderColor = .lightGray
        tagView.selectedTextColor = Color.GREEN
        tagView.selectedBorderColor = Color.GREEN
        
        addTags()
    }
    
    private func addTags() {
        // fetch the dropdownList according to master name
        CoreDataOperations.shared().fetchRecordsForMaster(masterName: masterName) { (records) in
            
            if let records = records {
                self.dropDownList.append(contentsOf: records)
            }
        }
        
        for obj in dropDownList {
            tagView.addTag(obj.name).isSelected = selectedTagsFromBack.contains(obj.name)
        }
    }
}

extension SEFilterVC: NextBackButtonDelegate {
    func nextButtonAction() {
        let arr = tagView.selectedTags()
        selectedTags = arr.map{$0.currentTitle!}
        let filteredArr = dropDownList.filter{
            return selectedTags.contains($0.name)
        }
        delegate?.selectedFilters(selectedFilterArray: filteredArr)
        AppDelegate.instance.applicationNavController.popViewController(animated: true)
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}

