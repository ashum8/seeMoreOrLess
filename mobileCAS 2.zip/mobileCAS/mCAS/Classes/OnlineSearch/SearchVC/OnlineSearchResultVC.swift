//
//  OnlineSearchResultVC.swift
//  mCAS
//
//  Created by iMac on 29/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class OnlineSearchResultVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var lblSelectMsg: UILabel!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    
    var searchType: OSSearchType?
    private var listArrayModel = [RAModelClasses.RateApprovalRecord]()
    private var offset = 0
    private var reachedEndOfItems = false
    var searchText: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        setupView()
        refreshList()
    }
    
    private func setupView() {
        
        self.view.backgroundColor = Color.LIGHTER_GRAY
        tableView.register(UINib(nibName: String(describing: CasesCell.self), bundle: Bundle.main), forCellReuseIdentifier: "CasesCell")
        tableView.tableFooterView = UIView()
        
        lblSelectMsg.font = CustomFont.shared().GETFONT_MEDIUM(19)
        lblSelectMsg.isHidden = true
        
        noDataCapturedView.setProperties(title: "No Data Found")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            headerView.setTitleWith(line1: "Rate Approval Request", showBack: true)
        }
    }
    
    @objc func refreshList() {
        offset = 0
        reachedEndOfItems = false
        listArrayModel.removeAll()
        
        fetchCases()
    }
    
    private func manageHeaderView() {
        
        if let headerView = AppDelegate.instance.headerView {
            if !self.listArrayModel.isEmpty {
                headerView.setTitleWith(line1: "\(self.listArrayModel.count) results found", showBack: true)
            }
            else {
                headerView.setTitleWith(line1: "Rate Approval Request", showBack: true)
            }
        }
    }
    
    private func fetchCases() {
        
        guard !reachedEndOfItems else {
            return
        }
        
        let param : [String:[String:Any]] = ["status"                       : ["code" : "NOT INITIATED"],
                                             "stage"                        : ["code" : "INITIATION"],
                                             "applicationSearchCriteria"    : ["applicationNumber" : self.searchText ?? ""],
                                             "pageInfo"                     : ["requestStartIndex" : offset]]
        
        Webservices.shared().POST(urlString: ServiceUrl.SEARCH_APPLICATION_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : AnyObject]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: RAModelClasses.RateApproverModel.self) { list in
                    var recordCount = 0
                    
                    if let records = list.rateApprovalRecords {
                        self.listArrayModel.append(contentsOf: records)
                        recordCount = records.count
                    }
                    
                    if let pageSize = list.pageInfo?.requestPageSize
                    {
                        if recordCount < pageSize {
                            self.reachedEndOfItems = true
                        }
                        self.offset += pageSize
                    }
                    
                    if recordCount > 0 {
                        self.tableView.reloadData()
                    }
                    
                    self.tableView.isHidden = self.listArrayModel.isEmpty
                    self.noDataCapturedView.isHidden = !self.listArrayModel.isEmpty
                    self.lblSelectMsg.isHidden = self.listArrayModel.isEmpty
                }
                
                self.manageHeaderView()
            }
            
        }, failure: { (error) in
            
            self.manageHeaderView()
            
            if error == ServiceUrl.ALERT_NO_DATA {
                self.tableView.isHidden = self.listArrayModel.isEmpty
                self.noDataCapturedView.isHidden = !self.listArrayModel.isEmpty
                self.lblSelectMsg.isHidden = self.listArrayModel.isEmpty
                
                self.reachedEndOfItems = true
            }
            
        }, noNetwork: { (error) in
            self.manageHeaderView()
        })
    }
}

extension OnlineSearchResultVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.listArrayModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CasesCell") as! CasesCell
        
        let record = self.listArrayModel[indexPath.row]
        
        cell.label1.text = record.application.applicant.fullName.uppercased()
        cell.label2.text = record.application.externalRefNumber
        cell.label3.text = record.loanAmount!
        
        if let productType = record.application.loanDetail?.productType?.code {
            cell.loanTypeLabel.text = productType
            
            //SK Change - check loan icon
            cell.setProperties(cellIndex: indexPath.row, showArrow: true, productTypeCode: record.application.loanDetail?.productType?.code)
        }
        
        // Check if the last row number is the same as the last current data element
        if indexPath.row == self.listArrayModel.count - 1 {
            self.fetchCases()
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        if (self.searchType == .RateApproval) {
            let st = UIStoryboard.init(name: Storyboard.RATE_APPROVAL, bundle: nil)
            let vc = st.instantiateViewController(withIdentifier: "CaseDetailVC") as! CaseDetailVC
            vc.caseType = .ToInitiate
            vc.caseData = self.listArrayModel[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
    
}
