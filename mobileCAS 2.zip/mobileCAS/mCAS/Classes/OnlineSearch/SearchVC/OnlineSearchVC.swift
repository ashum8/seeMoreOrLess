//
//  OnlineSearchVC.swift
//  mCAS
//
//  Created by iMac on 28/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

enum OSSearchType {  // Used in search module to check search is running for which module
    case FIV
    case RateApproval
}

class OnlineSearchVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var segmentedSearchTypeButton: UISegmentedControl!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var lblSearchVia: UILabel!
    
    var tableArray: [Any] = []
    var searchType: OSSearchType?
    var tempApplicationID: String?
    var dropDownIdTypesArray: [DropDown] = []
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        self.tableView.tableFooterView = UIView()
        
        //Setting for segmented Control
        if self.searchType == .FIV || self.searchType == .RateApproval {
            self.segmentedSearchTypeButton.removeSegment(at: 1, animated: false) //Remove Customer Info Tab
            self.segmentedSearchTypeButton.removeSegment(at: 1, animated: false) //Remove Unique ID Tab
        }
        
        self.segmentedSearchTypeButton.selectedSegmentIndex = 0
        self.segmentedSearchTypeButton.setTitleTextAttributes([.font: CustomFont.shared().GETFONT_REGULAR(15)], for: .normal)
        self.segmentedSearchTypeButton.tintColor = Color.BLUE
        self.lblSearchVia.font = CustomFont.shared().GETFONT_REGULAR(16)
        
        let dropDownObj = DropDown(code: "PHONE_NUMBER", name: NSLocalizedString("Mobile Number", comment: ""))
        self.dropDownIdTypesArray.append(dropDownObj)
        
        self.onlineSearchForTabButtonClicked(self.segmentedSearchTypeButton!)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            headerView.setTitleWith(line1: "Search Application", showBack: true)
        }
    }
    
    //    MARK: - Segmented Control Button Action
    
    @IBAction func onlineSearchForTabButtonClicked(_ sender: Any) {
        
        var tableModel = OSTableModel()
        tableModel.isVisible = true
        
        if self.segmentedSearchTypeButton.selectedSegmentIndex == 0 {
            tableModel.dequeIdentifier = "OSAppIDTableCell"
            tableModel.cellHeight = 55.0
        }
        else if self.segmentedSearchTypeButton.selectedSegmentIndex == 1 {
            tableModel.dequeIdentifier = "OSDOBTableCell"
            tableModel.cellHeight = 106.0
        }
        else {
            tableModel.dequeIdentifier = "OSUniqueIdTableCell"
            tableModel.cellHeight = 130.0
        }
        
        self.tableArray.removeAll()
        self.tableArray.append(tableModel)
        self.tableView.reloadData()
    }
    
    //    MARK: - Table View Delegate Methods
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.tableArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if var data = self.tableArray[indexPath.row] as? OSTableModel, let identifier = data.dequeIdentifier {
            let cell = tableView.dequeueReusableCell(withIdentifier: identifier, for: indexPath)
            
            if identifier == "OSUniqueIdTableCell" {
                
                if let simpleCell = cell as? OSUniqueIdTableCell {
                    simpleCell.setProperties()
                    
                    if data.isVisible {
                        simpleCell.simpleSearchTextField.text = ""
                        data.isVisible = false
                    }
                    
                    if self.dropDownIdTypesArray.isEmpty && simpleCell.idTypeButton.title(for: .normal)!.isEmpty {
                        if let dict = self.dropDownIdTypesArray.first {
                            simpleCell.idTypeButton.setTitle(dict.name, for: .normal)
                            simpleCell.simpleSearchTextField.placeholder = dict.name
                        }
                    }
                    
                    return simpleCell
                }
            }
            else if identifier == "OSAppIDTableCell" {
                
                if let simpleCell = cell as? OSAppIDTableCell {
                    simpleCell.setProperties()
                    
                    if data.isVisible {
                        simpleCell.simpleSearchTextField.text = ""
                        data.isVisible = false
                    }                    
                    return simpleCell
                }
            }
            else if identifier == "OSDOBTableCell" {
                if let simpleCell = cell as? OSDOBTableCell {
                    simpleCell.setProperties()
                    
                    if data.isVisible {
                        simpleCell.customerNameTextField.text = ""
                        simpleCell.dateOfBirthTextField.text = ""
                        data.isVisible = false
                    }
                    return simpleCell
                }
            }
        }
        
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let data = self.tableArray[indexPath.row] as! OSTableModel
        return data.cellHeight
    }
    
    func searchServiceCall(txtSearch: String) {
        if CommonUtils.shared().checkForReachabilityMode() {
            let st = UIStoryboard.init(name: Storyboard.ONLINE_SEARCH, bundle: nil)
            if let vc = st.instantiateViewController(withIdentifier: "OnlineSearchResultVC") as? OnlineSearchResultVC {
                vc.searchType = self.searchType
                vc.searchText = txtSearch
                self.navigationController?.pushViewController(vc, animated: false)
            }
        }
    }
    
}
