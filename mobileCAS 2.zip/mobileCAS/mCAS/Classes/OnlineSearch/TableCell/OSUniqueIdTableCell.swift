//
//  OSUniqueIdTableCell.swift
//  mCAS
//
//  Created by iMac on 28/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class OSUniqueIdTableCell: GenericTableViewCell, UITextFieldDelegate, LOVListDelegate {
    
    
    @IBOutlet weak var simpleSearchTextField: JVFloatLabeledTextField!
    @IBOutlet weak var searchButton: UIButton!
    @IBOutlet weak var idTypeButton: UIButton!
    
    func setProperties() {
        
        self.simpleSearchTextField.setCornerRadius()
        self.simpleSearchTextField.layer.borderColor = UIColor.lightGray.cgColor
        self.simpleSearchTextField.layer.borderWidth = 1.0
        self.simpleSearchTextField.autocapitalizationType = .allCharacters
        self.simpleSearchTextField.keyboardType = .default
        
        self.idTypeButton.setCornerRadius()
        self.idTypeButton.layer.borderColor = UIColor.lightGray.cgColor
        self.idTypeButton.layer.borderWidth = 1.0
        
        simpleSearchTextField.font = CustomFont.shared().GETFONT_REGULAR(15)
        searchButton.setButtonProperties()
        
    }
    
    @IBAction func idTypeButtonClicked(_ sender: Any) {
        
        let viewController = self.getViewController() as? OnlineSearchVC
        
        let storyboard = UIStoryboard.init(name: Storyboard.LOV_LIST, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "LOVListVC") as? LOVListVC {
            vc.setData(dropDownList: viewController!.dropDownIdTypesArray, delegate: self, title: "Id")
            viewController?.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    //   MARK: - LOVListVC Delegate
    
    func selectedLOV(selectedObj: DropDown) {
        
        if let viewController = self.getViewController() as? OnlineSearchVC {
            
            viewController.dropDownIdTypesArray = viewController.dropDownIdTypesArray.map({ (item) -> DropDown in
                
                item.isSelectedFlag = ((item.code == selectedObj.code) && (item.name == selectedObj.name))
                return item
            })
        }
        
        idTypeButton.setTitle(selectedObj.name, for: .normal)
        simpleSearchTextField.placeholder = selectedObj.name
        simpleSearchTextField.text = ""
    }
    
    //    MARK: Textfield delegate methods
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let stringValue = (textField.text ?? "") + string
        return stringValue.isAlphanumeric
    }
}
