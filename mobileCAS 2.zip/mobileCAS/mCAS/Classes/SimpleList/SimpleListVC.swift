//
//  SimpleListVC.swift
//  mCAS
//
//  Created by iMac on 16/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

protocol SimpleListVCDelegate {
    func selectedListOption(index: Int)
}

class SimpleListVC: UIViewController {
    
    private var delegate: SimpleListVCDelegate?
    private var listArray: [String] = []
    private var selectedValue: String?
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.tableView.tableFooterView = UIView()
    }
    
    func setData(listArray: [String], selectedValue: String? = "", delegate: SimpleListVCDelegate, width: CGFloat? = 180) {
        self.delegate = delegate
        self.listArray = listArray
        self.selectedValue = selectedValue
        
        self.preferredContentSize = CGSize(width: width!, height: CGFloat(listArray.count*45))
        self.modalPresentationStyle = .popover
    }
}

extension SimpleListVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell")
        
        if cell == nil {
            cell = UITableViewCell(style: .default, reuseIdentifier: "TableViewCell")
            cell?.backgroundColor = .clear
            cell?.backgroundView = nil
            cell?.selectionStyle = .none
        }
        
        cell?.tintColor = Color.BLUE
        
        cell?.accessoryType = (listArray[indexPath.row] == (selectedValue ?? "NO value")) ? .checkmark : .none
        cell?.textLabel?.textColor = (listArray[indexPath.row] == (selectedValue ?? "NO value")) ? Color.BLUE : .black
        cell?.textLabel?.textAlignment = .left
        cell?.textLabel?.font = (listArray[indexPath.row] == (selectedValue ?? "NO value")) ? CustomFont.shared().GETFONT_MEDIUM(17) : CustomFont.shared().GETFONT_REGULAR(17)
        cell?.textLabel?.text = listArray[indexPath.row]
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        delegate?.selectedListOption(index: indexPath.row)
    }
    
}
