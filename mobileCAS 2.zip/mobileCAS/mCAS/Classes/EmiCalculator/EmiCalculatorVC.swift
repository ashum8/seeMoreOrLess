//
//  EmiCalculatorVC.swift
//  mCAS
//
//  Created by iMac on 19/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


struct LabelModel {
    let shortValue: String
    let value: Int
}

class EmiCalculatorVC: UIViewController {
    
    @IBOutlet weak var loanAmountView: EMICalculatorView!
    @IBOutlet weak var rateOfInterestView: EMICalculatorView!
    @IBOutlet weak var emiView: EMICalculatorView!
    
    @IBOutlet weak var scrollView: UIScrollView!
    
    @IBOutlet weak var rateTypeLabel: UILabel!
    @IBOutlet weak var repaymentLabel: UILabel!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var amortizationChartButton: UIButton!
    @IBOutlet weak var resultView: UIView!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var repaymentView: UIView!
    @IBOutlet weak var repaymentViewHeight: NSLayoutConstraint!
    @IBOutlet weak var flatButton: UIButton!
    @IBOutlet weak var effectiveButton: UIButton!
    @IBOutlet weak var btnDaily: UIButton!
    @IBOutlet weak var btnWeekly: UIButton!
    @IBOutlet weak var btnFortnight: UIButton!
    @IBOutlet weak var btnMonthly: UIButton!
    @IBOutlet weak var btnYearly: UIButton!
    
    private enum RateType {
        case Flat
        case Effective
    }
    
    private enum RepaymentFrequency {
        case Daily
        case Weekly
        case Fortnight
        case Monthly
        case Yearly
    }
    
    private enum CalculateFor: String {
        case calculateRate = "ROI Calculator"
        case calculateTenure = "Tenure Calculator"
        case calculateEmi = "EMI Calculator"
    }
    
    private var selectedRate: RateType!
    private var selectedRepayment: RepaymentFrequency?
    private var dropdownOptionArray: [CalculateFor] = [.calculateEmi, .calculateRate, .calculateTenure]
    private var selectedCalculationType: CalculateFor?
    private var rateTypeBtnArray: [UIButton] = []
    private var frequencyBtnArray: [UIButton] = []
    
    private var MaxLimitLoanAmount = 10000000
    private var MinLimitLoanAmount = 10000
    private var MinLimitRate       = 1.00
    private var MaxLimitRate       = 30.00
    private var MinLimitTenure     = 1
    private var MaxLimitTenure     = 30
    private var MaxLimitEMI        = 100000
    private var MinLimitEMI        = 100
    
    private var rateTenureModelArray = [LabelModel]()
    private var emiModelArray = [LabelModel]()
    private var amounteModelArray = [LabelModel]()
    
    private var calculatedEMI: Double?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = Color.EXTREME_LIGHT_GRAY
        
        rateTypeLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
        repaymentLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
        
        resultView.setMainViewProperties()
        buttonView.setProperties(nextBtnTitle: "Calculate", delegate: self)
        repaymentView.layer.masksToBounds = true
        
        setupLabelsArray()
        
        rateTypeBtnArray = [flatButton, effectiveButton]
        frequencyBtnArray = [btnDaily, btnWeekly, btnFortnight, btnMonthly, btnYearly]
        
        resetSegmentLikeView(arr: rateTypeBtnArray)
        resetSegmentLikeView(arr: frequencyBtnArray)
       
        handleSelectedDropDown(index: 0)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let headerView = AppDelegate.instance.headerView, let bottomView  = AppDelegate.instance.bottomTabbarView {
            let dropdownListArray = dropdownOptionArray.map({ $0.rawValue })
            
            headerView.setTitleWith(showBack: true, showDropdownArrow: true, delegate: self, dropdownListArray: dropdownListArray)
            bottomView.isHidden = true
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if let headerView = AppDelegate.instance.headerView {
            headerView.setTitleWith(showBack: true)
        }
    }
    
    private func setupLabelsArray() {
        
        for i in stride(from: 0, to: MaxLimitTenure + 1, by: +3) {
            rateTenureModelArray.append(LabelModel(shortValue: (i == 0) ? "\(MinLimitTenure)" : "\(i)", value: (i == 0) ? MinLimitTenure : i))
        }
        
        for i in stride(from: 0, to: Int(MaxLimitLoanAmount) + 1, by: +1000000) {
            amounteModelArray.append(LabelModel(shortValue: (i == 0) ? "\(MinLimitLoanAmount)" : "\((i * 10) / 1000000)L", value: (i == 0) ? Int(MinLimitLoanAmount) : i))
        }
        
        for i in stride(from: 0, to: MaxLimitEMI + 1, by: +10000) {
            emiModelArray.append(LabelModel(shortValue: (i == 0) ? "\(MinLimitEMI)" : "\((i * 10) / 10000)K", value: (i == 0) ? MinLimitEMI : i))
        }
    }
    
    private func resetSegmentLikeView(arr: [UIButton]) {
        refreshResultView()

        for item in arr {
            item.resetSegmentButtonProperties()
        }
    }
    
    private func refreshResultView() {
        resultLabel.text = ""
        amortizationChartButton.isHidden = true
    }
    
    @IBAction func effectiveFlatButtonAction(_ sender: UIButton) {
        if !sender.isSelected {
            resetSegmentLikeView(arr: rateTypeBtnArray)
            sender.setSelectedSegmentButtonProperties()
            
            switch sender
            {
            case flatButton:
                selectedRate = .Flat
            case effectiveButton:
                selectedRate = .Effective
            default:
                break
            }
        }
    }
    
    @IBAction func repaymentFrequencyButtonAction(_ sender: UIButton) {
        if !sender.isSelected {
            resetSegmentLikeView(arr: frequencyBtnArray)
            sender.setSelectedSegmentButtonProperties()

            switch sender
            {
            case btnDaily:
                selectedRepayment = .Daily
            case btnWeekly:
                selectedRepayment = .Weekly
            case btnFortnight:
                selectedRepayment = .Fortnight
            case btnMonthly:
                selectedRepayment = .Monthly
            case btnYearly:
                selectedRepayment = .Yearly
            default:
                break
            }
        }
    }
    
    @IBAction func amortizationChartButtonAction(_ sender: Any) {
        
        let storyboard = UIStoryboard.init(name: Storyboard.EMI_CALCULATOR, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "AmortizationChartVC") as? AmortizationChartVC {
            
            vc.emiAmount = calculatedEMI ?? 0.00
            vc.principalAmount = Double(loanAmountView.getFieldValue()) ?? 0.00
            vc.tenure = getTenureForFrequencyType()
            vc.periodicInterest = getRateForFrequencyType()
            vc.ratePerAnnum =  Double(rateOfInterestView.getFieldValue()) ?? 0.00
            vc.tenureInYears = Double(emiView.getFieldValue()) ?? 0.00
            vc.tenureLoanType = "\(getTenureLoanTypeForFrequencyType())"
            vc.installmentLabelName = "\(getFrequencyTypeString(isTenure: true)) Installment"
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
    }
    
    // MARK: - Validations
    
    private func validateDataForEmiCalculation() -> Bool
    {
        if self.loanAmountValdiations(), self.rateOfInterestValidations(), self.tenureValdiations(tenureView: emiView)  {
            return true
        }
        return false
    }
    
    private func validateDataForRateCalculation()-> Bool
    {
        if self.loanAmountValdiations(), self.tenureValdiations(tenureView: rateOfInterestView), self.emiValdiations() {
            return true
        }
        return false
    }
    
    private func validateDataForTenureCalculation() -> Bool
    {
        if self.loanAmountValdiations(), self.rateOfInterestValidations(), self.emiValdiations()  {
            return true
        }
        return false
    }
    
    
    private func loanAmountValdiations() -> Bool {
        
        if loanAmountView.getFieldValue().isEmpty {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Please enter Loan Amount", comment: ""))
            return false
        }
        else if !loanAmountView.getFieldValue().validateStringWithRegex(regx: "^[0-9]+(\\.[0-9]{1,2})?$") {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Please enter a valid loan amount", comment: ""))
            return false
        }
        else if Double(loanAmountView.getFieldValue()) == 0.00 {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Loan Amount cannot be zero", comment: ""))
            return false
        }
        else if Double(loanAmountView.getFieldValue())! < Double(MinLimitLoanAmount) {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Loan Amount cannot be less than \(MinLimitLoanAmount)", comment: ""))
            return false
        }
        else if Double(loanAmountView.getFieldValue())! > Double(MaxLimitLoanAmount)  {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Loan Amount cannot be greater than \(MaxLimitLoanAmount)", comment: ""))
            return false
        }
        return true
    }
    
    
    private func rateOfInterestValidations()-> Bool
    {
        // Loan Amount Validation
        if rateOfInterestView.getFieldValue().isEmpty {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Please enter rate of Interest", comment: ""))
            return false
        }
        else if !rateOfInterestView.getFieldValue().validateStringWithRegex(regx: "^[0-9]+(\\.[0-9]{1,2})?$") {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Rate of Interest entered by you is invalid.", comment: ""))
            return false
        }
        else if Double(rateOfInterestView.getFieldValue()) == 0.00 {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Rate of Interest cannot be zero.", comment: ""))
            return false
        }
        else if Double(rateOfInterestView.getFieldValue())! < Double(MinLimitRate) {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Rate of Interest cannot be less than \(MinLimitRate)", comment: ""))
            return false
        }
        else if Double(rateOfInterestView.getFieldValue())! > Double(MaxLimitRate)  {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Rate of Interest cannot be greater than \(MaxLimitRate)", comment: ""))
            return false
        }
        
        return true
    }
    
    private func tenureValdiations(tenureView: EMICalculatorView) -> Bool {
        // Tenure Validation
        
        if tenureView.getFieldValue().isEmpty {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Please enter tenure", comment: ""))
            return false
        }
        else if !tenureView.getFieldValue().validateStringWithRegex(regx: "^[0-9]{1,2}$") {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Please enter a valid tenure", comment: ""))
            return false
        }
        else if Double(tenureView.getFieldValue()) == 0.00 {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Tenure can not be zero", comment: ""))
            return false
        }
        else if Double(tenureView.getFieldValue())! < Double(MinLimitTenure) {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Tenure cannot be less than \(MinLimitTenure)", comment: ""))
            return false
        }
        else if Double(tenureView.getFieldValue())! > Double(MaxLimitTenure)  {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Tenure cannot be greater than \(MaxLimitTenure)", comment: ""))
            return false
        }
        
        return true
    }
    
    private func emiValdiations()-> Bool
    {
        //EMI validation
        
        if emiView.getFieldValue().isEmpty {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Please enter EMI", comment: ""))
            return false
        }
        else if !emiView.getFieldValue().validateStringWithRegex(regx: "^[0-9]+(\\.[0-9]{1,2})?$") {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Please enter a valid EMI", comment: ""))
            return false
        }
        else if Double(emiView.getFieldValue()) == 0.00 {
            CommonAlert.shared().showAlert(message: NSLocalizedString("EMI cannot be zero", comment: ""))
            return false
        }
        else if Double(emiView.getFieldValue())! < Double(MinLimitEMI) {
            CommonAlert.shared().showAlert(message: NSLocalizedString("EMI cannot be less than \(MinLimitEMI)", comment: ""))
            return false
        }
        else if Double(emiView.getFieldValue())! > Double(loanAmountView.getFieldValue())!  {
            CommonAlert.shared().showAlert(message: NSLocalizedString("EMI Cannot be greater than Loan Amount", comment: ""))
            return false
        }
        return true
    }
    
    private func getTenureLoanTypeForFrequencyType() -> Int {
        
        switch (selectedRepayment) {
        case .Monthly:
            return 12
        case .Yearly:
            return 1
        case .Weekly:
            return 52
        case .Fortnight:
            return 26
        case .Daily:
            return 365
        default:
            return 12
        }
    }
    
    private func getFrequencyTypeString(isTenure: Bool = false) -> String {
        
        switch (selectedRepayment) {
        case .Monthly:
            return isTenure ? "Month" : "Monthly"
        case .Yearly:
            return isTenure ? "Year" : "Yearly"
        case .Weekly:
            return isTenure ? "Week" : "Weekly"
        case .Fortnight:
            return isTenure ? "Fortnight" : "Fortnightly"
        case .Daily:
            return isTenure ? "Day" : "Daily"
        default:
            return isTenure ? "Month" : "Monthly"
        }
    }
    
    private func getRateForFrequencyType() -> Double {
        let roi = Double(rateOfInterestView.getFieldValue()) ?? 0.00
        let frq = Double(getTenureLoanTypeForFrequencyType())
        return  roi / frq
    }
    
    private func getTenureForFrequencyType() -> Double {
        
        var tenure = Double(emiView.getFieldValue()) ?? 0.00
        tenure = tenure * 12
        let frq = Double(getTenureLoanTypeForFrequencyType())
        return tenure * frq / 12;
    }
    
    // MARK: - Rate of Interest Calculations
    
    private func calculateROIForEffective()
    {
        //if Rate type Effective & Calculate Rate Of Interest
        
        let emi = Double(emiView.getFieldValue()) ?? 0.00
        let loanAmount = Double(loanAmountView.getFieldValue()) ?? 0.00
        var tenure = Double(rateOfInterestView.getFieldValue()) ?? 0.00
        tenure = tenure * 12
        
        if ((tenure < 1) || (loanAmount / tenure) > emi) {
            
            CommonAlert.shared().showAlert(message: NSLocalizedString("Loan amount must be less than or equal to (tenure * emi)", comment: ""))
            return
        }
        
        var roiPart1: Double = 10
        var roiPart2: Double = 1200 * (emi / loanAmount) * (1 - pow(1200 / (1200 + roiPart1), tenure))
        
        var counter = 1
        
        while (counter != -1) {
            counter += 1
            roiPart1 = roiPart2
            roiPart2 = 1200 * (emi / loanAmount)  * (1 - pow(1200 / (1200 + roiPart1), tenure))
            
            if (roundf(Float(1000 * roiPart1)) == roundf(Float(1000 * roiPart2))) {
                break
            }
        }
        roiPart1 = Double((roundf(Float(roiPart1 * 100))) / 100)
        
        if (roiPart1 > MaxLimitRate) {
            
            CommonAlert.shared().showAlert(message: NSLocalizedString("Rate of interest is \(String(format: "%.2f", roiPart1)) which is greater than max supported rate \(MaxLimitRate)", comment: ""))
            
            refreshResultView()
        }
        else {
            setupResult(resultTitle: "Your ROI will be ", result: String(format: "%.2f", roiPart1) + "%")
        }
    }
    
    private func calculateROIForFlat()
    {
        //if Rate type Flat & Calculate Rate Of Interest
        
        let emi = Double(emiView.getFieldValue()) ?? 0.00
        let loanAmount = Double(loanAmountView.getFieldValue()) ?? 0.00
        var tenure = Double(rateOfInterestView.getFieldValue()) ?? 0.00
        tenure = tenure * 12
        
        if ((tenure < 1) || (loanAmount / tenure) > emi) {
            
            CommonAlert.shared().showAlert(message: NSLocalizedString("Loan amount must be less than or equal to (tenure * emi)", comment: ""))
            return
        }
        
        let roiPart1 = emi/loanAmount
        let roiPart2 = 1 / tenure
        let roi = 1200 * (roiPart1 - roiPart2)
        
        let  rateOfInterest = Double((roundf(Float(roi * 100))) / 100)
        
        if (rateOfInterest > MaxLimitRate) {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Rate of interest is \(String(format: "%.2f", roiPart1)) which is greater than max supported rate \(MaxLimitRate)", comment: ""))
            
            refreshResultView()
        }
        else {
            setupResult(resultTitle: "Your ROI will be ", result: String(format: "%.2f", rateOfInterest) + "%")
        }
    }
    
    // MARK: - EMI Calculations
    
    private func calculateEmiForEffectiveRate()
    {
        //if Rate type effective & calculate EMI
        let loanAmount = Double(loanAmountView.getFieldValue()) ?? 0.00
        
        let finalRate = self.getRateForFrequencyType() / 100
        let finalTenure = self.getTenureForFrequencyType()
        
        calculatedEMI = loanAmount * finalRate * pow(1 + finalRate, finalTenure) / (pow(1 + finalRate, finalTenure) - 1)
        
        let formatedEMI = "\(calculatedEMI!)".formatCurrency
        setupResult(resultTitle: "\(getFrequencyTypeString()) EMI ", result: formatedEMI)
        amortizationChartButton.isHidden = false
    }
    
    private func calculateEmiForFlatRate()
    {
        //if Rate type Flat & Calculate EMI
        let loanAmount = Double(loanAmountView.getFieldValue()) ?? 0.00
        let finalRate = self.getRateForFrequencyType() / 100
        let finalTenure = self.getTenureForFrequencyType()
        calculatedEMI = (loanAmount * (1 + finalTenure * finalRate)) / finalTenure
        
        let formatedEMI = "\(calculatedEMI!)".formatCurrency
        setupResult(resultTitle: "\(getFrequencyTypeString()) EMI ", result: formatedEMI)
        amortizationChartButton.isHidden = false
    }
    
    // MARK: - Tenure Calculations
    
    private func calculateTenureForEffectiveRate()
    {
        //if Rate type Effective & Tenure
        
        let rate = Double(rateOfInterestView.getFieldValue()) ?? 0.00
        let loanAmount = Double(loanAmountView.getFieldValue()) ?? 0.00
        let emi = Double(emiView.getFieldValue()) ?? 0.00
        
        let freq = Double(getTenureLoanTypeForFrequencyType() * 100)
        var numPortion1 = (freq * emi) - (loanAmount * rate)
        
        if numPortion1 < 0 {
            CommonAlert.shared().showAlert(message: NSLocalizedString("EMI is too low", comment: ""))
        }
        else {
            
            let numPortion2 = log(freq * emi)
            numPortion1 = log(numPortion1)
            let demoniPortion1 =   log(freq + rate)
            let demoniPortion2 =   log(freq)
            let tenure  =  roundf(Float((numPortion2 - numPortion1) / (demoniPortion1 - demoniPortion2)))
            
            let finalTenure = Int(tenure)
            
            setupResult(resultTitle: "Your Tenure Will be", result: "\(finalTenure) " + getFrequencyTypeString(isTenure: true))
        }
    }
    
    private func calculateTenureForFlatRate()
    {
        //if Rate type flat & Tenure
        
        let rate = Double(rateOfInterestView.getFieldValue()) ?? 0.00
        let loanAmount = Double(loanAmountView.getFieldValue()) ?? 0.00
        let emi = Double(emiView.getFieldValue()) ?? 0.00
        
        let freq = Double(getTenureLoanTypeForFrequencyType() * 100)
        
        let demoninator = ((freq * emi) - (loanAmount * rate))
        
        if demoninator < 0 {
            CommonAlert.shared().showAlert(message: NSLocalizedString("EMI is too low", comment: ""))
        }
        else {
            let numerator = loanAmount * freq
            let tenure = roundf(Float(numerator / demoninator))
            let finalTenure = Int(tenure)
            
            setupResult(resultTitle: "Your Tenure Will be", result: "\(finalTenure) " + getFrequencyTypeString(isTenure: true))
        }
    }
    
    // setup result label
    
    private func setupResult(resultTitle: String, result: String) {
        
        scrollView.scrollToBottom(animated: true)
        
        let formattedString = NSMutableAttributedString()
        
        formattedString
            .attributedText("\(resultTitle)\n", color: .gray, font: CustomFont.shared().GETFONT_REGULAR(17))
            .attributedText("\(result)",color: .black ,font: CustomFont.shared().GETFONT_MEDIUM(20))
        
        resultLabel.attributedText = formattedString
    }
}


extension EmiCalculatorVC: HeaderDelegate {
    
    func handleSelectedDropDown(index: Int) {
        selectedCalculationType = self.dropdownOptionArray[index]
        resetSegmentLikeView(arr: rateTypeBtnArray)
        resetSegmentLikeView(arr: frequencyBtnArray)
        
        switch self.selectedCalculationType {
        case .calculateEmi:
            loanAmountView.setProperties(title: "Loan Amount", type: .Number, placeHolder: "Amount", maxValue: Float(MaxLimitLoanAmount), labelsArray: amounteModelArray)
            rateOfInterestView.setProperties(title: "Rate of Interest (%)", type: .Decimal, placeHolder: "Interest", maxValue: Float(MaxLimitRate), labelsArray: rateTenureModelArray)
            emiView.setProperties(title: "Tenure (Years)", type: .Number, placeHolder: "Tenure", maxValue: Float(MaxLimitTenure), labelsArray: rateTenureModelArray)
            repaymentViewHeight.constant = 96.0
            btnMonthly.sendActions(for: .touchUpInside)
            flatButton.sendActions(for: .touchUpInside)
            
        case .calculateRate:
            loanAmountView.setProperties(title: "Loan Amount", type: .Number, placeHolder: "Amount", maxValue: Float(MaxLimitLoanAmount), labelsArray: amounteModelArray)
            rateOfInterestView.setProperties(title: "Tenure (Years)", type: .Number, placeHolder: "Tenure", maxValue: Float(MaxLimitTenure), labelsArray: rateTenureModelArray)
            emiView.setProperties(title: "EMI", type: .Number, placeHolder: "EMI", maxValue: Float(MaxLimitEMI), labelsArray: emiModelArray)
            repaymentViewHeight.constant = 0.0
            flatButton.sendActions(for: .touchUpInside)
            
        case .calculateTenure:
            loanAmountView.setProperties(title: "Loan Amount", type: .Number, placeHolder: "Amount", maxValue: Float(MaxLimitLoanAmount), labelsArray: amounteModelArray)
            rateOfInterestView.setProperties(title: "Rate of Interest (%)", type: .Decimal, placeHolder: "Interest", maxValue: Float(MaxLimitRate), labelsArray: rateTenureModelArray)
            emiView.setProperties(title: "EMI", type: .Number, placeHolder: "EMI", maxValue: Float(MaxLimitEMI), labelsArray: emiModelArray)
            repaymentViewHeight.constant = 96.0
            btnMonthly.sendActions(for: .touchUpInside)
            flatButton.sendActions(for: .touchUpInside)
            
        default:
            break
        }
    }
}

extension EmiCalculatorVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        refreshResultView()
        
        switch selectedCalculationType {
        case .calculateEmi:
            if self.validateDataForEmiCalculation() {
                if selectedRate == .Flat {
                    self.calculateEmiForFlatRate()
                }
                else if selectedRate == .Effective {
                    self.calculateEmiForEffectiveRate()
                }
            }
            
        case .calculateRate:
            if self.validateDataForRateCalculation() {
                if selectedRate == .Flat {
                    calculateROIForFlat()
                }
                else if selectedRate == .Effective {
                    calculateROIForEffective()
                }
            }
            
        case .calculateTenure:
            if self.validateDataForTenureCalculation() {
                if selectedRate == .Flat {
                    self.calculateTenureForFlatRate()
                }
                else if selectedRate == .Effective {
                    self.calculateTenureForEffectiveRate()
                }
            }
            
        default:
            break
        }
    }
}
