//
//  EMICalculatorView.swift
//  mCAS
//
//  Created by iMac on 19/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class EMICalculatorView: UIView {
    
    @IBOutlet var containerView: UIView!
    @IBOutlet weak var titleLable: UILabel!
    @IBOutlet weak var textFieldView: CustomTextFieldView!
    @IBOutlet weak var slider: StepSlider!
    
    var maxValue: Float = 0.0
    var isTextFieldEditing: Bool = false
    var labelsModelArray = [LabelModel]()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("EMICalculatorView", owner: self, options: nil)
        containerView.fixInView(self)
    }
    
    func setProperties(title: String, type: FieldType, placeHolder: String, maxValue: Float,  labelsArray: [LabelModel]) {
        slider.tintColor = Color.BLUE
        slider.sliderCircleColor = Color.BLUE;
        slider.trackColor = .lightGray
        slider.labels = labelsArray.map({ return $0.shortValue})
        slider.index = 0
        
        titleLable.font = CustomFont.shared().GETFONT_REGULAR(17)
        titleLable.text = title
        
        textFieldView.setProperties(placeHolder:placeHolder, type: type, delegate: self)
        textFieldView.setFieldValue(text: (type == .Decimal) ? "\(String(format: "%.2f", Double(labelsArray[0].value)))" : "\(labelsArray[0].value)")
        self.maxValue = maxValue
        labelsModelArray = labelsArray
    }
    
    @IBAction func sliderValueChangeAction(_ sender: Any) {
        if !isTextFieldEditing {
            textFieldView.setFieldValue(text: labelsModelArray.isEmpty ? "" : "\(labelsModelArray[Int(slider.index)].value)")
            
            if (textFieldView.textFieldType == .Decimal), let value = Double(textFieldView.getFieldValue()) {
                textFieldView.setFieldValue(text: String(format: "%.2f", value))
            }
        }
        else {
            isTextFieldEditing = false
        }
    }
    
    func getFieldValue() -> String {
        return textFieldView.getFieldValue()
    }
    
    private func getLabelsArrayIndex(text: Int) -> Int {
        let numbers = labelsModelArray.map({ return $0.value })
        let closest = numbers.enumerated().min( by: { abs($0.1 - text) < abs($1.1 - text) } )!
        return closest.offset
    }
}

extension EMICalculatorView: CustomTFViewDelegate {
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch textFieldView.textFieldType {
            
        case .Decimal:
            return Double(text) ?? 0.00 <= Double(self.maxValue)
            
        case .Number:
            return Double(text) ?? 0.00 <= Double(self.maxValue)
            
        default:
            return true
        }
    }
    
    func validateFields() {
        if let value = Float(textFieldView.getFieldValue()) {
            let index = getLabelsArrayIndex(text: Int(value))
            isTextFieldEditing = true
            slider.setIndex(UInt(index), animated: true)
        }
    }
}
