//
//  CalculatorModelClasses.swift
//  mCAS
//
//  Created by iss on 28/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation

class CalculatorModelClasses {
    
    struct ChartModel {
        var principalAmount: Double
        var interestAmount: Double
        var balanceAmount: Double
        
        init(principalAmount: Double, interestAmount: Double, balanceAmount: Double) {
            self.principalAmount = principalAmount
            self.interestAmount = interestAmount
            self.balanceAmount = balanceAmount
        }
    }
}


