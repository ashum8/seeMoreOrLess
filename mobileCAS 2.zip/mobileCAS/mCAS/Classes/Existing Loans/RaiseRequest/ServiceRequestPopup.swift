//
//  ServiceRequestPopup.swift
//  mCAS
//
//  Created by iMac on 18/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

protocol ServiceRequestDelegate {
    func goToHomeAction()
}

class ServiceRequestPopup: UIView {
    
    @IBOutlet weak var successLabel: UILabel!
    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet weak var popUpView: UIView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private var delegate: ServiceRequestDelegate?
    
    var selectedDay: String = ""
    
    func setProperties(width: CGFloat, height: CGFloat, delegate: ServiceRequestDelegate, crMNumber: String) {
        self.frame = CGRect(x: 0, y: 0, width: width, height: height)
        
        popUpView.layer.cornerRadius = 8
        successLabel.font = CustomFont.shared().GETFONT_REGULAR(19)
        closeButton.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(25)
        
        self.delegate = delegate
        
        buttonView.setProperties(showNext: true, nextBtnTitle: "Back To Home", delegate: self)
        
        let formattedString = NSMutableAttributedString()
        
        formattedString
            .attributedText("Request has been successfully raised. You can track request by Request ID ", color: .gray, font: CustomFont.shared().GETFONT_REGULAR(17))
            .attributedText("\(crMNumber)",color: .darkGray ,font: CustomFont.shared().GETFONT_MEDIUM(17))
        
        successLabel.attributedText = formattedString
    }
    
    @IBAction func closeButtonAction(_ sender: Any) {
        self.removeFromSuperview()
        delegate?.goToHomeAction()
    }
}

extension ServiceRequestPopup: NextBackButtonDelegate {
    
    func nextButtonAction() {
        closeButton.sendActions(for: .touchUpInside)
    }
}
