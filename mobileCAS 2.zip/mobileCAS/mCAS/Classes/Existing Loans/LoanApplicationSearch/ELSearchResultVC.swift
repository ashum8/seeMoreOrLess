//
//  ELSearchResultVC.swift
//  mCAS
//
//  Created by iMac on 12/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

struct LoanOptions {
    var name: String
    var identifier: String
}

class ELSearchResultVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    
    private var listModelArray = [ELModelClasses.LoanSearchDetailVOs]()
    private var cellOptionArray = [LoanOptions]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.register(UINib(nibName: "CasesCell", bundle: nil), forCellReuseIdentifier: "CasesCell")
        resultLabel.font = CustomFont.shared().GETFONT_MEDIUM(17)
        noDataCapturedView.setProperties(title: "No Data Found")
        setOptionsData()
        setTableViewData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            headerView.setTitleWith(line1: "Search Application", showBack: true)
        }
    }
    
    func setData(arr:[ELModelClasses.LoanSearchDetailVOs]) {
        self.listModelArray = arr
    }
    
    private func setOptionsData() {
        
        //viewController title and identifier
        cellOptionArray.append(LoanOptions(name: "Loan Summary", identifier: "LoanSummaryVC"))
        cellOptionArray.append(LoanOptions(name: "Loan Statement", identifier: "LoanStatementVC"))
        cellOptionArray.append(LoanOptions(name: "EMI Schedule", identifier: "EMIScheduleVC"))
        cellOptionArray.append(LoanOptions(name: "Transaction Details", identifier: "LoanTransactionVC"))
        cellOptionArray.append(LoanOptions(name: "IT Certificate", identifier: "ITCertificateVC"))
        cellOptionArray.append(LoanOptions(name: "Raise Request", identifier: "ServiceRequestVC"))
    }
    
    private func setTableViewData() {
        
        resultLabel.text = listModelArray.isEmpty ? "" : "\(listModelArray.count) RESULTS FOUND"
        tableView.isHidden = listModelArray.isEmpty
        noDataCapturedView.isHidden = !tableView.isHidden
        tableView.reloadData()
    }
}

extension ELSearchResultVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listModelArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CasesCell") as! CasesCell
        
        cell.label1.text = listModelArray[indexPath.row].title
        cell.label2.text = "LAN# \(listModelArray[indexPath.row].aggrementNumber)"
        cell.label3.text = "Disbursed On: \( CustomDateFormatter.shared().getFormatedDateStringFromString(inputString: listModelArray[indexPath.row].disbursalDate!))"
        cell.loanTypeLabel.text = listModelArray[indexPath.row].loanType
        
        let arr = cellOptionArray.map({ $0.name })
        cell.setProperties(cellIndex: indexPath.row, showOption: true, productTypeCode: "", delegate: self, optionArray: arr, optionsWidth: 200)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        selectedIndex(index: 0, cellIndex: indexPath.row)
    }
}

extension ELSearchResultVC: CaseCellDelegate {
    
    func selectedIndex(index: Int, cellIndex: Int) {
        
        let loan = listModelArray[cellIndex]
        
        if Constants.BLOCK_CLOSED_OR_CANCEL_LOAN {
            if loan.loanStatus == "X" {
                CommonAlert.shared().showAlert(message: "Your loan has been cancelled. Please contact branch for more details.")
                return
            }
            else if loan.loanStatus == "C" {
                CommonAlert.shared().showAlert(message: "Your loan has been closed. Please contact branch for more details.")
                return
            }
        }
        
        if Constants.CHECK_LOAN_LEGAL_FLAG {
            if loan.loanLegalFlag == "Y" || loan.loanRepoFlag == "Y" {
                CommonAlert.shared().showAlert(message: "Your loan account cannot be accessed at this time. Please contact branch for more details.")
                return
            }
        }
        
        if cellOptionArray[index].identifier == "ServiceRequestVC" {
            let st = UIStoryboard.init(name: Storyboard.EXISTING_LOANS, bundle: nil)
            let vc = st.instantiateViewController(withIdentifier: "ServiceRequestVC") as! ServiceRequestVC
            vc.setDate(data: listModelArray[cellIndex])
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else {
            let st = UIStoryboard.init(name: Storyboard.EXISTING_LOANS, bundle: nil)
            let vc = st.instantiateViewController(withIdentifier: "ExistingLoansBaseVC") as! ExistingLoansBaseVC
            vc.setDate(arr: cellOptionArray, selectedIndex: index, data: listModelArray[cellIndex])
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}
