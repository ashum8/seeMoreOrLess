//
//  LoanSummaryVC.swift
//  mCAS
//
//  Created by Mac on 04/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class LoanSummaryVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    private var dataObj: ELModelClasses.LoanSearchDetailVOs!
    private var listModelArray: [KeyValueModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Summary"
        setUpTableViewData()
    }
    
    private func setUpTableViewData() {
        tableView.register(UINib(nibName: "LoanDetailTableViewCell", bundle: nil), forCellReuseIdentifier: "LoanDetailTableViewCell")
        
        listModelArray.append(KeyValueModel(fieldName: "Customer ID", fieldValue: dataObj.customerId))
        listModelArray.append(KeyValueModel(fieldName: "LAN#", fieldValue:dataObj.aggrementNumber))
        listModelArray.append(KeyValueModel(fieldName: "Email ID", fieldValue:dataObj.emailId))
        listModelArray.append(KeyValueModel(fieldName: "Product", fieldValue:dataObj.loanType))
        listModelArray.append(KeyValueModel(fieldName: "Amount Financed", fieldValue:dataObj.amountFinance.formatCurrency))
        listModelArray.append(KeyValueModel(fieldName: "Next Due Installment", fieldValue: dataObj.emiAmount.formatCurrency))
        listModelArray.append(KeyValueModel(fieldName: "Tenure (Months)", fieldValue: dataObj.tenure))
        listModelArray.append(KeyValueModel(fieldName: "Currency", fieldValue: dataObj.currencyId))
        listModelArray.append(KeyValueModel(fieldName: "Rate of Interest", fieldValue: dataObj.effectiveRate))
        listModelArray.append(KeyValueModel(fieldName: "Rate Type", fieldValue: dataObj.floatingFlag))
        listModelArray.append(KeyValueModel(fieldName: "Disbursal Date", fieldValue: CustomDateFormatter.shared().getFormatedDateStringFromString(inputString: dataObj.disbursalDate!)))
        listModelArray.append(KeyValueModel(fieldName: "Installment Frequency", fieldValue: dataObj.frequency))
        listModelArray.append(KeyValueModel(fieldName: "Installment Due On", fieldValue: dataObj.dueDay))
        listModelArray.append(KeyValueModel(fieldName: "Next Installment Due On", fieldValue: CustomDateFormatter.shared().getFormatedDateStringFromString(inputString: dataObj.nextDueDate!)))
        listModelArray.append(KeyValueModel(fieldName: "Balance Tenure", fieldValue: dataObj.balanceTenure))
        listModelArray.append(KeyValueModel(fieldName: "Installment Unpaid", fieldValue: dataObj.installmentUnpaid))
        listModelArray.append(KeyValueModel(fieldName: "Amount Overdue", fieldValue: dataObj.amountOverdue.formatCurrency))
        
        
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    func setDate(data: ELModelClasses.LoanSearchDetailVOs) {
        self.dataObj = data
    }
    
}

extension LoanSummaryVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "LoanDetailTableViewCell", for: indexPath) as! LoanDetailTableViewCell
        cell.setProperties(arrList: self.listModelArray)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
}
