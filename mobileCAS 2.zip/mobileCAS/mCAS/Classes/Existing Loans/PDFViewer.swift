//
//  PDFViewer.swift
//  mCAS
//
//  Created by iMac on 07/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit
import WebKit

class PDFViewer: UIViewController {
    
    private var base64Str: String!
    @IBOutlet weak var webBrowser: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let decodeData = Data(base64Encoded: base64Str, options: .ignoreUnknownCharacters) {
            webBrowser.load(decodeData, mimeType: "application/pdf", characterEncodingName: "utf-8", baseURL: URL(fileURLWithPath: ""))
        }
    }
    
    func setData(base64Str: String) {
        self.base64Str = base64Str
    }
}
