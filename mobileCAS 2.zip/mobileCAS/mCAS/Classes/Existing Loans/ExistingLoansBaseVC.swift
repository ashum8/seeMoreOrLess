//
//  ExistingLoansBaseVC.swift
//  mCAS
//
//  Created by Mac on 04/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit


class ExistingLoansBaseVC: UIViewController {
    
    @IBOutlet weak var swipeMenuView: SwipeMenuView!
    @IBOutlet weak var questionMarkButton: UIButton!
    
    private var tabArray = [LoanOptions]()
    private var dataObj: ELModelClasses.LoanSearchDetailVOs!
    
    var moveToIndex: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        if tabArray.map({$0.identifier}).contains("ServiceRequestVC") {
            questionMarkButton.setPlusButtonProperties()
        }
        else {
            questionMarkButton.isHidden = true
        }
        
        self.setupTabs()
        
        var options: SwipeMenuViewOptions = .init()
        options.tabView.itemView.selectedTextColor = .white
        options.tabView.itemView.textColor = Color.LIGHTER_BLUE
        options.tabView.itemView.margin = 15.0
        options.tabView.itemView.font = CustomFont.shared().GETFONT_MEDIUM(18)
        options.tabView.additionView.backgroundColor = .white
        
        swipeMenuView.delegate = self
        swipeMenuView.dataSource = self
        swipeMenuView.reloadData(options: options)
        swipeMenuView.backgroundColor = Color.BLUE
        
        //Delay execution to update selected segment
        DispatchQueue.main.asyncAfter(deadline: .now()) { [weak self] in
            guard let self = self else {
                return
            }
            
            DispatchQueue.global(qos: .userInteractive).async {
                DispatchQueue.main.async {
                    self.swipeMenuView.jump(to: self.moveToIndex, animated: true)
                }
            }
        }
    }
    
    func setDate(arr: [LoanOptions], selectedIndex: Int = 0, data: ELModelClasses.LoanSearchDetailVOs) {
        self.moveToIndex = selectedIndex
        self.tabArray = arr
        self.dataObj = data
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            headerView.setTitleWith(line1: dataObj.title, line2: "LAN# \(dataObj.aggrementNumber)", showBack: true)
        }
    }
    
    private func setupTabs() {
        
        let st = UIStoryboard.init(name: Storyboard.EXISTING_LOANS, bundle: nil)
        
        for str in tabArray {
            
            if str.identifier == "LoanSummaryVC" {
                let vc = st.instantiateViewController(withIdentifier: str.identifier) as! LoanSummaryVC
                vc.setDate(data: dataObj)
                self.addChild(vc)
            }
            else if str.identifier == "LoanStatementVC" {
                let vc = st.instantiateViewController(withIdentifier: str.identifier) as! LoanStatementVC
                vc.setDate(data: dataObj)
                self.addChild(vc)
            }
            else if str.identifier == "EMIScheduleVC" {
                let vc = st.instantiateViewController(withIdentifier: str.identifier) as! EMIScheduleVC
                vc.setDate(data: dataObj)
                self.addChild(vc)
            }
            else if str.identifier == "LoanTransactionVC" {
                let vc = st.instantiateViewController(withIdentifier: str.identifier) as! LoanTransactionVC
                vc.setDate(data: dataObj)
                self.addChild(vc)
            }
            else if str.identifier == "ITCertificateVC" {
                let vc = st.instantiateViewController(withIdentifier: str.identifier) as! ITCertificateVC
                vc.setDate(data: dataObj)
                self.addChild(vc)
            }
        }
    }
    
    @IBAction func questionMarkButtonAction(_ sender: UIButton) {
        
        let st = UIStoryboard.init(name: Storyboard.EXISTING_LOANS, bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "ServiceRequestVC") as! ServiceRequestVC
        vc.setDate(data: dataObj)
        self.navigationController?.pushViewController(vc, animated: false)
    }
}

extension ExistingLoansBaseVC: SwipeMenuViewDelegate {
    func swipeMenuView(_ swipeMenuView: SwipeMenuView, viewWillSetupAt currentIndex: Int) {
        //called for first time only
    }
    
    func swipeMenuView(_ swipeMenuView: SwipeMenuView, willChangeIndexFrom fromIndex: Int, to toIndex: Int) {        
    }
}

extension ExistingLoansBaseVC: SwipeMenuViewDataSource {
    // MARK - SwipeMenuViewDataSource
    
    func numberOfPages(in swipeMenuView: SwipeMenuView) -> Int {
        return children.count
    }
    
    func swipeMenuView(_ swipeMenuView: SwipeMenuView, titleForPageAt index: Int) -> String {
        return children[index].title ?? ""
    }
    
    func swipeMenuView(_ swipeMenuView: SwipeMenuView, viewControllerForPageAt index: Int) -> UIViewController {
        let vc = children[index]
        vc.didMove(toParent: self)
        return vc
    }
}


