//
//  PaymentBouncesTVCell.swift
//  mCAS
//
//  Created by iMac on 19/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class PaymentBouncesTVCell: UITableViewCell {
    @IBOutlet weak var dateTitleLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var titleLabel1: UILabel!
    @IBOutlet weak var valueLabel1: UILabel!
    @IBOutlet weak var titleLabel2: UILabel!
    @IBOutlet weak var valueLabel2: UILabel!
    @IBOutlet weak var titleLabel3: UILabel!
    @IBOutlet weak var valueLabel3: UILabel!
    @IBOutlet weak var bgView: UIView!
    
    func setProperties() {
        bgView.setShadow()
        bgView.setCornerRadius()
        
        dateTitleLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        dateLabel.font = CustomFont.shared().GETFONT_MEDIUM(16)
        dateTitleLabel.text = "Date"
        
        titleLabel1.font = CustomFont.shared().GETFONT_REGULAR(16)
        valueLabel1.font = CustomFont.shared().GETFONT_REGULAR(16)
        
        titleLabel2.font = CustomFont.shared().GETFONT_REGULAR(16)
        valueLabel2.font = CustomFont.shared().GETFONT_REGULAR(16)
        
        titleLabel3.font = CustomFont.shared().GETFONT_REGULAR(16)
        valueLabel3.font = CustomFont.shared().GETFONT_REGULAR(16)
    }
}
