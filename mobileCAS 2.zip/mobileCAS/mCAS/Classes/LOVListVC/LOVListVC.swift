//
//  LOVListVC.swift
//  mCAS
//
//  Created by iMac on 09/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


protocol LOVListDelegate {    
    func selectedLOV(selectedObj: DropDown)
}

class LOVListVC: UIViewController, LOVOptionCellDelegate {
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var bottomButtonViewHeight: NSLayoutConstraint!
    @IBOutlet weak var bottomButtonView: UIView!
    @IBOutlet weak var searchBarHeight: NSLayoutConstraint!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var tableView: UITableView!
    
    enum LOVListType {
        case Default
        case Other
    }
    
    private var selectedButton: UIButton?
    private let LOV_TAG = 1000
    private var delegate: LOVListDelegate?
    private var optionArray: [DropDown]?
    private var searchOptionArray: [DropDown]?
    private var lovType: LOVListType?
    private var currentStep: Int = 0
    private var totalStep: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.backgroundColor = Color.LIGHTER_GRAY
        
        self.searchOptionArray = self.optionArray
        
        tableView.tableFooterView = UIView()
        searchBar.setProperties()
        bottomButtonView.layer.masksToBounds = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let titleString = NSLocalizedString("Select", comment: "") + " \(title ?? "")"
        
        if lovType == .Other {
            //When we want to show this screen as flow screen (i.e. from Lead and Sourcing Modules) instead of LOV selection
                        
            if let headerView = AppDelegate.instance.headerView {
                if totalStep > 0 {
                    headerView.showHideStepHeader(isHide: false, title: titleString, step: "("+"\(currentStep)"+"/"+"\(totalStep)"+")")
                }
                else {
                    headerView.showHideStepHeader(isHide: false, title: titleString)
                }
            }
        }
        else {
            if let headerView = AppDelegate.instance.headerView {
                //When we want to show this screen as LOV selection with blue header
                
                headerView.showHideStepHeader(isHide: true)
                headerView.setTitleWith(line1: titleString, showBack: true)
            }
            else {
                //When we come from force change password screen - show white header with title in center and a close button
                
                let topPadding = AppDelegate.instance.getTopPadding()
                let lovHeaderView = LOVHeaderView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: Constants.HEADER_HEIGHT + topPadding))
                lovHeaderView.hideShowCloseButton(hide: false)
                lovHeaderView.setTitle(title: title ?? "")
                view.addSubview(lovHeaderView)
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        searchBar.resignFirstResponder()
    }
    
    func setData(lovType: LOVListType? = .Default, totalStep: Int? = 0, currentStep: Int? = 0, dropDownList: [DropDown], delegate: LOVListDelegate, title: String, selectedButton: UIButton? = nil, backButtonTitle: String? = nil, doneButtonTitle: String? = nil, showSearch: Bool? = true) {
        
        self.lovType = lovType
        self.selectedButton = selectedButton
        self.optionArray = dropDownList
        self.delegate = delegate
        self.title = title
        
        if let totalStep = totalStep, totalStep > 0, let currentStep = currentStep {
            self.currentStep = currentStep
            self.totalStep = totalStep
        }
        
        var backText = ""
        var doneText = ""

        if let backTitle = backButtonTitle, !backTitle.isEmpty {
            backText = backTitle
        }
        
        if let doneTitle = doneButtonTitle, !doneTitle.isEmpty {
            doneText = doneTitle
        }
        
        //Delay execution for a second to update UI.
        DispatchQueue.main.asyncAfter(deadline: .now()) { [weak self] in
            guard let self = self else {
                return
            }
            
            DispatchQueue.global(qos: .utility).async {
                DispatchQueue.main.async {
                    if let showSearch = showSearch, !showSearch {
                        self.searchBarHeight.constant = 0.0
                    }
                    
                    if !backText.isEmpty || !doneText.isEmpty {
                        self.bottomButtonViewHeight.constant = 75.0
                        self.buttonView.setProperties(showBack: !backText.isEmpty, backBtnTitle: backText, showNext: !doneText.isEmpty, nextBtnTitle: doneText, delegate: self)
                    }
                }
            }
        }
    }
    
    // MARK: - LOVOptionCellDelegate
    
    func buttonSelectAction(tag: NSInteger, btn: UIButton) {
        
        let obj = self.searchOptionArray![tag - LOV_TAG]
        
        if lovType == .Other {
            self.optionArray = self.optionArray!.map({(item) -> DropDown in
                item.isSelectedFlag = (obj.code == item.code && obj.name == item.name)
                return item
            })
            
            self.searchOptionArray = self.searchOptionArray!.map { (item) -> DropDown in
                item.isSelectedFlag = (obj.code == item.code && obj.name == item.name)
                return item
            }
            
            self.tableView.reloadData()
            
            delegate?.selectedLOV(selectedObj: obj)
        }
        else {
            delegate?.selectedLOV(selectedObj: obj)
            navigationController?.popViewController(animated: true)
        }
    }
}


extension LOVListVC: UITableViewDelegate, UITableViewDataSource  {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.searchOptionArray?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let tempDic = self.searchOptionArray?[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "LOVOptionCell", for: indexPath) as! LOVOptionCell
        cell.setProperties(title: tempDic?.displayValue ?? "", isSelected: tempDic?.isSelectedFlag ?? false, delegate: self)
        cell.tag = LOV_TAG + indexPath.row
        return cell
    }
    
}
extension LOVListVC: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        handleSearchResult()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        handleSearchResult()
    }
    
    //on keyboard clear button this method is called
    func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool {
        handleSearchResult()
        return true
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        searchBar.resignFirstResponder()
        handleSearchResult()
    }
    
    private func handleSearchResult() {
        if let text = searchBar.text, !text.isEmpty {
            self.searchOptionArray = self.optionArray?.filter { ($0.displayValue.lowercased().contains(text.lowercased()))}
        }
        else {
            self.searchOptionArray = self.optionArray
        }
        
        tableView.reloadData()
    }
}

extension LOVListVC: NextBackButtonDelegate {
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
    
    func nextButtonAction() {
        if let obj = self.searchOptionArray!.filter({ $0.isSelectedFlag == true }).first {
            delegate?.selectedLOV(selectedObj: obj)
        }
    }
}
