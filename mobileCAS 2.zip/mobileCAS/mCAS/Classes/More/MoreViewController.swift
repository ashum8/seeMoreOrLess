//
//  MoreViewController.swift
//  mCAS
//
//  Created by iss on 22/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class MoreViewController: UIViewController {
    
    fileprivate var moreButtonsArray: [ButtonModel]!
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        if !AppDelegate.instance.mainMenuArray.isEmpty {
            let last = Int(Constants.bottomTabsCount)-1
            let indexesToBeRemoved = [Int](0...last)
            
            moreButtonsArray = AppDelegate.instance.mainMenuArray.enumerated().filter { !indexesToBeRemoved.contains($0.offset) }.map { $0.element }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.changeTabButtonSelection(id: UserRoles.MORE)
            bottomView.isHidden = false
            
            headerView.setTitleWith(line1: "More Options", showBack: false)
        }
    }
}

extension MoreViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.moreButtonsArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MoreButtonCell", for: indexPath) as! MoreButtonCell
        cell.setCellProperties(btnModel: self.moreButtonsArray[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let btnModel = self.moreButtonsArray[indexPath.row]
        AppDelegate.instance.tabsButtonAction(tabID: btnModel.buttonID)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let availableWidth = (view.frame.width/3)
        return CGSize(width: availableWidth, height: availableWidth)
    }
    
}
