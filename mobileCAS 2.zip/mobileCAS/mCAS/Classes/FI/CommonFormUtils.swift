//
//  CommonFormUtils.swift
//  mCAS
//
//  Created by iMac on 22/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//
import Foundation

class CommonFormUtils: NSObject {
    
    private static var instance: CommonFormUtils?
    
    static func shared() -> CommonFormUtils{
        if instance == nil {
            instance = CommonFormUtils()
        }
        return instance!
    }
    
    func setupHeadingLabel(title: String, font: UIFont = CustomFont.shared().GETFONT_REGULAR(16), isMandatory: Bool = false, bgColor: UIColor = .clear)-> UILabel {
        let label = UILabel()
        label.font = font
        label.textColor = .darkGray
        label.backgroundColor = bgColor
        
        let formattedString = NSMutableAttributedString()
        if isMandatory {
            formattedString
                .attributedText(title, color: .gray, font: font)
                .attributedText("*",color: Color.RED ,font: font)
        }
        else {
            formattedString
                .attributedText(title, color: .gray, font: font)
        }
        label.attributedText = formattedString
        return label
    }
    
    func setupMultiFormButton(dataObj: FIModelClasses.DynamicVerificationTypeVOList, tag: Int, font: UIFont = CustomFont.shared().GETFONT_REGULAR(16)) -> UIButton {
        let btn = UIButton()
        btn.setCornerRadius()
        btn.layer.borderWidth = 1
        btn.titleLabel?.font = font
        btn.setTitleColor(Color.BLUE, for: .normal)
        btn.layer.borderColor = Color.BLUE.cgColor
        btn.backgroundColor = .white
        btn.accessibilityIdentifier = dataObj.fieldId
        btn.setTitle("+ \(dataObj.fieldLabel!)", for: .normal)
        return btn
    }
    
    func setupCustomTextView(dataObj: FIModelClasses.DynamicVerificationTypeVOList, tag: Int, delegate:CustomTFViewDelegate? = nil, unitText:String = "", type: FieldType = .Text) -> UIView {
        
        let view = CustomTextFieldView()
        view.accessibilityIdentifier = dataObj.fieldId
        view.setProperties(placeHolder: "Enter \(dataObj.fieldLabel!)", type: type, delegate: delegate,unitText: unitText, tag: tag, enabled: dataObj.isFieldDisabled == "Y" ? false : true)
        view.tag = tag
        return view
    }
    
    func setupCustomLOVView(dataObj: FIModelClasses.DynamicVerificationTypeVOList, tag: Int, delegate:SelectedLOVDelegate, autoFillValue: String, lovData:FIModelClasses.FIVData) -> UIView {
        let view = LOVFieldView()
        view.tag = tag
        view.accessibilityIdentifier = dataObj.fieldId
        view.setLOVProperties(title: dataObj.fieldLabel!, tag: tag, autoFillValue: autoFillValue, delegate: delegate, optionArray: genrateLOVDropDownArray(queryType: dataObj.controlQuery!, fiData: lovData), enable: dataObj.isFieldDisabled == "Y" ? false : true)
        return view
    }
    
    func setupCustomPhoneView(dataObj: FIModelClasses.DynamicVerificationTypeVOList, tag: Int, delegate:SelectedLOVDelegate) -> UIView {
        
        let view = CustomPhoneNumberView()
        view.accessibilityIdentifier = dataObj.fieldId
        view.setProperties(tag: tag, delegate: delegate)
        view.tag = tag
        return view
    }
    
    func setupCustomMobileView(dataObj: FIModelClasses.DynamicVerificationTypeVOList, tag: Int, delegate:SelectedLOVDelegate) -> UIView {
        
        let view = CustomMobileNumberView()
        view.accessibilityIdentifier = dataObj.fieldId
        view.setProperties(tag: tag, delegate: delegate)
        view.tag = tag
        return view
    }
    
    
    private func genrateLOVDropDownArray(queryType: String, fiData: FIModelClasses.FIVData) ->[DropDown] {
        var dropdownArray: [DropDown] = []
        if let arrayObj = fiData.verificationMasterDetailVOList , !arrayObj.isEmpty {
            let dictObj = arrayObj.filter({$0.parentKey == queryType})
            if let arrayKeyValue = dictObj.first?.keyValuePairs , !arrayKeyValue.isEmpty {
                dropdownArray = arrayKeyValue.map({ DropDown(code: $0.key!, name: $0.value!)})
            }
        }
        
        return dropdownArray
    }
}
