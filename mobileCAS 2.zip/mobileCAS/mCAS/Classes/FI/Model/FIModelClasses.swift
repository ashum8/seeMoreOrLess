//
//  File.swift
//  mCAS
//
//  Created by iMac on 21/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import Foundation

class FIModelClasses {
    
    struct FIVData : Codable {
        var dynamicVerificationTypeVOList : [DynamicVerificationTypeVOList]?
        let loanFieldVerificationDetailVOList : [LoanFieldVerificationDetailVOList]?
        let verificationMasterDetailVOList : [VerificationMasterDetailVOList]?
    }
    
    struct DynamicVerificationTypeVOList : Codable {
        let verificationType : String?
        let fieldLabel : String?
        let fieldType : String?
        let fieldName : String?
        let fieldId : String?
        let fieldLength : String?
        let isFieldMandatory : String?
        let isFieldDisabled : String?
        var fieldValue : String?
        let controlType : String?
        let controlQuery : String?
        let groupId : String?
        let groupDescription : String?
        let productType : String?
        let multiEntryDynamicFormVOList : [DynamicVerificationTypeVOList]?
        
    }
    
    struct LoanFieldVerificationDetailVOList : Codable {
        let loanVerificationCategoryVOList : [LoanVerificationCategoryVOList]?
    }
    
    struct LoanVerificationCategoryVOList : Codable {
        let applicationId : String?
        let customerId : String?
        let theFIVType : String?
        let theFIInitDetailId : String?
        let verificationNameKey : String?
        let verificationStatus : String?
        let customerName : String?
        let productType : String?
        let productTypeDesc : String?
        let customerAddressVO : CustomerAddressVO?
    }
    
    struct CustomerAddressVO : Codable {
        let phone : String?
        let fivAddressDetailVOList : [FivAddressDetailVOList]?
    }
    
    struct FivAddressDetailVOList : Codable {
        let addressType : String?
        let address : String?
        let city : String?
        let state : String?
        let country : String?
        let zipCode : String?
        let districtName : String?
        
    }
    
    struct VerificationMasterDetailVOList : Codable {
        let verificationType : String?
        let parentKey : String?
        let keyValuePairs : [KeyValuePairs]?
    }
    
    struct KeyValuePairs : Codable {
        let key : String?
        let value : String?
        
    }
    
    struct AddressListModel {
        let name: String
        let addressType: String
        let address: String
        let addressDistance: String
    }
}
