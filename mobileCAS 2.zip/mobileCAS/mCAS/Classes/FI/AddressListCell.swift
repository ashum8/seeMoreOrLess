//
//  AddressListCell.swift
//  mCAS
//
//  Created by iMac on 06/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddressListCell: UITableViewCell {
    
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var addressTypeLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var distanceLabel: UILabel!
    @IBOutlet weak var directionButton: UIButton!
    @IBOutlet weak var uploadButton: UIButton!
    @IBOutlet weak var submitButton: UIButton!
    @IBOutlet weak var buttonView: UIView!
    @IBOutlet weak var callButton: UIButton!
    @IBOutlet weak var dividerView: UIView!
    
    
    func setProperties(dataObj: FIModelClasses.AddressListModel) {
        bgView.setShadow()
        bgView.setCornerRadius()
        buttonView.setCornerRadius()
        
        dividerView.backgroundColor = Color.LIGHTER_GRAY
        nameLabel.font = CustomFont.shared().GETFONT_MEDIUM(19)
        addressTypeLabel.font = CustomFont.shared().GETFONT_MEDIUM(19)
        
        addressLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        distanceLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        
        directionButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(16)
        
        uploadButton.setCornerRadius()
        uploadButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(19)
        uploadButton.backgroundColor = Color.BLUE
        uploadButton.setTitleColor(.white, for: .normal)
        
        submitButton.setCornerRadius()
        submitButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(19)
        submitButton.backgroundColor = .lightGray
        submitButton.setTitleColor(.white, for: .normal)
        
        callButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(16)
        callButton.layer.cornerRadius = 13
        callButton.layer.borderColor = Color.GREEN.cgColor
        callButton.layer.borderWidth = 1
        
        nameLabel.text = dataObj.name
        addressTypeLabel.text = dataObj.addressType
        if dataObj.addressDistance.isEmpty {
            distanceLabel.text = ""
        }
        else {
            distanceLabel.text = dataObj.addressDistance + " away"
        }
        addressLabel.text = dataObj.address
        
    }
}
