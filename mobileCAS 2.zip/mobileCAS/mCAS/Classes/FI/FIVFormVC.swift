//
//  FIVFormVC.swift
//  mCAS
//
//  Created by iMac on 20/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

protocol FIVFormDelegate {
    func filledForm(fillDetailArr: [[String: Any]], identifier: String, subForm: Int)
}

class FIVFormVC: UIViewController {
    
    @IBOutlet weak var applicationDetailView: UIView!
    @IBOutlet weak var applicationDetailViewHeight: NSLayoutConstraint!
    @IBOutlet weak var detailSatckView: UIStackView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    @IBOutlet weak var formView: UIView!
    @IBOutlet weak var formViewHeight: NSLayoutConstraint!
    @IBOutlet weak var formStackView: UIStackView!

    private var delegate: FIVFormDelegate?
    private struct FIUserDetail  {
        let title: String
        let imageName: String
    }
    
    private var userDetailArray: [FIUserDetail] = []
    private var selectedLOVDic: [String: DropDown] = [:]
    private var FIVData: FIModelClasses.FIVData!
    private var dataObj: FIModelClasses.LoanVerificationCategoryVOList!
    private var fieldData: [FIModelClasses.DynamicVerificationTypeVOList]!
    private var subForm: Int = 0
    private var buttonIdentifier: String!
    
    private let BASE_TAG = 10000
    private let NO_OF_ATTEMPT_TAG = 1000
    private let REMARKS_TAG = 1001
    private let RESULT_TAG = 1002
    
    private var attemptsView = CustomTextFieldView()
    private var remarksView = CustomTextFieldView()
    
    private var dynamicFieldsValue = [[String: Any]]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupDetailView()
//        fetchOnlineFormData()
        setDynamicForm()
    }
    private var heightOfView:CGFloat = 0.0
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            let navArray = AppDelegate.instance.applicationNavController.viewControllers
            let lastVC = navArray[navArray.count-2]
            var title = ""
            if let dataArr = FIVData?.loanFieldVerificationDetailVOList, !dataArr.isEmpty {
                title = dataArr.first?.loanVerificationCategoryVOList?.first?.customerName ?? ""
            }
            print(subForm)
            if subForm > 0 {
                headerView.setTitleWith(line1: title, showBack: true)
            }
            else {
            headerView.showHideStepHeader(isHide: false, title: title, landingPage: lastVC)
            }
        }
    }
    
    func setData(FIVData: FIModelClasses.FIVData, fieldData: [FIModelClasses.DynamicVerificationTypeVOList], data: FIModelClasses.LoanVerificationCategoryVOList? = nil, isSubForm: Int = 0, fivFormDelegate: FIVFormDelegate? = nil, identifier: String = "") {
        self.FIVData = FIVData
        self.dataObj = data
        self.subForm = isSubForm
        self.fieldData = fieldData
        self.delegate = fivFormDelegate
        self.buttonIdentifier = identifier
    }
    
    private func setupDetailView(showAll: Bool = true) {
        if subForm > 0 {
            buttonView.setProperties(showNext: true, nextBtnTitle: "Add", delegate: self)
            applicationDetailViewHeight.constant = 0
        }
        else {
            buttonView.setProperties(showNext: true, nextBtnTitle: "Continue", delegate: self)
            applicationDetailView.backgroundColor = Color.BLUE
            userDetailArray.removeAll()
            if showAll {
                userDetailArray.append(FIUserDetail(title: self.dataObj.applicationId ?? "", imageName: "address_icon"))
                userDetailArray.append(FIUserDetail(title: self.dataObj.verificationNameKey ?? "", imageName: "address_icon"))
            }
            
            if let addrs = dataObj.customerAddressVO, let addrsArray = addrs.fivAddressDetailVOList, !addrsArray.isEmpty {
                
                userDetailArray.append(FIUserDetail(title: "\(addrsArray.first?.address ?? ""),\(addrsArray.first?.city  ?? ""),\(addrsArray.first?.state  ?? ""),\(addrsArray.first?.country  ?? ""),\(addrsArray.first?.zipCode  ?? "")", imageName: "address_icon"))
            }
            
            for (_, item) in userDetailArray.enumerated() {
                let view = CustomUserDetailView()
                view.setProperties(title:item.title, imageName: item.imageName)
                detailSatckView.addArrangedSubview(view)
            }
            
            applicationDetailViewHeight.constant = CGFloat(userDetailArray.count*38 + 40)
        }
    }
    
    private func setDynamicForm() {
        
        var groupIDArray = self.fieldData?.map({ $0.groupId }) ?? []
        groupIDArray = groupIDArray.distinctElements
        for (i,item) in groupIDArray.enumerated() {
            let groupId = item
            let arrayByGroupId = self.fieldData?.filter({ $0.groupId == groupId }) ?? []
            let label = CommonFormUtils.shared().setupHeadingLabel(title: arrayByGroupId.first!.groupDescription!, font: CustomFont.shared().GETFONT_MEDIUM(16), bgColor: Color.EXTREME_LIGHT_GRAY)
            formStackView.addArrangedSubview(label)
            formStackView.addConstraint(NSLayoutConstraint(item: label, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: 35))
            heightOfView += 35
            let tagVal = BASE_TAG*(i+1)
            for (index,obj) in arrayByGroupId.enumerated() {
                
                let label = CommonFormUtils.shared().setupHeadingLabel(title: obj.fieldLabel ?? "", isMandatory: (obj.isFieldMandatory ?? "" == "Y") ? true : false)
                formStackView.addArrangedSubview(label)
                formStackView.addConstraint(NSLayoutConstraint(item: label, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: 35))
                
                let componentTag = tagVal + index
                var height:CGFloat = 0.0
                switch obj.controlType {
                case "TB":
                    let view = CommonFormUtils.shared().setupCustomTextView(dataObj: obj, tag: componentTag, delegate: self)
                    height = 65
                    formStackView.addArrangedSubview(view)
                    formStackView.addConstraint(NSLayoutConstraint(item: view, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: height))
                    
                case "LOV":
                    let view = CommonFormUtils.shared().setupCustomLOVView(dataObj: obj, tag: componentTag, delegate: self, autoFillValue: "", lovData: FIVData)
                    height = 65
                    formStackView.addArrangedSubview(view)
                    formStackView.addConstraint(NSLayoutConstraint(item: view, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: height))
                    
                case "TELE":
                    let view = CommonFormUtils.shared().setupCustomPhoneView(dataObj: obj, tag: componentTag, delegate: self)
                    height = 65
                    formStackView.addArrangedSubview(view)
                    formStackView.addConstraint(NSLayoutConstraint(item: view, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: height))
                    
                case "CURR":
                    let view = CommonFormUtils.shared().setupCustomTextView(dataObj: obj, tag: componentTag, delegate: self, type: .Amount)
                    height = 65
                    formStackView.addArrangedSubview(view)
                    formStackView.addConstraint(NSLayoutConstraint(item: view, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: height))
                    
                case "CAL":
                    let view = CommonFormUtils.shared().setupCustomTextView(dataObj: obj, tag: componentTag, delegate: self, type: .DATE)
                    height = 65
                    formStackView.addArrangedSubview(view)
                    formStackView.addConstraint(NSLayoutConstraint(item: view, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: height))
                    
                case "MOB":
                    let view = CommonFormUtils.shared().setupCustomMobileView(dataObj: obj, tag: componentTag, delegate: self)
                    height = 65
                    formStackView.addArrangedSubview(view)
                    formStackView.addConstraint(NSLayoutConstraint(item: view, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: height))
                    
                case "MUL_ENTRY":
                    let valueView = UIView()
                    valueView.layer.borderColor = Color.BLUE.cgColor
                    valueView.layer.borderWidth = 1
                    valueView.setCornerRadius()
                    valueView.tag = componentTag
                    valueView.accessibilityIdentifier = obj.fieldId! + "View"
                    height = 5
                    formStackView.addArrangedSubview(valueView)
                    formStackView.addConstraint(NSLayoutConstraint(item: valueView, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: height))
                    
                    let btn = CommonFormUtils.shared().setupMultiFormButton(dataObj: obj, tag: componentTag)
                    btn.addTarget(self, action: #selector(multiFormAction(_:)), for: .touchUpInside)
                    height = 35
                    formStackView.addArrangedSubview(btn)
                    formStackView.addConstraint(NSLayoutConstraint(item: btn, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: height))
                    
                default:
                   break
                }

                heightOfView += 35 + height

                
            }
        }
        
        //        making static fields
        
        if subForm == 0 {
            let headingLabel = CommonFormUtils.shared().setupHeadingLabel(title: "Decision", font: CustomFont.shared().GETFONT_MEDIUM(16), bgColor: Color.EXTREME_LIGHT_GRAY)
            formStackView.addArrangedSubview(headingLabel)
            formStackView.addConstraint(NSLayoutConstraint(item: headingLabel, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: 35))
            heightOfView += 35
            
            //No. Of Attempts
            let label = CommonFormUtils.shared().setupHeadingLabel(title: "No. Of Attempts", isMandatory: true)
            formStackView.addArrangedSubview(label)
            formStackView.addConstraint(NSLayoutConstraint(item: label, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: 35))
            
            attemptsView = CustomTextFieldView()
            attemptsView.setProperties(placeHolder: "Enter Value", delegate: self, tag:NO_OF_ATTEMPT_TAG)
            
            formStackView.addArrangedSubview(attemptsView)
            formStackView.addConstraint(NSLayoutConstraint(item: attemptsView, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: 65))
            heightOfView += 35 + 65
            //remarks
            let label1 = CommonFormUtils.shared().setupHeadingLabel(title: "Remarks")
            formStackView.addArrangedSubview(label1)
            formStackView.addConstraint(NSLayoutConstraint(item: label1, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: 35))
            
            remarksView = CustomTextFieldView()
            remarksView.setProperties(placeHolder: "Enter Value", delegate: self, tag:REMARKS_TAG)
            
            formStackView.addArrangedSubview(remarksView)
            formStackView.addConstraint(NSLayoutConstraint(item: remarksView, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: 65))
            heightOfView += 35 + 65
            //result
            let label2 = CommonFormUtils.shared().setupHeadingLabel(title: "Result", isMandatory: true)
            formStackView.addArrangedSubview(label2)
            formStackView.addConstraint(NSLayoutConstraint(item: label2, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: 35))
            
            let view2 = LOVFieldView()
            var resultArr = [DropDown]()
            resultArr.append(DropDown(code: "SEL", name: "Select"))
            resultArr.append(DropDown(code: "NEUTRAL", name: "Neutral"))
            resultArr.append(DropDown(code: "POSITIVE", name: "Positive"))
            resultArr.append(DropDown(code: "NEGATIVE", name: "Negative"))
            view2.setLOVProperties(title: "Result", tag: RESULT_TAG, delegate: self, optionArray: resultArr)
            view2.tag = RESULT_TAG
            formStackView.addArrangedSubview(view2)
            formStackView.addConstraint(NSLayoutConstraint(item: view2, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: 65))
            heightOfView += 35 + 65
            
        }
        formViewHeight.constant = heightOfView
    }
   
     @objc func multiFormAction(_ sender: UIButton) {
           
        let arr = fieldData.filter({$0.fieldId == sender.accessibilityIdentifier})
        print(arr.count)
        let data = arr.first?.multiEntryDynamicFormVOList ?? []
        let st = UIStoryboard.init(name: Storyboard.FI, bundle: nil)
        if let vc = st.instantiateViewController(withIdentifier: "FIVFormVC") as? FIVFormVC {
            vc.setData(FIVData: FIVData, fieldData: data, isSubForm: (subForm + 1), fivFormDelegate: self, identifier: sender.accessibilityIdentifier!)
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
    
    @IBAction func showHideDetailButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        detailSatckView.removeAllSubviews()
        setupDetailView(showAll: !sender.isSelected)
    }
    
    private func saveFormData() {
        
        let params: [String: Any] = ["applicationId"    : self.dataObj.applicationId!,
                                     "customerId"  : self.dataObj.applicationId!,
                                     "loanFIVId": "",
                                     "loanFIVSequenceId": "",
                                     "verificationType" : self.dataObj.verificationNameKey!,
                                     "decision" : attemptsView.getFieldValue(),
                                     "remarks" : remarksView.getFieldValue(),
                                     "createdBy" : "",
                                     "investigationType" : "",
                                     "fivAddress" : userDetailArray.last?.title ?? "",
                                     "dynamicFieldSets" : dynamicFieldsValue]
        print(params)
        Webservices.shared().POST(urlString: ServiceUrl.SAVE_DATA_FI_URL, paramaters: params, autoHandleLoader: true, success: { (header, responseObj) in
            print(responseObj)
            if let response = responseObj as? [String: Any]
            {
                if let isCompleted = response["completed"] as? Int , isCompleted == 1 {
                    CommonAlert.shared().showAlert(message: "Fiv Data Sync Successfully.", okTitle: "OK", okAction: { _ in
                        self.navigationController?.popViewController(animated: true)
                    })
                }
                
            }
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
            
        })
    }
    
}


extension FIVFormVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        
        for view in formStackView.subviews {
            let identifier = view.accessibilityIdentifier
            let dataArr = self.fieldData.filter({ $0.fieldId == identifier})
            if let vw = view as? CustomTextFieldView {
                if !dataArr.isEmpty {
                    let mandateField = dataArr.first?.isFieldMandatory == "Y" ? true : false
                    if mandateField && vw.getFieldValue().isEmpty {
                        CommonAlert.shared().showAlert(message: "Please Enter \(dataArr.first?.fieldLabel ?? "")")
                        return
                    }
                    else {
                        self.removeExistingValue(identifier: identifier!)
                        var dict = [String: Any]()
                        dict["fieldId"] = identifier
                        dict["fieldValue"] = vw.getFieldValue()
                        dynamicFieldsValue.append(dict)
                        print(vw.getFieldValue())
                    }
                }
            }
            else if let vw = view as? LOVFieldView {
                if !dataArr.isEmpty {
                    let mandateField = dataArr.first?.isFieldMandatory == "Y" ? true : false
                    if mandateField && (selectedLOVDic["\(vw.tag)"]?.name == nil) {
                        CommonAlert.shared().showAlert(message: "Please Enter \(dataArr.first?.fieldLabel ?? "")")
                        return
                    }
                    else {
                        self.removeExistingValue(identifier: identifier!)
                        var dict = [String: Any]()
                        dict["fieldId"] = identifier
                        dict["fieldValue"] = (selectedLOVDic["\(vw.tag)"]?.name == nil) ? "" : selectedLOVDic["\(vw.tag)"]?.name
                        dynamicFieldsValue.append(dict)
                    }
                }
            }
        }
        if subForm == 0 {
            if attemptsView.getFieldValue().isEmpty {
                CommonAlert.shared().showAlert(message: "Please Enter no of attempts")
                return
            }
            else if selectedLOVDic["\(RESULT_TAG)"] == nil {
                CommonAlert.shared().showAlert(message: "Please Enter result")
                return
            }
        }
        print(dynamicFieldsValue)
        if subForm > 0 {
            delegate?.filledForm(fillDetailArr: dynamicFieldsValue, identifier: buttonIdentifier, subForm: subForm)
            self.navigationController?.popViewController(animated: true)
        }
        else {
            CommonAlert.shared().showAlert(message: "Are you sure you want to save?", okTitle: "OK", cancelTitle: "NO", okAction: { _ in
                
                self.saveFormData()
            })
        }
        
    }
    
    private func removeExistingValue(identifier: String) {
        dynamicFieldsValue = dynamicFieldsValue.filter({
            return ($0["fieldId"] as? String ?? "" != identifier)
        })
    }
}

extension FIVFormVC: SelectedLOVDelegate {
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
    }
}


extension FIVFormVC: CustomTFViewDelegate {
    func validateFields() {
        print("hdgsjfhgh")
    }

    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        if tag == NO_OF_ATTEMPT_TAG {
            return text.count == 1 && text.isNumeric
        }
        else if tag == REMARKS_TAG {
            return text.count < Constants.REMARKS_LENGTH && text.isAlphanumericAndSpace
        }
        else {
            let editingView = formStackView.subviews.filter{$0.tag == tag}.first
            if  let view = editingView?.viewWithTag(tag) as? CustomTextFieldView {
                print(view.accessibilityIdentifier!)
                return getValidationFromData(identifier: view.accessibilityIdentifier ?? "", text: text)
            }
        }
        return true
    }
    
    func getValidationFromData(identifier: String, text: String) -> Bool {
        let dataArr = self.fieldData.filter({ $0.fieldId == identifier})
        if !dataArr.isEmpty {
            let fieldType = dataArr.first?.fieldType
            let fieldLength = dataArr.first?.fieldLength
            var validate = true
            if fieldType == "AN" {
                validate = text.isAlphanumericAndSpace
            }
            else if fieldType == "NUMBER" {
                validate = text.isNumeric
            }
            else if fieldType == "MOB" {
                validate = text.isNumeric
            }
            return validate && text.count <= Int(fieldLength ?? "0")!
        }
        return true
    }
}


extension FIVFormVC: FIVFormDelegate {
    func filledForm(fillDetailArr: [[String : Any]], identifier: String, subForm: Int) {
        self.removeExistingValue(identifier: identifier)
        var dict = [String: Any]()
        dict["fieldId"] = identifier
        dict["fieldValue"] = fillDetailArr
        dynamicFieldsValue.append(dict)
        
        self.subForm = subForm - 1
        print(subForm)
        
        for view in formStackView.subviews {
            if view.accessibilityIdentifier == "\(identifier)View" {
                let stackView = UIStackView()
                view.addSubview(stackView)
                for item in fillDetailArr {
                    let keyValueView = KeyValueFormView()
                    keyValueView.setProperties(key: item["fieldId"] as? String ?? "", value: item["fieldValue"] as? String ?? "")
                    stackView.addArrangedSubview(keyValueView)
                }
                view.removeAllConstraints()
                view.frame = CGRect(x: view.frame.origin.x, y: view.frame.origin.y, width: view.frame.size.width, height: CGFloat(fillDetailArr.count*35))
                heightOfView = heightOfView + CGFloat(fillDetailArr.count*35)
                formViewHeight.constant = heightOfView
            }
        }
    }
}
