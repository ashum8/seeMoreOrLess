//
//  KeyValueFormView.swift
//  mCAS
//
//  Created by iMac on 23/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class KeyValueFormView: UIView {

    @IBOutlet weak var keyLabel: UILabel!
    @IBOutlet weak var valueLabel: UILabel!
    
    @IBOutlet weak var containerView: UIView!
    override init(frame: CGRect) {
          super.init(frame: frame)
          commonInit()
      }
      
      required init?(coder aDecoder: NSCoder) {
          super.init(coder: aDecoder)
          commonInit()
      }
      
      private func commonInit() {
          Bundle.main.loadNibNamed("KeyValueFormView", owner: self, options: nil)
          containerView.fixInView(self)
          self.layer.masksToBounds = true
      }
    
    func setProperties(key: String, value: String) {
        self.backgroundColor = .clear
        
        self.keyLabel.textColor = .gray
        self.valueLabel.textColor = .gray
        
        self.keyLabel.font = CustomFont.shared().GETFONT_REGULAR(16)
        self.valueLabel.font = CustomFont.shared().GETFONT_REGULAR(16)

        keyLabel.text = key
        valueLabel.text = value
    }
    
}
