//
//  FISearchResultVC.swift
//  mCAS
//
//  Created by iMac on 23/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class FISearchResultVC: UIViewController {
    
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    @IBOutlet weak var tableView: UITableView!
    private var FIVData: FIModelClasses.FIVData!
    private var listModelArray = [FIModelClasses.LoanVerificationCategoryVOList]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        noDataCapturedView.setProperties()
        tableView.register(UINib(nibName: "CasesCell", bundle: nil), forCellReuseIdentifier: "CasesCell")
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            headerView.setTitleWith(line1: "Search Result", showBack: true)
            bottomView.isHidden = true
        }
    }
    
    func setData(FIVData: FIModelClasses.FIVData, data: [FIModelClasses.LoanVerificationCategoryVOList]) {
        self.FIVData = FIVData
        self.listModelArray = data
    }
    
    
}

extension FISearchResultVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listModelArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CasesCell") as! CasesCell
        
        let model = listModelArray[indexPath.row]
        cell.label1.text = model.customerName
        cell.label2.text = model.applicationId
        if let customerAddressList = model.customerAddressVO?.fivAddressDetailVOList {
            cell.label3.text = "\(customerAddressList.count) verifications required"
        }
        
        cell.loanTypeLabel.text = model.productTypeDesc
        cell.label3.textColor = .orange
        cell.setProperties(cellIndex: indexPath.row, customerType: Constants.CUSTOMER_TYPE_INDV, showArrow: true, productTypeCode: model.productType)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let st = UIStoryboard.init(name: Storyboard.FI, bundle: nil)
        if let vc = st.instantiateViewController(withIdentifier: "AddressListVC") as? AddressListVC {
            vc.setData(FIVData: FIVData, data: listModelArray[indexPath.row])
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
}
