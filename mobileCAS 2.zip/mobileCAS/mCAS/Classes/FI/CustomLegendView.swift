//
//  CustomLegendView.swift
//  mCAS
//
//  Created by iMac on 06/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

struct LegendModel {
    var bgColor: UIColor
    var title: String
}

protocol CustomLegendViewDelegate {
    func showHideList(show: Bool)
}

class CustomLegendView: UIView {
    
    @IBOutlet var containerVw: UIView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var showHideButton: UIButton!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var bgView: UIView!
    
    private var delegate: CustomLegendViewDelegate?
    private var listModelArray = [LegendModel]()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("CustomLegendView", owner: self, options: nil)
        containerVw.fixInView(self)
        
        tableView.register(UINib(nibName: "LegendsTableViewCell", bundle: nil), forCellReuseIdentifier: "LegendsTableViewCell")
    }
    
    func setupProperties(arr: [LegendModel], delegate: CustomLegendViewDelegate) {
        
        bgView.layer.cornerRadius = 8
        self.layer.cornerRadius = 8
        self.setShadow()
        self.delegate = delegate
        
        listModelArray = arr
        showHideButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(19)
        showHideButton.semanticContentAttribute = .forceRightToLeft
        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(19)
        
        DispatchQueue.main.async {
            self.showHideButton.sendActions(for: .touchUpInside)
        }
    }
    
    @IBAction func showHideButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        delegate?.showHideList(show: sender.isSelected)
    }
}

extension CustomLegendView: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listModelArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "LegendsTableViewCell", for: indexPath) as! LegendsTableViewCell
        cell.setProperties(dataObj: listModelArray[indexPath.row])
        return cell
    }
}
