//
//  DashboardTableCell.swift
//  mCAS
//
//  Created by iss on 04/03/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class DashboardTableCell: UITableViewCell {
    
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var iconImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.bgView.setCornerRadius()
        self.bgView.layer.masksToBounds = true
        self.bgView.layer.borderColor = UIColor.lightGray.cgColor
        self.bgView.layer.borderWidth = 0.5
        
        self.titleLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
    }
    
    func setCellProperties(btnModel: ButtonModel) {
        self.iconImageView.image = UIImage(named: btnModel.buttonImage)
        self.titleLabel.text = btnModel.buttonText
    }
    
}
