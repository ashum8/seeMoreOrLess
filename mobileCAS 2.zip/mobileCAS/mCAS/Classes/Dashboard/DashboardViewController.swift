//
//  DashboardViewController.swift
//  mCAS
//
//  Created by Mac on 20/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class DashboardViewController: UIViewController {
    
    fileprivate var collectionArray: [ButtonModel]!
    fileprivate var tableArray: [ButtonModel]!
    
    @IBOutlet weak var primaryActionLabel: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var collectionViewHeight: NSLayoutConstraint!
    @IBOutlet weak var topTableView: UIView!
    
    //Dashboard CollectionView Grid
    private let DRAFT_APPLICATIONS          = "DRAFT_APPLICATIONS"
    private let ASSIGNED_LEADS              = "ASSIGNED_LEADS"
    private let ASSIGNED_FI                 = "ASSIGNED_FI"
    private let ASSIGNED_QUERY              = "ASSIGNED_QUERY"
    private let APPLICATIONS_PUNCHED        = "APPLICATIONS_PUNCHED"
    private let RAISED_QUERY                = "RAISED_QUERY"
    
    //Dashboard TableView Grid
    private let CREATE_LEAD                 = "CREATE_LEAD"
    private let CREATE_APPLICATION          = "CREATE_APPLICATION"
    private let CHECK_ELIGIBILITY           = "CHECK_ELIGIBILITY"
    private let RAISE_QUERY                 = "RAISE_QUERY"
    private let RATE_INITIATION             = "RATE_INITIATION"
    private let RATE_APPROVAL               = "RATE_APPROVAL"
    private let STATUS_ENQUIRY              = "STATUS_ENQUIRY"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.view.backgroundColor = Color.LIGHTER_GRAY
        self.primaryActionLabel.font = CustomFont.shared().GETFONT_MEDIUM(17)
        
//        showCollectionGrid()
        setTableViewData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.changeTabButtonSelection(id: UserRoles.HOME_DASHBOARD)
            bottomView.isHidden = false
            
            headerView.showHideDashboardHeader(isHide: false)
            headerView.setTitleWith(showBack: false)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideDashboardHeader(isHide: true)
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        let insetMargin: CGFloat = 15.0
        let spaceMargin: CGFloat = 8.0
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        self.collectionView.collectionViewLayout = layout
        self.collectionView.contentInset = UIEdgeInsets(top: 0, left: insetMargin, bottom:0, right: insetMargin)
        
        if let layout = self.collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.minimumInteritemSpacing = spaceMargin
            layout.minimumLineSpacing = spaceMargin
            layout.itemSize = CGSize(width: (self.collectionView.frame.size.width-(insetMargin*2+spaceMargin))/2, height: (self.collectionView.frame.size.height-spaceMargin)/2)
            layout.invalidateLayout()
        }
    }
    
    private func showCollectionGrid() {
        collectionViewHeight.constant = 200
        
        var frame = self.topTableView.frame
        frame.size.height = 250
        self.topTableView.frame = frame
        
        setCollectionViewData()
        collectionView.delegate = self
        collectionView.dataSource = self
    }
    
    private func setCollectionViewData() {
        let collectionCellData = [DRAFT_APPLICATIONS    : ButtonModel(buttonText: "Draft Applications", buttonID: DRAFT_APPLICATIONS, buttonImage: "dashboard_icon_draft_applications", order: 1),
                                  ASSIGNED_LEADS        : ButtonModel(buttonText: "Assigned Leads", buttonID: ASSIGNED_LEADS, buttonImage: "dashboard_icon_assigned_leads", order: 2),
                                  ASSIGNED_FI           : ButtonModel(buttonText: "Assigned FI", buttonID: ASSIGNED_FI, buttonImage: "dashboard_icon_assigned_fi", order: 3),
                                  ASSIGNED_QUERY        : ButtonModel(buttonText: "Assigned Queries", buttonID: ASSIGNED_QUERY, buttonImage: "dashboard_icon_assigned_query", order: 4),
                                  APPLICATIONS_PUNCHED  : ButtonModel(buttonText: "Applications Punched", buttonID: APPLICATIONS_PUNCHED,  buttonImage: "dashboard_icon_applications_punched", order: 5),
                                  RAISED_QUERY          : ButtonModel(buttonText: "Raised Query", buttonID: RAISED_QUERY, buttonImage: "dashboard_icon_raised_query", order: 6)]
        
        collectionArray = []
        
        for btnModel in AppDelegate.instance.mainMenuArray {
            if btnModel.buttonID == UserRoles.SOURCING, let btnModel = collectionCellData[DRAFT_APPLICATIONS] {
                collectionArray.append(btnModel)
                
                if let btnModel1 = collectionCellData[APPLICATIONS_PUNCHED] {
                    collectionArray.append(btnModel1)
                }
            }
            else if btnModel.buttonID == UserRoles.VIEW_LEAD, let btnModel = collectionCellData[ASSIGNED_LEADS] {
                collectionArray.append(btnModel)
            }
            else if btnModel.buttonID == UserRoles.FIELD_VERIFY, let btnModel = collectionCellData[ASSIGNED_FI] {
                collectionArray.append(btnModel)
            }
            else if btnModel.buttonID == UserRoles.QUERY_MODULE, let btnModel = collectionCellData[ASSIGNED_QUERY] {
                collectionArray.append(btnModel)
                
                if let btnModel1 = collectionCellData[RAISED_QUERY] {
                    collectionArray.append(btnModel1)
                }
            }
        }
    }
    
    private func setTableViewData() {
        let collectionCellData = [CREATE_APPLICATION    : ButtonModel(buttonText: "Create Application", buttonID: CREATE_APPLICATION, buttonImage: "dashboard_icon_create_application", order: 1),
                                  CREATE_LEAD           : ButtonModel(buttonText: "Create Lead", buttonID: CREATE_LEAD, buttonImage: "dashboard_icon_create_lead", order: 2),
                                  RATE_INITIATION       : ButtonModel(buttonText: "Rate Initiation", buttonID: RATE_INITIATION, buttonImage: "dashboard_icon_rate_type_approval", order: 3),
                                  RATE_APPROVAL         : ButtonModel(buttonText: "Rate Approval", buttonID: RATE_APPROVAL, buttonImage: "dashboard_icon_rate_type_approval", order: 4),
                                  STATUS_ENQUIRY        : ButtonModel(buttonText: "File Status", buttonID: STATUS_ENQUIRY, buttonImage: "dashboard_icon_rate_type_approval", order: 5),
//                                  CHECK_ELIGIBILITY   : ButtonModel(buttonText: "Check Eligibility", buttonID: CHECK_ELIGIBILITY, buttonImage: "check_eligibility_icon", order: 3),
//                                  RAISE_QUERY           : ButtonModel(buttonText: "Raise Query", buttonID: RAISE_QUERY, buttonImage: "dashboard_icon_raise_query", order: 4),
        ]
        
        tableArray = []
        
        for btnModel in AppDelegate.instance.mainMenuArray {
            if btnModel.buttonID == UserRoles.SOURCING, let btnModel = collectionCellData[CREATE_APPLICATION] {
                tableArray.append(btnModel)
                
                if let btnModel1 = collectionCellData[CHECK_ELIGIBILITY] {
                    tableArray.append(btnModel1)
                }
            }
            else if btnModel.buttonID == UserRoles.RATE_INITIATION, let btnModel = collectionCellData[RATE_INITIATION] {
                tableArray.append(btnModel)
            }
            else if btnModel.buttonID == UserRoles.RATE_APPROVAL, let btnModel = collectionCellData[RATE_APPROVAL] {
                tableArray.append(btnModel)
            }
            else if btnModel.buttonID == UserRoles.VIEW_LEAD, let btnModel = collectionCellData[CREATE_LEAD] {
                tableArray.append(btnModel)
            }
            else if btnModel.buttonID == UserRoles.QUERY_MODULE, let btnModel = collectionCellData[RAISE_QUERY] {
                tableArray.append(btnModel)
            }
        }
        
        tableArray.sort { $0.order < $1.order }
    }
}

extension DashboardViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return collectionArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DashboardCell", for: indexPath) as! DashboardCell
        cell.setCellProperties(btnModel: collectionArray[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        
    }
}

extension DashboardViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DashboardTableCell", for: indexPath) as! DashboardTableCell
        cell.setCellProperties(btnModel: tableArray[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let btnModel = tableArray[indexPath.row]
        
        switch btnModel.buttonID {
        case CREATE_APPLICATION:
            AppDelegate.instance.tabsButtonAction(tabID: UserRoles.CREATE_APPLICATION)
            break
            
        case CREATE_LEAD:
            AppDelegate.instance.tabsButtonAction(tabID: UserRoles.CAPTURE_LEAD)
            break
            
        case RATE_INITIATION:
            AppDelegate.instance.tabsButtonAction(tabID: UserRoles.RATE_INITIATION)
            break
            
        case RATE_APPROVAL:
            AppDelegate.instance.tabsButtonAction(tabID: UserRoles.RATE_APPROVAL)
            break
            
        case RAISE_QUERY:
            AppDelegate.instance.tabsButtonAction(tabID: RAISE_QUERY)
            break
            
        case STATUS_ENQUIRY:
            AppDelegate.instance.tabsButtonAction(tabID: UserRoles.STATUS_ENQUIRY)
            break
            
        default:
            break
        }
    }
    
}
