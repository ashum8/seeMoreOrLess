//
//  DashboardCell.swift
//  mCAS
//
//  Created by iss on 25/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class DashboardCell: UICollectionViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var iconView: UIImageView!
    
    func setCellProperties(btnModel: ButtonModel) {
        
        self.backgroundColor = .white
        self.setCornerRadius()
        self.layer.borderWidth = 0.5
        self.layer.borderColor = UIColor.lightGray.cgColor
        
        titleLabel.textColor = .darkGray
        countLabel.textColor = .darkGray
        
        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(15)
        countLabel.font = CustomFont.shared().GETFONT_MEDIUM(32)
        
        titleLabel.text = btnModel.buttonText
        countLabel.text = "02"
        iconView.image = UIImage(named: btnModel.buttonImage)
    }
}
