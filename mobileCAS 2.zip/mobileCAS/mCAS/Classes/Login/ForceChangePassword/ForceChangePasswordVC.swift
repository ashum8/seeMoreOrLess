//
//  ForceChangePasswordVC.swift
//  mCAS
//
//  Created by iMac on 06/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//


import UIKit

struct QuestionModel {
    var question: String?
    var answer: String?
    var id: String?
}

class ForceChangePasswordVC: UIViewController {
    
    @IBOutlet weak var staticLavel1: UILabel!
    @IBOutlet weak var staticLavel2: UILabel!
    @IBOutlet weak var setSecurityQuestionStaticLable: EdgeInsetLabel!
    
    @IBOutlet weak var currentPasswordView: CustomTextFieldView!
    @IBOutlet weak var newPasswordView: CustomTextFieldView!
    @IBOutlet weak var confirmNewPassword: CustomTextFieldView!
    @IBOutlet weak var securityQuestionsView: UIView!
    @IBOutlet weak var securityQuestionsStackView: UIStackView!
    @IBOutlet weak var SecurityQuestionsMainVwHeight: NSLayoutConstraint!
    
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private var loaderOverlay: MRProgressOverlayView!
    private var questionAnswerArray: [QuestionModel] = []
    var questionsArray: [[String: Any]]?
    var username: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        setUpView()
        addSubviews()
        validateFields()
    }
    
    private func setUpView() {
        
        staticLavel1.font = CustomFont.shared().GETFONT_MEDIUM(24)
        staticLavel2.font = CustomFont.shared().GETFONT_REGULAR(16)
        setSecurityQuestionStaticLable.font = CustomFont.shared().GETFONT_MEDIUM(17)
        
        currentPasswordView.setProperties(placeHolder: "Current Password", type: .Password, delegate: self)
        newPasswordView.setProperties(placeHolder: "New Password", type: .Password, delegate: self)
        confirmNewPassword.setProperties(placeHolder: "Confirm New Password", type: .Password, delegate: self)
        
        buttonView.setProperties(nextBtnTitle: "Change Password", delegate: self)
    }
    
    private func addSubviews() {       
        
        if let questionArray = questionsArray {
            
            let dropDownQuestionArray = questionArray.map { (item) -> DropDown in
                return DropDown(id: "\(item["id"] ?? "")", code: "\(item["description"] ?? "")", name: "\(item["description"] ?? "")")
            }
            
            questionAnswerArray = []
            
            SecurityQuestionsMainVwHeight.constant = CGFloat(questionArray.count*130)
            setSecurityQuestionStaticLable.isHidden = questionArray.isEmpty
            
            for (index, _) in questionArray.enumerated() {
                questionAnswerArray.append(QuestionModel(question: "", answer: "", id: ""))
                
                let view = QuestionAnswerView()
                view.setQuestionView(index: index, optionArray: dropDownQuestionArray.map{$0.copy() as! DropDown}, delegate: self)
                securityQuestionsStackView.addArrangedSubview(view)
            }
        }
    }
    
    @IBAction func backButtonClicked(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    private func getTokenService()  {
        
        loaderOverlay = MRProgressOverlayView.showOverlayAdded(to: self.view, animated: true)
        loaderOverlay.titleLabelText = NSLocalizedString("Please wait...", comment:"")
        
        Webservices.shared().getTokenFromServer(withSession: true) { (token) in
            if let token = token {
                self.forceChangePasswordService(token: token)
            }
            else {
                self.loaderOverlay.dismiss(true)
            }
        }
    }
    
    private func forceChangePasswordService(token: String) {
        
        let securityAnswers = questionAnswerArray.map { (item) -> [String : String] in
            ["id" : "\(item.id!)", "description" : "\(item.answer!)"]
        }
        
        let encryptedPassword = Cipher.encrypt(newPasswordView.getFieldValue(), withToken: token)
        let encryptedOldPassword = Cipher.encrypt(currentPasswordView.getFieldValue(), withToken: token)
        
        let param = ["oldPassword"      : encryptedOldPassword,
                     "password"         : encryptedPassword,
                     "securityAnswers"  : securityAnswers] as [String : Any]
        
        Webservices.shared().POST(urlString: ServiceUrl.FORCE_CHANGE_PASSWORD_URL, paramaters: param, success: { (header ,responseObj) in
            
            Webservices.shared().logoutFromServer(username: self.username, allowOfflineAlert: false) { _ in }
            
            let storyboard = UIStoryboard.init(name: Storyboard.MAIN, bundle: nil)
            
            if let vc = storyboard.instantiateViewController(withIdentifier: "PasswordSentVC") as? PasswordSentVC {
                vc.fromChangePassword = true
                self.navigationController?.pushViewController(vc, animated: false)
            }
            
            self.loaderOverlay.dismiss(true)
            
        }, failure: { (error) in
            
            self.loaderOverlay.dismiss(true)
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
            self.loaderOverlay.dismiss(true)
        })
    }
    
    private func validateSecurityQuestions(question: String, tag: Int) -> Bool {
        
        for i in 0 ..< questionAnswerArray.count {
            if (questionAnswerArray[i].question ?? "" == question && tag != i) {
                return false
            }
        }
        return true
    }
}

extension ForceChangePasswordVC: QuesAnsDelegate {
    
    func setLOVValue(answer: String?, selectedLOV: DropDown?, tag: Int, isAnswering: Bool) {
        
        if isAnswering {
            questionAnswerArray[tag].answer = answer
        }
        else {
            if let selectedLOV = selectedLOV {
                if validateSecurityQuestions(question: selectedLOV.code, tag: tag) {
                    questionAnswerArray[tag].question = selectedLOV.code
                    questionAnswerArray[tag].id = selectedLOV.id
                    
                    if let view = self.securityQuestionsStackView.arrangedSubviews[tag] as? QuestionAnswerView {
                        view.questionView.setLOVText(selectedObj: selectedLOV)
                    }
                }
                else {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        CommonAlert.shared().showAlert(message: NSLocalizedString("Security questions can not be same", comment: ""))
                    }
                }
            }
        }
        
        validateFields()
    }
}

extension ForceChangePasswordVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true
        if (currentPasswordView.getFieldValue().isEmpty || newPasswordView.getFieldValue().isEmpty || confirmNewPassword.getFieldValue().isEmpty || newPasswordView.getFieldValue() != confirmNewPassword.getFieldValue()) {
            isEnabled = false
        }
        
        for item in questionAnswerArray {
            if item.question == "" || item.answer == "" {
                isEnabled = false
            }
        }
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
}

extension ForceChangePasswordVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        
        if newPasswordView.getFieldValue() == currentPasswordView.getFieldValue() {
            CommonAlert.shared().showAlert(message: NSLocalizedString("New password and old password can not be same", comment: ""))
            return
        }
        
        for item in questionAnswerArray {
            if item.question == "" || item.answer == "" {
                CommonAlert.shared().showAlert(message: NSLocalizedString("Please fill security questions", comment: ""))
                return
            }
        }
        
        getTokenService()
    }
}
