//
//  QuestionAnswerView.swift
//  mCAS
//
//  Created by Ashutosh Mishra on 07/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

protocol QuesAnsDelegate {
    func setLOVValue(answer: String?, selectedLOV: DropDown?, tag: Int, isAnswering: Bool)
}

class QuestionAnswerView: UIView {
    
    @IBOutlet var CustomVw: UIView!
    @IBOutlet weak var answerView: CustomTextFieldView!
    @IBOutlet weak var questionView: LOVFieldView!
    
    private var delegate: QuesAnsDelegate?
    private let tagConstant = 100
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("QuestionAnswerView", owner: self, options: nil)
        CustomVw.fixInView(self)
        answerView.setProperties(placeHolder: "Answer", type: .Text, delegate: self)
    }
    
    func setQuestionView(index: Int, optionArray: [DropDown], delegate: QuesAnsDelegate) {
        self.tag = tagConstant + index
        self.delegate = delegate
        
        questionView.setLOVProperties(title: "Security Question \(index + 1)", tag: self.tag, delegate: self, optionArray: optionArray, allowLOVSetText: false)
    }
}

extension QuestionAnswerView: CustomTFViewDelegate {
    
    func validateFields() {
        delegate?.setLOVValue(answer: answerView.getFieldValue(), selectedLOV: nil, tag: self.tag - tagConstant, isAnswering: true)
    }    
}

extension QuestionAnswerView: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        delegate?.setLOVValue(answer: "", selectedLOV: selectedObj, tag: self.tag - tagConstant, isAnswering: false)
    }
}
