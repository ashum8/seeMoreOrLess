//
//  LoginSwiftViewController.swift
//  mCAS
//
//  Created by Mac on 08/02/17.
//  Copyright © 2017 Nucleus. All rights reserved.
//

import Foundation
import UIKit
import CoreData


class LoginSwiftViewController: UIViewController {
    private var loaderOverlay: MRProgressOverlayView!
    
    @IBOutlet weak var staticLavel1: UILabel!
    @IBOutlet weak var staticLavel2: UILabel!
    @IBOutlet weak var staticLavel3: UILabel!
    
    @IBOutlet weak var userNameLogoImage: UIImageView!
    @IBOutlet weak var userNameTextField: JVFloatLabeledTextField!
    @IBOutlet weak var passWordTextField: JVFloatLabeledTextField!
    @IBOutlet weak var userNameView: UIView!
    @IBOutlet weak var passWordView: UIView!
    @IBOutlet weak var lblVersionNo: UILabel!
    @IBOutlet weak var hideShowPasswordButton: UIButton!
    @IBOutlet weak var fPassButton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var poweredByverticalConstraint: NSLayoutConstraint!
    @IBOutlet weak var fPassHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var rememberButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let dictionary = Bundle.main.infoDictionary!
        let version = dictionary["CFBundleShortVersionString"] as! String
        let build = dictionary["CFBundleVersion"] as! String
        lblVersionNo.text = String(format: NSLocalizedString("Version: %@ (%@)", comment: ""), version, build)
        lblVersionNo.isHidden = true
        
//        if (CommonUtils.shared().getApplicationLanguage() == "ar") {
        hideShowPasswordButton.isHidden = true
//        }
        
        setProperties()
    }
    
    private func setProperties() {
        
        staticLavel1.font = CustomFont.shared().GETFONT_MEDIUM(24)
        staticLavel2.font = CustomFont.shared().GETFONT_REGULAR(16)
        staticLavel3.font = CustomFont.shared().GETFONT_REGULAR(13)
        
        userNameTextField.autocapitalizationType = .allCharacters
        
        //set color of username and password view
        userNameView.setTextFieldViewProperties()
        passWordView.setTextFieldViewProperties(autoCapitalize: false)
        
        fPassButton.setTitleColor(Color.BLUE, for: .normal)
        fPassButton.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(16)
        
        rememberButton.titleLabel?.font = CustomFont.shared().GETFONT_MEDIUM(16)
        
        loginButton.setButtonProperties()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        userNameTextField.text=""
        passWordTextField.text=""
        
        if let isRemember = CommonUtils.shared().getDataFromSecretUserDefault(key: UserDefaultKey.REMEMBER_USER_ID) as? Int, isRemember == 1 {
            rememberButton.isSelected = true
            userNameTextField.text = AppDelegate.instance.getSavedUserID()
        }
        else {
            rememberButton.isSelected = false
        }
        
//        userNameTextField.text="NEHA"
//        passWordTextField.text="Admin@1122"
        
//        userNameTextField.text="arvind"
//        passWordTextField.text="Admin@55" //"Admin@001"
//        
//        userNameTextField.text="tuna"
//        passWordTextField.text="Npd@7979"
        
        userNameTextField.text="MOBFIV"
        passWordTextField.text="Nsel@4321"
        
//        userNameTextField.text="FIVTOM"
//        passWordTextField.text="Nsel@121"
//        
//        userNameTextField.text="sachin1" //sachink
//        passWordTextField.text="Sachin@411"
//        
//        userNameTextField.text="sachin"
//        passWordTextField.text="Admin@11"
//
//        userNameTextField.text="shlok1"
//        passWordTextField.text="Nsel@4321"
        
        self.navigationController?.isNavigationBarHidden = true
        AppDelegate.instance.isLoggedin = false
        
        let verticalSpace = UIScreen.main.bounds.height - (fPassButton.frame.origin.y + fPassHeightConstraint.constant + 60)
        
        poweredByverticalConstraint.constant = max(verticalSpace, 60)
        
        let username = userNameTextField.text! as String
        let password = passWordTextField.text! as String
        
        setloginButtonProperties(username: username, password: password)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if JBroken.isDeviceCompromised() || JBroken.isAppBroken() {
            CommonAlert.shared().showAlert(message: "Sorry! your device is jail breaked. You can no longer use this application.", okAction: { _ in
                exit(-1)
            })
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        AppDelegate.instance.isLoggedin = true
    }
    
    @IBAction func rememberButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }
    
    @IBAction func hideShowPassword(_ sender: UIButton) {
        passWordTextField.isSecureTextEntry = !passWordTextField.isSecureTextEntry
        sender.isSelected = !sender.isSelected
    }
    
    @IBAction func loginButtonClicked(_ sender: UIButton) {
        
        if let username = userNameTextField.text, let password = passWordTextField.text, !username.isEmpty, !password.isEmpty {
            self.view.endEditing(true)
            
            //If Online Reachable
            if(ReachabilityManager.isReachable()){
                loaderOverlay = MRProgressOverlayView.showOverlayAdded(to: self.view, animated: true)
                loaderOverlay.titleLabelText = NSLocalizedString("Please wait authenticating...", comment:"")
                
                getTokenFromService(username: username, password: password)
            }
            else {
                let predicate = NSPredicate(format: "\(CDUserDetailsAttributes.username) = %@", username)
                let entityName = String(describing: CDUserDetails.self)
                
                CoreDataOperations.shared().fetchSingleRecord(predicate: predicate, entityName: entityName, success: { (record) in
                    
                    //SK Change - 1 day
                    if let userData = record as? CDUserDetails, let loginTime = userData.loginTime, Int(loginTime.getDaysDifference(toDate: Date())) < 10 {
                        self.checkOfflineUserCredential(password: password, userData: userData)
                    }
                    else {
                        CommonAlert.shared().showAlert(message: NSLocalizedString("Offline login not available\nPlease login first in online mode to validate login credentials.", comment: ""))
                    }
                })
            }
        }
        else {
            CommonAlert.shared().showAlert(message: NSLocalizedString("Please enter login credentials", comment: ""))
        }
    }
    
    @IBAction func forgotButtonAction(_ sender: Any) {
        
        
        let storyboard = UIStoryboard.init(name: Storyboard.FI, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "FIHomeVC") as? FIHomeVC {
            self.navigationController?.pushViewController(vc, animated: false)
        }
        
        return
        if Constants.ENABLE_FORGOT_PWD_VIA_OTP {
            self.performSegue(withIdentifier: "ResetPasswordVC", sender: nil)
        }
        else {
            self.performSegue(withIdentifier: "ForgotPasswordVC", sender: nil)
        }
    }
    
    func getTokenFromService(username: String, password: String) {
        Webservices.shared().getTokenFromServer(withSession: false) { (token) in
            if let token = token {
                self.callOnlineLoginWebService(username:username, password: password, token:token)
            }
            else {
                self.loaderOverlay.dismiss(true)
            }
        }
    }
    
    func checkOfflineUserCredential(password: String, userData: CDUserDetails){
        
        CommonAlert.shared().showAlert(message: NSLocalizedString("Network not available. Do you want to login in offline mode?", comment: ""), okTitle: "Yes", cancelTitle: "No", okAction: { _ in
            
            let encryptedPassword = Cipher.encrypt(password, withToken: userData.token!)
            
            if encryptedPassword == userData.encryptedpassword {
                self.navigateToDashboard(username: userData.username!)
            }
            else {
                CommonAlert.shared().showAlert(message: NSLocalizedString("Please enter correct login credentials", comment: ""))
            }
        })
    }
    
    func callOnlineLoginWebService(username: String, password: String, token: String) {
        
        let encryptedPassword = Cipher.encrypt(password, withToken: token)
        
        let param = ["username"     : username,
                     "password"     : encryptedPassword,
                     "deviceId"     : AppDelegate.instance.getDeviceID(),
                     "moduleCode"   : "mCAS"]
        
        Webservices.shared().POST(urlString: ServiceUrl.LOGIN_URL, paramaters: param, success: { (header ,responseObj) in
            
            if let dictionary = responseObj as? [String : Any]
            {
                if let alreadyLogIn = dictionary["alreadyLoggedIn"] as? Bool, alreadyLogIn {
                    self.loaderOverlay.dismiss(true)
                    
                    CommonAlert.shared().showAlert(message: NSLocalizedString("You are already logged in. Do you want to kill the previous session?", comment: ""), okTitle: "Continue", cancelTitle: "Cancel", okAction: { _ in
                        
                        self.loaderOverlay = MRProgressOverlayView.showOverlayAdded(to: self.view, animated: true)
                        self.loaderOverlay.titleLabelText = NSLocalizedString("Signing out...", comment:"")
                        
                        Webservices.shared().logoutFromServer(username: username) { (success) in
                            
                            if success == true {
                                self.loaderOverlay.titleLabelText = NSLocalizedString("Please wait authenticating...", comment:"")
                                self.getTokenFromService(username: username, password: password)
                            }
                            else {
                                self.loaderOverlay.dismiss(true)
                                CommonAlert.shared().showAlert(message: NSLocalizedString(ServiceUrl.ALERT_SERVICE_ERROR, comment: ""))
                            }
                        }
                    })
                }
                else if let forceChangePassword = dictionary["forcePasswordResetForLogin"] as? Bool, forceChangePassword {
                    
                    self.loaderOverlay.dismiss(true)
                    
                    let storyboard = UIStoryboard.init(name: Storyboard.MAIN, bundle: nil)
                    
                    if let vc = storyboard.instantiateViewController(withIdentifier: "ForceChangePasswordVC") as? ForceChangePasswordVC {
                        vc.questionsArray = dictionary["questions"] as? [[String: Any]] ?? []
                        vc.username = username
                        self.navigationController?.pushViewController(vc, animated: false)
                    }
                }
                else {
                    self.updateUserRecordInDB(username: username, password: password, token: token)
                }
            }
            
        }, failure: { (error) in
            if self.loaderOverlay != nil {
                self.loaderOverlay.dismiss(true)
            }
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
        }, noNetwork: { (error) in
            if self.loaderOverlay != nil {
                self.loaderOverlay.dismiss(true)
            }
        })
    }
    
    func updateUserRecordInDB(username: String, password: String? = nil, token: String? = nil) {
        
        if let password = password, let token = token {
            let encryptedPassword = Cipher.encrypt(password, withToken: token)
            let predicate = NSPredicate(format: "\(CDUserDetailsAttributes.username) = %@", username)
            let entityName = String(describing: CDUserDetails.self)
            
            CoreDataOperations.shared().updateRecord(predicate: predicate, entityName: entityName, success: { (record) in
                
                if let userData = record as? CDUserDetails {
                    userData.username = username
                    userData.encryptedpassword = encryptedPassword
                    userData.name = username
                    userData.token = token
                    userData.loginTime = Date()
                    
                    AppDelegate.instance.saveContext()
                }
            })
        }
        
        fetchAuthorities(username: username)
    }
    
    func navigateToDashboard(username: String) {
        
        //Flag to remember userid or not
        CommonUtils.shared().saveData(value:self.rememberButton.isSelected, key: UserDefaultKey.REMEMBER_USER_ID)
        CommonUtils.shared().saveData(value: username, key: UserDefaultKey.USER_ID)
        
        CoreDataOperations.shared().getCurrentLoggedinUser(success: { record in
            if let userData = record {
                AppDelegate.instance.currentLoggedInUser = userData
            }
        })
        
        if let userData = AppDelegate.instance.currentLoggedInUser, let rolesInDB = userData.getUserRoles(), !rolesInDB.isEmpty {
            Webservices.shared().loadMasterData()
            
            for role in rolesInDB {
                if (role.roleID == UserRoles.RATE_INITIATION || role.roleID == UserRoles.RATE_APPROVAL) {
                    Webservices.shared().fetchDecisionReasonMaster()
                    break
                }
            }
        }
        
        AppDelegate.instance.createBottomTabBar()
    }
    
    func fetchAuthorities(username: String) {
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_AUTHORITIES_URL, success: { (header ,responseObj) in
            
            //            if let response = responseObj as? [String : Any]
            if let rolesFromServer = responseObj as? [String]
            {
                //                if let rolesFromServer = response["authorities"] as? [String], let extraParam = response["extraParam"] as? String {
                //                    var checksum = username.uppercased() + rolesFromServer.joined()
                //                    checksum = Cipher.sha256(checksum)
                //
                //                    if checksum == extraParam {
                let predicate = NSPredicate(format: "\(CDUserDetailsAttributes.username) = %@", username)
                let entityName = String(describing: CDUserDetails.self)
                
                CoreDataOperations.shared().fetchSingleRecord(predicate: predicate, entityName: entityName, success: { (record) in
                    
                    if let userData = record as? CDUserDetails, let rolesInDB = userData.getUserRoles()
                    {
                        let context = AppDelegate.instance.getContext()
                        
                        for role in rolesInDB {
                            context.delete(role)
                        }
                        
                        let entityName = String(describing: CDUserRoles.self)
                        var roleArray: [CDUserRoles] = []
                        
                        for role in rolesFromServer {
                            let entity = NSEntityDescription.entity(forEntityName: entityName, in: context)
                            let userRoles = NSManagedObject(entity: entity!, insertInto: context) as! CDUserRoles
                            userRoles.roleID = role
                            roleArray.append(userRoles)
                        }
                        
                        userData.userRoles = NSOrderedSet(array: roleArray)
                        
                        AppDelegate.instance.saveContext()
                    }
                })
                
                self.navigateToDashboard(username: username)
                //                    }
                //                    else {
                //                        CommonAlert.shared().showAlert(message: NSLocalizedString(ServiceUrl.ALERT_SERVICE_ERROR, comment: ""))
                //                    }
                //                }
            }
            
            self.loaderOverlay.dismiss(true)
            
            
        }, failure: { (error) in
            
            if let error = error {
                CommonAlert.shared().showAlert(message: NSLocalizedString(error, comment: ""))
            }
            
            if self.loaderOverlay != nil {
                self.loaderOverlay.dismiss(true)
            }
        },
           noNetwork: { (error) in
            if self.loaderOverlay != nil {
                self.loaderOverlay.dismiss(true)
            }
        })
    }
    
    func setloginButtonProperties(username: String, password: String) {
        
        var isEnabled = true
        if (username.isEmpty || password.isEmpty) {
            isEnabled = false
        }
        loginButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
}

extension LoginSwiftViewController: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == userNameTextField {
            userNameView.layer.borderColor = Color.BLUE.cgColor
        }
        else {
            passWordView.layer.borderColor = Color.BLUE.cgColor
        }
        
        self.setloginButtonProperties(username: "", password: "")
    }
    
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        let username = userNameTextField.text! as String
        let password = passWordTextField.text! as String
        
        if textField == userNameTextField {
            userNameView.layer.borderColor = UIColor.lightGray.cgColor
        }
        else {
            passWordView.layer.borderColor = UIColor.lightGray.cgColor
        }
        
        self.setloginButtonProperties(username: username, password: password)
        
        return true
    }
}


