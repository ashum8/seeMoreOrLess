//
//  AddExpenseVC.swift
//  mCAS
//
//  Created by iMac on 28/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddExpenseVC: UIViewController {
    
    @IBOutlet weak var expenseHeadLOV: LOVFieldView!
    @IBOutlet weak var frequencyLOV: LOVFieldView!
    @IBOutlet weak var amountView: CustomTextFieldView!
    @IBOutlet weak var percentageView: CustomTextFieldView!
    @IBOutlet weak var netAmountView: CustomTextFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
        
    private var selectedLOVDic: [String: DropDown] = [:]
    
    private let TAG_EXPENSE = 1000
    private let TAG_FREQUENCY = 1001
    private let TAG_AMOUNT = 10000
    private let TAG_PERCENTAGE = 10001
    
    private let MaxLimitAmount = 10000000
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    private func setupView() {
        
        expenseHeadLOV.setLOVProperties(masterName: Entity.INCOME_EXPENSE_HEAD, title: "Expense Head", tag: TAG_EXPENSE, delegate: self)
        frequencyLOV.setLOVProperties(masterName: Entity.FREQUENCY, title: "Frequency", tag: TAG_FREQUENCY, delegate: self)
        
        amountView.setProperties(placeHolder: "Amount",type: .Amount, delegate: self, tag: TAG_AMOUNT)
        percentageView.setProperties(placeHolder: "Percentage(%)",type: .Decimal, delegate: self, tag: TAG_PERCENTAGE, enabled: false)
        netAmountView.setProperties(placeHolder: "Net Amount",type: .Text, delegate: self, enabled: false)
        
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        
        percentageView.setFieldValue(text: "100.00")
        validateFields()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Expense")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: true)
        }
    }
    
    @IBAction func checkBoxButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }
    
}

extension AddExpenseVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        validateFields()
    }
}

extension AddExpenseVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true
        
        if let cost = Int(amountView.getFieldValue()) {
            netAmountView.setFieldValue(text: "\(cost)".formatCurrency)
        }
        
        if (selectedLOVDic["\(TAG_EXPENSE)"] == nil || selectedLOVDic["\(TAG_FREQUENCY)"] == nil || amountView.getFieldValue().isEmpty || netAmountView.getFieldValue().isEmpty ) {
            
            isEnabled = false
        }
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch tag {
        case TAG_AMOUNT:
            return Int(text) ?? 0 < MaxLimitAmount
        case TAG_PERCENTAGE:
            return Int(text) ?? 0 <= 100
        default:
            return true
        }
    }
}

extension AddExpenseVC: NextBackButtonDelegate {
    func nextButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}
