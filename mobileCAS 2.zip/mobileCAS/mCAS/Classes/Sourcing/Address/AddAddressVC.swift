//
//  AddAddressVC.swift
//  mCAS
//
//  Created by iMac on 27/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddAddressVC: UIViewController {
    
    @IBOutlet weak var addressTypeLOV: LOVFieldView!
    @IBOutlet weak var residenceStatusLOV: LOVFieldView!
    @IBOutlet weak var residenceLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var addressL1View: CustomTextFieldView!
    @IBOutlet weak var addressL2View: CustomTextFieldView!
    @IBOutlet weak var landmarkView: CustomTextFieldView!
    @IBOutlet weak var countryLOV: LOVFieldView!
    @IBOutlet weak var stateLOV: LOVFieldView!
    @IBOutlet weak var cityLOV: LOVFieldView!
    @IBOutlet weak var checkBoxButton: UIButton!
    @IBOutlet weak var residenceTypeLOV: LOVFieldView!
    @IBOutlet weak var residenceTypeLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var documentRefView: LOVFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var addressDurationView: DurationView!
    @IBOutlet weak var cityDurationView: DurationView!
    @IBOutlet weak var currentLocationButton: UIButton!
    @IBOutlet weak var sameAsTitleLabel: UILabel!
    @IBOutlet weak var sameAsButton1: UIButton!
    @IBOutlet weak var sameAsButton2: UIButton!
    @IBOutlet weak var pincodeView: CustomPincodeView!
    
    @IBOutlet weak var sameAsAddressView: UIView!
    @IBOutlet weak var sameAsAddressViewHeight: NSLayoutConstraint!
    
    private let TAG_ADDRESS = 1000
    private let TAG_COUNTRY = 1001
    private let TAG_STATE = 1002
    private let TAG_CITY = 1003
    private let TAG_DOCUMENT = 1004
    private let TAG_RESIDENCE = 1005
    private let TAG_RESIDENCE_TYPE = 1006
    
    private let TAG_ADDRESS_LANDMARK = 1006
    
    private var selectedLOVDic: [String: DropDown] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    private func setupView() {
        
        addressTypeLOV.setLOVProperties(masterName: Entity.ADDTYPE, title: "Address Type", tag: TAG_ADDRESS, delegate: self)
        residenceStatusLOV.setLOVProperties(masterName: Entity.RESTYP, title: "Residence Status", tag: TAG_RESIDENCE, delegate: self)
        countryLOV.setLOVProperties(masterName: Entity.COUNTRY, title: "Country", tag: TAG_COUNTRY, delegate: self)
        stateLOV.setLOVProperties(masterName: Entity.STATE, title: "State", tag: TAG_STATE, delegate: self)
        cityLOV.setLOVProperties(masterName: Entity.CITY, title: "City", tag: TAG_CITY, delegate: self)
        documentRefView.setLOVProperties(masterName: Entity.CITY, title: "Document Refered", tag: TAG_DOCUMENT, delegate: self, enable: false)
        residenceTypeLOV.setLOVProperties(masterName: Entity.RESIDENCETYPE, title: "Residence Type", tag: TAG_RESIDENCE_TYPE, delegate: self)
        
        addressL1View.setProperties(placeHolder: "Address Line 1", delegate: self, tag: TAG_ADDRESS_LANDMARK)
        addressL2View.setProperties(placeHolder: "Address Line 2 (Optional)", delegate: self, tag: TAG_ADDRESS_LANDMARK)
        pincodeView.setProperties()
        landmarkView.setProperties(placeHolder: "Landmark", delegate: self, tag: TAG_ADDRESS_LANDMARK)
        
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        
        checkBoxButton.setCheckboxProperties(title: "Use this as correspondence address", isSelected: false)
        
        addressDurationView.setProperties(title: "Duration at Current Address", delegate: self)
        cityDurationView.setProperties(title: "Duration at Current City", delegate: self)
        
        setLocationButtonProperties()
        
        sameAsTitleLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
        sameAsButton1.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(19)
        sameAsButton2.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(19)
        sameAsAddressView.layer.masksToBounds = true
        
        validateFields()        
    }    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Address")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: true)
        }
    }
    
    @IBAction func checkBoxButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }
    
    @IBAction func currentLocationButtonAction(_ sender: Any) {
        
        addressL1View.setFieldValue(text: AppDelegate.instance.gpsDictionary?["addressLineOne"] ?? "")
        addressL2View.setFieldValue(text: AppDelegate.instance.gpsDictionary?["addressLineTwo"] ?? "")
        cityLOV.autoFillLOV(value: AppDelegate.instance.gpsDictionary?["city"] ?? "")
        countryLOV.autoFillLOV(value: AppDelegate.instance.gpsDictionary?["country"] ?? "")
        stateLOV.autoFillLOV(value: AppDelegate.instance.gpsDictionary?["state"] ?? "")
        pincodeView.setFieldValue(text: AppDelegate.instance.gpsDictionary?["pincode"] ?? "")
        
    }
    
    
    private func setLocationButtonProperties() {
        currentLocationButton.setCornerRadius()
        currentLocationButton.layer.borderWidth = 1
        currentLocationButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(18)
        currentLocationButton.setTitleColor(Color.BLUE, for: .normal)
        currentLocationButton.layer.borderColor = Color.BLUE.cgColor
        currentLocationButton.backgroundColor = .white
    }
    
    
    @IBAction func sameAsButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }
    
    private func refreshFieldData() {
        residenceStatusLOV.resetLOVWithParentKey(key: "")
        residenceTypeLOV.resetLOVWithParentKey(key: "")
        selectedLOVDic["\(TAG_RESIDENCE)"] = nil
        selectedLOVDic["\(TAG_RESIDENCE_TYPE)"] = nil
    }
}

extension AddAddressVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true
        if (selectedLOVDic["\(TAG_ADDRESS)"] == nil || addressL1View.getFieldValue().isEmpty || landmarkView.getFieldValue().isEmpty  || selectedLOVDic["\(TAG_COUNTRY)"] == nil || selectedLOVDic["\(TAG_STATE)"] == nil || selectedLOVDic["\(TAG_CITY)"] == nil || pincodeView.getFieldValue().isEmpty || addressDurationView.yearView.getFieldValue().isEmpty || addressDurationView.monthView.getFieldValue().isEmpty || cityDurationView.yearView.getFieldValue().isEmpty || cityDurationView.monthView.getFieldValue().isEmpty) {
            
            isEnabled = false
        }
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch tag {
        case TAG_ADDRESS_LANDMARK:
            return text.validateStringWithRegex(regx: "^[A-Z-a-z0-9,.() #@$*%-_\\/:?]{1,40}$")
        default:
            return true
        }
    }
}

extension AddAddressVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        if btntag == TAG_ADDRESS {
            
            switch selectedObj.code {
                
            case ConstantCodes.ADDRESS_TYPE_PERM:
                residenceLOVHeight.constant = 65
                sameAsAddressViewHeight.constant = 86
                residenceTypeLOVHeight.constant = 65
                sameAsButton2.isHidden = false
                sameAsButton1.setCheckboxProperties(title: "Office")
                sameAsButton2.setCheckboxProperties(title: "Residence")
                
            case ConstantCodes.ADDRESS_TYPE_OFC:
                residenceLOVHeight.constant = 0
                sameAsAddressViewHeight.constant = 0
                residenceTypeLOVHeight.constant = 0
                
            case ConstantCodes.ADDRESS_TYPE_RES:
                residenceLOVHeight.constant = 65
                sameAsAddressViewHeight.constant = 86
                residenceTypeLOVHeight.constant = 65
                sameAsButton2.isHidden = false
                sameAsButton1.setCheckboxProperties(title: "Permanent")
                sameAsButton2.setCheckboxProperties(title: "Office")
                
            default:
                sameAsButton2.isHidden = true
                sameAsButton1.setCheckboxProperties(title: "Office")
                sameAsAddressViewHeight.constant = 86
                residenceLOVHeight.constant = 0
                residenceTypeLOVHeight.constant = 0
            }
        }
        else if btntag == TAG_COUNTRY {
            if let dd = selectedLOVDic["\(TAG_COUNTRY)"] {
                stateLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_STATE)"] = nil
                
                cityLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_CITY)"] = nil
                
                pincodeView.setFieldValue()
            }
        }
        else if btntag == TAG_STATE {
            if let dd = selectedLOVDic["\(TAG_STATE)"] {
                cityLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_CITY)"] = nil
                
                pincodeView.setFieldValue()
            }
        }
        else if btntag == TAG_CITY {
            if let dd = selectedLOVDic["\(TAG_CITY)"] {
                pincodeView.setProperties(city: dd.code)
            }
        }
        
        validateFields()
    }
}

extension AddAddressVC: NextBackButtonDelegate {
    func nextButtonAction() {
        
        if let yearInAdd = Int(addressDurationView.yearView.getFieldValue()), let yearInCity = Int(cityDurationView.yearView.getFieldValue()) {
            
            if yearInCity < yearInAdd {
                CommonAlert.shared().showAlert(message: "Duration in city must be greater than or equal to Duration in address.")
                return
            }
            else if yearInCity == yearInAdd {
                if let monthInAdd = Int(addressDurationView.monthView.getFieldValue()), let monthInCity = Int(cityDurationView.monthView.getFieldValue()) {
                    if monthInCity < monthInAdd {
                        CommonAlert.shared().showAlert(message: "Duration in city must be greater than or equal to duration in address.")
                        return
                    }
                }
            }
            
        }
        
        self.navigationController?.popViewController(animated: true)
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}

extension AddAddressVC: CustomDVDelegate {    
    func validateYearMonth() {
        self.validateFields()
    }
}
