//
//  AddCollateralVC.swift
//  mCAS
//
//  Created by iMac on 31/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddCollateralVC: UIViewController {
    
    @IBOutlet weak var assetCategoryLOV: LOVFieldView!
    @IBOutlet weak var assetMakeLOV: LOVFieldView!
    @IBOutlet weak var assetModelLOV: LOVFieldView!
    @IBOutlet weak var assetVariantLOV: LOVFieldView!
    @IBOutlet weak var assetCostView: CustomTextFieldView!
    @IBOutlet weak var quantityView: CustomTextFieldView!
    @IBOutlet weak var effectiveAssetCostView: CustomTextFieldView!
    @IBOutlet weak var dealerLOV: LOVFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private let TAG_CATEGORY = 1000
    private let TAG_ASSET_MAKE = 1001
    private let TAG_ASSET_MODEL = 1002
    private let TAG_ASSET_VARIENT = 1003
    private let TAG_DEALER = 1004
    
    private let TAG_COST = 10000
    private let TAG_QUANTITY = 10001
    
    private let maxCost = 10000000
    private let maxQuantity = 100
    
    private var selectedLOVDic: [String: DropDown] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    private func setupView() {
        
        assetCategoryLOV.setLOVProperties(masterName: Entity.ASSET, title: "Asset Category", tag: TAG_CATEGORY, delegate: self)
        assetMakeLOV.setLOVProperties(masterName: Entity.ASSET_MAKE, title: "Asset Make", tag: TAG_ASSET_MAKE, delegate: self)
        assetModelLOV.setLOVProperties(masterName: Entity.ASSET_MODEL, title: "Asset Model", tag: TAG_ASSET_MODEL, delegate: self)
        assetVariantLOV.setLOVProperties(masterName: Entity.ASSET_VARIANT, title: "Asset Variant(Optional)", tag: TAG_ASSET_VARIENT, delegate: self)
        dealerLOV.setLOVProperties(masterName: Entity.SALES_AGENT, title: "Dealer", tag: TAG_DEALER, delegate: self)
        
        assetCostView.setProperties(placeHolder: "Asset Cost", type: .Amount, delegate: self, tag: TAG_COST)
        quantityView.setProperties(placeHolder: "Quantity",type: .Number, delegate: self, tag: TAG_QUANTITY)
        effectiveAssetCostView.setProperties(placeHolder: "Effective Asset Cost", delegate: self, enabled: false)
        
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        
        validateFields()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Collateral")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: true)
        }
    }
    
    
}

extension AddCollateralVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        switch btntag {
        case TAG_CATEGORY:
            if let dd = selectedLOVDic["\(TAG_CATEGORY)"] {
                assetMakeLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_ASSET_MAKE)"] = nil
            }
        case TAG_ASSET_MAKE:
            if let dd = selectedLOVDic["\(TAG_ASSET_MAKE)"] {
                assetModelLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_ASSET_MODEL)"] = nil
            }
        case TAG_ASSET_MODEL:
        if let dd = selectedLOVDic["\(TAG_ASSET_MODEL)"] {
            assetVariantLOV.resetLOVWithParentKey(key: dd.code)
            selectedLOVDic["\(TAG_ASSET_VARIENT)"] = nil
        }
        default:
            debugPrint("case not matched")
        }
        
        validateFields()
    }
}

extension AddCollateralVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true
        
        if let cost = Int(assetCostView.getFieldValue()), let quantity = Int(quantityView.getFieldValue()) {
            effectiveAssetCostView.setFieldValue(text: "\(cost*quantity)".formatCurrency)
        }
        
        if (selectedLOVDic["\(TAG_CATEGORY)"] == nil || selectedLOVDic["\(TAG_ASSET_MAKE)"] == nil || selectedLOVDic["\(TAG_ASSET_MODEL)"] == nil || assetCostView.getFieldValue().isEmpty || quantityView.getFieldValue().isEmpty || effectiveAssetCostView.getFieldValue().isEmpty || selectedLOVDic["\(TAG_DEALER)"] == nil ) {
            
            isEnabled = false
        }
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch tag {
        case TAG_COST:
            return Int(text) ?? 0 <= maxCost
        case TAG_QUANTITY:
            return Int(text) ?? 0 <= maxQuantity
        default:
            return true
        }
    }
}

extension AddCollateralVC: NextBackButtonDelegate {
    func nextButtonAction() {
        
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}
