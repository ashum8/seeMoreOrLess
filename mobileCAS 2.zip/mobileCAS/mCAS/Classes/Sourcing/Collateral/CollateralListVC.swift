//
//  CollateralListVC.swift
//  mCAS
//
//  Created by iMac on 31/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class CollateralListVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private enum DetailOptions: String {
        case edit = "Edit"
        case delete = "Delete"
    }
    
    private struct DataModel {
        var title: String
        var name: String
        var amount: String
        var address: String
    }
    
    private var dataModelArray = [DataModel]()
    private var cellOptionArray: [DetailOptions] = [.edit, .delete]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            let navArray = AppDelegate.instance.applicationNavController.viewControllers
            let lastVC = navArray[navArray.count-2]
            headerView.showHideStepHeader(isHide: false, title: "Collateral", landingPage: lastVC)
        }
    }
    
    private func setupView() {
        dataModelArray.append(DataModel(title: "FLAT", name: "Industrial", amount: "5,00,000", address: "A 39, Block A, Industrial Area, Sector 62, Noida, Uttar Pradesh 201309, India"))
        dataModelArray.append(DataModel(title: "FLAT", name: "Corporate", amount: "2,00,000", address: "A 39, Block A, Industrial Area, Sector 62, Noida, Uttar Pradesh 201309, India"))
        
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        addButton.setPlusButtonProperties()
        
        noDataCapturedView.setProperties(title: "Do you have any collateral to add?")
            
        tableView.register(UINib(nibName: "SourcingCommonListCell", bundle: nil), forCellReuseIdentifier: "SourcingCommonListCell")
        tableView.tableFooterView = UIView()
        
        buttonView.setProperties(nextBtnTitle: "Save Details", delegate: self)
        
        setListData()
    }
    
    private func setListData() {
        tableView.isHidden = dataModelArray.isEmpty
        noDataCapturedView.isHidden = !tableView.isHidden
        self.tableView.reloadData()
    }
    
    @IBAction func addButtonAction(_ sender: UIButton) {
        let st = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = st.instantiateViewController(withIdentifier: "AddCollateralVC") as? AddCollateralVC  {
            AppDelegate.instance.applicationNavController.pushViewController(vc , animated: true)
        }
    }
}

extension CollateralListVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataModelArray.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SourcingCommonListCell", for: indexPath) as! SourcingCommonListCell
        cell.setProperties(optionArray: cellOptionArray.map({ $0.rawValue }), cellIndex: indexPath.row, delegate: self)
        
        cell.label1.text = dataModelArray[indexPath.row].title
        cell.label2.text = "\(dataModelArray[indexPath.row].name) \(Constants.SEPERATOR) \(Constants.CURRENCY_SYMBOL) \(dataModelArray[indexPath.row].amount)"
        cell.label3.text = dataModelArray[indexPath.row].address
        
        return cell
    }
    
}

extension CollateralListVC : NextBackButtonDelegate {
    func nextButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}

extension CollateralListVC : CommonListCellDelegate {
    
    func selectedIndex(index: Int, cellIndex: Int) {
        let item = self.cellOptionArray[index]
        if item == .edit {
            let st = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
            
            if let vc = st.instantiateViewController(withIdentifier: "AddCollateralVC") as? AddCollateralVC  {
                AppDelegate.instance.applicationNavController.pushViewController(vc , animated: true)
            }
            
        }
        else if item == .delete {
            dataModelArray.remove(at: cellIndex)
            setListData()
        }
    }
}
