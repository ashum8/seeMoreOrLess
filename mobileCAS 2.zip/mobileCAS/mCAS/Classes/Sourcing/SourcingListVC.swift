//
//  SourcingListVC.swift
//  mCAS
//
//  Created by Mac on 13/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//


import UIKit

class SourcingListVC: UIViewController {
    
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    
    private var refreshControl: UIRefreshControl!
    private var cellOptionArray: [String] = ["View Details"]
    
    private var listModelArray = [SourcingModelClasses.SourcingModel]()
    private var filteredListModelArray = [SourcingModelClasses.SourcingModel]()
    
    private var productCategory: LoanType!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Do any additional setup after loading the view.
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        addButton.setPlusButtonProperties()
        
        noDataCapturedView.setProperties(title: "No Draft Application", image: "no_lead_icon")
        
        tableView.register(UINib.init(nibName: "CasesCell", bundle: Bundle.main), forCellReuseIdentifier: "CasesCell")
        tableView.tableFooterView = UIView()
        
        refreshControl = UIRefreshControl()
        refreshControl.tintColor = .darkGray
        refreshControl.addTarget(self, action: #selector(fetchCases), for: .valueChanged)
        tableView.addSubview(refreshControl)
        
        fetchCases()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            headerView.setTitleWith(line1: "View Sourcing", showBack: true)
            headerView.showHideSearchMikeFilterOption(showSearch: true, delegate: self)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideSearchMikeFilterOption(showSearch: false)
        }
    }
    
    @objc func fetchCases() {
        
        listModelArray.removeAll()
        
        Webservices.shared().POST(urlString: ServiceUrl.GET_SOURCING_LIST_URL, autoHandleLoader: true, allowOfflineAlert:false, success: { (header ,responseObj) in
            
            if let response = responseObj as? [[String : AnyObject]]
            {
                CommonUtils.shared().JSONtoModel(jsonObject: response, type: [SourcingModelClasses.SourcingModel].self) { list in
                    self.listModelArray.append(contentsOf: list)
                    self.filteredListModelArray = self.listModelArray
                }
            }
            
            self.setListData()
            
        }, failure: { (error) in
            
            self.setListData()
            
        }, noNetwork: { (error) in
            
            self.setListData()
        })
    }
    
    func setListData(isSearchON: Bool = false) {
        self.refreshControl.endRefreshing()
        
        tableView.isHidden = filteredListModelArray.isEmpty
        noDataCapturedView.isHidden = !filteredListModelArray.isEmpty || isSearchON
        tableView.reloadData()
    }
    
    @IBAction func addButtonAction(_ sender: UIButton) {
        moveToCreateApplication()
    }
    
    func moveToCreateApplication() {
        let storyboard = UIStoryboard.init(name: Storyboard.LEAD, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "ProductTypeVC") as? ProductTypeVC {
            vc.setData(delegate: self)
            AppDelegate.instance.applicationNavController.pushViewController(vc, animated: false)
        }
    }
}

extension SourcingListVC: ProductTypeVCDelegate {
    
    func selected(productType: LoanType, currentStep: Int, totalStep: Int) {
        
        self.productCategory = productType
        
        var dropDownList: [DropDown] = []
        
        //fetch the dropdownList according to master name
        CoreDataOperations.shared().fetchRecordsForMaster(masterName: Entity.APPLICATION_TYPE) { (records) in
            
            if var records = records {
                //Pre select New Application by default
                records = records.map({(item) -> DropDown in
                    item.isSelectedFlag = (Constants.DEFAULT_APPLICATION_TYPE_CODE == item.code)
                    return item
                })
                
                dropDownList.append(contentsOf: records)
            }
        }
        
        let storyboard = UIStoryboard.init(name: Storyboard.LOV_LIST, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "LOVListVC") as? LOVListVC {
            vc.setData(lovType: .Other, dropDownList: dropDownList, delegate: self, title: "Application Type", backButtonTitle: "Back", doneButtonTitle: "Start Application", showSearch: false)
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

extension SourcingListVC: LOVListDelegate {
    
    func selectedLOV(selectedObj: DropDown) {
        
        let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "SourcingDashboardVC") as? SourcingDashboardVC {
            vc.setData(productCategory: self.productCategory, applicationType: selectedObj)
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

extension SourcingListVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredListModelArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CasesCell") as! CasesCell
        
        let model = filteredListModelArray[indexPath.row]
        cell.label1.text = model.applicant.firstName! + model.applicant.lastName!
        cell.label2.text = "\(model.neutronReferenceNumber) \(Constants.SEPERATOR) \(model.applicant.mobileNumber!)"
        cell.label3.text = String(model.loanDetail.loanAmount!).formatCurrency
        cell.loanTypeLabel.text = model.loanDetail.productType.name
        cell.setProperties(cellIndex: indexPath.row, customerType: model.applicant.customerType.code!, showOption: true, productTypeCode: model.loanDetail.productType.code, optionArray: cellOptionArray)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        if let vc = self.storyboard?.instantiateViewController(withIdentifier: "SourcingDashboardVC") as? SourcingDashboardVC {
            AppDelegate.instance.applicationNavController.pushViewController(vc, animated: false)
        }
    }
}


extension SourcingListVC: HeaderDelegate {
    
    func searchOnOff(isSearching: Bool) {
        handleSearch(text: "")
        tableView.addSubview(refreshControl)
        setListData(isSearchON: isSearching)
    }
    
    func handleSearch(text: String) {
        
        //SK Change
        if !text.isEmpty {
            filteredListModelArray = listModelArray.filter { ($0.applicant.firstName!.lowercased().contains(text.lowercased())) || ($0.applicant.lastName!.lowercased().contains(text.lowercased())) || ($0.applicant.mobileNumber!.lowercased().contains(text.lowercased())) || ($0.applicant.neutronCustRefNumber.lowercased().contains(text.lowercased())) }
        }
        else {
            filteredListModelArray = listModelArray
        }
        setListData(isSearchON: true)
        tableView.reloadData()
    }
    
}


/*
 loancontract/getall
  [{"applicant":{"customerType":{"code":"INDIVIDUAL","name":"Individual"},"firstName":"FARM","middleName":"A","lastName":"A","mobileNumber":"9999999999","neutronCustRefNumber":"32018744944120032002202017052201"},"loanDetail":{"loanAmount":12345.00,"productType":{"code":"FE","name":"Farm Equipment"},"product":{"code":"TRL","name":"Tractor Loan"},"branch":{"code":"BAN","name":"BANDRA"}},"neutronReferenceNumber":"320187449441200320022020170522"},{"applicant":{"customerType":{"code":"INDIVIDUAL","name":"Individual"},"firstName":"FFGGD","middleName":"VDVD","lastName":"DVVD","mobileNumber":"9999999999","neutronCustRefNumber":"32018744944120032002202017105001"},"loanDetail":{"loanAmount":8787.00,"productType":{"code":"CV","name":"Commercial Vehicle"},"product":{"code":"ACVDW","name":"AIB CV DCB"},"branch":{"code":"BAN","name":"BANDRA"}},"neutronReferenceNumber":"320187449441200320022020171050"}]
 
 
 
 loancontract/getallcustomers
 
 {"neutronReferenceNumber":"131531303805070719022020142945"}
 
 RP1 -
 {"type":"VALIDATION","cause":"EXCEPTION","errorEntries":[{"errorCode":"NO_DATA_AVAILABLE","placeholders":[]}]}
 
 RP2 - [{"applicantRole":{"code":"0","name":"PRIMARY"},"customerType":{"code":"INDIVIDUAL","name":"Individual"},"salutation":{"code":"MR","name":"Mr"},"firstName":"HSHS","middleName":"SUJS","lastName":"AHSH","emailAddress":"hsh@ha.xom","isdCode":{"code":"IN","name":"+91"},"dateOfBirth":"2001-02-20T00:00:00.000+0000","gender":{"code":"MALE","name":"Male"},"maritalStatus":{"code":"Married","name":"Married"},"mobileNumber":"9676454844","fatherName":"HAJA","motherMaidenName":"AHN","customerCategory":{"code":"GEN","name":"General"},"residentialStatus":{"code":"Resident","name":"Resident Indian"},"preferredLanguage":{"code":"Hindi","name":"Hindi"},"phoneNumber":"649494","neutronCustRefNumber":"13153130380507071902202014294501","numOfDependents":1,"numOfChildDependents":1,"isdCodePhoneNo":{"code":"IN","name":"+91"},"householdType":{"code":"FAMILY","name":"Family"},"extn":"","stdCode":"9464","nationality":{"code":"IND","name":"Indian"},"constitution":{"code":"Indiv","name":"Individual"}}]
 
 
 
 customer/save
 
 {"neutronReferenceNumber":"131531303805070719022020142945","neutronCustRefNumber":"13153130380507071902202014294501","applicant":{"firstName":"HSHS","lastName":"AHSH","dateOfBirth":"2001-02-20","fatherName":"HAJA","motherMaidenName":"AHN","numOfDependents":"1","numOfChildDependents":"1","emailAddress":"hsh@ha.xom","mobileNumber":"9676454844","stdCode":"9464","phoneNumber":"649494","extn":"","neutronCustRefNumber":"13153130380507071902202014294501","middleName":"SUJS","isBasicDetails":true,"gender":{"code":"MALE","name":"Male"},"maritalStatus":{"code":"Married","name":"Married"},"customerCategory":{"code":"GEN","name":"General"},"nationality":{"code":"IND","name":"Indian"},"residentialStatus":{"code":"Resident","name":"Resident Indian"},"isdCode":{"code":"IN","name":"+91"},"isdCodePhoneNo":{"code":"IN","name":"+91"},"preferredLanguage":{"code":"Hindi","name":"Hindi"},"applicantRole":{"code":"0"},"customerType":{"code":"INDIVIDUAL"},"salutation":{"code":"MR","name":"Mr"},"partyRelationship":{},"constitution":{"code":"Indiv","name":"Individual"},"householdType":{"code":"FAMILY","name":"Family"}},"loanDetail":{"productType":{"code":"CON_VEH","name":"Consumer Vehicle"},"applicationType":{}}}
 
 {"completed":true}
 
 
 
 identification/save
 
 R1 -
 {"neutronReferenceNumber":"131531303805070719022020142945","neutronCustRefNumber":"13153130380507071902202014294501","identificationDetails":[{"neutronIdentificationId":"13153130380507071902202014294501_AAdhar_No","identificationValue":"727727656545","issueDate":"2020-02-08","expiryDate":"2020-02-22","issuingCountry":{"code":"IND","name":"India"},"identificationType":{"code":"AAdhar_No","name":"Aadhar No."},"validatePan":false}]}
 
 R2 -
 {"neutronReferenceNumber":"131531303805070719022020142945","neutronCustRefNumber":"13153130380507071902202014294501","identificationDetails":[{"neutronIdentificationId":"13153130380507071902202014294501_AAdhar_No","identificationValue":"333333333333","issueDate":"2020-02-08","expiryDate":"","issuingCountry":{"code":"IND","name":"India"},"identificationType":{"code":"AAdhar_No","name":"Aadhar No."},"validatePan":false}]}
 
 {"completed":true}
 
 
 
 identification/getall
 
 {"neutronCustRefNumber":"13153130380507071902202014294501"}
 
 [{"identificationType":{"code":"AAdhar_No","name":"Aadhar No."},"identificationValue":"727727656545","issueDate":"2020-02-08T00:00:00.000+0000","expiryDate":"2020-02-22T00:00:00.000+0000","issuingCountry":{"code":"IND","name":"India"},"attemptsDone":0,"neutronIdentificationId":"13153130380507071902202014294501_AAdhar_No"}]
 
 
 
 employment/save
 
 R1 -
 {"neutronReferenceNumber":"131531303805070719022020142945","neutronCustRefNumber":"13153130380507071902202014294501","employmentDetails":[{"employmentId":"13153130380507071902202014294501914","occupationType":{"code":"salaried","name":"Salaried"},"employerName":{"code":"ABC","name":"ABC Bank"},"natureOfBusiness":{"code":"Manufacturing","name":"Manufacturing"},"natureOfOccupation":{"code":"","name":""},"natureOfProfession":{"code":"","name":""},"industry":{"code":"Apparels","name":"Apparels"},"otherEmployerName":"","employedFrom":"2020-02-15","organizationName":"","registrationNumber":"","majorOccupation":"true"}]}
 
 R2 -
 {"neutronReferenceNumber":"131531303805070719022020142945","neutronCustRefNumber":"13153130380507071902202014294501","employmentDetails":[{"employmentId":"13153130380507071902202014294501885","occupationType":{"code":"others","name":"Others"},"employerName":{"code":"","name":""},"natureOfBusiness":{"code":"","name":""},"natureOfOccupation":{"code":"Farmer and Commercial","name":"Farmer and Commercial"},"natureOfProfession":{"code":"","name":""},"industry":{"code":"","name":""},"otherEmployerName":"","employedFrom":"","organizationName":"","registrationNumber":"","majorOccupation":"true"}]}
 
 R3 -
 {"neutronReferenceNumber":"131531303805070719022020142945","neutronCustRefNumber":"13153130380507071902202014294501","employmentDetails":[{"employmentId":"13153130380507071902202014294501885","occupationType":{"code":"others","name":"Others"},"employerName":{"code":"","name":""},"natureOfBusiness":{"code":"","name":""},"natureOfOccupation":{"code":"Farmer and Commercial","name":"Farmer and Commercial"},"natureOfProfession":{"code":"","name":""},"industry":{"code":"","name":""},"otherEmployerName":"","employedFrom":"","organizationName":"","registrationNumber":"","majorOccupation":"true"}]}
 
 {"completed":true}
 
 
 
 employment/getall
 
 {"neutronCustRefNumber":"13153130380507071902202014294501"}
 
 
 [{"id":10002,"industry":{"code":"Apparels","name":"Apparels"},"occupationType":{"code":"salaried","name":"Salaried"},"employerName":{"code":"ABC","name":"ABC Bank"},"majorOccupation":true,"natureOfBusiness":{"code":"Manufacturing","name":"Manufacturing"},"otherEmployerName":"","organizationName":"","registrationNumber":"","employedFrom":"2020-02-15T00:00:00.000+0000","employmentId":"13153130380507071902202014294501914"}]
 
 
 
 master/getzipcodes
 
 {"city":"NOI"}
 
 [{"code":"201301","name":"Noida"}]
 
 
 
 address/save
 
 R1 -
 {"neutronReferenceNumber":"131531303805070719022020142945","neutronCustRefNumber":"13153130380507071902202014294501","addressDetails":[{"neutronAddressId":"13153130380507071902202014294501_ResidentialAddress","addressType":{"code":"ResidentialAddress","name":"Residential Address"},"unit":"HAH","streetNo":"AY","streetName":"HA","landmark":"HA","country":{"code":"IND","name":"India"},"state":{"code":"UP","name":"Uttar Pradesh"},"city":{"code":"NOI","name":"Noida"},"postalCode":{"code":"201301","name":"Noida(201301)"},"residenceType":{"code":"Chawl","name":"Chawl"},"residentialStatus":{"code":"PARENTAL","name":"Owned by Parent \/Sibling"},"numberOfMonthsAtAddress":"5","numberOfYearsAtAddress":"5","numberOfMonthsAtCity":"5","numberOfYearsAtCity":"5","communicationAddress":true,"sameAsPermanentAddr":true,"sameAsOfficeAddr":true,"sameAsResidentialAddr":false,"fromScan":false}]}
 
 
 R2 -
 {"neutronReferenceNumber":"131531303805070719022020142945","neutronCustRefNumber":"13153130380507071902202014294501","addressDetails":[{"neutronAddressId":"13153130380507071902202014294501_OfficeAddress","addressType":{"code":"OfficeAddress","name":"Office\/ Business Address"},"unit":"GAH","streetNo":"","streetName":"","landmark":"","country":{"code":"IND","name":"India"},"state":{"code":"UP","name":"Uttar Pradesh"},"city":{"code":"NOI","name":"Noida"},"postalCode":{"code":"201301","name":"Noida(201301)"},"residenceType":{"code":"","name":""},"residentialStatus":{"code":"","name":""},"numberOfMonthsAtAddress":"","numberOfYearsAtAddress":"","numberOfMonthsAtCity":"","numberOfYearsAtCity":"","communicationAddress":true,"sameAsPermanentAddr":false,"sameAsOfficeAddr":false,"sameAsResidentialAddr":false,"fromScan":false}]}
 
 {"completed":true}
 
 
 
 
 address/getall
 
 {"neutronCustRefNumber":"13153130380507071902202014294501"}
 
 [{"unit":"HAH","streetNo":"AY","streetName":"HA","landmark":"HA","communicationAddress":true,"addressType":{"code":"ResidentialAddress","name":"Residential Address"},"state":{"code":"UP","name":"Uttar Pradesh"},"city":{"code":"NOI","name":"Noida"},"country":{"code":"IND","name":"India"},"postalCode":{"code":"201301","name":"201301"},"residenceType":{"code":"Chawl","name":"Chawl"},"residentialStatus":{"code":"PARENTAL","name":"Owned by Parent /Sibling"},"numberOfYearsAtAddress":5,"numberOfMonthsAtAddress":5,"numberOfYearsAtCity":5,"numberOfMonthsAtCity":5,"sameAsOfficeAddr":true,"sameAsPermanentAddr":true,"sameAsResidentialAddr":false,"neutronAddressId":"13153130380507071902202014294501_ResidentialAddress"}]
 
 
 
 income/getall
 
 {"neutronCustRefNumber":"13153130380507071902202014294501"}
 
 [{"id":10002,"industry":{"id":10003,"code":"Apparels","name":"Apparels"},"occupationType":{"id":2606,"code":"salaried","name":"Salaried"},"employerName":{"id":10001,"code":"ABC","name":"ABC Bank"},"majorOccupation":false,"natureOfBusiness":{"id":2562,"code":"Manufacturing","name":"Manufacturing"},"otherEmployerName":"","organizationName":"","registrationNumber":"","employedFrom":"2020-02-15T00:00:00.000+0000","employmentId":"13153130380507071902202014294501914","incomeDetails":[]},{"id":10003,"occupationType":{"id":2609,"code":"others","name":"Others"},"employerName":{},"majorOccupation":true,"otherEmployerName":"","natureOfOccupation":{"id":600862,"code":"Farmer and Commercial","name":"Farmer and Commercial"},"organizationName":"","registrationNumber":"","employmentId":"13153130380507071902202014294501885","incomeDetails":[]}]
 
 
 
 income/save
 
 R1 -
 {"neutronReferenceNumber":"131531303805070719022020142945","neutronCustRefNumber":"13153130380507071902202014294501","employmentDetails":[{"employmentId":"13153130380507071902202014294501914","occupationType":{"code":"salaried","name":"Salaried"},"employerName":{"code":"ABC","name":"ABC Bank"},"industry":{"code":"Apparels","name":"Apparels"},"natureOfBusiness":{"code":"Manufacturing","name":"Manufacturing"},"natureOfOccupation":{},"organizationName":"","otherEmployerName":"","incomeDetails":[{"incomeId":"13153130380507071902202014294501177","incomeExpense":{"code":"BS","name":"BASIC"},"incomeFrequency":{"code":"BIMONTHLY","name":"Bi-Monthly"},"grossAmount":"946","percentage":"45","netAmount":"425.70","year1Income":"","year2Income":"","year3Income":""}]}]}
 
 R2 -
 {"neutronReferenceNumber":"131531303805070719022020142945","neutronCustRefNumber":"13153130380507071902202014294501","employmentDetails":[{"employmentId":"13153130380507071902202014294501885","occupationType":{"code":"others","name":"Others"},"employerName":{},"industry":{},"natureOfBusiness":{},"natureOfOccupation":{"code":"Farmer and Commercial","name":"Farmer and Commercial"},"organizationName":"","otherEmployerName":"","incomeDetails":[{"incomeId":"13153130380507071902202014294501599","incomeExpense":{"code":"BS","name":"BASIC"},"incomeFrequency":{"code":"BIMONTHLY","name":"Bi-Monthly"},"grossAmount":"94","percentage":"43","netAmount":"40.42","year1Income":"","year2Income":"","year3Income":""}]}]}
 
 {"completed":true}
 
 
 
 deduction/getall
 
 {"neutronCustRefNumber":"13153130380507071902202014294501"}
 
 [{"id":10002,"industry":{"id":10003,"code":"Apparels","name":"Apparels"},"occupationType":{"id":2606,"code":"salaried","name":"Salaried"},"employerName":{"id":10001,"code":"ABC","name":"ABC Bank"},"majorOccupation":false,"natureOfBusiness":{"id":2562,"code":"Manufacturing","name":"Manufacturing"},"otherEmployerName":"","organizationName":"","registrationNumber":"","employedFrom":"2020-02-15T00:00:00.000+0000","employmentId":"13153130380507071902202014294501914","deductionDetails":[]},{"id":10003,"occupationType":{"id":2609,"code":"others","name":"Others"},"employerName":{},"majorOccupation":true,"otherEmployerName":"","natureOfOccupation":{"id":600862,"code":"Farmer and Commercial","name":"Farmer and Commercial"},"organizationName":"","registrationNumber":"","employmentId":"13153130380507071902202014294501885","deductionDetails":[]}]
 
 
 
 deduction/save
 
 {"neutronReferenceNumber":"131531303805070719022020142945","neutronCustRefNumber":"13153130380507071902202014294501","employmentDetails":[{"employmentId":"13153130380507071902202014294501914","occupationType":{"code":"salaried","name":"Salaried"},"employerName":{"code":"ABC","name":"ABC Bank"},"industry":{"code":"Apparels","name":"Apparels"},"natureOfBusiness":{"code":"Manufacturing","name":"Manufacturing"},"natureOfOccupation":{},"organizationName":"","otherEmployerName":"","deductionDetails":[{"deductionId":"20200221125636002","deductionType":{"code":"GC1","name":"Groceries"},"deductionFrequency":{"code":"FORTNIGHTLY","name":"Fortnightly"},"grossAmount":"676","percentage":"34","netAmount":"229.84","year1Deduction":"","year2Deduction":"","year3Deduction":""}]}]}
 
 {"completed":true}
 
 
 
 expense/save
 
 {"neutronReferenceNumber":"131531303805070719022020142945","neutronCustRefNumber":"13153130380507071902202014294501","expenseDetails":[{"expenseId":"13153130380507071902202014294501_TDS","expenseType":{"code":"TDS","name":"INCOME TAX \/ TDS "},"expenseFrequency":{"code":"BIMONTHLY","name":"Bi-Monthly"},"grossAmount":"646","percentage":"100.0","netAmount":"646.00"}]}
 
 {"completed":true}
 
 
 expense/getall
 
 {"neutronCustRefNumber":"13153130380507071902202014294501"}
 
 [{"expenseType":{"code":"TDS","name":"INCOME TAX / TDS "},"grossAmount":646.00,"expenseFrequency":{"code":"BIMONTHLY","name":"Bi-Monthly"},"externalFlag":false,"percentage":"100.0","expenseId":"13153130380507071902202014294501_TDS"}]
 
 
 
 incomeasset/save
 
 {"neutronReferenceNumber":"131531303805070719022020142945","neutronCustRefNumber":"13153130380507071902202014294501","incomeAssetDetails":[{"incomeAssetCategory":{"code":"agriculture_land","name":"Agriculture Land"},"incomeAssetType":{"code":"Agriculture Land","name":"Agriculture Land"},"assetId":"13153130380507071902202014294501207","incomeAssetValue":"6464","incomeAssetDescription":"ha"}]}
 
 {"completed":true}
 
 
 
 incomeasset/getall
 
 {"neutronCustRefNumber":"13153130380507071902202014294501"}
 
 [{"incomeAssetCategory":{"code":"agriculture_land","name":"Agriculture Land"},"incomeAssetType":{"code":"Agriculture Land","name":"Agriculture Land"},"incomeAssetValue":6464.00,"incomeAssetDescription":"ha","assetId":"13153130380507071902202014294501207"}]
 
 
 
 liability/save
 
 {"neutronReferenceNumber":"131531303805070719022020142945","neutronCustRefNumber":"13153130380507071902202014294501","liabilityDetails":[{"liabilityType":{"code":"Loans","name":"Loans"},"externalProduct":{"code":"AUTO LOAN","name":"AUTO LOAN"},"institution":{"code":"Codd","name":"Codd"},"frequencyForLiability":{"code":"5","name":"Half Yearly"},"installmentAmount":"79","closedDate":"2020-02-22","otherLiabilityDescription":"","sanctionedAmount":"676494","loanTenure":"","balance":"434","emiStartDate":"2020-02-14","liabilityId":"13153130380507071902202014294501896"}]}
 
 
 {"completed":true}
 
 
 
 liability/getall
 
 {"neutronCustRefNumber":"13153130380507071902202014294501"}

 
 [{"liabilityType":{"code":"Loans","name":"Loans"},"frequencyForLiability":{"code":"5","name":"Half Yearly"},"externalProduct":{"code":"AUTO LOAN","name":"AUTO LOAN"},"installmentAmount":79.00,"balance":434.00,"sanctionedAmount":676494.00,"otherLiabilityDescription":"","bureauFlag":false,"closedDate":"2020-02-22T00:00:00.000+0000","emiStartDate":"2020-02-14T00:00:00.000+0000","loanTenure":0,"liabilityId":"13153130380507071902202014294501896"}]
 
 
 
 posidex/initiate
 
 {"neutronReferenceNumber":"131531303805070719022020142945","applicant":{"neutronCustRefNumber":"13153130380507071902202014294501"}}
 
 {"pdf":"JVBERi0xLjQKJeLjz9MKlMjQ0PjxiZGIxOTVlNjA0MzYyNDBkODAzNTlmNGI1NzNmNzQ4NT5dL1Jvb3QgMTggMCBSL1NpemUgMjA+PgpzdGFydHhyZWYKNTMyNzgKJSVFT0YK"}
 
 
 
 
 posidex/report
 
 {"neutronReferenceNumber":"131531303805070719022020142945","applicant":{"neutronCustRefNumber":"13153130380507071902202014294501"}}
 
 {}
 
 
 
 loancontract/get
 
 {"neutronReferenceNumber":"131531303805070719022020142945"}
 
 {"loanDetail":{"productType":{"code":"CON_VEH","name":"Consumer Vehicle"}}}
 
 
 
 loancontract/save
 
 {"neutronReferenceNumber":"131531303805070719022020142945","loanDetail":{"tenure":"25","dueDay":"19","rateOfInterest":"24","loanAmount":"94949","noOfAdvanceEmi":"","branch":{"code":"BAN","name":"BANDRA"},"productType":{"code":"CON_VEH","name":"Consumer Vehicle"},"applicationType":{},"product":{"code":"AAL","name":"AAL"},"scheme":{"code":"AL","name":"AIB Banking Program"},"loanPurpose":{"code":"PUU","name":"Used Vehicle Purchase"},"rmOfficer":{"code":"5000240","name":"Ajay Ojha"}}}
 
 {"completed":true}
 
 
 
 */

