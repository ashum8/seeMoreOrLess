//
//  SourcingDashboardVC.swift
//  mCAS
//
//  Created by Ashutosh Mishra on 29/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class SourcingDashboardVC: UIViewController {
    
    @IBOutlet weak var addDetailView: LoanDetailOptionView!
    @IBOutlet weak var applicantDetailView: LoanDetailOptionView!
    @IBOutlet weak var addCollateralDetailView: LoanDetailOptionView!
    @IBOutlet weak var uploadDocumentView: LoanDetailOptionView!
    @IBOutlet weak var sideMenuView: SideMenuView!
    @IBOutlet weak var sideMenuLeftMargin: NSLayoutConstraint!
    @IBOutlet weak var sideMenuBGView: UIView!
    
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var titleLabel: UILabel!
    
    private var applicationType: DropDown!
    private var productCategory: LoanType!
    
    private let addDetailTag = 100
    private let applicantDetailTag = 101
    private let collateralDetailTag = 102
    private let uploadDocumentTag = 103
    
    //Slider TableView Grid
    private let NEED_ANALYSIS               = "NEED_ANALYSIS"
    private let CHECKS_VERIFICATION         = "CHECKS_VERIFICATION"
    private let CHECK_ELIGIBILITY           = "CHECK_ELIGIBILITY"
    private let PERSONAL_DISCUSSION         = "PERSONAL_DISCUSSION"
    private let PROCESSING_FEES             = "PROCESSING_FEES"
    private let REFERENCE_DETAIL            = "REFERENCE_DETAIL"
    
    private var listModelArray = [ButtonModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            headerView.showHideStepHeader(isHide: false)
            bottomView.isHidden = true
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideStepHeader(isHide: true)
        }
    }
    
    func setData(productCategory: LoanType, applicationType: DropDown) {
        self.productCategory = productCategory
        self.applicationType = applicationType
    }
    
    private func setupView() {
        
        setTableViewData()
        
        addDetailView.setProperties(title: "Add Loan Details", image: "sourcing_dashboard_loan_details_icon", delegate: self, tag: addDetailTag)
        
        applicantDetailView.setProperties(title: "Applicant Details", image: "individual_icon", progressColor: Color.GREEN, progressTitle: "100% Completed", delegate: self, tag: applicantDetailTag)
        
        addCollateralDetailView.setProperties(title: "Add Collateral Details", image: "sourcing_dashboard_collateral_icon", delegate: self, tag: collateralDetailTag)
        
        uploadDocumentView.setProperties(title: "Upload Documents", image: "sourcing_dashboard_upload_doc_icon", delegate: self, tag: uploadDocumentTag)
        
        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(22)
        
        buttonView.setProperties(nextBtnTitle: "Review & Submit", delegate: self)
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: true)
        
        sideMenuView.setProperties(delegate: self, arrList: listModelArray)
    }
    
    private func setTableViewData() {
        
        listModelArray.append(ButtonModel(buttonText: "Need Analysis", buttonID: NEED_ANALYSIS, buttonImage: "sourcing_dashboard_upload_doc_icon", order: 1))
        
        listModelArray.append(ButtonModel(buttonText: "Checks and Verifications", buttonID: CHECKS_VERIFICATION, buttonImage: "sourcing_dashboard_upload_doc_icon", order: 2))
        
        listModelArray.append(ButtonModel(buttonText: "Check Eligibility", buttonID: CHECK_ELIGIBILITY, buttonImage: "sourcing_dashboard_upload_doc_icon", order: 3))
                
        listModelArray.append(ButtonModel(buttonText: "Personal Discussion", buttonID: PERSONAL_DISCUSSION, buttonImage: "sourcing_dashboard_upload_doc_icon", order: 4))

        listModelArray.append(ButtonModel(buttonText: "Processing Fees", buttonID: PROCESSING_FEES, buttonImage: "sourcing_dashboard_upload_doc_icon", order: 5))
        
        listModelArray.append(ButtonModel(buttonText: "Referance Detail", buttonID: REFERENCE_DETAIL, buttonImage: "sourcing_dashboard_upload_doc_icon", order: 6))
    }
}

extension SourcingDashboardVC: LoanDetailOptionViewDelegate {
    
    func buttonAction(tag: Int) {
        
        switch tag
        {
        case addDetailTag:
            let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
            
            if let vc = storyboard.instantiateViewController(withIdentifier: "SourcingLoanDetailVC") as? SourcingLoanDetailVC {
                vc.setData(productCategory: self.productCategory, applicationType: self.applicationType)
                self.navigationController?.pushViewController(vc, animated: true)
            }
            
        case applicantDetailTag:
            let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
            
            if let vc = storyboard.instantiateViewController(withIdentifier: "ApplicantListVC") as? ApplicantListVC {
                self.navigationController?.pushViewController(vc, animated: true)
            }
            
        case collateralDetailTag:
            let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
            
            if let vc = storyboard.instantiateViewController(withIdentifier: "CollateralListVC") as? CollateralListVC {
                self.navigationController?.pushViewController(vc, animated: true)
            }
            
        case uploadDocumentTag:
            print("upload document")
            
        default:
            break
        }
    }
}

extension SourcingDashboardVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        let st = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "SourcingSearchResultVC") as! SourcingSearchResultVC
        self.navigationController?.pushViewController(vc, animated: false)
    }
}

extension SourcingDashboardVC: SideMenuDelegate {
    
    func showHideSideMenu(isOpen: Bool) {
        self.sideMenuBGView.isHidden = !isOpen
        if isOpen {
            self.sideMenuLeftMargin.constant = 0
            UIView.animate(withDuration: 0.3) {
                self.view.layoutIfNeeded()
                self.sideMenuBGView.alpha = 0.5
            }
        }
        else {
            self.sideMenuLeftMargin.constant = 125
            UIView.animate(withDuration: 0.3) {
                self.view.layoutIfNeeded()
                self.sideMenuBGView.alpha = 0
            }
        }
    }
    
    func selectedSideMenuItem(index: Int) {
        
        let btnModel = listModelArray[index]
        
        switch btnModel.buttonID {
        case NEED_ANALYSIS:
            print("NEED_ANALYSIS")
        case CHECKS_VERIFICATION:
            print("CHECKS_VERIFICATION")
            
        case CHECK_ELIGIBILITY:
            print("CHECK_ELIGIBILITY")
            
        case PERSONAL_DISCUSSION:
            print("PERSONAL_DISCUSSION")
            
        case PROCESSING_FEES:
            print("PROCESSING_FEES")
            
        case REFERENCE_DETAIL:
            print("REFERENCE_DETAIL")
            
        default:
            break
        }
    }
    
}
