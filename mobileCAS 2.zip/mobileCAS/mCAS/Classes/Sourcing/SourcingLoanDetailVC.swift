//
//  SourcingLoanDetailVC.swift
//  mCAS
//
//  Created by iMac on 20/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class SourcingLoanDetailVC: UIViewController {
    
    @IBOutlet weak var branchLOV: LOVFieldView!
    @IBOutlet weak var productTypeLOV: LOVFieldView!
    @IBOutlet weak var schemeLOV: LOVFieldView!
    @IBOutlet weak var loanPurposeLOV: LOVFieldView!
    @IBOutlet weak var agentLOV: LOVFieldView!
    @IBOutlet weak var loanAmountTFView: CustomTextFieldView!
    @IBOutlet weak var tenureTFView: CustomTextFieldView!
    @IBOutlet weak var rateTFView: CustomTextFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var installmentTitleLabel: UILabel!
    @IBOutlet weak var firstRadioButton: RadioButtonView!
    @IBOutlet weak var secondRadioButton: RadioButtonView!
    @IBOutlet weak var thirdRadioButton: RadioButtonView!
    @IBOutlet weak var fourthRadioButton: RadioButtonView!
    @IBOutlet weak var dayOfMonthView: UIView!
    @IBOutlet weak var dueDateTitleLabel: UILabel!
    @IBOutlet weak var dayOfMonthViewHeight: NSLayoutConstraint!
    @IBOutlet weak var dayOfMonthButton: UIButton!
    @IBOutlet weak var noOfAdvanceEMIView: CustomTextFieldView!
    @IBOutlet weak var noOfAdvanceEmiViewHeight: NSLayoutConstraint!
    
    private let TAG_BRANCH      = 1000
    private let TAG_PRODUCT     = 1001
    private let TAG_SCHEME      = 1002
    private let TAG_LOANPURPOSE = 1003
    private let TAG_AGENT       = 1004
    private let TAG_AMOUNT      = 10000
    private let TAG_TENURE      = 10001
    private let TAG_ROI         = 10002
    private let TAG_ADVANCE_EMI = 10003
    
    private let MaxLimitLoanAmount = 10000000
    private let MaxLimitRate       = 30.00
    private let MaxLimitTenure     = 30
    
    
    private enum RadioBtnOption: String, CaseIterable {
        case First = "5"
        case Second = "10"
        case Third = "15"
        case Other = "Others"
    }
    
    private enum suffix: String {
        case th = "th"
        case st = "st"
        case nd = "nd"
        case rd = "rd"
    }
    
    private var selectedLOVDic: [String: DropDown] = [:]
    private var dueDatePopView: MonthView!
    
    private var applicationType: DropDown!
    private var productCategory: LoanType!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    private func setupView() {
        
        branchLOV.setLOVProperties(masterName: Entity.BRANCH, title: "Branch", tag: TAG_BRANCH, delegate: self)
        productTypeLOV.setLOVProperties(masterName: Entity.PRODUCT, title: "Product Type", tag: TAG_PRODUCT, delegate: self, parentKey: self.productCategory.code)
        schemeLOV.setLOVProperties(masterName: Entity.SCHEME, title: "Scheme", tag: TAG_SCHEME, delegate: self)
        loanPurposeLOV.setLOVProperties(masterName: Entity.LOAN_PURPOSE, title: "Loan Purpose", tag: TAG_LOANPURPOSE, delegate: self, parentKey: self.productCategory.code)
        agentLOV.setLOVProperties(masterName: Entity.SALES_AGENT, title: "Sales Agent", tag: TAG_AGENT, delegate: self)
        
        loanAmountTFView.setProperties(placeHolder: "Loan Amount Requested", type: .Amount, delegate: self, tag: TAG_AMOUNT)
        tenureTFView.setProperties(placeHolder: "Tenure", type: .Number, delegate: self, unitText: "Year", tag: TAG_TENURE)
        rateTFView.setProperties(placeHolder: "Rate of interest", type: .Decimal, delegate: self, unitText: "%", tag: TAG_ROI)
        noOfAdvanceEMIView.setProperties(placeHolder: "No. of Advance EMI", type: .Number, delegate: self, tag: TAG_ADVANCE_EMI)
        
        buttonView.setProperties(nextBtnTitle: "Save Details", delegate: self)
        dayOfMonthButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(19)
        installmentTitleLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
        
        firstRadioButton.setProperties(title: "\(RadioBtnOption.First.rawValue)\(suffix.th.rawValue)", delegate: self)
        secondRadioButton.setProperties(title: "\(RadioBtnOption.Second.rawValue)\(suffix.th.rawValue)", delegate: self)
        thirdRadioButton.setProperties(title: "\(RadioBtnOption.Third.rawValue)\(suffix.th.rawValue)", delegate: self)
        fourthRadioButton.setProperties(title: "\(RadioBtnOption.Other.rawValue)", delegate: self)
        
        dayOfMonthView.layer.masksToBounds = true
        dayOfMonthView.setMainViewProperties()
        
        if self.productCategory.code == ConstantCodes.PRODUCT_TYPE_CL {
            noOfAdvanceEmiViewHeight.constant = 65
        }
        validateFields()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            let navArray = AppDelegate.instance.applicationNavController.viewControllers
            let lastVC = navArray[navArray.count-2]
            headerView.showHideStepHeader(isHide: false, title: "Loan Details", landingPage: lastVC)
            bottomView.isHidden = true
        }
    }
    
    func setData(productCategory: LoanType, applicationType: DropDown) {
        self.productCategory = productCategory
        self.applicationType = applicationType
    }
    
    private func resetAllRadioButton() {
        
        firstRadioButton.setButtonState(isSelected: false)
        secondRadioButton.setButtonState(isSelected: false)
        thirdRadioButton.setButtonState(isSelected: false)
        fourthRadioButton.setButtonState(isSelected: false)
    }
    
    @IBAction func dueDatesButtonAction(_ sender: Any) {
        
        if self.dueDatePopView == nil {
            self.dueDatePopView = .fromNib()
            self.dueDatePopView.setProperties(width: self.view.frame.size.width, height: self.view.frame.size.height, delegate: self, removeOptionsArr: RadioBtnOption.allCases.map { $0.rawValue })
            self.view.addSubview(self.dueDatePopView)
        }
        
        self.dueDatePopView.collectionView.reloadData()
        self.dueDatePopView.alpha = 1
    }
    
    private func getSuffix(day: String) -> String {
        
        switch day {
        case "1", "21", "31" : return suffix.st.rawValue
        case "2", "22": return suffix.nd.rawValue
        case "3", "23": return suffix.rd.rawValue
        default: return suffix.th.rawValue
        }
    }
    
    
}

extension SourcingLoanDetailVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        if btntag == TAG_PRODUCT {
            if let dd = selectedLOVDic["\(TAG_PRODUCT)"] {
                schemeLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_SCHEME)"] = nil
            }
        }
        
        validateFields()
    }
}

extension SourcingLoanDetailVC: CustomTFViewDelegate {
    func validateFields() {
        
        var isEnabled = true
        let installmentDate = dayOfMonthButton.title(for: .normal) ?? ""
        
        if (selectedLOVDic["\(TAG_BRANCH)"] == nil || selectedLOVDic["\(TAG_PRODUCT)"] == nil || selectedLOVDic["\(TAG_SCHEME)"] == nil || selectedLOVDic["\(TAG_LOANPURPOSE)"] == nil || selectedLOVDic["\(TAG_AGENT)"] == nil || loanAmountTFView.getFieldValue().isEmpty || tenureTFView.getFieldValue().isEmpty || rateTFView.getFieldValue().isEmpty ) || installmentDate.isEmpty
        {
            
            isEnabled = false
        }
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch tag {
        case TAG_AMOUNT:
            return Int(text) ?? 0 <= MaxLimitLoanAmount
        case TAG_ROI:
            return Double(text) ?? 0.0 <= MaxLimitRate
        case TAG_TENURE:
            return Int(text) ?? 0 <= MaxLimitTenure
        case TAG_ADVANCE_EMI:
            return text.count <= 3
        default:
            return true
        }
    }
}

extension SourcingLoanDetailVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        print("save details call")
    }
    
}

extension SourcingLoanDetailVC: RadioButtonDelegate {
    
    func selectedRadioButton(view: RadioButtonView) {
        resetAllRadioButton()
        
        switch view {
            
        case firstRadioButton, secondRadioButton, thirdRadioButton:
            dayOfMonthViewHeight.constant = 0
            view.radioButton.isSelected = true
            dayOfMonthButton.setTitle(view.titleLabel.text, for: .normal)
            
            if let view = self.dueDatePopView {
                view.selectedDay = ""
            }
            validateFields()
            
        case fourthRadioButton:
            dayOfMonthButton.sendActions(for: .touchUpInside)
            
        default:
            debugPrint("case not matched")
        }
    }
}

extension SourcingLoanDetailVC: MonthViewDelegate {
    func selectedDueDate(day: String) {
        if !day.isEmpty {
            dayOfMonthButton.setTitle("\(day)\(getSuffix(day: day))", for: .normal)
            fourthRadioButton.radioButton.isSelected = true
            dayOfMonthViewHeight.constant = 50
        }
        else {
            dayOfMonthButton.setTitle("", for: .normal)
        }
        validateFields()
    }
}
