//
//  AddEmploymentVC.swift
//  mCAS
//
//  Created by iMac on 24/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddEmploymentVC: UIViewController {
    
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var employmentTypeLOV: LOVFieldView!
    @IBOutlet weak var employerNameLOV: LOVFieldView!
    @IBOutlet weak var employerViewHeight: NSLayoutConstraint!
    @IBOutlet weak var natureOfBusinessLOV: LOVFieldView!
    @IBOutlet weak var natureOfBViewHeight: NSLayoutConstraint!
    @IBOutlet weak var industryLOV: LOVFieldView!
    @IBOutlet weak var industryLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var employedFromView: CustomTextFieldView!
    @IBOutlet weak var employedFromViewHeight: NSLayoutConstraint!
    @IBOutlet weak var checkBoxButton: UIButton!
    @IBOutlet weak var organizationView: CustomTextFieldView!
    @IBOutlet weak var organizationViewHeight: NSLayoutConstraint!
    @IBOutlet weak var registrationNoView: CustomTextFieldView!
    @IBOutlet weak var registrationNoViewHeight: NSLayoutConstraint!
    
    private let TAG_EMP_TYPE = 1000
    private let TAG_EMPLOYER = 1001
    private let TAG_BUSINESS = 1002
    private let TAG_INDUSTRY = 1003
    
    private var selectedLOVDic: [String: DropDown] = [:]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    private func setupView() {
        
        employmentTypeLOV.setLOVProperties(masterName: Entity.OCCUPATION_TYPE, title: "Employment Type", tag: TAG_EMP_TYPE, delegate: self)
        employerNameLOV.setLOVProperties(masterName: Entity.EMPLOYER, title: "Employer Name", tag: TAG_EMPLOYER, delegate: self)
        industryLOV.setLOVProperties(masterName: Entity.INDUSTRY, title: "Industry", tag: TAG_INDUSTRY, delegate: self)
        
        employedFromView.setProperties(placeHolder: "Employed From",type: .DATE, delegate: self)
        organizationView.setProperties(placeHolder: "Organization Name",type: .Text, delegate: self)
        registrationNoView.setProperties(placeHolder: "Registration Number",type: .Text, delegate: self)
        
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        checkBoxButton.setCheckboxProperties(title: "Mark this as primary employment", isSelected: false)
        
        validateFields()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Employment")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: true)
        }
    }
    
    @IBAction func checkBoxButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }
    
    private func refreshFieldData() {
        employedFromView.setFieldValue()
        natureOfBusinessLOV.resetLOVWithParentKey(key: "")
        industryLOV.resetLOVWithParentKey(key: "")
        employedFromView.setFieldValue()
        registrationNoView.setFieldValue()
        organizationView.setFieldValue()
        selectedLOVDic["\(TAG_BUSINESS)"] = nil
        selectedLOVDic["\(TAG_INDUSTRY)"] = nil
    }
    
    private func setFields(showEmployer: Bool = false, showNatureOfBusiness: Bool = false, showIndustry: Bool = false, showEmployedFrom: Bool = false, showRegistrationNo: Bool = false, showOrganization: Bool = false) {
        
        refreshFieldData()

        employerViewHeight.constant         = (showEmployer ? 65 : 0)
        natureOfBViewHeight.constant        = (showNatureOfBusiness ? 65 : 0)
        industryLOVHeight.constant          = (showIndustry ? 65 : 0)
        employedFromViewHeight.constant     = (showEmployedFrom ? 65 : 0)
        registrationNoViewHeight.constant   = (showRegistrationNo ? 65 : 0)
        organizationViewHeight.constant     = (showOrganization ? 65 : 0)
    }
}

extension AddEmploymentVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        if btntag == TAG_EMP_TYPE {
            
            switch selectedObj.code {
                
            case ConstantCodes.EMP_TYPE_OTH:
                setFields(showNatureOfBusiness: true)
                natureOfBusinessLOV.setLOVProperties(masterName: Entity.NATURE_OF_OCCUPATION, title: "Nature of Occupation", tag: TAG_BUSINESS, delegate: self)
                
            case ConstantCodes.EMP_TYPE_SAL:
                setFields(showEmployer: true, showNatureOfBusiness: true, showIndustry: true, showEmployedFrom: true)
                natureOfBusinessLOV.setLOVProperties(masterName: Entity.BUSINESS_NATURE, title: "Nature of Business", tag: TAG_BUSINESS, delegate: self)
                
            case ConstantCodes.EMP_TYPE_SENP:
                setFields(showNatureOfBusiness: true, showOrganization: true)
                natureOfBusinessLOV.setLOVProperties(masterName: Entity.BUSINESS_NATURE, title: "Nature of Business", tag: TAG_BUSINESS, delegate: self)
                
            case ConstantCodes.EMP_TYPE_SEP:
                setFields(showNatureOfBusiness: true, showRegistrationNo: true, showOrganization: true)
                natureOfBusinessLOV.setLOVProperties(masterName: Entity.NATURE_OF_PROF, title: "Nature of Profession", tag: TAG_BUSINESS, delegate: self)
                
            default:
                setFields()
                natureOfBusinessLOV.setLOVProperties(masterName: Entity.BUSINESS_NATURE, title: "Nature of Business", tag: TAG_BUSINESS, delegate: self)
            }
        }
        validateFields()
    }
}

extension AddEmploymentVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = !(selectedLOVDic["\(TAG_EMP_TYPE)"] == nil || selectedLOVDic["\(TAG_BUSINESS)"] == nil)
        
        if isEnabled, let selectedObj = selectedLOVDic["\(TAG_EMP_TYPE)"]
        {
            if selectedObj.code == ConstantCodes.EMP_TYPE_SAL {
                isEnabled = !(selectedLOVDic["\(TAG_EMPLOYER)"] == nil || selectedLOVDic["\(TAG_INDUSTRY)"] == nil || employedFromView.getFieldValue().isEmpty )
            }
            else if selectedObj.code == ConstantCodes.EMP_TYPE_SENP {
                isEnabled = !(organizationView.getFieldValue().isEmpty)
            }
            else if selectedObj.code == ConstantCodes.EMP_TYPE_SEP {
                isEnabled = !(organizationView.getFieldValue().isEmpty || registrationNoView.getFieldValue().isEmpty)
            }
        }
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        return text.isAlphanumeric
    }
}

extension AddEmploymentVC: NextBackButtonDelegate {
    func nextButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}
