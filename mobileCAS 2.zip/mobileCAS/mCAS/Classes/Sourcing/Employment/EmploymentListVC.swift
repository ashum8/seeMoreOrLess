//
//  EmploymentListVC.swift
//  mCAS
//
//  Created by iMac on 23/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class EmploymentListVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var headerTitleView: SourcingTitleView!
    
    private enum DetailOptions: String {
        case edit = "Edit"
        case delete = "Delete"
        case asPrimary = "Mark as Primary"
    }
    
    private struct EmploymentDataModel {
        var title: String
        var type: String
    }
    
    private var employmentModelArray = [EmploymentDataModel]()
    private var cellOptionArray: [DetailOptions] = [.edit, .delete, .asPrimary]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    private func setupView() {
        
        employmentModelArray.append(EmploymentDataModel(title: "xyz", type: "salaried"))
        employmentModelArray.append(EmploymentDataModel(title: "ABC", type: "Business"))
        employmentModelArray.append(EmploymentDataModel(title: "Azsx.", type: "salaried"))
        employmentModelArray.append(EmploymentDataModel(title: "ewr", type: "Business"))
        employmentModelArray.append(EmploymentDataModel(title: "erwtwer ", type: "salaried"))
        
        headerTitleView.setProperties(title: "Employment")
        
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        addButton.setPlusButtonProperties()
        
        noDataCapturedView.setProperties()
        
        tableView.register(UINib(nibName: "SourcingCommonListCell", bundle: nil), forCellReuseIdentifier: "SourcingCommonListCell")
        tableView.tableFooterView = UIView()
        
        buttonView.setProperties(showBack: true, nextBtnTitle: "Continue", delegate: self)
    }
    
    private func setListData() {
        tableView.isHidden = true
        noDataCapturedView.isHidden = !tableView.isHidden
        self.tableView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideStepHeader(isHide: false, title: "Add Applicant")
        }
    }
    
    @IBAction func addButtonAction(_ sender: UIButton) {
        let st = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = st.instantiateViewController(withIdentifier: "AddEmploymentVC") as? AddEmploymentVC {
            AppDelegate.instance.applicationNavController.pushViewController(vc , animated: true)
        }
    }
}

extension EmploymentListVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return employmentModelArray.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SourcingCommonListCell", for: indexPath) as! SourcingCommonListCell
        
        cell.setProperties(optionArray: cellOptionArray.map({ $0.rawValue }), cellIndex: indexPath.row, delegate: self, showStatus: true)
        cell.label1.text = employmentModelArray[indexPath.row].title
        cell.label2.text = employmentModelArray[indexPath.row].type
        cell.label3.text = "PRIMARY"
        return cell
    }
    
    
}

extension EmploymentListVC : NextBackButtonDelegate {
    func nextButtonAction() {
        let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "SourcingAddressListVC") as? SourcingAddressListVC {
            AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
        }
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}

extension EmploymentListVC : CommonListCellDelegate {
    
    func selectedIndex(index: Int, cellIndex: Int) {
        let item = self.cellOptionArray[index]
        if item == .edit {
            
            
        }
        else if item == .delete {
            employmentModelArray.remove(at: cellIndex)
            tableView.reloadData()
        }
        else if item == .asPrimary {
            
        }
    }
}
