//
//  ApplicantSearchVC.swift
//  mCAS
//
//  Created by iMac on 05/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

enum ApplicantType {
    case Individual
    case Corporate
}

class ApplicantSearchVC: UIViewController {
    
    @IBOutlet weak var indButton: UIButton!
    @IBOutlet weak var corpButton: UIButton!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var searchTypeLOV: LOVFieldView!
    @IBOutlet weak var textView: CustomTextFieldView!
    @IBOutlet weak var textViewHeight: NSLayoutConstraint!
    
    private let TAG_SEARCH_TYPE = 1000
    private var selectedLOVDic: [String: DropDown] = [:]
    
    private var customerType: ApplicantType!
    private var dropDownList = [DropDown]()
    
    private let APPLICATION_ID_CODE = "APPID"
    private let ACCOUNT_NUMBER_CODE = "ACC_NUMBER"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            let navArray = AppDelegate.instance.applicationNavController.viewControllers
            let lastVC = navArray[navArray.count-2]
            headerView.showHideStepHeader(isHide: false, landingPage: lastVC)
            bottomView.isHidden = true
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideStepHeader(isHide: true)
        }
    }
    
    private func setupView() {
        
        dropDownList.append(DropDown(code: APPLICATION_ID_CODE, name: "Application ID"))
        dropDownList.append(DropDown(code: "CUST_NAME", name: "Customer Name + Mobile Number"))
        dropDownList.append(DropDown(code: "ID_TYPE", name: "Identification Type"))
        dropDownList.append(DropDown(code: ACCOUNT_NUMBER_CODE, name: "Account Number"))
        
        searchTypeLOV.setLOVProperties(title: "Search Type", tag: TAG_SEARCH_TYPE, delegate: self, optionArray: dropDownList)
        textView.setProperties(placeHolder: "Enter Number", delegate: self)
        buttonView.setProperties(nextBtnTitle: "Search", delegate: self)
        
        indButton.sendActions(for: .touchUpInside)
        
        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(22)
        
        validateFields()
    }
    
    @IBAction func searchTypeButtonAction(_ sender: UIButton) {
        
        if !sender.isSelected {
            if sender == indButton {
                customerType = .Individual
                corpButton.resetSegmentButtonProperties()
                indButton.setSelectedSegmentButtonProperties()
            }
            else {
                customerType = .Corporate
                indButton.resetSegmentButtonProperties()
                corpButton.setSelectedSegmentButtonProperties()
            }
        }
    }
}

extension ApplicantSearchVC : NextBackButtonDelegate {
    func nextButtonAction() {
        let st = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        if let vc = st.instantiateViewController(withIdentifier: "SourcingSearchResultVC") as? SourcingSearchResultVC {
            vc.setData(type: self.customerType)
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

extension ApplicantSearchVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        textViewHeight.constant = 65
        validateFields()
    }
}

extension ApplicantSearchVC: CustomTFViewDelegate {
    
    func validateFields() {
        let isEnabled = !(selectedLOVDic["\(TAG_SEARCH_TYPE)"] == nil || textView.getFieldValue().isEmpty)
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        if let selectedObj = selectedLOVDic["\(TAG_SEARCH_TYPE)"]
        {
            if selectedObj.code == APPLICATION_ID_CODE {
                return text.isAlphanumeric && text.count <= Constants.APPLICATION_ID_LENGTH
            }
            else if selectedObj.code == ACCOUNT_NUMBER_CODE {
                return text.isAlphanumeric && text.count <= 18
            }
        }
        return text.isAlphanumeric
    }
}
