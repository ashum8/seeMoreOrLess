//
//  SourcingUploadPhotoVC.swift
//  mCAS
//
//  Created by iMac on 30/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class SourcingUploadPhotoVC: UIViewController {
    
    @IBOutlet weak var headerTitleView: SourcingTitleView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var galleryButton: UIButton!
    
    private var pManager: PhotoManager?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    private func setupView() {
        
        imageView.setCircleImageProperty()
        imageView.image = UIImage(named: "upload_image_placeholder")
        editButton.layer.cornerRadius = 20
        editButton.setButtonShadow()
        
        galleryButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(19)
        
        headerTitleView.setProperties(title: "Upload Photo")
        buttonView.setProperties(showBack: true, nextBtnTitle: "Countinue", delegate: self)
    }
    
    @IBAction func editGalleryButtonAction(_ sender: Any) {
        self.pManager = PhotoManager()
        self.pManager?.delegate = self
        self.pManager!.showImageUploadDialogWithViewController(vc: self)
    }
}

extension SourcingUploadPhotoVC: NextBackButtonDelegate {
    
    func nextButtonAction() {
        
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}

extension SourcingUploadPhotoVC: PhotoManagerDelegate {
    func didFinishPickingImage(image: UIImage) {
        imageView.image = image
    }
}
