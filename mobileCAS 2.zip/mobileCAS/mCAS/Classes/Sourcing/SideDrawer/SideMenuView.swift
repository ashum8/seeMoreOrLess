//
//  SideMenuVC.swift
//  mCAS
//
//  Created by iMac on 03/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

protocol SideMenuDelegate {
    func showHideSideMenu(isOpen: Bool)
    func selectedSideMenuItem(index: Int)
}

class SideMenuView: UIView {
    
    @IBOutlet var containerView: UIView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var sideMenuButton: UIButton!
    
    private var delegate:SideMenuDelegate?
    private var listModelArray = [ButtonModel]()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("SideMenuView", owner: self, options: nil)
        containerView.fixInView(self)
        
        tableView.register(UINib(nibName: "SideMenuTVCell", bundle: nil), forCellReuseIdentifier: "SideMenuTVCell")
        tableView.tableFooterView = UIView()
    }
    
    func setProperties(delegate: SideMenuDelegate, arrList:[ButtonModel]) {
        tableView.setCornerRadius()
        sideMenuButton.setShadow()
        sideMenuButton.setCornerRadius()
        self.delegate = delegate
        self.listModelArray = arrList
    }
    
    @IBAction func sideMenuButtonClicked(_ sender: UIButton){
        sender.isSelected = !sender.isSelected
        delegate?.showHideSideMenu(isOpen: sender.isSelected)
    }
    
    @IBAction func panGestureRecognization(_ sender: UIPanGestureRecognizer) {
        let velocity = sender.velocity(in: self)
        
        delegate?.showHideSideMenu(isOpen: velocity.x < 0)
        sideMenuButton.isSelected = velocity.x < 0
    }
}

extension SideMenuView: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listModelArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let model = listModelArray[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SideMenuTVCell") as! SideMenuTVCell
        cell.setProprties()
        cell.titleLabel.text = model.buttonText
        cell.imgView.image = UIImage(named: model.buttonImage)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        delegate?.selectedSideMenuItem(index: indexPath.row)
    }
}
