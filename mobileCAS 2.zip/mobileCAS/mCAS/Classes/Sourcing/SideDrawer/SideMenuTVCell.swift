//
//  SideMenuTVCell.swift
//  mCAS
//
//  Created by iMac on 03/02/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class SideMenuTVCell: UITableViewCell {

    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    
    func setProprties() {
        titleLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
    }    
}
