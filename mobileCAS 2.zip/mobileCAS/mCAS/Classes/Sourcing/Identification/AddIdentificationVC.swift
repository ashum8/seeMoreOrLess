//
//  AddIdentificationVC.swift
//  mCAS
//
//  Created by iMac on 23/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddIdentificationVC: UIViewController {
    
    @IBOutlet weak var identificationTypeLOV: LOVFieldView!
    @IBOutlet weak var identificationNumberView: CustomTextFieldView!
    @IBOutlet weak var issueDateView: CustomTextFieldView!
    @IBOutlet weak var expiryDateView: CustomTextFieldView!
    @IBOutlet weak var issuingCountryLOV: LOVFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private let TAG_IDENTIFICATION = 1000
    private let TAG_COUNTRY = 1001
    
    private var selectedLOVDic: [String: DropDown] = [:]
    private var dropDownList = [DropDown]()
    private var customerType: ApplicantType!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    private func setupView() {
        var parentKey = Constants.ID_TYPE_INDV
        
        if self.customerType == .Corporate {
            parentKey = Constants.ID_TYPE_CORP
        }
        
        identificationTypeLOV.setLOVProperties(masterName: Entity.ID_TYPE, title: "Identification Type", tag: TAG_IDENTIFICATION, delegate: self, parentKey: parentKey)
        issuingCountryLOV.setLOVProperties(masterName: Entity.COUNTRY, title: "Issuing Country", tag: TAG_COUNTRY, delegate: self)
        
        identificationNumberView.setProperties(placeHolder: "Identification No.", delegate: self)
        issueDateView.setProperties(placeHolder: "Issue Date", type: .DATE, delegate: self)
        expiryDateView.setProperties(placeHolder: "Expiry Date", type: .DATE, delegate: self, minimumDate: Date() , maximumDate: nil)
        
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        validateFields()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Identification")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: true)
        }
    }
    
    func setData(type: ApplicantType) {
        self.customerType = type
    }
    
    private func refreshFieldData() {
        identificationNumberView.setFieldValue()
        issueDateView.setFieldValue()
        expiryDateView.setFieldValue()
    }
}


extension AddIdentificationVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = !(selectedLOVDic["\(TAG_IDENTIFICATION)"] == nil || selectedLOVDic["\(TAG_COUNTRY)"] == nil || identificationNumberView.getFieldValue().isEmpty)
        
        if isEnabled, let selectedObj = selectedLOVDic["\(TAG_IDENTIFICATION)"]
        {
            if selectedObj.code == ConstantCodes.ID_TYPE_DL {
                isEnabled = (isEnabled && !(issueDateView.getFieldValue().isEmpty || expiryDateView.getFieldValue().isEmpty))
            }
            else if selectedObj.code == ConstantCodes.ID_TYPE_PASSPORT {
                isEnabled = (isEnabled && !expiryDateView.getFieldValue().isEmpty)
            }
            else if selectedObj.code == ConstantCodes.ID_TYPE_PAN {
                isEnabled = (isEnabled && identificationNumberView.getFieldValue().validatePAN)
            }
        }
        
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        if let selectedObj = selectedLOVDic["\(TAG_IDENTIFICATION)"]
        {
            if selectedObj.code == ConstantCodes.ID_TYPE_AADHAR {
                return text.isNumeric && text.count <= Constants.AADHAR_LENGTH
            }
            else if selectedObj.code == ConstantCodes.ID_TYPE_PAN {
                return text.isAlphanumeric && text.count <= Constants.PAN_LENGTH
            }
        }
        
        return text.isAlphanumeric
    }
}

extension AddIdentificationVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        if btntag == TAG_IDENTIFICATION
        {
            if selectedObj.code == ConstantCodes.ID_TYPE_DL {
                setFields(issueDateOptional: false, expiryDateOptional: false)
            }
            else if selectedObj.code == ConstantCodes.ID_TYPE_PASSPORT {
                setFields(expiryDateOptional: false)
            }
            else {
                setFields()
            }
        }
        validateFields()
    }
    
    private func setFields(issueDateOptional: Bool = true, expiryDateOptional: Bool = true) {
        
        refreshFieldData()
        
        if issueDateOptional {
            issueDateView.setFieldPlaceHolder(placeHolder: "Issue Date (Optional)")
        }
        else {
            issueDateView.setFieldPlaceHolder(placeHolder: "Issue Date")
        }
        
        if expiryDateOptional {
            expiryDateView.setFieldPlaceHolder(placeHolder: "Expiry Date (Optional)")
        }
        else {
            expiryDateView.setFieldPlaceHolder(placeHolder: "Expiry Date")
        }
    }
}

extension AddIdentificationVC: NextBackButtonDelegate {
    func nextButtonAction() {
        
        if let fromDate = CustomDateFormatter.shared().getRespectiveDateFromString(inputString: issueDateView.getFieldValue()),
            let toDate = CustomDateFormatter.shared().getRespectiveDateFromString(inputString: expiryDateView.getFieldValue())
        {
            if fromDate.timeDifferenceInSeconds(toDate: toDate) < 0 {
                CommonAlert.shared().showAlert(message: "expiry date must be greater than issue date")
                return
            }
        }
        
        self.navigationController?.popViewController(animated: true)
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}
