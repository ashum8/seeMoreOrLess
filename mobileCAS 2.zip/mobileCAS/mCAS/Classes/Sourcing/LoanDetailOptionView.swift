//
//  LoanDetailOptionView.swift
//  mCAS
//
//  Created by iMac on 30/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

protocol LoanDetailOptionViewDelegate {
    func buttonAction(tag: Int)
}

class LoanDetailOptionView: UIView {
    
    @IBOutlet var containerView: UIView!
    
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var progressLabel: UILabel!
    @IBOutlet weak var progressView: UIView!
    
    private var delegate: LoanDetailOptionViewDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("LoanDetailOptionView", owner: self, options: nil)
        containerView.fixInView(self)
    }
    
    func setProperties(title: String, image: String, progressColor: UIColor = .clear, progressTitle: String = "", delegate: LoanDetailOptionViewDelegate, tag: Int) {
        
        self.setShadow()
        self.tag = tag
        
        button.setTitle(title, for: .normal)
        button.setImage(UIImage(named: image), for: .normal)
        button.setTitleColor(.darkGray, for: .normal)
        button.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(17)
        button.titleLabel?.numberOfLines = 2
        button.setAlignmentOfButton(isTab: false)
        
        self.delegate = delegate
        progressView.backgroundColor = progressColor
        
        progressLabel.font = CustomFont.shared().GETFONT_REGULAR(14)
        progressLabel.textColor = progressColor
        progressLabel.text = progressTitle
    }
    
    @IBAction func btnClicked(_ sender: Any) {
        delegate?.buttonAction(tag: self.tag)
    }
}
