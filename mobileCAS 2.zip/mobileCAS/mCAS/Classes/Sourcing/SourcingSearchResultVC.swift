//
//  SourcingSearchResultVC.swift
//  mCAS
//
//  Created by iMac on 02/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

struct SearchResultModel {
    let name: String
    let role: String
    let AppId: String
}

import UIKit

class SourcingSearchResultVC: UIViewController {
    
    @IBOutlet weak var resultView: UIView!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    @IBOutlet weak var asNewCustomerButton: UIButton!
    
    @IBOutlet weak var headerDetailView: UIView!
    @IBOutlet weak var lanNumberTitleLabel: UILabel!
    @IBOutlet weak var productCategoryTitleLabel: UILabel!
    @IBOutlet weak var lanNumberLabel: UILabel!
    @IBOutlet weak var productCategoryLabel: UILabel!
    @IBOutlet weak var viewDetailButton: UIButton!
    
    @IBOutlet weak var copyDetailsOfApplicantLabel: UILabel!
    @IBOutlet weak var notInterstedToCopyLabel: UILabel!
    @IBOutlet weak var continueAsNewCustomerButton: UIButton!
    
    @IBOutlet weak var tableView: UITableView!
    
    var listArrayModel = [SearchResultModel]()
    
    private var customerType: ApplicantType!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setListData()
        setupView()
    }
    
    private func setupView() {
        
        noDataCapturedView.setProperties()
        asNewCustomerButton.setButtonProperties()
        headerDetailView.backgroundColor = Color.EXTREME_LIGHT_GRAY
        
        lanNumberTitleLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
        productCategoryTitleLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
        lanNumberLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
        productCategoryLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
        viewDetailButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(17)
        
        copyDetailsOfApplicantLabel.font = CustomFont.shared().GETFONT_REGULAR(19)
        notInterstedToCopyLabel.font = CustomFont.shared().GETFONT_REGULAR(17)
        continueAsNewCustomerButton.titleLabel?.font = CustomFont.shared().GETFONT_REGULAR(17)
        
        lanNumberLabel.text = "68754223"
        productCategoryLabel.text = "Home Loan"
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView, let bottomView = AppDelegate.instance.bottomTabbarView {
            bottomView.isHidden = true
            headerView.setTitleWith(line1: "4 results found", showBack: true)
        }
    }
    
    func setData(type: ApplicantType) {
        self.customerType = type
    }
    
    func setListData() {
        listArrayModel.append(SearchResultModel(name: "ASHUTOSH", role: "Primary Applicant", AppId: "XXXX - XXXX - 9012"))
        listArrayModel.append(SearchResultModel(name: "ASHUTOSH 1", role: "Primary Applicant", AppId: "XXXX - XXXX - 9012"))
        listArrayModel.append(SearchResultModel(name: "ASHUTOSH 2", role: "Primary Applicant", AppId: "XXXX - XXXX - 9012"))
        listArrayModel.append(SearchResultModel(name: "ASHUTOSH 3", role: "Primary Applicant", AppId: "XXXX - XXXX - 9012"))
    }
    
    func noDataFound() {
        resultView.isHidden = true
        noDataCapturedView.isHidden = false
        asNewCustomerButton.isHidden = false
    }
    
    @IBAction func continueAsNewCustomerBtnAction(_ sender: Any) {
        let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "ApplicantPersonalDetailVC") as? ApplicantPersonalDetailVC {
            vc.setData(type: customerType)
            AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
        }
    }
}

extension SourcingSearchResultVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listArrayModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SourcingSearchResultCell", for: indexPath) as! SourcingSearchResultCell
        
        cell.setProperties(dataObj: listArrayModel[indexPath.row])
        return cell
    }
}
