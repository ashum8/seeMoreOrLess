//
//  SourcingCommonListCell.swift
//  mCAS
//
//  Created by iMac on 23/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

protocol CommonListCellDelegate {
    func selectedIndex(index: Int, cellIndex: Int)
}

class SourcingCommonListCell: UITableViewCell {
    
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label3: EdgeInsetLabel!
    @IBOutlet weak var optionButton: UIButton!
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var label3TopMargin: NSLayoutConstraint!
    
    private var optionArray: [String] = []
    private var cellTag: Int!
    private var delegate: CommonListCellDelegate?
    
    func setProperties(optionArray: [String], cellIndex: Int, delegate: CommonListCellDelegate, showStatus: Bool = false) {
        
        label1.font = CustomFont.shared().GETFONT_MEDIUM(19)
        label2.font = CustomFont.shared().GETFONT_REGULAR(16)
        label3.font = CustomFont.shared().GETFONT_REGULAR(16)
        
        bgView.setCornerRadius()
        bgView.setShadow()
        
        self.optionArray = optionArray
        self.cellTag = cellIndex
        self.delegate = delegate
        
        if showStatus {
            self.label3.setStatusLabelProperties(borderColor: Color.SKY_BLUE)
            label3TopMargin.constant = 5
        }
    }
    
    @IBAction func optionButtonAction(_ sender: Any) {
        
        let obj = SimpleListVC.init(nibName: "SimpleListVC", bundle: nil)
        obj.setData(listArray: optionArray, delegate: self)
        
        if let popoverPresentationController = obj.popoverPresentationController {
            popoverPresentationController.permittedArrowDirections = .up
            popoverPresentationController.sourceView = self.optionButton
            popoverPresentationController.sourceRect = self.optionButton.bounds
            popoverPresentationController.delegate = self
            AppDelegate.instance.applicationNavController.present(obj, animated: true, completion: nil)
        }
    }
    
}


extension SourcingCommonListCell : SimpleListVCDelegate {
    
    func selectedListOption(index: Int) {
        
        DispatchQueue.main.async {
            AppDelegate.instance.applicationNavController.dismiss(animated: true) {
                self.delegate?.selectedIndex(index: index, cellIndex: self.cellTag)
            }
        }
    }
}

extension SourcingCommonListCell: UIPopoverPresentationControllerDelegate {
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }
    
    func popoverPresentationControllerDidDismissPopover(_ popoverPresentationController: UIPopoverPresentationController) {
        
    }
    
    func popoverPresentationControllerShouldDismissPopover(_ popoverPresentationController: UIPopoverPresentationController) -> Bool {
        return true
    }
}
