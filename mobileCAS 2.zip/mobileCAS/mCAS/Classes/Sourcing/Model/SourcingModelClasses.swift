//
//  SourcingModelClasses.swift
//  mCAS
//
//  Created by Mac on 31/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import Foundation

class SourcingModelClasses {
    struct SourcingList: Codable {
        let list: [SourcingModel]?
    }
    
    struct SourcingModel: Codable {
        
        let applicant: Applicant
        let loanDetail: LoanDetail
        let neutronReferenceNumber: String
        
        struct Applicant: Codable {
            let customerType: CustomerType
            let firstName: String?
            let middleName: String?
            let lastName: String?
            let mobileNumber: String?
            let neutronCustRefNumber: String
            
            struct CustomerType: Codable {
                let code: String?
                let name: String?
            }
        }
        
        struct LoanDetail: Codable {
            let loanAmount: Double?
            let productType: ProductType
            let product: Product
            let branch: Branch
            
            struct ProductType: Codable {
                let code: String?
                let name: String?
            }
            
            struct Product: Codable {
                let code: String?
                let name: String?
            }
            
            struct Branch: Codable {
                let code: String?
                let name: String?
            }
        }
    }
}
