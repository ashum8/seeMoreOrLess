//
//  ApplicantListVC.swift
//  mCAS
//
//  Created by iMac on 21/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class ApplicantListVC: UIViewController {
    
    private enum DetailOptions: String {
        case viewDetail = "View/Edit Details"
        case deleteDocument = "Delete"
    }
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var addApplicantButton: UIButton!
    @IBOutlet weak var buttonViewHeight: NSLayoutConstraint!
    
    private var cellOptionArray: [DetailOptions] = [.viewDetail, .deleteDocument]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        addButton.setPlusButtonProperties()
        
        noDataCapturedView.setProperties(title: "You have not added applicants yet!")
        addApplicantButton.setButtonProperties()
        
        tableView.register(UINib.init(nibName: "CasesCell", bundle: Bundle.main), forCellReuseIdentifier: "CasesCell")
        tableView.tableFooterView = UIView()
        
        buttonView.setProperties(nextBtnTitle: "Done", delegate: self)
        setTableViewData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.setTitleWith(line1: "Add Applicant", showBack: true)
        }
    }
    
    private func setTableViewData() {
        tableView.isHidden = true
        noDataCapturedView.isHidden = false
        addApplicantButton.isHidden = false
        addButton.isHidden = true
        buttonViewHeight.constant = 0
    }
    
    @IBAction func addButtonAction(_ sender: UIButton) {
        
        let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = storyboard.instantiateViewController(withIdentifier: "ApplicantSearchVC") as? ApplicantSearchVC {
            AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
        }
    }
    
}

extension ApplicantListVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let optionArray = cellOptionArray.map({ $0.rawValue })
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CasesCell") as! CasesCell
        cell.label1.text = "Ashu" + " Mishra"
        cell.label2.text = "AK000123 \(Constants.SEPERATOR) 809012345"
        cell.setProperties(showSyncButton: true, cellIndex: indexPath.row, showOption: true, productTypeCode:"Auto Loan", showOfflineFlag: true, delegate: self, optionArray: optionArray)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
}

extension ApplicantListVC: NextBackButtonDelegate {
    func nextButtonAction() {
        print("")
    } 
}

extension ApplicantListVC: CaseCellDelegate {
    
    func selectedIndex(index: Int, cellIndex: Int) {
        let item = self.cellOptionArray[index]
        if item == .viewDetail {
            let storyboard = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
            
            if let vc = storyboard.instantiateViewController(withIdentifier: "ApplicantPersonalDetailVC") as? ApplicantPersonalDetailVC {
                AppDelegate.instance.applicationNavController?.pushViewController(vc, animated: true)
            }
        }
        else if item == .deleteDocument {
            
        }
    }
}
