//
//  AddAssetVC.swift
//  mCAS
//
//  Created by iMac on 29/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddAssetVC: UIViewController {
    
    @IBOutlet weak var assetCategoryLOV: LOVFieldView!
    @IBOutlet weak var assetTypeLOV: LOVFieldView!
    @IBOutlet weak var assetValueView: CustomTextFieldView!
    @IBOutlet weak var assetDescriptionView: CustomTextFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
        
    private var selectedLOVDic: [String: DropDown] = [:]
    
    private let TAG_CATEGORY = 1000
    private let TAG_TYPE = 1001
    private let TAG_AMOUNT = 10000
    private let TAG_DESCRIPTION = 10001
    
    private let MaxLimitAmount = 10000000
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    private func setupView() {
        
        assetCategoryLOV.setLOVProperties(masterName: Entity.INCOME_ASSET_CATEGORY, title: "Asset Category", tag: TAG_CATEGORY, delegate: self)
        assetTypeLOV.setLOVProperties(masterName: Entity.INCOME_ASSET_TYPE, title: "Asset Type", tag: TAG_TYPE, delegate: self)
        
        assetValueView.setProperties(placeHolder: "Amount",type: .Amount, delegate: self, tag: TAG_AMOUNT)
        
        assetDescriptionView.setProperties(placeHolder: "Asset Description",type: .Text, delegate: self, tag: TAG_DESCRIPTION)
        
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        
        validateFields()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Asset")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: true)
        }
    }
}

extension AddAssetVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        if btntag == TAG_CATEGORY {
            if let dd = selectedLOVDic["\(TAG_CATEGORY)"] {
                assetTypeLOV.resetLOVWithParentKey(key: dd.code)
                selectedLOVDic["\(TAG_TYPE)"] = nil
            }
        }
        
        validateFields()
    }
}

extension AddAssetVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true
        if (selectedLOVDic["\(TAG_CATEGORY)"] == nil || selectedLOVDic["\(TAG_TYPE)"] == nil || assetValueView.getFieldValue().isEmpty || assetDescriptionView.getFieldValue().isEmpty ) {
            
            isEnabled = false
        }
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch tag {
        case TAG_AMOUNT:
            return Int(text) ?? 0 < MaxLimitAmount
        case TAG_DESCRIPTION:
            return text.count < Constants.REMARKS_LENGTH && text.isAlphanumericAndSpace
            
        default:
            return true
        }
    }
}

extension AddAssetVC: NextBackButtonDelegate {
    func nextButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}
