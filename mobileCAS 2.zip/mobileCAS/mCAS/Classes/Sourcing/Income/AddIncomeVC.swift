//
//  AddIncomeVC.swift
//  mCAS
//
//  Created by iMac on 28/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddIncomeVC: UIViewController {
    
    @IBOutlet weak var employmentTypeLOV: LOVFieldView!
    @IBOutlet weak var incomeTypeLOV: LOVFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var frequencyLOV: LOVFieldView!
    @IBOutlet weak var frequencyLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var amountView: CustomTextFieldView!
    @IBOutlet weak var amountViewHeight: NSLayoutConstraint!
    @IBOutlet weak var percentageView: CustomTextFieldView!
    @IBOutlet weak var percentageViewHeight: NSLayoutConstraint!
    @IBOutlet weak var netAmountView: CustomTextFieldView!
    @IBOutlet weak var netAmountViewHeight: NSLayoutConstraint!
    
    private let TAG_EMPLOYMENT = 1000
    private let TAG_INCOME = 1001
    private let TAG_FREQUENCY = 1002
    
    private let TAG_AMOUNT = 1003
    private let TAG_PERCENTAGE = 1004
    
    private let maxAmount = 10000000
    private let maxPercentage = 30
    
    private var selectedLOVDic: [String: DropDown] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    private func setupView() {
        
        employmentTypeLOV.setLOVProperties(masterName: Entity.EMPLOYMENT_TYPE, title: "Employment Type", tag: TAG_EMPLOYMENT, delegate: self)
        incomeTypeLOV.setLOVProperties(masterName: Entity.INCOME_EXPENSE_HEAD, title: "Income Type", tag: TAG_INCOME, delegate: self)
        frequencyLOV.setLOVProperties(masterName: Entity.FREQUENCY, title: "Frequency", tag: TAG_FREQUENCY, delegate: self)
        
        amountView.setProperties(placeHolder: "Amount", type: .Amount, delegate: self, tag: TAG_AMOUNT)
        
        netAmountView.setProperties(placeHolder: "Net Amount", enabled: false)

        percentageView.setProperties(placeHolder: "Percentage (%)", type: .Decimal, delegate: self, tag: TAG_PERCENTAGE)
        
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        
        validateFields()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Income")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: true)
        }
    }
    
}

extension AddIncomeVC: CustomTFViewDelegate {
    
    func validateFields() {
                
        if let cost = Double(amountView.getFieldValue()), let percentage = Double(percentageView.getFieldValue()) {
            netAmountView.setFieldValue(text: "\((cost*percentage) / 100 )".formatCurrency)
        }
        
        let isEnabled = !(selectedLOVDic["\(TAG_EMPLOYMENT)"] == nil || selectedLOVDic["\(TAG_INCOME)"] == nil || selectedLOVDic["\(TAG_FREQUENCY)"] == nil || amountView.getFieldValue().isEmpty || percentageView.getFieldValue().isEmpty)

        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch tag {
        case TAG_AMOUNT:
            return Int(text) ?? 0 <= maxAmount
        case TAG_PERCENTAGE:
            return Int(text) ?? 0 <= maxPercentage
        default:
            return true
        }
    }
}

extension AddIncomeVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        if btntag == TAG_EMPLOYMENT {
            frequencyLOVHeight.constant = 65
            amountViewHeight.constant = 65
            percentageViewHeight.constant = 65
            netAmountViewHeight.constant = 65
        }
        validateFields()
    }
}

extension AddIncomeVC: NextBackButtonDelegate {
    func nextButtonAction() {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}
