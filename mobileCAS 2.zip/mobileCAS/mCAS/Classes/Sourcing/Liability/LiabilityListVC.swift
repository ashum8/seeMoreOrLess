//
//  LiabilityListVC.swift
//  mCAS
//
//  Created by iMac on 29/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class LiabilityListVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var noDataCapturedView: CustomNoDataView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var headerTitleView: SourcingTitleView!
    
    private enum DetailOptions: String {
        case edit = "Edit"
        case delete = "Delete"
    }
    
    private struct DataModel {
        var title: String
        var name: String
        var amount: String
    }
    
    private var dataModelArray = [DataModel]()
    private var cellOptionArray: [DetailOptions] = [.edit, .delete]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideStepHeader(isHide: false, title: "Add Applicant")
        }
    }
    
    private func setupView() {
        
        dataModelArray.append(DataModel(title: "Auto Loan", name: "HDFC Bank", amount: "5,00,000"))
        dataModelArray.append(DataModel(title: "Car Loan", name: "ICICI Bank", amount: "2,00,000"))
        
        headerTitleView.setProperties(title: "Liability")
        
        self.view.backgroundColor = Color.LIGHTER_GRAY
        
        addButton.setPlusButtonProperties()
        
        noDataCapturedView.setProperties(title: "Add Liability details here.", image:"asset_placeholder")
        
        tableView.register(UINib(nibName: "SourcingCommonListCell", bundle: nil), forCellReuseIdentifier: "SourcingCommonListCell")
        tableView.tableFooterView = UIView()
        
        buttonView.setProperties(showBack: true, nextBtnTitle: "Skip", delegate: self)
        
        setListData()
    }
    
    private func setListData() {
        
        tableView.isHidden = dataModelArray.isEmpty
        noDataCapturedView.isHidden = !tableView.isHidden
        self.tableView.reloadData()
    }
    
    @IBAction func addButtonAction(_ sender: UIButton) {
        
        let st = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = st.instantiateViewController(withIdentifier: "AddLiabilityVC") as? AddLiabilityVC  {
            AppDelegate.instance.applicationNavController.pushViewController(vc , animated: true)
        }
        
    }
}

extension LiabilityListVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataModelArray.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SourcingCommonListCell", for: indexPath) as! SourcingCommonListCell
        cell.setProperties(optionArray: cellOptionArray.map({ $0.rawValue }), cellIndex: indexPath.row, delegate: self)
        
        cell.label1.text = dataModelArray[indexPath.row].title
        cell.label2.text = "\(dataModelArray[indexPath.row].name) \(Constants.SEPERATOR) \(Constants.CURRENCY_SYMBOL) \(dataModelArray[indexPath.row].amount)"
        
        return cell
    }
    
}

extension LiabilityListVC : NextBackButtonDelegate {
    func nextButtonAction() {
        let st = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
        
        if let vc = st.instantiateViewController(withIdentifier: "SourcingUploadPhotoVC") as? SourcingUploadPhotoVC  {
            AppDelegate.instance.applicationNavController.pushViewController(vc , animated: true)
        }
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}

extension LiabilityListVC : CommonListCellDelegate {
    
    func selectedIndex(index: Int, cellIndex: Int) {
        let item = self.cellOptionArray[index]
        if item == .edit {
            let st = UIStoryboard.init(name: Storyboard.SOURCING, bundle: nil)
            
            if let vc = st.instantiateViewController(withIdentifier: "AddLiabilityVC") as? AddLiabilityVC  {
                AppDelegate.instance.applicationNavController.pushViewController(vc , animated: true)
            }
            
        }
        else if item == .delete {
            dataModelArray.remove(at: cellIndex)
            setListData()
        }
    }
}
