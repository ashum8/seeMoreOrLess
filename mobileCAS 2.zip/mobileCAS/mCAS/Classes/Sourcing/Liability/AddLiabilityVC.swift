//
//  AddLiabilityVC.swift
//  mCAS
//
//  Created by iMac on 29/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddLiabilityVC: UIViewController {
    
    @IBOutlet weak var liabiltyTypeLOV: LOVFieldView!
    @IBOutlet weak var loanTypeLOV: LOVFieldView!
    @IBOutlet weak var institutionLOV: LOVFieldView!
    @IBOutlet weak var sanctionAmountView: CustomTextFieldView!
    @IBOutlet weak var principleOutstandingView: CustomTextFieldView!
    @IBOutlet weak var emiStartDateView: CustomTextFieldView!
    @IBOutlet weak var installmentFrequencyLOV: LOVFieldView!
    @IBOutlet weak var installmentAmountView: CustomTextFieldView!
    @IBOutlet weak var closedDateView: CustomTextFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    
    private let TAG_LIABILITY = 1000
    private let TAG_LOAN = 1001
    private let TAG_INSTITUTION = 1002
    private let TAG_LIABILITY_FREQUENCY = 1003
    
    private var selectedLOVDic: [String: DropDown] = [:]
    
    private let TAG_AMOUNT = 10000
    private let TAG_EMI_AMOUNT = 10001
    
    private let MaxLimitAmount = 10000000
    private let MaxLimitEMIAmount = 100000
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    private func setupView() {
        
        liabiltyTypeLOV.setLOVProperties(masterName: Entity.LIABILITY_TYPE, title: "Liability Type", tag: TAG_LIABILITY, delegate: self)
        loanTypeLOV.setLOVProperties(masterName: Entity.EXTERNAL_LOAN_TYPE, title: "Loan Type", tag: TAG_LOAN, delegate: self)
        institutionLOV.setLOVProperties(masterName: Entity.EXTERNAL_BANKS, title: "Institution", tag: TAG_INSTITUTION, delegate: self)
        installmentFrequencyLOV.setLOVProperties(masterName: Entity.LIABILITY_FREQUENCY, title: "Installment Frequency", tag: TAG_LIABILITY_FREQUENCY, delegate: self)
        
        sanctionAmountView.setProperties(placeHolder: "Sanction Amount",type: .Amount, delegate: self, tag: TAG_AMOUNT)
        principleOutstandingView.setProperties(placeHolder: "Principle Outstanding",type: .Amount, delegate: self, tag: TAG_AMOUNT)
        emiStartDateView.setProperties(placeHolder: "Emi Start Date",type: .DATE, delegate: self)
        installmentAmountView.setProperties(placeHolder: "Installment Amount",type: .Amount, delegate: self, tag: TAG_EMI_AMOUNT)
        closedDateView.setProperties(placeHolder: "Closed Date",type: .DATE, delegate: self, minimumDate: Date(), maximumDate: nil)
        
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        
        validateFields()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Liability")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: true)
        }
    }
}

extension AddLiabilityVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        validateFields()
    }
}

extension AddLiabilityVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true
        if (selectedLOVDic["\(TAG_LIABILITY)"] == nil || selectedLOVDic["\(TAG_LOAN)"] == nil || selectedLOVDic["\(TAG_INSTITUTION)"] == nil || sanctionAmountView.getFieldValue().isEmpty || principleOutstandingView.getFieldValue().isEmpty || emiStartDateView.getFieldValue().isEmpty || selectedLOVDic["\(TAG_LIABILITY_FREQUENCY)"] == nil || installmentAmountView.getFieldValue().isEmpty || closedDateView.getFieldValue().isEmpty ) {
            
            isEnabled = false
        }
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch tag {
        case TAG_AMOUNT:
            return Int(text) ?? 0 < MaxLimitAmount
        case TAG_EMI_AMOUNT:
            return Int(text) ?? 0 < MaxLimitEMIAmount
        default:
            return true
        }
    }
}

extension AddLiabilityVC: NextBackButtonDelegate {
    func nextButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}
