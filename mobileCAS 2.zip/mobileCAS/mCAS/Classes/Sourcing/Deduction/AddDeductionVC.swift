//
//  AddDeductionVC.swift
//  mCAS
//
//  Created by iMac on 28/01/20.
//  Copyright © 2020 Nucleus. All rights reserved.
//

import UIKit

class AddDeductionVC: UIViewController {
    
    @IBOutlet weak var employmentTypeLOV: LOVFieldView!
    @IBOutlet weak var deductionTypeLOV: LOVFieldView!
    @IBOutlet weak var buttonView: NextBackButtonView!
    @IBOutlet weak var frequencyLOV: LOVFieldView!
    @IBOutlet weak var frequencyLOVHeight: NSLayoutConstraint!
    @IBOutlet weak var amountView: CustomTextFieldView!
    @IBOutlet weak var amountViewHeight: NSLayoutConstraint!
    @IBOutlet weak var percentageView: CustomTextFieldView!
    @IBOutlet weak var percentageViewHeight: NSLayoutConstraint!
    @IBOutlet weak var netAmountView: CustomTextFieldView!
    @IBOutlet weak var netAmountViewHeight: NSLayoutConstraint!
    
    private let TAG_EMPLOYMENT = 1000
    private let TAG_DEDUCTION = 1001
    private let TAG_FREQUENCY = 1002
    
    private let TAG_AMOUNT = 1003
    private let TAG_PERCENTAGE = 1004
    
    private let maxAmount = 10000000
    private let maxPercentage = 30
    private var selectedLOVDic: [String: DropDown] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
    
    private func setupView() {
        
        employmentTypeLOV.setLOVProperties(masterName: Entity.EMPLOYMENT_TYPE, title: "Employment Type", tag: TAG_EMPLOYMENT, delegate: self)
        
        deductionTypeLOV.setLOVProperties(masterName: Entity.INCOME_EXPENSE_HEAD, title: "Deduction Type", tag: TAG_DEDUCTION, delegate: self)
        
        frequencyLOV.setLOVProperties(masterName: Entity.FREQUENCY, title: "Frequency", tag: TAG_FREQUENCY, delegate: self)
        
        amountView.setProperties(placeHolder: "Amount", type: .Amount, delegate: self, tag: TAG_AMOUNT)
        
        netAmountView.setProperties(placeHolder: "Net Amount", enabled: false)
        percentageView.setProperties(placeHolder: "Percentage (%)", type: .Decimal, delegate: self, tag: TAG_PERCENTAGE)
        
        buttonView.setProperties(showBack: true, backBtnTitle: "Cancel", nextBtnTitle: "Add", delegate: self)
        
        validateFields()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: false, hideCloseButton: true, title: "Add Deduction")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance.headerView {
            headerView.showHideWhiteHeader(isHide: true)
        }
    }
    
}

extension AddDeductionVC: CustomTFViewDelegate {
    
    func validateFields() {
        
        var isEnabled = true
        
        if let cost = Double(amountView.getFieldValue()), let percentage = Double(percentageView.getFieldValue()) {
            netAmountView.setFieldValue(text: "\((cost*percentage) / 100 )".formatCurrency)
        }
        
        if (selectedLOVDic["\(TAG_EMPLOYMENT)"] == nil || selectedLOVDic["\(TAG_DEDUCTION)"] == nil || selectedLOVDic["\(TAG_FREQUENCY)"] == nil || amountView.getFieldValue().isEmpty || percentageView.getFieldValue().isEmpty) {
            
            isEnabled = false
        }
        buttonView.nextButton.setEnableDisableButtonColor(isEnable: isEnabled)
    }
    
    func textFieldEditing(text: String, tag: Int) -> Bool {
        
        switch tag {
        case TAG_AMOUNT:
            return Int(text) ?? 0 <= maxAmount
        case TAG_PERCENTAGE:
            return Int(text) ?? 0 <= maxPercentage
        default:
            return true
        }
    }
}

extension AddDeductionVC: SelectedLOVDelegate {
    
    func selectedLOVResult(selectedObj: DropDown, btntag: Int) {
        selectedLOVDic["\(btntag)"] = selectedObj
        
        if btntag == TAG_EMPLOYMENT {
            frequencyLOVHeight.constant = 65
            amountViewHeight.constant = 65
            percentageViewHeight.constant = 65
            netAmountViewHeight.constant = 65
        }
        validateFields()
    }
}

extension AddDeductionVC: NextBackButtonDelegate {
    func nextButtonAction() {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    func backButtonAction() {
        self.navigationController?.popViewController(animated: true)
    }
}

