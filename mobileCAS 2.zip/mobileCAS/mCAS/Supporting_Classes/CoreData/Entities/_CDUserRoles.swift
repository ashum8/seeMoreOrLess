// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to CDUserRoles.swift instead.

import Foundation
import CoreData

public enum CDUserRolesAttributes: String {
    case roleID = "roleID"
}

public enum CDUserRolesRelationships: String {
    case rolesForUser = "rolesForUser"
}

open class _CDUserRoles: CDUserDetails {

    // MARK: - Class methods

    override open class func entityName () -> String {
        return "CDUserRoles"
    }

    override open class func entity(managedObjectContext: NSManagedObjectContext) -> NSEntityDescription? {
        return NSEntityDescription.entity(forEntityName: self.entityName(), in: managedObjectContext)
    }

    @nonobjc
    open class func fetchRequest() -> NSFetchRequest<CDUserRoles> {
        return NSFetchRequest(entityName: self.entityName())
    }

    // MARK: - Life cycle methods

    public override init(entity: NSEntityDescription, insertInto context: NSManagedObjectContext?) {
        super.init(entity: entity, insertInto: context)
    }

    public convenience init?(managedObjectContext: NSManagedObjectContext) {
        guard let entity = _CDUserRoles.entity(managedObjectContext: managedObjectContext) else { return nil }
        self.init(entity: entity, insertInto: managedObjectContext)
    }

    // MARK: - Properties

    @NSManaged open
    var roleID: String?

    // MARK: - Relationships

    @NSManaged open
    var rolesForUser: CDUserDetails?

}

