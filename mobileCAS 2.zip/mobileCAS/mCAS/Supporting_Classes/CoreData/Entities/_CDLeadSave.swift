// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to CDLeadSave.swift instead.

import Foundation
import CoreData

public enum CDLeadSaveAttributes: String {
    case leadData = "leadData"
    case tempLeadID = "tempLeadID"
}

public enum CDLeadSaveRelationships: String {
    case loginUser = "loginUser"
}

open class _CDLeadSave: NSManagedObject {

    // MARK: - Class methods

    open class func entityName () -> String {
        return "CDLeadSave"
    }

    open class func entity(managedObjectContext: NSManagedObjectContext) -> NSEntityDescription? {
        return NSEntityDescription.entity(forEntityName: self.entityName(), in: managedObjectContext)
    }

    @nonobjc
    open class func fetchRequest() -> NSFetchRequest<CDLeadSave> {
        return NSFetchRequest(entityName: self.entityName())
    }

    // MARK: - Life cycle methods

    public override init(entity: NSEntityDescription, insertInto context: NSManagedObjectContext?) {
        super.init(entity: entity, insertInto: context)
    }

    public convenience init?(managedObjectContext: NSManagedObjectContext) {
        guard let entity = _CDLeadSave.entity(managedObjectContext: managedObjectContext) else { return nil }
        self.init(entity: entity, insertInto: managedObjectContext)
    }

    // MARK: - Properties

    @NSManaged open
    var leadData: AnyObject?

    @NSManaged open
    var tempLeadID: String?

    // MARK: - Relationships

    @NSManaged open
    var loginUser: CDUserDetails?

}

