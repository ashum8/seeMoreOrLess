import Foundation

@objc(CDLeadSave)
open class CDLeadSave: _CDLeadSave {
	// Custom logic goes here.
}
