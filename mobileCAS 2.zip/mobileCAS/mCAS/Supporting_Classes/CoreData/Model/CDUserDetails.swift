import Foundation

@objc(CDUserDetails)
open class CDUserDetails: _CDUserDetails {
	// Custom logic goes here.
    
    func getUserRoles() -> [CDUserRoles]? {
        return self.userRoles.array as? [CDUserRoles]
    }
    
    func getOfflineLeads() -> [CDLeadSave]? {
        return self.savedLead.allObjects as? [CDLeadSave]
    }
    
    func getDropDownEntityUpdateArray() -> [CDDropDownEntityUpdate]? {
        return self.dropDownEntityUpdate.allObjects as? [CDDropDownEntityUpdate]
    }
}
