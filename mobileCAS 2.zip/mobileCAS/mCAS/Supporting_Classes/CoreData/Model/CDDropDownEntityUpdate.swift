import Foundation

@objc(CDDropDownEntityUpdate)
open class CDDropDownEntityUpdate: _CDDropDownEntityUpdate {
	// Custom logic goes here.
}
