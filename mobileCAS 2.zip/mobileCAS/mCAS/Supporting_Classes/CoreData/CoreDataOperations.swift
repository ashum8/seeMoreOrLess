//
//  CoreDataOperations.swift
//  mCAS
//
//  Created by Mac on 26/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

// //https://medium.com/@ankurvekariya/core-data-crud-with-swift-4-2-for-beginners-40efe4e7d1cc


import UIKit
import CoreData

class CoreDataOperations {
    
    private static var instance: CoreDataOperations?
    
    static func shared() -> CoreDataOperations{
        if instance == nil {
            instance = CoreDataOperations()
        }
        return instance!
    }
    
    func updateRecord(predicate: NSPredicate, entityName: String, success:@escaping (_ responseObject: NSManagedObject) -> Void) {
        
        let context = AppDelegate.instance.getContext()
        
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: entityName)
        fetchRequest.predicate = predicate
        
        do {
            let records = try context.fetch(fetchRequest)
            let record: NSManagedObject
            
            if !records.isEmpty {
                record = records[0] as! NSManagedObject
            }
            else {
                let entity = NSEntityDescription.entity(forEntityName: entityName, in: context)
                record = NSManagedObject(entity: entity!, insertInto: context)
            }
            
            success(record)
        }
        catch { }
    }
    
    func fetchAllRecords(predicate: NSPredicate, entityName: String, success:@escaping (_ responseObject: [NSManagedObject]?) -> Void) {
        
        let context = AppDelegate.instance.getContext()
        
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: entityName)
        fetchRequest.predicate = predicate
        
        do {
            if let records = try context.fetch(fetchRequest) as? [NSManagedObject] {
                success(records)
            }
            else { success(nil) }
        }
        catch { success(nil) }
    }
    
    func fetchSingleRecord(predicate: NSPredicate, entityName: String, success:@escaping (_ responseObject: NSManagedObject?) -> Void) {
        
        fetchAllRecords(predicate: predicate, entityName: entityName) { records in
            
            if let records = records, !records.isEmpty {
                success(records[0])
            }
            else { success(nil) }
        }
    }
    
    func deleteAllRecords(predicate: NSPredicate, entityName: String) {
        
        fetchAllRecords(predicate: predicate, entityName: entityName) { records in
            
            let context = AppDelegate.instance.getContext()
            
            if let records = records {
                for record in records {
                    context.delete(record)
                }
                AppDelegate.instance.saveContext()
            }
        }
    }
    
    func fetchRecordsForMaster(masterName: String, parentKey: String? = nil, success:@escaping (_ responseObject: [DropDown]?) -> Void) {
        var predicate: NSPredicate
        
        if let parentKey = parentKey, !parentKey.isEmpty {
            predicate = NSPredicate(format: "(\(CDDropDownRelationships.loginUser) == %@) AND (\(CDDropDownAttributes.masterName) == %@) AND (\(CDDropDownAttributes.parentKey) == %@)", AppDelegate.instance.currentLoggedInUser, masterName, parentKey)
        }
        else {
            predicate = NSPredicate(format: "(\(CDDropDownRelationships.loginUser) == %@) AND (\(CDDropDownAttributes.masterName) == %@)", AppDelegate.instance.currentLoggedInUser, masterName)
        }
        
        let entityName = String(describing: CDDropDown.self)
        
        fetchAllRecords(predicate: predicate, entityName: entityName) { records in
            
            if let records = records as? [CDDropDown], !records.isEmpty {
                
                var recordsModel = records.map { (CDObj) -> DropDown in
                    return DropDown(code: CDObj.code ?? "", name: CDObj.name ?? "", parentKey: CDObj.parentKey ?? "")
                }
                
                recordsModel.sort { $0.name.lowercased() < $1.name.lowercased() }
                
                success(recordsModel)
            }
            else { success(nil) }
        }
    }
    
    func updateMasterRecords(dic: [String : Any]) {
        
        if let masterName = dic["masterName"] as? String {
            //Delete old master records
            let predicate = NSPredicate(format: "(\(CDDropDownRelationships.loginUser) == %@) AND (\(CDDropDownAttributes.masterName) == %@)", AppDelegate.instance.currentLoggedInUser, masterName)
            
            let entityName = String(describing: CDDropDown.self)
            
            CoreDataOperations.shared().deleteAllRecords(predicate: predicate, entityName: entityName)
            
            //Insert new master records
            if let masters = dic["masters"] as? [[String : Any]]
            {
                let context = AppDelegate.instance.getContext()
                
                for record in masters {
                    let entity = NSEntityDescription.entity(forEntityName: entityName, in: context)
                    let dropdown = NSManagedObject(entity: entity!, insertInto: context) as! CDDropDown
                    dropdown.loginUser = AppDelegate.instance.currentLoggedInUser
                    dropdown.masterName = masterName
                    dropdown.id = record["id"] as? NSNumber
                    dropdown.code = record["code"] as? String ?? ""
                    dropdown.name = record["name"] as? String ?? ""
                    dropdown.parentKey = record["masterType"] as? String ?? ""
                }
                AppDelegate.instance.saveContext()
            }
            
            
            //Update timestamp of new master
            if let timeStamp = dic["lastUpdatedTime"] as? String
            {
                let predicate = NSPredicate(format: "(\(CDDropDownEntityUpdateRelationships.loginUser) == %@) AND (\(CDDropDownEntityUpdateAttributes.masterName) == %@)", AppDelegate.instance.currentLoggedInUser, masterName)
                
                let entityName = String(describing: CDDropDownEntityUpdate.self)
                
                CoreDataOperations.shared().updateRecord(predicate: predicate, entityName: entityName, success: { (record) in
                    
                    if let record = record as? CDDropDownEntityUpdate {
                        record.loginUser = AppDelegate.instance.currentLoggedInUser
                        record.timeStamp = timeStamp
                        record.masterName = masterName
                        
                        AppDelegate.instance.saveContext()
                    }
                })
            }
        }
    }
    
    func getCurrentLoggedinUser(success:@escaping (_ userData: CDUserDetails?) -> Void) {
        let username = AppDelegate.instance.getSavedUserID()
        let predicate = NSPredicate(format: "\(CDUserDetailsAttributes.username) = %@", username)
        let entityName = String(describing: CDUserDetails.self)
        
        CoreDataOperations.shared().fetchSingleRecord(predicate: predicate, entityName: entityName, success: { (record) in
            
            if let userData = record as? CDUserDetails
            {
                success(userData)
            }
        })
    }
    
}
