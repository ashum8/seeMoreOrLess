//
//  Constants.swift
//  mCAS
//
//  Created by Mac on 27/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation


public class Constants: NSObject {
    
    //Module/Functionality - Enable/Disable
    public static let SHOW_GALLERY_WITH_CAMERA      = true
    public static let ENABLE_LOCATION_UPDATE_IN_BG  = false
    public static let ENABLE_FORGOT_PWD_VIA_OTP     = true
    public static let CHECK_LOAN_LEGAL_FLAG         = false
    public static let BLOCK_CLOSED_OR_CANCEL_LOAN   = false

    
    public static let bottomTabsCount: CGFloat      = 4
    
    public static let OTP_TIMER                     = 30
    public static let OTP_LENGTH                    = 6
    public static let REMARKS_LENGTH                = 250
    public static let HEADER_HEIGHT: CGFloat        = 45
    public static let AADHAR_LENGTH                 = 12
    public static let PAN_LENGTH                    = 10
    public static let MOBILE_NUMBER_LENGTH          = 10
    public static let APPLICATION_ID_LENGTH         = 12

    
    public static let CURRENCY_SYMBOL               = "₹"
    
    public static let SEPERATOR                     = "•"

    public static let APPL_TYPE_PRIMARY             = "PRIMARY"
    public static let APPL_TYPE_COAPPLICANT         = "Co-applicant"
    public static let APPL_TYPE_GUARANTOR           = "Guarantor"

    public static let APPLICANT_ROLE_CODE_PRIMARY   = "0"
    public static let APPLICANT_ROLE_NAME_PRIMARY   = "Primary Applicant"
    
    public static let APPLICANT_ROLE_CODE_COAPPL    = "1"
    public static let APPLICANT_ROLE_NAME_COAPPL    = "Co-applicant"

    public static let APPLICANT_ROLE_CODE_GUARANTOR = "2"
    public static let APPLICANT_ROLE_NAME_GUARANTOR = "Guarantor"
    
    public static let DEFAULT_COUNTRY_CODE          = "+91"
    public static let DEFAULT_APPLICATION_TYPE_CODE = "NewApplication"
    
    public static let CUSTOMER_TYPE_INDV            = "INDIVIDUAL"
    public static let CUSTOMER_TYPE_CORP            = "CORPORATE"
    
    //Date Formats
    public static let DATE_FORMAT_VIEW              = "dd-MM-yyyy"
    public static let DATE_FORMAT_SERVICE           = "yyyy-MM-dd"
    
    
    public static let FIELD_TYPE_NUMBER             = "NUMBER"
    public static let FIELD_TYPE_DECIMAL            = "DECIMAL"
    
    public static let ID_TYPE_INDV                  = "IndvCustomer"
    public static let ID_TYPE_CORP                  = "NonIndvCustomer"
    
    public static let LOV_DEFAULT_TITLE             = NSLocalizedString("Select", comment: "")
}

public class ConstantCodes {
    //Hardcoded codes for compare
    public static let PRODUCT_TYPE_CC               = "CC"
    public static let PRODUCT_TYPE_KCC              = "KCC"
    public static let PRODUCT_TYPE_CL               = "CL"
    public static let PRODUCT_TYPE_HL               = "HL"
    public static let PRODUCT_TYPE_LAP              = "LAP"
    public static let PRODUCT_TYPE_CV               = "CV"
    public static let PRODUCT_TYPE_EQUIPMNT         = "EQUIPMNT"
    public static let PRODUCT_TYPE_MHL              = "MHL"
    public static let PRODUCT_TYPE_FE               = "FE"
    public static let PRODUCT_TYPE_EDU              = "EDU"
    public static let PRODUCT_TYPE_AGRL             = "AGRL"
    public static let PRODUCT_TYPE_PF               = "PF"
    public static let PRODUCT_TYPE_CON_VEH          = "CON_VEH"

    
    public static let EMP_TYPE_SENP                 = "selfEmployedNonProfessional"
    public static let EMP_TYPE_SEP                  = "selfEmployedProfessional"
    public static let EMP_TYPE_SAL                  = "salaried"
    public static let EMP_TYPE_OTH                  = "others"

    public static let ID_TYPE_DL                    = "Driving_Licence"
    public static let ID_TYPE_PASSPORT              = "PASSPORT_No"
    public static let ID_TYPE_PAN                   = "PAN"
    public static let ID_TYPE_AADHAR                = "AAdhar_No"
    public static let ID_TYPE_VOTER                 = "Voter_ID"
    
    public static let ID_TYPE_CODE_DOB              = "DOB"
    public static let ID_TYPE_NAME_DOB              = "Date of Birth"
    
    public static let ID_TYPE_CODE_MOBILE           = "MOBILE"
    public static let ID_TYPE_NAME_MOBILE           = "Mobile Number"
    
    public static let ID_TYPE_CODE_LAN              = "LAN"
    public static let ID_TYPE_NAME_LAN              = "Loan Account Number"
    
    public static let LOV_TYPE_CODE_SELECT          = "SELECT"
    public static let LOV_TYPE_NAME_SELECT          = "Select"


    public static let ADDRESS_TYPE_PERM             = "PermanentAddress"
    public static let ADDRESS_TYPE_OFC              = "OfficeAddress"
    public static let ADDRESS_TYPE_RES              = "ResidentialAddress"

}

public class UserDefaultKey {
    //User Defaults Variable Names
    public static let USER_ID                = "MCAS.USER_ID"
    public static let REMEMBER_USER_ID       = "MCAS.REMEMBER_USER_ID"
}

public class Color {
    //Colors
    public static let LIGHTER_BLUE             = UIColor(red: 157.0/255.0, green: 201.0/255.0, blue: 241.0/255.0, alpha: 1)
    public static let LIGHT_BLUE               = UIColor(red: 71.0/255.0, green: 109.0/255.0, blue: 220.0/255.0, alpha: 1)
    public static let LIGHT_BLUE_PINK          = UIColor(red: 235.0/255.0, green: 235.0/255.0, blue: 246.0/255.0, alpha: 1)
    public static let SKY_BLUE                 = UIColor(red: 85.0/255.0, green: 138.0/255.0, blue: 243.0/255.0, alpha: 1)
    public static let BLUE                     = UIColor(red: 52.0/255.0, green: 122.0/255.0, blue: 184.0/255.0, alpha: 1)
    public static let GREEN                    = UIColor(red: 103.0/255.0, green: 186.0/255.0, blue: 47.0/255.0, alpha: 1)
    public static let RED                      = UIColor(red: 255.0/255.0, green: 59.0/255.0, blue: 48.0/255.0, alpha: 1)
    public static let LIGHTER_GRAY             = UIColor(red: 237.0/255.0, green: 237.0/255.0, blue: 237.0/255.0, alpha: 1)
    public static let EXTREME_LIGHT_GRAY       = UIColor(red: 249.0/255.0, green: 249.0/255.0, blue: 249.0/255.0, alpha: 1)
}

public class UserRoles {
    //User Roles
    public static let CAPTURE_LEAD          = "FN_MOB_CAPTURE_LEAD"
    public static let SOURCING              = "FN_MOB_SOURCING"
    public static let QUERY_MODULE          = "FN_MOB_QUERY_MODULE"
    public static let FIELD_VERIFY          = "FN_MOB_FIELD_VERIFY"
    public static let CALC                  = "FN_MOB_CALC"
    public static let STATUS_ENQUIRY        = "FN_MOB_STAT_INQUIRY"
    public static let PD_FORM               = "FN_MOB_PD_FORM"
    public static let CIBIL_INITIATE        = "FN_MOB_CBL_INITIATE"
    public static let TO_DO_LIST            = "FN_MOB_TO_DO_LIST"
    public static let EXISTING_LOANS        = "FN_MOB_EXISTING_LOAN_DTLS"
    public static let MIS                   = "FN_MOB_MIS"
    public static let RATE_INITIATION       = "FN_MOB_RA_INITIATE"
    public static let RATE_APPROVAL         = "FN_MOB_RA_APPROVE"
    public static let RATE_RECOMMEND        = "FN_MOB_RA_RECOMMEND"
    
    //Default
    public static let CREATE_APPLICATION    = "CREATE_APPLICATION"
    public static let VIEW_LEAD             = "VIEW_LEAD"
    public static let HOME_DASHBOARD        = "HOME_DASHBOARD"
    public static let MORE                  = "MORE"
    public static let CHANGE_PASSWORD       = "CHANGE_PASSWORD"
}

public class Storyboard {
    //StoryBoard Names Constant
    public static let MAIN                  = "Main"
    public static let LOV_LIST              = "LovList"
    public static let EMI_CALCULATOR        = "EmiCalculator"
    public static let RATE_APPROVAL         = "RateApproval"
    public static let ONLINE_SEARCH         = "OnlineSearch"
    public static let LEAD                  = "Lead"
    public static let STATUS_ENQUIRY        = "StatusEnquiry"
    public static let SOURCING              = "Sourcing"
    public static let FI                    = "FI"
    public static let EXISTING_LOANS        = "ExistingLoans"
}

public class Entity {
    //Entity names
    public static let PHONE_COUNTRYCODE      = "PHONE_COUNTRYCODE_ENTITY"
    public static let PRODUCT                = "PRODUCT_ENITY"
    public static let PRODUCT_CATEGORY       = "PRODUCT_CATEGORY_ENTITY"
    public static let BRANCH                 = "BRANCH_ENTITY"
    public static let SCHEME                 = "SCHEME_ENTITY"
    public static let LOAN_PURPOSE           = "LOAN_PURPOSE_ENTITY"
    public static let SALES_AGENT            = "OFFICER_ENTITY"
    public static let APPLICATION_TYPE       = "APPLICATION_TYPE_ENTITY"
    public static let COLL_SUB_TYPE          = "COLL_SUB_TYPE_ENTITY"
    public static let INCOME_EXPENSE_HEAD    = "INCOME_EXPENSE_HEAD_ENTITY"
    public static let PROP_TYPE              = "PROP_TYPE_ENTITY"
    public static let RELATION               = "RELATION_ENTITY"
    public static let SALUTATION             = "SALUTATION_ENTITY"
    public static let OCCUPATION_TYPE        = "OCCUPATION_TYPE_ENTITY"
    public static let NATURE_OF_PROF         = "NATURE_OF_PROF_ENTITY"
    public static let ADDTYPE                = "GENERICPARAMETERS_ENTITY^KEY1:ADDTYPE"
    public static let ID_TYPE                = "IDENTIFICATION_TYPE_ENTITY"
    public static let MARITAL                = "GENERICPARAMETERS_ENTITY^KEY1:MARITAL"
    public static let BUSINESS_NATURE        = "BUSINESS_NATURE_ENTITY"
    public static let RESTYP                 = "GENERICPARAMETERS_ENTITY^KEY1:RESTYP"
    public static let RESIDENCETYPE          = "RESIDENCETYPE_ENTITY"
    public static let RESIDENT_TYPE          = "RESIDENT_TYPE_ENTITY"
    public static let NATURE_OF_OCCUPATION   = "NATURE_OF_OCCUPATION_ENTITY"
    public static let GENDER                 = "GENERICPARAMETERS_ENTITY^KEY1:GENDER"
    public static let CC_REQUEST_TYPE        = "CC_REQUEST_TYPE_ENTITY"
    public static let FUNDED_FOR             = "FUNDED_FOR_ENTITY"
    public static let BODY_MAN_NAME          = "BODY_MAN_NAME_ENTITY"
    public static let BODY_TYPE              = "BODY_TYPE_ENTITY"
    public static let PREFERRED_LANGUAGE     = "PREFERRED_LANGUAGE_ENTITY"
    public static let CITIZEN                = "GENERICPARAMETERS_ENTITY^KEY1:CITIZEN"
    public static let STATE                  = "STATE_ENTITY"
    public static let COUNTRY                = "COUNTRY_ENTITY"
    public static let CITY                   = "CITY_ENTITY"
    public static let STAGE                  = "STAGE_ENTITY"
    public static let FREQUENCY              = "FREQUENCY_ENTITY"
    public static let APPLTYPE               = "GENERICPARAMETERS_ENTITY^KEY1:APPLTYPE"
    public static let INDUSTRY               = "INDUSTRY_ENTITY"
    public static let EMPLOYER               = "EMPLOYER_ENTITY"
    public static let EXTERNAL_BANKS         = "EXTERNAL_BANKS_ENTITY"
    public static let CONSTITUTION           = "CONSTITUTION_ENTITY"
    public static let EMPLOYMENT_TYPE        = "EMPLOYMENT_TYPE_ENTITY"
    public static let INDUSTRY_CLAS          = "INDUSTRY_CLAS_ENTITY"
    public static let NATURE_OF_PROP         = "NATURE_OF_PROP_ENTITY"
    public static let REF_RELATIONSHIP       = "REF_RELATIONSHIP_ENTITY"
    public static let RELIGION               = "RELIGION_ENTITY"
    public static let PAYMENT_MODES          = "PAYMENT_MODES_ENTITY"
    public static let SUBPAYMENT_MODES       = "SUBPAYMENT_MODES_ENTITY"
    public static let ASSET_TYPE             = "ASSET_TYPE_ENTITY"
    public static let ASSET_MODEL            = "ASSET_MODEL_ENTITY"
    public static let ASSET                  = "ASSET_ENTITY"
    public static let FINANCEMODE            = "FINANCEMODE_ENTITY"
    public static let ASSETLEVEL             = "ASSETLEVEL_ENTITY"
    public static let ASSET_VARIANT          = "ASSET_VARIANT_ENTITY"
    public static let ASSET_MAKE             = "ASSET_MAKE_ENTITY"
    public static let ASSET_VARIANT_PRICE    = "ASSET_VARIANT_PRICE_ENTITY"
    public static let CUSTOMER_CATEGORY      = "CUSTOMER_CATEGORY_IDENTIFIER_ENTITY"
    public static let INCOME_ASSET_TYPE      = "INCOME_ASSET_TYPE_ENTITY"
    public static let LIABILITY_TYPE         = "LIABILITY_TYPE_ENTITY"
    public static let LIABILITY_FREQUENCY    = "LIABILITY_FREQUENCY_ENTITY"
    public static let INCOME_ASSET_CATEGORY  = "INCOME_ASSET_CATEGORY_ENTITY"
    public static let EXTERNAL_LOAN_TYPE     = "EXTERNAL_LOAN_TYPE_ENTITY"
}

