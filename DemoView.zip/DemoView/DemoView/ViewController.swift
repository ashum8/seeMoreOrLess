//
//  ViewController.swift
//  DemoView
//
//  Created by Ashutosh Mishra on 04/12/19.
//  Copyright © 2019 Ashutosh Mishra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var headerView: UIView!
    var myCustomView = SearchHeaderView()
    override func viewDidLoad() {
        super.viewDidLoad()
        myCustomView.frame = CGRect(x: 0, y: 40, width: self.headerView.bounds.width, height: 60)
        myCustomView.backgroundColor = .gray
        myCustomView.btnBack.addTarget(self, action: #selector(btnSearchBack), for: .touchUpInside)
        headerView.addSubview(myCustomView)
        myCustomView.isHidden = true
        // Do any additional setup after loading the view.
    }

    @IBAction func btnCheckClicked(_ sender: Any) {
        myCustomView.isHidden = false
        
    }
   
    @objc func btnSearchBack() {
        print("back clicked")
        myCustomView.isHidden = true
        
    }
}

