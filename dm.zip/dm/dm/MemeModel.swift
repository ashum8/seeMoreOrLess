//
//  MemeModel.swift
//  dm
//
//  Created by Ashutosh Mishra on 02/04/19.
//  Copyright © 2019 Ashutosh Mishra. All rights reserved.
//

import UIKit

struct MemeModel {
    let image: UIImage
    let name: String
}
