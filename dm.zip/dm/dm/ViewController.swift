//
//  ViewController.swift
//  dm
//
//  Created by Ashutosh Mishra on 02/04/19.
//  Copyright © 2019 Ashutosh Mishra. All rights reserved.
//

import UIKit

class ViewController: UIViewController,InshortsViewDelegate,InshortsViewDataSource {
    
    let data: [MemeModel] = [MemeModel(image: UIImage(named: "ic_bookmark")!, name: "Mocking Spongebob"),
                             MemeModel(image: UIImage(named: "ic_bookmark")!, name: "Drake"),
                             MemeModel(image: UIImage(named: "ic_bookmark")!, name: "Dat boi"),
                             MemeModel(image: UIImage(named: "ic_bookmark")!, name: "Expanding Brain"),
                             MemeModel(image: UIImage(named: "ic_bookmark")!, name: "Expanding Brain")]
    var isHideNavBar:Bool = true
    @IBOutlet var collectionView: UICollectionView!
    var inshortsView = InshortsView()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        collectionView.dataSource = self
//        collectionView.delegate = self
//        collectionView.register(UINib.init(nibName: "MemeCell", bundle: nil), forCellWithReuseIdentifier: "MemeCell")
        self.inshortsView = InshortsView.init(frame: self.view.frame)
//        self.inshortsView = [[InshortsView alloc] initWithFrame:self.view.frame];
        self.inshortsView.dataSource = self;
        self.inshortsView.delegate = self;
        self.view.addSubview(self.inshortsView)
//        [self.view addSubview:self.inshortsView];
        
        
    }
    @objc func checkAction(sender : UITapGestureRecognizer) {
        // Do what you want
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
//    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        return data.count
//    }
    
//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MemeCell", for: indexPath) as! MemeCell
//        cell.configure(with: data[indexPath.row])
//        return cell
//    }
    func numberOfItems(in inshortsView: InshortsView!) -> Int {
        return 5
    }
    
    func inshortsView(_ inshortsView: InshortsView!, viewForItemAt index: Int, reusing view: UIView!) -> UIView! {
        if (index < 0 || index >= 5)
        {
            return nil;
        }
        
        var temp :UIView?
        if (view != nil) {
            print("reusing view");
            temp = view;
        }
        else {
            temp = Bundle.main.loadNibNamed("MemeCell", owner: self, options: nil)?[0] as? MemeCell
//            temp = [[[NSBundle mainBundle] loadNibNamed:@"NewsCardView" owner:self options:nil] objectAtIndex:0];
            let v = temp as! MemeCell
//            NewsCardView *v = (NewsCardView*)temp;
            v.containerWidth = Int(inshortsView.frame.size.width - 32)
//            v.containerWidth = Int(inshortsView.frame.size.width - 32);
            v.containerHeight = Int(inshortsView.frame.size.height - 40);
            v.containerX = 16;
            v.containerY = 20;
//            temp.frame = CGRectMake(0, 0,inshortsView.frame.size.width, inshortsView.frame.size.height);
            temp?.frame = CGRect(x: 0, y: 0, width: Int(inshortsView.frame.size.width), height: Int(inshortsView.frame.size.height))
            v.configure(with: data[index])
//            let gesture = UITapGestureRecognizer(target: self, action:  #selector(self.checkAction))
//            v.addGestureRecognizer(gesture)
            
        }
        var tapGesture = UITapGestureRecognizer()
        tapGesture = UITapGestureRecognizer(target: self, action:  #selector(ViewController.checkAction(sender:)))
        temp!.addGestureRecognizer(tapGesture)
         return temp;
    }
    
    func inshortsViewCurrentItemIndexDidChange(_ inshortsView: InshortsView!) {
        print("inshorts index= \(inshortsView.currentItemIndex)")
    }
    func inshortsView(_ inshortsView: InshortsView!, didSelectItemAt index: Int) {
        print("didSelectItemAtIndex = \(index)")
        if(isHideNavBar)
        {
            isHideNavBar = false
            self.navigationController?.setNavigationBarHidden(true, animated: true)
        }
        else{
            self.navigationController?.setNavigationBarHidden(false, animated: true)
            isHideNavBar = true
        }
    }
}

