//
//  MemeCell.swift
//  dm
//
//  Created by Ashutosh Mishra on 02/04/19.
//  Copyright © 2019 Ashutosh Mishra. All rights reserved.
//

import UIKit

class MemeCell: UIView {
    @IBOutlet var image: UIImageView!
    @IBOutlet var name: UILabel!
    @IBOutlet weak var btnTest: UIButton!
    
    @IBOutlet weak var ContainerView: UIView!
    
    var containerWidth:Int?
    var containerHeight:Int?
    var containerX:Int?
    var containerY:Int?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    public func configure(with model: MemeModel) {
        image.image = model.image
        name.text = model.name
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        self.ContainerView.frame = CGRect(x: self.containerX ?? 0, y: self.containerY ?? 0, width: self.containerWidth ?? Int(self.bounds.width), height: self.containerHeight ?? Int(self.bounds.height))
        self.ContainerView.translatesAutoresizingMaskIntoConstraints = true
//        self.containerView.frame = CGRectMake(self.containerX, self.containerY, self.containerWidth, self.containerHeight);
//        self.containerView.translatesAutoresizingMaskIntoConstraints = YES;
    }
}
