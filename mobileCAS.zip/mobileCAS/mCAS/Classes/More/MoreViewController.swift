//
//  MoreViewController.swift
//  mCAS
//
//  Created by iss on 22/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class MoreViewController: UIViewController {

    fileprivate var moreButtonsArray: [ButtonModel]!
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.view.backgroundColor = Constants.LIGHTER_GRAY_COLOR

        if let array = AppDelegate.instance().mainMenuArray as? [ButtonModel] {
            let last = Int(Constants.bottomTabsCount)-1
            let indexesToBeRemoved = [Int](0...last)

            moreButtonsArray = array.enumerated().filter { !indexesToBeRemoved.contains($0.offset) }.map { $0.element }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance()?.headerView, let bottomView = AppDelegate.instance()?.bottomTabbarView {
            bottomView.isHidden = false
            headerView.setTitleWithShowBackButton(title: "More Options", showBackButton: false)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance()?.headerView {
            headerView.setTitleWithShowBackButton(title: "", showBackButton: false)
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension MoreViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.moreButtonsArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MoreButtonCell", for: indexPath) as! MoreButtonCell
        cell.setCellProperties(btnModel: self.moreButtonsArray[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let btnModel = self.moreButtonsArray[indexPath.row]
        
        if AppDelegate.instance() != nil {
            AppDelegate.instance()?.tabsButtonAction(withTabID: btnModel.buttonID)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0.0, left: 0.0, bottom: 0.0, right: 0.0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let availableWidth = (view.frame.width/3)
        return CGSize(width: availableWidth, height: availableWidth)
    }

}
