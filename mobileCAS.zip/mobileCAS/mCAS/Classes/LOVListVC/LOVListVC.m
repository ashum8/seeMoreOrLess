//
//  LOVListVC.m
//  mCAS
//
//  Created by Mac on 29/12/15.
//  Copyright © 2015 Nucleus. All rights reserved.
//

#import "LOVListVC.h"

@interface LOVListVC ()<LOVOptionCellDelegate>

@end

@implementation LOVListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = Constants.LIGHTER_GRAY_COLOR;

    self.searchOptionArray = [[NSArray alloc] initWithArray:self.optionArray];

    self.tableView.tableFooterView = [UIView new];

    //SearchBar Text
    UITextField *textFieldInsideUISearchBar = [applicationSearchBar valueForKey:@"searchField"];
    textFieldInsideUISearchBar.font = [CustomFont GETFONT_REGULAR:17];
    
    //SearchBar Placeholder
    UILabel *textFieldInsideUISearchBarLabel = [textFieldInsideUISearchBar valueForKey:@"placeholderLabel"];
    textFieldInsideUISearchBarLabel.font = [CustomFont GETFONT_REGULAR:17];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [[AppDelegate instance].headerView setTitleWithShowBackButtonWithTitle:[NSLocalizedString(@"Select", nil) stringByAppendingFormat:@" %@",self.title] showBackButton:YES];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [applicationSearchBar resignFirstResponder];
}

#pragma mark - TableViewDelegate Methods

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.searchOptionArray count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSDictionary *tempDic = [self.searchOptionArray objectAtIndex:indexPath.row];

    LOVOptionCell *cell = (LOVOptionCell *)[tableView dequeueReusableCellWithIdentifier:@"LOVOptionCell" forIndexPath:indexPath];
    [cell setProperties];
    cell.tag = 1000+indexPath.row;
    cell.delegate = self;
    cell.titleLabel.text = [tempDic objectForKey:Constants.LOV_VALUE];
    cell.checkButton.selected = [[tempDic objectForKey:Constants.IS_SELECTED_FLAG] isEqualToString:@"Y"];
    
    return cell;
}

#pragma mark - LOVOptionCellDelegate

- (void)buttonSelectActionWithTag:(NSInteger)tag btn:(UIButton * _Nonnull)btn {
    
    if ([self.delegate respondsToSelector:@selector(selectedLOV:withSelectedButton:)]) {
        [self.delegate selectedLOV:[self.searchOptionArray objectAtIndex:tag-1000] withSelectedButton:self.selectedButton];
    }
    
    if ([self.delegate respondsToSelector:@selector(selectedLOV:withSelectedButtonTag:)]) {
        [self.delegate selectedLOV:[self.searchOptionArray objectAtIndex:tag-1000] withSelectedButtonTag:self.selectedLOVTag];
    }
    
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UISearch Bar Methods

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    [self handleSearch:searchBar];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    [self handleSearch:searchBar];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    [searchBar setText:@""];
    [searchBar resignFirstResponder];
    [self handleSearch:nil];
}

- (void)handleSearch:(UISearchBar *)searchBar {
    
    if ([searchBar.text length] > 0) {
        NSIndexSet * indexes = [self.optionArray indexesOfObjectsPassingTest:^BOOL(id obj, NSUInteger idx, BOOL *stop) {
            
            if (([[[obj valueForKey:Constants.LOV_DISPLAY_VALUE] lowercaseString] rangeOfString:[searchBar.text lowercaseString]].location != NSNotFound))
                return YES;
            return NO;
        }];
        self.searchOptionArray = [self.optionArray objectsAtIndexes:indexes];
    }
    else {
        self.searchOptionArray = self.optionArray;
    }
    [self.tableView reloadData];
}


@end
