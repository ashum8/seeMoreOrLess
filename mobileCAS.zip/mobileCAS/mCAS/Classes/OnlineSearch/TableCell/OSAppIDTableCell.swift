//
//  OSAppIDTableCell.swift
//  mCAS
//
//  Created by iMac on 28/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class OSAppIDTableCell: GenericTableViewCell, UITextFieldDelegate {

    @IBOutlet weak var simpleSearchTextField: JVFloatLabeledTextField!
    @IBOutlet weak var searchButton: UIButton!
    
    override func awakeFromNib() {
        // Initialization code
        super.awakeFromNib()
        simpleSearchTextField.layer.cornerRadius = 5.0
        simpleSearchTextField.layer.borderColor = UIColor.lightGray.cgColor
        simpleSearchTextField.layer.borderWidth = 1.0
        simpleSearchTextField.autocapitalizationType = .allCharacters
        simpleSearchTextField.keyboardType = .default
        
        FIApplicationUtils.setButtonProperties(self.searchButton)
    }
    
    @IBAction func searchButtonClicked(_ sender: Any) {
        
        if !(simpleSearchTextField.text!.isAlphanumeric()) || simpleSearchTextField.text!.isEmpty {
            FIApplicationUtils.showAlert(withTitle: NSLocalizedString("", comment: ""), andMessage: NSLocalizedString("Please enter valid Application Id", comment: ""))
        }
        else {
            simpleSearchTextField.resignFirstResponder()

            if let viewController = self.getViewController() as? OnlineSearchVC {
                viewController.searchServiceCall(txtSearch: simpleSearchTextField.text!.uppercased())
            }
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let count = textField.text!.count + string.count - range.length
        
        if !string.isAlphanumeric() || count > 25 {
            return false
        }
        
        return true
    }

}
