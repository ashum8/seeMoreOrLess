//
//  OSUniqueIdTableCell.swift
//  mCAS
//
//  Created by iMac on 28/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class OSUniqueIdTableCell: GenericTableViewCell, UITextFieldDelegate, LOVListDelegate {

    @IBOutlet weak var simpleSearchTextField: JVFloatLabeledTextField!
    @IBOutlet weak var searchButton: UIButton!
    @IBOutlet weak var idTypeButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.simpleSearchTextField.layer.cornerRadius = 5.0
        self.simpleSearchTextField.layer.borderColor = UIColor.lightGray.cgColor
        self.simpleSearchTextField.layer.borderWidth = 1.0;
        self.simpleSearchTextField.autocapitalizationType = .allCharacters
        self.simpleSearchTextField.keyboardType = .default
        
        self.idTypeButton.layer.cornerRadius = 5.0;
        self.idTypeButton.layer.borderColor = UIColor.lightGray.cgColor
        self.idTypeButton.layer.borderWidth = 1.0;
    }

     @IBAction func idTypeButtonClicked(_ sender: Any) {
        
        let viewController = self.getViewController() as? OnlineSearchVC
//        OnlineSearchVC *viewController = (OnlineSearchVC*)[self getViewController];
        let storyboard = UIStoryboard.init(name: Constants.STORYBOARD_LOV_LIST, bundle: nil)
        let obj = storyboard.instantiateViewController(withIdentifier: "LOVListVC") as? LOVListVC
        obj?.title = NSLocalizedString("Select Id", comment: "")
        obj?.delegate = self
        obj?.optionArray = viewController?.idTypesArray as? NSMutableArray
        viewController?.navigationController?.pushViewController(obj!, animated: true)
    }
    
//   MARK: - LOVListVC Delegate

    func selectedLOV(_ sender: Any?, btntag: Int) {
        
        let tempLOVDic = sender as? [AnyHashable : Any]

        if let viewController = self.getViewController() as? OnlineSearchVC {
            for i in 0..<(viewController.idTypesArray.count) {
                if var dic = viewController.idTypesArray[i] as? [String: Any] , let dicLovKey = dic[Constants.LOV_KEY] as? String , let tempDicLovKey = tempLOVDic?[Constants.LOV_KEY] as? String , let dicLovValue = dic[Constants.LOV_DISPLAY_VALUE] as? String , let tempDicLovValue = tempLOVDic?[Constants.LOV_DISPLAY_VALUE] as? String {

                    if (dicLovKey == tempDicLovKey) && (dicLovValue == tempDicLovValue) {
                        dic[Constants.IS_SELECTED_FLAG] = "Y"
                    } else {
                        dic[Constants.IS_SELECTED_FLAG] = "N"
                    }
                    viewController.idTypesArray[i] = dic
                }
            }
            
        }
        
        idTypeButton.setTitle(tempLOVDic?[Constants.LOV_DISPLAY_VALUE] as? String, for: .normal)
        simpleSearchTextField.placeholder = tempLOVDic?[Constants.LOV_DISPLAY_VALUE] as? String
        simpleSearchTextField.text = ""
        
    }
    
//    MARK: - Search bar action

    @IBAction func searchButtonClicked(_ sender: Any) {
    
    }
    
//    MARK: Textfield delegate methods

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return string.isAlphanumeric()
    }
}
