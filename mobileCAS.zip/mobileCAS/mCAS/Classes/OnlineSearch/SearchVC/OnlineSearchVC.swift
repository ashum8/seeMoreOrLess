//
//  OnlineSearchVC.swift
//  mCAS
//
//  Created by iMac on 28/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

enum OSSearchType {  // Used in search module to check search is running for which module
    case FIV
    case RateApproval
}

class OnlineSearchVC: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var segmentedSearchTypeButton: UISegmentedControl!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var lblSearchVia: UILabel!
    
    var tableArray: [Any] = []
    var searchType: OSSearchType?
    var tempApplicationID: String?
    var idTypesArray: [Any] = []
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = Constants.LIGHTER_GRAY_COLOR
        
        self.tableView.tableFooterView = UIView()
        // register custom nib
        self.tableView.register(UINib(nibName: String(describing: CasesCell.self), bundle: Bundle.main), forCellReuseIdentifier: "CasesCell")
        
        //Setting for segmented Control
        if self.searchType == .FIV || self.searchType == .RateApproval {
            self.segmentedSearchTypeButton.removeSegment(at: 1, animated: false) //Remove Customer Info Tab
            self.segmentedSearchTypeButton.removeSegment(at: 1, animated: false) //Remove Unique ID Tab
        }
        
        self.segmentedSearchTypeButton.selectedSegmentIndex = 0
        self.segmentedSearchTypeButton.setTitleTextAttributes([.font: CustomFont.getfont_REGULAR(15)!], for: .normal)
        self.segmentedSearchTypeButton.tintColor = Constants.BLUE_COLOR
        self.lblSearchVia.font = CustomFont.getfont_REGULAR(16)

        self.idTypesArray.append(["key": "PHONE_NUMBER", "value": NSLocalizedString("Mobile Number", comment: ""), "isSelected":"N"])
        self.onlineSearchForTabButtonClicked(self.segmentedSearchTypeButton!)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        AppDelegate.instance()?.bottomTabbarView.isHidden = true
        AppDelegate.instance()?.headerView.setTitleWithShowBackButton(title: "Search Application", showBackButton: true)
    }

//    MARK: - Segmented Control Button Action

    @IBAction func onlineSearchForTabButtonClicked(_ sender: Any) {
        
        var tableModel = OSTableModel()
        tableModel.isVisible = true
        
        if self.segmentedSearchTypeButton.selectedSegmentIndex == 0 {
            tableModel.dequeIdentifier = "OSAppIDTableCell"
            tableModel.cellHeight = 55.0
        }
        else if self.segmentedSearchTypeButton.selectedSegmentIndex == 1 {
            tableModel.dequeIdentifier = "OSDOBTableCell"
            tableModel.cellHeight = 106.0
        }
        else {
            tableModel.dequeIdentifier = "OSUniqueIdTableCell"
            tableModel.cellHeight = 130.0
        }
        
        self.tableArray.removeAll()
        self.tableArray.append(tableModel)
        self.tableView.reloadData()
    }
    
//    MARK: - Table View Delegate Methods

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.tableArray.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if var data = self.tableArray[indexPath.row] as? OSTableModel, let identifier = data.dequeIdentifier {
            let cell = tableView.dequeueReusableCell(withIdentifier: identifier, for: indexPath)
            
            if identifier == "OSUniqueIdTableCell" {
                
                if let simpleCell = cell as? OSUniqueIdTableCell {
                    simpleCell.simpleSearchTextField.font = CustomFont.getfont_REGULAR(15)
                    
                    FIApplicationUtils.setButtonProperties(simpleCell.searchButton)
                    
                    if data.isVisible {
                        simpleCell.simpleSearchTextField.text = ""
                        data.isVisible = false
                    }
                    
                    if self.idTypesArray.isEmpty && simpleCell.idTypeButton.title(for: .normal)!.isEmpty {
                        if let dict = self.idTypesArray.first as? [String: Any] , let value = dict["value"] as? String {
                            simpleCell.idTypeButton.setTitle(value, for: .normal)
                            simpleCell.simpleSearchTextField.placeholder = value
                        }
                    }
                    
                    return simpleCell
                }
            }
            else if identifier == "OSAppIDTableCell" {
                
                if let simpleCell = cell as? OSAppIDTableCell {
                    simpleCell.simpleSearchTextField.font = CustomFont.getfont_REGULAR(15)
                    
                    if data.isVisible {
                        simpleCell.simpleSearchTextField.text = ""
                        data.isVisible = false
                    }
                    FIApplicationUtils.setButtonProperties(simpleCell.searchButton)
                    
                    return simpleCell
                }
            }
            else if identifier == "OSDOBTableCell" {
                if let simpleCell = cell as? OSDOBTableCell {
                    
                    simpleCell.customerNameTextField.font = CustomFont.getfont_REGULAR(15)
                    simpleCell.dateOfBirthTextField.font = CustomFont.getfont_REGULAR(15)
                    
                    if data.isVisible {
                        simpleCell.customerNameTextField.text = ""
                        simpleCell.dateOfBirthTextField.text = ""
                        data.isVisible = false
                    }
                    
                    FIApplicationUtils.setButtonProperties(simpleCell.searchButton)
                    
                    simpleCell.selectedDate = Date()
                    return simpleCell
                }
            }
        }
        
        return UITableViewCell()
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let data = self.tableArray[indexPath.row] as! OSTableModel
        return data.cellHeight
    }

    func searchServiceCall(txtSearch: String) {
        if FIApplicationUtils.checkForReachabilityMode() {
            let st = UIStoryboard.init(name: Constants.STORYBOARD_ONLINE_SEARCH, bundle: nil)
            if let vc = st.instantiateViewController(withIdentifier: "OnlineSearchResultVC") as? OnlineSearchResultVC {
                vc.searchType = self.searchType
                vc.searchText = txtSearch
                self.navigationController?.pushViewController(vc, animated: false)
            }
        }
    }
    
}
