//
//  HeaderView.swift
//  mCAS
//
//  Created by Mac on 19/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class LOVHeaderView: UIView {
    private var titleLabel: UILabel!
    var closeButton: UIButton!

    override init(frame: CGRect) {
        super.init(frame: frame)
       
        let view: UIView = UIView(frame: CGRect(x: 0, y: 0, width: self.frame.size.width, height: self.frame.size.height))
        view.backgroundColor = .white
        self.addSubview(view)
        
        let buttonWidth = self.frame.size.height-20

        titleLabel = UILabel(frame: CGRect(x: 10, y: 20, width: self.frame.size.width-(buttonWidth+20), height: self.frame.size.height-20))
        titleLabel.lineBreakMode = .byWordWrapping
        titleLabel.numberOfLines = 2
        titleLabel.textAlignment = .center
        titleLabel.font = CustomFont.getfont_MEDIUM(19)
        titleLabel.textColor = .darkGray
        view.addSubview(titleLabel)
        
        closeButton = UIButton(frame: CGRect(x: self.frame.size.width-buttonWidth, y: 20, width: buttonWidth, height: buttonWidth))
        closeButton.setImage(UIImage(named: "close_gray_icon"), for: .normal)
        closeButton.addTarget(self, action:#selector(closeButtonAction(_:)), for: .touchUpInside)
        closeButton.isHidden = true
        view.addSubview(closeButton)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func setTitle(title: String) {
        titleLabel.text = title
    }
    
    @objc private func closeButtonAction(_ sender: UIButton) {
        AppDelegate.instance().applicationNavController.popViewController(animated: false)
    }
    
    @objc func setAttributedTitle(line1: String, line2: String) {
        titleLabel.setHeaderTitleOnWhiteBG(line1: line1, line2: line2)
    }
}
