//
//  LOVOptionCell.swift
//  mCAS
//
//  Created by Mac on 02/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


@objc protocol LOVOptionCellDelegate : class {
    func buttonSelectAction(tag: NSInteger, btn: UIButton)
}


class LOVOptionCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var checkButton: UIButton!
    @objc weak var delegate: LOVOptionCellDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    @objc func setProperties() {
        self.backgroundColor = .white
        self.selectionStyle = .none

        titleLabel.font = CustomFont.getfont_REGULAR(17)
    }
    
    @IBAction func checkButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        delegate?.buttonSelectAction(tag: self.tag, btn: sender)
    }

}
