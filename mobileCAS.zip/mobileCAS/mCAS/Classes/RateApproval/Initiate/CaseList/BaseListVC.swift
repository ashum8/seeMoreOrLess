//
//  BaseListVC.swift
//  mCAS
//
//  Created by Mac on 23/08/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

enum CASETYPE: String {
    case Initiated = "Initiated"
    case Approved = "Approved"
    case Rejected = "Rejected"
    case Cancelled = "Cancelled"
    case Approval = "Approval"
    case ToInitiate = "Initiate"
    case ToApprove = "Approve"
    case ToReject = "Reject"
    case ToForward = "Forward"
}

class BaseListVC: UIViewController {
    
    @IBOutlet weak var swipeMenuView: SwipeMenuView!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var swipeMenuTopMarginConstraint: NSLayoutConstraint!
    
    private var caseTypes: [CASETYPE] = [.Initiated, .Approved, .Rejected, .Cancelled]
    
    var currentIndex: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.view.backgroundColor = Constants.LIGHTER_GRAY_COLOR
        
        addButton.layer.cornerRadius = 28
        addButton.backgroundColor = Constants.BLUE_COLOR
        addButton.titleLabel?.font = CustomFont.getfont_MEDIUM(48)
        addButton.setButtonShadow()
        
        caseTypes.forEach { data in
            let st = UIStoryboard.init(name: Constants.STORYBOARD_RATE_INITIATE, bundle: nil)
            let vc = st.instantiateViewController(withIdentifier: "CaseListVC") as! CaseListVC
            vc.caseType = data
            self.addChild(vc)
        }
        
        var options: SwipeMenuViewOptions = .init()
        options.tabView.itemView.selectedTextColor = .white
        options.tabView.itemView.textColor = Constants.LIGHTER_BLUE_COLOR
        options.tabView.itemView.margin = 15.0
        options.tabView.itemView.font = CustomFont.getfont_MEDIUM(18)
        options.tabView.additionView.backgroundColor = .white
        
        swipeMenuView.delegate = self
        swipeMenuView.dataSource = self
        swipeMenuView.reloadData(options: options)
        swipeMenuView.backgroundColor = Constants.BLUE_COLOR
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance()?.headerView, let bottomView = AppDelegate.instance()?.bottomTabbarView {
            bottomView.isHidden = true
            headerView.setTitleWithShowBackButton(title: "Rate Approval", showBackButton: true)
            headerView.delegate = self
            headerView.showHideSearchMikeOption(show: true)
            searchOnOff(isSearching: false)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if let headerView = AppDelegate.instance()?.headerView {
            headerView.setTitleWithShowBackButton(title: "", showBackButton: false)
            headerView.showHideSearchMikeOption(show: false)
        }
    }
    
    
    @IBAction func addButtonAction(_ sender: UIButton) {
        
        let st = UIStoryboard.init(name: Constants.STORYBOARD_ONLINE_SEARCH, bundle: nil)
        let vc = st.instantiateInitialViewController() as! OnlineSearchVC
        vc.searchType = .RateApproval
        self.navigationController?.pushViewController(vc, animated: false)
    }
    
}

extension BaseListVC: SwipeMenuViewDelegate {
    func swipeMenuView(_ swipeMenuView: SwipeMenuView, viewWillSetupAt currentIndex: Int) {
        //called for first time only
        
        self.currentIndex = currentIndex
        let vc = children[currentIndex] as! CaseListVC
        vc.fetchCases()
    }
    
    func swipeMenuView(_ swipeMenuView: SwipeMenuView, willChangeIndexFrom fromIndex: Int, to toIndex: Int) {
        
        self.currentIndex = toIndex
        let vc = children[toIndex] as! CaseListVC
        if !vc.isServiceCalled {
            vc.fetchCases()
        }
    }
}

extension BaseListVC: SwipeMenuViewDataSource {
    // MARK - SwipeMenuViewDataSource
    
    func numberOfPages(in swipeMenuView: SwipeMenuView) -> Int {
        return children.count
    }
    
    func swipeMenuView(_ swipeMenuView: SwipeMenuView, titleForPageAt index: Int) -> String {
        return children[index].title ?? ""
    }
    
    func swipeMenuView(_ swipeMenuView: SwipeMenuView, viewControllerForPageAt index: Int) -> UIViewController {
        let vc = children[index]
        vc.didMove(toParent: self)
        return vc
    }
}

extension BaseListVC: searchOptionsDelegates {
    
    func searchOnOff(isSearching: Bool) {
        
        let vc = children[currentIndex] as! CaseListVC
        
        swipeMenuTopMarginConstraint.constant = isSearching ? 0 : 45
        swipeMenuView.contentScrollView?.isScrollEnabled = !isSearching
        
        if isSearching {
            vc.refreshControl.removeFromSuperview()
        }
        else {
            vc.handleSearch(searchTxt: "")
            vc.tableView.addSubview(vc.refreshControl)
        }
    }
    
    func handleSearch(text : String) {
        let vc = children[currentIndex] as! CaseListVC
        vc.handleSearch(searchTxt: text)
    }
    
}
