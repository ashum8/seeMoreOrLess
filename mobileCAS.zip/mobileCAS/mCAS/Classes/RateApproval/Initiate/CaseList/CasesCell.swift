//
//  CasesCell.swift
//  mCAS
//
//  Created by Mac on 27/08/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

@objc class CasesCell: UITableViewCell {

    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label3: UILabel!
    @IBOutlet weak var loanTypeLabel: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var arrowIcon: UIImageView!
    @IBOutlet weak var optionButton: UIButton!

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    @objc func setProperties() {
        self.contentView.backgroundColor = .clear
        self.backgroundColor = .clear

        bgView.layer.cornerRadius = 3.0
        bgView.setShadow()
        
        label1.font = CustomFont.getfont_MEDIUM(19)
        label2.font = CustomFont.getfont_REGULAR(16)
        label3.font = CustomFont.getfont_REGULAR(16)
        loanTypeLabel.font = CustomFont.getfont_REGULAR(16)
    }

    @IBAction func optionButtonAction(_ sender: Any) {
        
    }
}
