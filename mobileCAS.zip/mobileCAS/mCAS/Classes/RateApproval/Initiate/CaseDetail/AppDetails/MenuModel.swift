//
//  MenuModel.swift
//  mCAS
//
//  Created by Mac on 27/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

struct MenuModel {
    var title: String!
    var menuID: String!
    var imageName: String!
    var visible: Bool!
    
    init(title: String, menuID: String, imageName: String? = nil, visible: Bool? = false) {
        self.title = title
        self.menuID = menuID
        self.imageName = imageName
        self.visible = visible
    }
}
