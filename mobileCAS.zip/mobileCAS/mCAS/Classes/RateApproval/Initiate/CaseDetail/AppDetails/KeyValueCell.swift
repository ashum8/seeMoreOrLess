//
//  KeyValueCell.swift
//  mCAS
//
//  Created by Mac on 27/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class KeyValueCell: UITableViewCell {
    
    @IBOutlet weak var keyLabel: UILabel!
    @IBOutlet weak var valueLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
}
