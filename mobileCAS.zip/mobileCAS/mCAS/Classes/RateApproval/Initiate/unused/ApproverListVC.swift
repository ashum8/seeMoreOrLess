//
//  ApproverListVC.swift
//  mCAS
//
//  Created by Mac on 06/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class ApproverListVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    private var selectAllButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.view.backgroundColor = Constants.LIGHTER_GRAY_COLOR
        tableView.tableFooterView = UIView()
        tableView.register(UINib.init(nibName: "ApproverCell", bundle: Bundle.main), forCellReuseIdentifier: "ApproverCell")
        
        if let headerView = AppDelegate.instance()?.headerView {
            selectAllButton = UIButton(frame: CGRect(x: headerView.frame.size.width - 130, y: 20, width: 120, height: headerView.frame.size.height - 20))
            selectAllButton.contentHorizontalAlignment = .right
            selectAllButton.titleLabel?.font = CustomFont.getfont_REGULAR(18)
            selectAllButton.setTitle("Select All", for: .normal)
            selectAllButton.setTitle("UnSelect All", for: .selected)
            selectAllButton.addTarget(self, action:#selector(selectAllAction(_:)), for: .touchUpInside)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance()?.headerView, let bottomView = AppDelegate.instance()?.bottomTabbarView {
            bottomView.isHidden = true
            headerView.setTitleWithShowBackButton(title: "Rate Approval", showBackButton: true)
            headerView.addSubview(selectAllButton)
        }
    }
    
    @objc private func selectAllAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        
        if let headerView = AppDelegate.instance()?.headerView {
            if sender.isSelected == true {
                headerView.setTitleWithShowBackButton(title: "50 selected", showBackButton: true)
            }
            else {
                headerView.setTitleWithShowBackButton(title: "Rate Approval", showBackButton: true)
            }
        }
    }

    
    @IBAction func longPressAction(_ sender: UILongPressGestureRecognizer) {
        if sender.state == .began {
            let touchPoint = sender.location(in: tableView)
            if let indexPath = tableView.indexPathForRow(at: touchPoint) {
                let cell: ApproverCell = tableView.cellForRow(at: indexPath) as! ApproverCell
                cell.loanTypeButtonAction(cell.loanTypeButton)
            }
        }
    }
    

    
}

extension ApproverListVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 50
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: ApproverCell = tableView.dequeueReusableCell(withIdentifier: "ApproverCell") as! ApproverCell
        
        cell.label1.text = "50009022"
        cell.label2.text = "Ravikant Dubey (14354)"
        cell.label3.text = "8,30,000 • IRR: 9.65% (-1.47%)"
        cell.setProperties()
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        //SK Change - check if any row is selected than on single click user can select another
//        if cell.loanTypeButton.isSelected == true {
//            cell.loanTypeButtonAction(cell.loanTypeButton)
//        }
//        else {
            let st = UIStoryboard.init(name: Constants.STORYBOARD_RATE_INITIATE, bundle: nil)
            let vc = st.instantiateViewController(withIdentifier: "ApproverReferVC") as! ApproverReferVC
            self.navigationController?.pushViewController(vc, animated: false)
//        }
    }
}
