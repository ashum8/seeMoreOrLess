//
//  ApproverReferVC.swift
//  mCAS
//
//  Created by Mac on 05/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class ApproverReferVC: UIViewController {

    @IBOutlet weak var approverView: UIView!
    @IBOutlet weak var approverTitleLabel: UILabel!
    
    @IBOutlet weak var reasonView: UIView!
    @IBOutlet weak var reasonTitleLabel: UILabel!
    
    @IBOutlet weak var remarksView: UIView!
    @IBOutlet weak var remarksTitleLabel: UILabel!
    @IBOutlet weak var remarksTextView: UITextView!
    
    @IBOutlet weak var submitButton: UIButton!

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        approverView.setMainViewProperties()
        reasonView.setMainViewProperties()
        remarksView.setMainViewProperties()
        
        approverTitleLabel.resetSingleSelectLOV(line1: "Approver")
        reasonTitleLabel.resetSingleSelectLOV(line1: "Reason")

        remarksTitleLabel.setRemarks(title: "Remarks")

        remarksTextView.setRemarksTextView()
        
        FIApplicationUtils.setButtonProperties(submitButton)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance()?.headerView {
            headerView.setDefaultHeaderTitle(line1: "Refer", line2: "50009022 • Kapil Verma", showBackButton: true)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func submitButtonAction(_ sender: Any) {
        
    }
}
