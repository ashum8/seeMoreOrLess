//
//  InterestRateTableViewCell.swift
//  mCAS
//
//  Created by iMac on 02/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class InterestRateTableViewCell: UITableViewCell {

    @IBOutlet weak var lblRequestedRate: UILabel!
    @IBOutlet weak var lblCurrentRate: UILabel!
    @IBOutlet weak var lblChargesCode: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setupView() {
        
        lblRequestedRate.font = CustomFont.getfont_REGULAR(16)
        lblCurrentRate.font = CustomFont.getfont_REGULAR(16)
        lblChargesCode.font = CustomFont.getfont_REGULAR(16)
    }
    
}
