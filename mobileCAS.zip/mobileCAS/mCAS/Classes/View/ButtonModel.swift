//
//  ButtonModel.swift
//  mCAS
//
//  Created by iss on 25/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

struct ButtonModel {

    var buttonText: String!
    var buttonID: String!
    var buttonImage: String!
    var activeIcon: String!
    var mediumIcon: String!
    var order: Int!
    
    init(buttonText: String?, buttonID: String?, buttonImage: String?, order: Int?) {
        self.buttonText = buttonText
        self.buttonID = buttonID
        self.buttonImage = buttonImage
        self.order = order
        self.mediumIcon = buttonImage?.appendingFormat("%-12@","_medium")
        self.activeIcon = buttonImage?.appendingFormat("%-12@","_active")
    }
}
