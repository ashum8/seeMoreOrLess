//
//  HeaderView.swift
//  mCAS
//
//  Created by Mac on 19/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit
import AudioToolbox

protocol searchOptionsDelegates: class {
    func searchOnOff(isSearching: Bool)
    func handleSearch(text : String)
}

class HeaderView: UIView {
    private var titleLabel: UILabel!
    private var backButton: UIButton!
    
    var searchMikeView = UIView()
    var searchButton: UIButton!
    var mikeButton: UIButton!
    var searchView = SearchHeaderView()
    var delegate: searchOptionsDelegates?
    var speechController = SpeechController()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let view: UIView = UIView(frame: CGRect(x: 0, y: 0, width: self.frame.size.width, height: self.frame.size.height))
        view.backgroundColor = Constants.BLUE_COLOR
        self.addSubview(view)
        
        let margin: CGFloat = 5
        let height = self.frame.size.height-20
        
        backButton = UIButton(frame: CGRect(x: margin, y: 20, width: height, height: height))
        backButton.setImage(UIImage(named: "white_back_icon"), for: .normal)
        backButton.addTarget(self, action:#selector(backButtonAction(_:)), for: .touchUpInside)
        backButton.isHidden = true
        view.addSubview(backButton)
        
        let xCord = backButton.frame.origin.x+backButton.frame.size.width+10
        
        titleLabel = UILabel(frame: CGRect(x: xCord, y: 20, width: self.frame.size.width-xCord-margin, height: height))
        titleLabel.lineBreakMode = .byWordWrapping
        titleLabel.numberOfLines = 2
        titleLabel.font = CustomFont.getfont_REGULAR(19)
        titleLabel.textColor = .white
        titleLabel.isHidden = true
        view.addSubview(titleLabel)
        
        setupSearchOptions(view: view)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func setTitleWithShowBackButton(title: String, showBackButton: Bool) {
        
        titleLabel.text = title
        titleLabel.isHidden = false
        backButton.isHidden = !showBackButton
        
        setTitleLabelFrame()
    }
    
    private func setTitleLabelFrame() {
        
        var frame = titleLabel.frame
        
        if backButton.isHidden == true {
            frame.origin.x = 10
        }
        else {
            frame.origin.x = backButton.frame.origin.x+backButton.frame.size.width+10
        }
        
        titleLabel.frame = frame
    }
    
    @objc func setDefaultHeaderTitle(line1: String, line2: String, showBackButton: Bool) {
        titleLabel.setHeaderTitleOnBlueBG(line1: line1, line2: line2)
        titleLabel.isHidden = false
        backButton.isHidden = !showBackButton
        
        setTitleLabelFrame()
    }
    
    @objc private func backButtonAction(_ sender: UIButton) {
        AppDelegate.instance().applicationNavController.popViewController(animated: false)
    }
    
    func setupSearchOptions(view: UIView) {
        
        let width = view.frame.size.height-20

        searchMikeView = UIView(frame: CGRect(x: view.frame.size.width - (width*2), y: 0, width: width*2 , height: view.frame.size.height))
        searchMikeView.backgroundColor = .clear
        view.addSubview(searchMikeView)

        searchButton = UIButton(frame: CGRect(x: 0, y: 20, width: width, height: width))
        searchButton.contentHorizontalAlignment = .center
        searchButton.setImage(UIImage(named: "search_icon"), for: .normal)
        searchButton.addTarget(self, action:#selector(searchButtonAction(_:)), for: .touchUpInside)
        
        mikeButton = UIButton(frame: CGRect(x: width, y: 20, width: width, height: width))
        mikeButton.contentHorizontalAlignment = .center
        mikeButton.setImage(UIImage(named: "mike_icon"), for: .normal)
        mikeButton.addTarget(self, action:#selector(stopRecording), for: .touchUpInside)
        mikeButton.addTarget(self, action:#selector(startRecording), for: .touchDown)
        mikeButton.addTarget(self, action:#selector(stopRecording), for: .touchUpOutside)
        
        searchMikeView.addSubview(searchButton)
        searchMikeView.addSubview(mikeButton)
        
        searchView.frame = CGRect(x: 0, y: 20, width: view.frame.size.width, height: 45)
        searchView.delegate = self
        view.addSubview(searchView)
        
        showHideSearchMikeOption(show: false)
        speechController.delegate = self
    }
    
    @objc func showHideSearchMikeOption(show: Bool) {
        searchMikeView.isHidden = !show
        searchView.isHidden = true
    }

    @objc private func searchButtonAction(_ sender: UIButton) {
        
        searchView.isHidden = false
        searchView.searchBar.becomeFirstResponder()
        searchView.searchBar.text = ""
        delegate?.searchOnOff(isSearching: true)
    }
    
    @objc private func startRecording() {
        searchView.searchBar.text = ""
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)
        
        do {
            try self.speechController.startRecording()
//            self.messageLabel.text = "Listening..."
        }
        catch {
//            self.messageLabel.text = "Press and hold microphone to record"
        }
    }
    
    @objc private func stopRecording() {

        speechController.stopRecording()
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)
        
//            self.messageLabel.text = "Press and hold microphone to record"

        if let text = searchView.searchBar.text {
            //handle search
            print(text)
            
            searchView.isHidden = false
            delegate?.searchOnOff(isSearching: true)
        }
    }
}

extension HeaderView: SearchViewDelegate {
    
    func searchDataFromString(text : String) {
        delegate?.handleSearch(text: text)
    }
    
    func searchBackAction() {
        delegate?.searchOnOff(isSearching: false)
    }
}

extension HeaderView: SpeechControllerDelegate {
    func speechController(_ speechController: SpeechController, didRecogniseText text: String) {
        searchView.searchBar.text = text
    }
}
