//
//  CustomerTypeViewController.swift
//  mCAS
//
//  Created by iss on 22/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class CustomerTypeViewController: UIViewController {

    private var stepsView: StepsHeaderView!
    @IBOutlet weak var indvButton: UIButton!
    @IBOutlet weak var corpButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        indvButton.layer.borderColor = UIColor.lightGray.cgColor
        indvButton.layer.borderWidth = 0.5
        indvButton.layer.cornerRadius = 2.0
        indvButton.setTitleColor(UIColor.darkGray, for: .normal)
        indvButton.titleLabel?.font = CustomFont.getfont_REGULAR(17)
        FIApplicationUtils.setAlignmentOf(indvButton, isTabButton: false)

        createHeaderControls()
        
    }

    private func createHeaderControls() {
        
        if let headerView = AppDelegate.instance()?.headerView {
            stepsView = StepsHeaderView(frame: CGRect(x: 0, y: 0, width: headerView.frame.size.width, height: headerView.frame.size.height))
            headerView.addSubview(stepsView)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        stepsView.isHidden = false
        stepsView.setTitleAndStep(title: "Customer Type", step: "(1/5)")
        
        if let bottomView = AppDelegate.instance()?.bottomTabbarView {
            bottomView.isHidden = true
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stepsView.isHidden = true
    }
    
    @IBAction func customerButtonAction(_ sender: Any) {
    
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
