//
//  DashboardHeaderView.swift
//  mCAS
//
//  Created by Mac on 19/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class DashboardHeaderView: UIView {
    private var titleLabel: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
       
        let height = self.frame.size.height-20
        let view: UIView = UIView(frame: CGRect(x: 0, y: 20, width: self.frame.size.width, height: height))
        view.backgroundColor = .clear
        self.addSubview(view)
        
        let buttonWidth: CGFloat = height
        let firstButtonXCord: CGFloat = self.frame.size.width - (buttonWidth*3) - 10

        
        titleLabel = UILabel(frame: CGRect(x: 10, y: 0, width: firstButtonXCord, height: height))
        titleLabel.textColor = .white
        titleLabel.font = CustomFont.getfont_REGULAR(19)
        view.addSubview(titleLabel)
        
        if let userName = AppDelegate.instance()?.getSavedUserID() {
            self.setTitle(text: "Hi! \(userName)")
        }
        
//        let searchButton = UIButton(frame: CGRect(x: firstButtonXCord, y: 0, width: buttonWidth, height: height))
//        searchButton.setImage(UIImage(named: "search_icon"), for: .normal)
//        searchButton.addTarget(self, action:#selector(searchButtonAction(_:)), for: .touchUpInside)
//        view.addSubview(searchButton)
//
//        let notificationButton = UIButton(frame: CGRect(x: firstButtonXCord + buttonWidth, y: 0, width: buttonWidth, height: height))
//        notificationButton.setImage(UIImage(named: "notification_icon"), for: .normal)
//        notificationButton.addTarget(self, action:#selector(notificationButtonAction(_:)), for: .touchUpInside)
//        view.addSubview(notificationButton)

        let profileButton = UIButton(frame: CGRect(x: firstButtonXCord + (buttonWidth*2), y: 0, width: buttonWidth, height: height))
        profileButton.setImage(UIImage(named: "user_profile_icon"), for: .normal)
        profileButton.addTarget(self, action:#selector(profileButtonAction(_:)), for: .touchUpInside)
        view.addSubview(profileButton)
    }
    
    func setTitle(text: String) {
        titleLabel.text = text
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func searchButtonAction(_ sender: UIButton) {
        
    }
    
    @objc private func notificationButtonAction(_ sender: UIButton) {
        
    }
    
    @objc private func profileButtonAction(_ sender: UIButton) {
        
        FIApplicationUtils.showAlert(withMessage: "Are you sure you want to logout?", withOkTitle: "Yes", withCancelTitle: "No") { (action) in
            
            Webservices.sharedInstance().logoutFromServer { (success) in }
            AppDelegate.instance().presentLoginViewController()
        }
    }

}
