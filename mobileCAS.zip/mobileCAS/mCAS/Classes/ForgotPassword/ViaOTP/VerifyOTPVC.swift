//
//  VerifyOTPVC.swift
//  mCollect
//
//  Created by Mac on 24/06/19.
//  Copyright © 2019 Mac. All rights reserved.
//

import UIKit

class VerifyOTPVC: UIViewController {

    @IBOutlet weak var otpLabel: UILabel!
    @IBOutlet weak var enterOTPLabel: UILabel!
    @IBOutlet weak var didNotLabel: UILabel!
    @IBOutlet weak var resendLabel: UILabel!
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var resendButton: UIButton!
    @IBOutlet weak var otpTextField: JVFloatLabeledTextField!
    @IBOutlet weak var timerView: UIStackView!
    @IBOutlet weak var resendView: UIStackView!
    
    var seconds = OTP_TIMER
    var timer = Timer()
    var userID: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setProperties()
        resetTimer()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        otpTextField.text = ""
    }
    
    private func setProperties() {
        
        otpLabel.font = CustomFont.getfont_MEDIUM(24)
        enterOTPLabel.font = CustomFont.getfont_REGULAR(16)
        didNotLabel.font = CustomFont.getfont_REGULAR(16)
        resendLabel.font = CustomFont.getfont_REGULAR(16)
        timerLabel.font = CustomFont.getfont_MEDIUM(16)
        otpTextField.font = CustomFont.getfont_MEDIUM(20)
        resendButton.titleLabel?.font = CustomFont.getfont_MEDIUM(16)
        resendButton.setTitleColor(Constants.BLUE_COLOR, for: .normal)
        
        otpTextField.defaultTextAttributes.updateValue(10, forKey: NSAttributedString.Key.kern)
        
        enterOTPLabel.text = "Kindly enter \(OTP_LENGTH)-digit OTP sent to mobile number +91 98XXXXXX10"
        otpTextField.becomeFirstResponder()
    }
    
    func resetTimer() {
        otpTextField.text = ""
        resendView.isHidden = true
        timerView.isHidden = false
        seconds = OTP_TIMER
        
        timerLabel.text = String(format: "00:%02d",seconds)
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self,   selector: (#selector(updateTimer)), userInfo: nil, repeats: true)
    }
    
    @objc func updateTimer() {
        seconds -= 1     //This will decrement(count down)the seconds.
        timerLabel.text = String(format: "00:%02d",seconds)

        if seconds == 0 {
            timer.invalidate()
            resendView.isHidden = false
            timerView.isHidden = true
        }
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func resendButtonAction(_ sender: Any) {

        self.view.endEditing(true)
        
        let param : [String:String] = ["userId" : userID]
        
        Webservices.sharedInstance().POST(urlString: ServiceUrl.RESET_PASSWORD_GET_OTP_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            FIApplicationUtils.showAlert(withTitle: "", andMessage: "OTP re-send successfully")

        }, failure: { (error) in
            if error != nil {
                FIApplicationUtils.showAlert(withTitle: "", andMessage: error)
            }
            
        }, noNetwork: { (error) in })
    }
    
    func verifyOTPService() {

        self.view.endEditing(true)

        let checkSumSHA256 = Cipher.sha256(userID! + otpTextField.text!)
        
        let param = ["userId"       : userID!,
                     "otpValue"     : otpTextField.text,
                     "userDetails"  : checkSumSHA256] as! [String : String]

        Webservices.sharedInstance().POST(urlString: ServiceUrl.RESET_PASSWORD_VERIFY_OTP_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let dictionary = responseObj as? [String : String] {
                self.performSegue(withIdentifier: "NewPasswordVC", sender: dictionary["resetToken"])
            }

        }, failure: { (error) in
            if error != nil {
                FIApplicationUtils.showAlert(withTitle: "", andMessage: error)
            }
            
        }, noNetwork: { (error) in })
    }


    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
   
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "NewPasswordVC" {
            if let controller = segue.destination as? NewPasswordVC {
                controller.userID = self.userID
                controller.resetToken = sender as? String
            }
        }
    }
}



extension VerifyOTPVC: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let currentCharacterCount = textField.text?.count ?? 0
        if range.length + range.location > currentCharacterCount {
            return false
        }
        let newLength = currentCharacterCount + string.count - range.length
        
        if newLength == OTP_LENGTH {
           verifyOTPService()
        }
        
        return string.isDigit() && newLength <= OTP_LENGTH
    }
}
