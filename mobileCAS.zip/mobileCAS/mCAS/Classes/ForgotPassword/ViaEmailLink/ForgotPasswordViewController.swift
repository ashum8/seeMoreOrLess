//
//  ForgotPasswordViewController.swift
//  mCAS
//
//  Created by Mac on 10/08/18.
//  Copyright © 2018 Nucleus. All rights reserved.
//

import UIKit

class ForgotPasswordViewController: UIViewController {

    @IBOutlet weak var staticLavel1: UILabel!
    @IBOutlet weak var staticLavel2: UILabel!

    @IBOutlet weak var userNameTextField: JVFloatLabeledTextField!
    @IBOutlet weak var emailTextField: JVFloatLabeledTextField!
    @IBOutlet weak var userNameView: UIView!
    @IBOutlet weak var emailView: UIView!
    @IBOutlet weak var resetButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        self.navigationController?.navigationBar.isHidden = true
        
        setProperties()
    }
    
    private func setProperties() {
        
        staticLavel1.font = CustomFont.getfont_MEDIUM(24)
        staticLavel2.font = CustomFont.getfont_REGULAR(16)

        userNameTextField.autocapitalizationType = .allCharacters
        
        //set color of username and email view
        FIApplicationUtils.setTextFieldViewProperties(userNameView)
        FIApplicationUtils.setTextFieldViewProperties(emailView)
        
        FIApplicationUtils.setButtonProperties(resetButton)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
//        userNameTextField.text = "SHLOK1"
//        emailTextField.text = "shlok.goyal@nucleussoftware.com"
        
        let userName = userNameTextField.text! as String
        let email = emailTextField.text! as String

        setButtonColoring(userName: userName, email: email)
    }
    
    @IBAction func resetButtonClicked(_ sender: Any) {
        let userName = userNameTextField.text! as String
        let email = emailTextField.text! as String
        
        if(userName.isEmpty()) {
            FIApplicationUtils.showAlert(withTitle: "", andMessage: NSLocalizedString("Please enter username", comment: ""))
        }
        else if(!email.isEmail()) {
            FIApplicationUtils.showAlert(withTitle: "", andMessage: NSLocalizedString("Please enter valid email id", comment: ""))
        }
        else {
            self.view.endEditing(true)
            resetPasswordFromServerWith(userName: userName, email: email)
        }
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func resetPasswordFromServerWith(userName: String, email: String)  {
        
        let param : [String:Any] = ["userId"      : userName,
                                    "emailId"     : email,
                                    "extraParam1" : Cipher.sha256(userName),
                                    "extraParam2" : Cipher.sha256(email)]
        
        Webservices.sharedInstance().POST(urlString: ServiceUrl.FORGOT_PASSWORD_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
                        
            self.performSegue(withIdentifier: "PasswordSentViewController", sender: nil)
            
        }, failure: { (error) in
            if error != nil {
                FIApplicationUtils.showAlert(withTitle: "", andMessage: error)
            }
            
        }, noNetwork: { (error) in })
    }
    
    func setButtonColoring(userName: String, email: String) {
        
        var isEnabled: Bool = true
        if (userName.isEmpty() || email.isEmpty() || !email.isEmail()) {
            isEnabled = false
        }
        FIApplicationUtils.setButtonColorWith(resetButton, enabled:isEnabled)
    }

}



extension ForgotPasswordViewController: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == userNameTextField {
            userNameView.layer.borderColor = Constants.BLUE_COLOR.cgColor
        }
        else {
            emailView.layer.borderColor = Constants.BLUE_COLOR.cgColor
        }
        
        self.setButtonColoring(userName: "", email: "")
    }
    
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        let userName = userNameTextField.text! as String
        let email = emailTextField.text! as String
        
        if textField == userNameTextField {
            userNameView.layer.borderColor = UIColor.lightGray.cgColor
        }
        else {
            emailView.layer.borderColor = UIColor.lightGray.cgColor
        }
        
        self.setButtonColoring(userName: userName, email: email)
        
        return true
    }
}
