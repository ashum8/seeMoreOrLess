//
//  AmortizationChartVC.swift
//  mCAS
//
//  Created by iss on 27/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit
import Charts

class AmortizationChartVC: UIViewController {

    @IBOutlet weak var pieChartView: PieChartView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var monthlyEMIKeyLabel: UILabel!
    @IBOutlet weak var monthlyEMIValueLabel: UILabel!
    @IBOutlet weak var principalAmountKeyLabel: UILabel!
    @IBOutlet weak var principalAmountValueLabel: UILabel!
    @IBOutlet weak var totalInterestKeyLabel: UILabel!
    @IBOutlet weak var totalInterestValueLabel: UILabel!
    @IBOutlet weak var periodicInterestKeyLabel: UILabel!
    @IBOutlet weak var periodicInterestValueLabel: UILabel!
    @IBOutlet weak var totalAmountKeyLabel: UILabel!
    @IBOutlet weak var totalAmountValueLabel: UILabel!

    fileprivate var chartArray: [ChartModel] = []

    @objc var installmentLabelName: String!
    @objc var tenureLoanType: String!
    @objc var emiAmount: Double = 0
    @objc var principalAmount: Double = 0
    @objc var tenure: Double = 0
    @objc var tenureInYears: Double = 0
    @objc var ratePerAnnum: Double = 0
    @objc var periodicInterest: Double = 0
    fileprivate var emailButton: UIButton!
    private var esv: EmailSendView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        tableView.tableFooterView = UIView(frame: .zero)

        monthlyEMIKeyLabel.text = installmentLabelName
        
        monthlyEMIKeyLabel.font = CustomFont.getfont_REGULAR(16)
        principalAmountKeyLabel.font = CustomFont.getfont_REGULAR(16)
        totalInterestKeyLabel.font = CustomFont.getfont_REGULAR(16)
        periodicInterestKeyLabel.font = CustomFont.getfont_REGULAR(16)
        totalAmountKeyLabel.font = CustomFont.getfont_REGULAR(16)

        monthlyEMIValueLabel.font = CustomFont.getfont_MEDIUM(18)
        principalAmountValueLabel.font = CustomFont.getfont_MEDIUM(18)
        totalInterestValueLabel.font = CustomFont.getfont_MEDIUM(18)
        periodicInterestValueLabel.font = CustomFont.getfont_MEDIUM(18)
        totalAmountValueLabel.font = CustomFont.getfont_MEDIUM(18)

        principalAmountValueLabel.textColor = Constants.GREEN_COLOR
        totalInterestValueLabel.textColor = Constants.BLUE_COLOR
        
        let totalAmount = emiAmount * tenure
        let totalInterest = totalAmount - principalAmount

        monthlyEMIValueLabel.text = NSString.formatCurrency(String(emiAmount))
        principalAmountValueLabel.text = NSString.formatCurrency(String(principalAmount))
        totalInterestValueLabel.text = NSString.formatCurrency(String(totalInterest))
        periodicInterestValueLabel.text = String(format: "%.2f", periodicInterest)+"%"
        totalAmountValueLabel.text = NSString.formatCurrency(String(totalAmount))

        if let headerView = AppDelegate.instance()?.headerView {
            let height = headerView.frame.size.height - 20
            let margin: CGFloat = 5

            emailButton = UIButton(frame: CGRect(x: self.view.frame.size.width - (height+margin), y: 20, width: height, height: height))
            emailButton.setImage(UIImage(named: "send_mail_icon"), for: .normal)
            emailButton.addTarget(self, action:#selector(emailButtonAction(_:)), for: .touchUpInside)
        }

        esv = .fromNib()
        esv.setProperties()
        esv.delegate = self
        self.view.addSubview(esv)
        esv.alpha = 0
        
        setChart(values: [principalAmount, totalInterest])
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        calculateEMIChart()
        
        if let headerView = AppDelegate.instance()?.headerView {
            headerView.setTitleWithShowBackButton(title: "Amortization Chart", showBackButton: true)
            headerView.addSubview(emailButton)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        emailButton.removeFromSuperview()
    }
    
    @objc func emailButtonAction(_ sender: UIButton) {
        if esv.alpha == 0 {
            esv.alpha = 1
        }
        else {
            esv.alpha = 0
            self.view.endEditing(true)
        }
    }

    func setChart(values: [Double]) {
        
        let dataEntries: [ChartDataEntry] = values.map { (value) -> ChartDataEntry in
            return PieChartDataEntry(value: value)
        }
        
        let set = PieChartDataSet(entries: dataEntries, label: "")
        set.drawIconsEnabled = false
        set.sliceSpace = 5
        set.colors = [Constants.GREEN_COLOR, Constants.BLUE_COLOR]
        set.selectionShift = 0
        
        let data = PieChartData(dataSet: set)
        data.setDrawValues(false)

        pieChartView.data = data
        pieChartView.holeRadiusPercent = 0.82
        pieChartView.legend.enabled = false
        pieChartView.rotationEnabled = false
        pieChartView.highlightPerTapEnabled = false
        pieChartView.usePercentValuesEnabled = false
        pieChartView.drawEntryLabelsEnabled = false
    }
    
    func calculateEMIChart() {
        let r = periodicInterest / 100
        let rPower = pow(1 + r, tenure)
        let monthlyPayment = principalAmount * r * rPower / (rPower - 1)
        var balance = principalAmount

        chartArray = []
        
        for i in 1...Int(tenure) {
            let interestPayment = balance * r
            let principalPayment = monthlyPayment - interestPayment
            balance -= principalPayment
            
            if i == Int(tenure), balance < 0 { balance = 0 }
            
            chartArray.append(ChartModel(principalAmount: principalPayment, interestAmount: interestPayment, balanceAmount: balance))
        }
    }
}

extension AmortizationChartVC: EmailSendViewDelegate {
    func callEmailService(toEmail: String, ccEmail: String) {
                
        let param : [String:Any] = ["originalPrincipalAmount"  :String(principalAmount),
                                    "tenureInYears"            :String(format: "%.2f", tenureInYears),
                                    "tenureLoanType"           :tenureLoanType ?? "",
                                    "annualInterest"           :ratePerAnnum,
                                    "mailTo"                   :toEmail,
                                    "mailCc"                   :ccEmail]
        
        Webservices.sharedInstance().POST(urlString: ServiceUrl.EMAIL_AMORTIZATION_SCHEDULE_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
                        
            FIApplicationUtils.showAlert(withTitle: "", andMessage: "Email sent successfully")
            self.emailButtonAction(self.emailButton)
            
        }, failure: { (error) in
            if error != nil {
                FIApplicationUtils.showAlert(withTitle: "", andMessage: error)
            }
            
        }, noNetwork: { (error) in })
    }
}

extension AmortizationChartVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return chartArray.count+1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: ChartCell = tableView.dequeueReusableCell(withIdentifier: "ChartCell", for: indexPath as IndexPath) as! ChartCell
        
        if indexPath.row == 0 {
            cell.setData(index: indexPath.row, chartData: nil)
        }
        else {
            cell.setData(index: indexPath.row, chartData: chartArray[indexPath.row-1])
        }
        
        return cell
    }
    
    
}
