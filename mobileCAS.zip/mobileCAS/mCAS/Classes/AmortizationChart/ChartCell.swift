//
//  ChartCell.swift
//  mCAS
//
//  Created by iss on 28/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class ChartCell: UITableViewCell {

    @IBOutlet weak var srNumLabel: UILabel!
    @IBOutlet weak var principalLabel: UILabel!
    @IBOutlet weak var interestLabel: UILabel!
    @IBOutlet weak var outstandingLabel: UILabel!

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func setData(index: Int, chartData: ChartModel?) {
        if index == 0 {
            self.backgroundColor = Constants.LIGHTER_GRAY_COLOR
            
            self.srNumLabel.font = CustomFont.getfont_MEDIUM(16)
            self.principalLabel.font = CustomFont.getfont_MEDIUM(16)
            self.interestLabel.font = CustomFont.getfont_MEDIUM(16)
            self.outstandingLabel.font = CustomFont.getfont_MEDIUM(16)

            self.srNumLabel.text = "Sr. No."
            self.principalLabel.text = "Principal"
            self.interestLabel.text = "Interest"
            self.outstandingLabel.text = "Outstanding"
        }
        else {
            if index % 2 == 0 {
                self.backgroundColor = Constants.EXTREME_LIGHT_GRAY_COLOR
            }
            else {
                self.backgroundColor = .clear
            }
            
            self.srNumLabel.font = CustomFont.getfont_REGULAR(16)
            self.principalLabel.font = CustomFont.getfont_REGULAR(16)
            self.interestLabel.font = CustomFont.getfont_REGULAR(16)
            self.outstandingLabel.font = CustomFont.getfont_REGULAR(16)

            self.srNumLabel.text = "\(index)"
            
            if let cData = chartData {
                self.principalLabel.text = NSString.formatCurrency(String(cData.principalAmount))
                self.interestLabel.text = NSString.formatCurrency(String(cData.interestAmount))
                self.outstandingLabel.text = NSString.formatCurrency(String(cData.balanceAmount))
            }
            
        }
    }
}
