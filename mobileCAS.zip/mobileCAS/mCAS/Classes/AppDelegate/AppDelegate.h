//
//  AppDelegate.h
//  mCAS
//
//  Created by amit.swami on 28/08/14.
//  Copyright (c) 2014 Nucleus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@class BottomTabbarView;
@class HeaderView;
@class DashboardViewController;


@interface AppDelegate : UIResponder <UIApplicationDelegate, CLLocationManagerDelegate>

@property(nonatomic, strong) UIWindow *window;
@property(nonatomic, strong) UINavigationController *applicationNavController;
@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;
@property(nonatomic, assign) BOOL isLoggedin;
@property(nonatomic, strong) UIImageView *imageView;
@property(nonatomic, strong) NSDate *appInBackgroundDateTime;
@property(nonatomic, strong) BottomTabbarView *bottomTabbarView;
@property(nonatomic, strong) HeaderView *headerView;
@property(nonatomic, strong) NSMutableArray *mainMenuArray;

+ (AppDelegate *)instance;
- (void)createBottomTabBar;
- (void)createHeaderView;
- (void)popToSpecificView:(Class)targetClass;
- (void)tabsButtonActionWithTabID:(NSString *)tabID;
- (NSString *)getSavedUserID;
- (UIViewController *)intializeViewController:(NSString *)viewControllerIdentifier;
- (void)presentLoginViewController;

-(NSString *)getDeviceID;
-(NSString *)getLatitude;
-(NSString *)getLongitude;
-(NSString *)getAltitude;
-(NSString *)getNetworkProvider;
-(NSString *)getAccuracy;
-(NSString *)getSpeed;
-(NSString *)getTimeStamp;

#pragma mark - CLLocationManager
@property(nonatomic, strong) NSString *formattedAddressString;
@property(nonatomic, strong) NSDictionary *gpsDictionary;
@property(nonatomic, strong) CLLocationManager *locationManager;

@end
