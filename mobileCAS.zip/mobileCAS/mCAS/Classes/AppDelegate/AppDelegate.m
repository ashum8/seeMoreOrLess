//
//  AppDelegate.m
//  mCAS
//
//  Created by amit.swami on 28/08/14.
//  Copyright (c) 2014 Nucleus. All rights reserved.
//

#import "AppDelegate.h"
#import "KeychainItemWrapper.h"
#import "TIMERUIApplication.h"
#import "IQKeyboardManager.h"
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <CoreTelephony/CTCarrier.h>


#define DB_NAME @"mCAS-Sourcing.db"


@interface AppDelegate ()

@property(nonatomic, assign) BOOL networkPreviousStateActive;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
    [self intializeKeyboardManager];
    
    //Mandatory to set secret for encrption on NSUserDefaults
    [[NSUserDefaults standardUserDefaults] setSecret:@"sk.encryptedUserDefaults"];

    self.formattedAddressString = @"";
    
    //Get User Location
    self.locationManager = [[CLLocationManager alloc] init];
    self.locationManager.delegate = self;
    self.locationManager.distanceFilter = 200.0; // Will notify the LocationManager every 200 meters
    self.locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    [self.locationManager requestWhenInUseAuthorization];
    [self.locationManager startUpdatingLocation];

    //invalidate session in offline mode functionality
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidTimeout:) name:kApplicationDidTimeoutNotification object:nil];

    [[UIApplication sharedApplication] ignoreSnapshotOnNextApplicationLaunch];
   
    if (![ReachabilityManager isReachable]) {
        self.networkPreviousStateActive = YES;
    }
    else {
        self.networkPreviousStateActive = NO;
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(networkStatusChanged) name:kReachabilityChangedNotification object:nil];
        
    self.applicationNavController = (UINavigationController*)self.window.rootViewController;
   
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    self.appInBackgroundDateTime = [NSDate date];

    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    //
    
    /*
     Remove sensitive information from views before moving to the background.
     When an app transitions to the background, the system takes a snapshot of the app’s main window
     */
    self.appInBackgroundDateTime = [NSDate date];

    self.imageView = [[UIImageView alloc] initWithFrame:self.window.bounds];
    [self.imageView setImage:[UIImage imageNamed:@"P-LaunchImage"]];   // assuming P-LaunchImage is your splash image's name
    [UIApplication.sharedApplication.keyWindow.subviews.lastObject addSubview:self.imageView];
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    [self.imageView removeFromSuperview];
    [self.locationManager startUpdatingLocation];
    self.locationManager.delegate = self;
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
   
    // If user is not using the app for more than xx minutes invalidate session
    NSTimeInterval interval = [[NSDate date] timeIntervalSinceDate:self.appInBackgroundDateTime]/60;
    NSUInteger timeoutvalue = kApplicationTimeoutInMinutes;

    if (interval >= timeoutvalue) {
        [FIApplicationUtils showAlertForInvalidSession];
    }
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    self.locationManager = nil;
}

+ (AppDelegate *)instance {
   return (AppDelegate*)[UIApplication sharedApplication].delegate;
}

- (NSString *)getSavedUserID {
    return [FIApplicationUtils getDataFromSecretUserDefaultWithKey:Constants.UD_USER_ID];
}

- (void)presentLoginViewController {
    [self.applicationNavController popToRootViewControllerAnimated:FALSE];

    [self.bottomTabbarView removeFromSuperview];
    [self.headerView removeFromSuperview];
    self.bottomTabbarView = nil;
    self.headerView = nil;
}

#pragma mark - CLLocationManager Delegate

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    if ([error code] == kCLErrorDenied) {
        [manager stopUpdatingLocation];
    }
}

-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations {
    
    if (locations.count) {
        CLLocation *newLocation = locations[0];
        
        NSString *altitude = @"";
        if(newLocation.verticalAccuracy > 0) {
            altitude = [NSString stringWithFormat:@"%f",newLocation.altitude];
        }
        
        NSString *speed = @"";
        if (newLocation.speed > 0) {
            speed = [NSString stringWithFormat:@"%f",newLocation.speed];
        }
        
        NSString *accuracy = @"";
        if (newLocation.altitude > 0) {
            accuracy = [NSString stringWithFormat:@"%f",newLocation.horizontalAccuracy];
        }
        
        NSString *timeStamp = @"";
        if (newLocation.timestamp > 0) {
            timeStamp = [NSString stringWithFormat:@"%lld",[@(floor([newLocation.timestamp timeIntervalSince1970])) longLongValue]];
        }
        
        self.gpsDictionary = [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:[NSString stringWithFormat:@"%f",newLocation.coordinate.latitude],[NSString stringWithFormat:@"%f",newLocation.coordinate.longitude],altitude, speed, accuracy, timeStamp, nil] forKeys:[NSArray arrayWithObjects:@"Latitude",@"Longitude",@"Altitude",@"Speed",@"Accuracy",@"TimeStamp", nil]];
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0), ^{
            self.formattedAddressString = [self getFormattedAddress:newLocation.coordinate.latitude logitude:newLocation.coordinate.longitude];
            
            if (Constants.ENABLE_LOCATION_UPDATE_IN_BG) {
                //[self updateLocationOnServer];
            }
        });
    }
}

-(NSString *)getDeviceID {
    return [NSString validateStringData:[[[UIDevice currentDevice] identifierForVendor] UUIDString]];
}

-(NSString *)getLatitude {
    return [NSString validateStringData:self.gpsDictionary[@"Latitude"]];
}

-(NSString *)getLongitude {
    return [NSString validateStringData:self.gpsDictionary[@"Longitude"]];
}

-(NSString *)getAltitude {
    return [NSString validateStringData:self.gpsDictionary[@"Altitude"]];
}

-(NSString *)getNetworkProvider {
    CTTelephonyNetworkInfo *netinfo = [[CTTelephonyNetworkInfo alloc] init];
    CTCarrier *carrier = [netinfo subscriberCellularProvider];
    return [NSString validateStringData:[carrier carrierName]];
}

-(NSString *)getAccuracy {
    return [NSString validateStringData:self.gpsDictionary[@"Accuracy"]];
}

-(NSString *)getSpeed {
    return [NSString validateStringData:self.gpsDictionary[@"Speed"]];
}

-(NSString *)getTimeStamp {
    return [NSString validateStringData:self.gpsDictionary[@"TimeStamp"]];
}

#pragma mark - Geocode Address

- (NSString *)getFormattedAddress:(double) lattitude logitude:(double) longitude
{
    NSString *urlString = [NSString stringWithFormat:@"https://maps.google.com/maps/api/geocode/json?latlng=%f,%f&sensor=true&key=AIzaSyCpgJS1jT5VXmONImP-Rq56nQYWirX-3jE",lattitude,longitude];
    
    NSURL *urlFromString = [NSURL URLWithString:urlString];
    NSString *reverseGeoString = [NSString stringWithContentsOfURL:urlFromString encoding:NSUTF8StringEncoding error:nil];
    
    if (!reverseGeoString) {
        return @"";
    }
    NSDictionary *locationResult = [NSJSONSerialization JSONObjectWithData: [reverseGeoString dataUsingEncoding:NSUTF8StringEncoding]
                                                                   options: NSJSONReadingMutableContainers
                                                                     error: nil];
    
    NSString *status = [NSString validateStringData:locationResult[@"status"]];
    
    if([status isEqualToString:@"OK"])
    {
        NSDictionary *tempDic = [NSDictionary new];
        NSArray *results = [locationResult objectForKey:@"results"];

        for (int i = 0; i < [results count]; i++) {
            NSDictionary *tDic = [results objectAtIndex:i];
            if ([tDic[@"types"] containsObject:@"street_address"]) {
                tempDic = tDic;
                break;
            }
        }
        if([results count] > 0 && !tempDic)
        {
            tempDic=[results objectAtIndex:0];
        }
        return tempDic[@"formatted_address"];
    }
    else {
        //"error_message" = "You have exceeded your daily request quota for this API.";
        //results =     (
        //);
        //status = "OVER_QUERY_LIMIT";
        return @"";
    }
}

#pragma mark - SESSION INVALIDATE IN OFFLINE MODE

-(void)applicationDidTimeout:(NSNotification *) notif
{
    //This is where storyboarding vs xib files comes in. Whichever view controller you want to revert back to, on your storyboard, make sure it is given the identifier that matches the following code. In my case, "loginViewController". My storyboard file is called STORYBOARD_MAIN, so make sure your file name matches the storyboardWithName property.
    
    [FIApplicationUtils showAlertForInvalidSession];
}

#pragma mark - Core Data stack

@synthesize managedObjectContext = _managedObjectContext;
@synthesize managedObjectModel = _managedObjectModel;
@synthesize persistentStoreCoordinator = _persistentStoreCoordinator;

- (NSURL *)applicationDocumentsDirectory {
    // The directory the application uses to store the Core Data store file. This code uses a directory named "" in the application's documents directory.
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}

- (NSManagedObjectModel *)managedObjectModel {
    // The managed object model for the application. It is a fatal error for the application not to be able to find and load its model.
    if (_managedObjectModel != nil) {
        return _managedObjectModel;
    }
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"mCAS" withExtension:@"momd"];
    _managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    return _managedObjectModel;
}

- (NSPersistentStoreCoordinator *)persistentStoreCoordinator {
    // The persistent store coordinator for the application. This implementation creates and return a coordinator, having added the store for the application to it.
    if (_persistentStoreCoordinator != nil) {
        return _persistentStoreCoordinator;
    }
    
    // Create the coordinator and store
    
    _persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self managedObjectModel]];
    
    
    NSURL *storeURL = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"mCAS.db"];
    NSError *error = nil;
    
    // important part starts here
    NSDictionary *options = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSNumber numberWithBool:YES], NSMigratePersistentStoresAutomaticallyOption,
                             [NSNumber numberWithBool:YES], NSInferMappingModelAutomaticallyOption,
                             nil];
    
    NSString *failureReason = NSLocalizedString(@"There was an error creating or loading the application's saved data.", nil);
    if (![_persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:options error:&error]) {
        // Report any error we got.
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        dict[NSLocalizedDescriptionKey] = NSLocalizedString(@"Failed to initialize the application's saved data", nil);
        dict[NSLocalizedFailureReasonErrorKey] = failureReason;
        dict[NSUnderlyingErrorKey] = error;
        error = [NSError errorWithDomain:@"YOUR_ERROR_DOMAIN" code:9999 userInfo:dict];
        // Replace this with code to handle the error appropriately.
        // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
        //        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
    
    return _persistentStoreCoordinator;
}

- (NSManagedObjectContext *)managedObjectContext {
    // Returns the managed object context for the application (which is already bound to the persistent store coordinator for the application.)
    if (_managedObjectContext) {
        return _managedObjectContext;
    }
    
    NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
    if (!coordinator) {
        return nil;
    }
    _managedObjectContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSMainQueueConcurrencyType];
    [_managedObjectContext setPersistentStoreCoordinator:coordinator];
    return _managedObjectContext;
}

#pragma mark - Network Status Messages

- (void)networkStatusChanged
{
    if ([ReachabilityManager isReachable] && !self.networkPreviousStateActive) {
        
        //SK Change -
        //If session is available do auto sync but in case of logout session becomes invalid so do not auto sync
//        if ([[NSString validateStringData:[self getDataFromSecretUserDefaultWithKey:HTTP_HEADER_SESSION_ID]] length]) {
//            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
//                //SK Change - sync data
//            });
//        }
        
        [MRProgressOverlayView showOverlayAddedTo:self.window title:NSLocalizedString(@"You are online now.", @"Alert for network status.") mode:MRProgressOverlayViewModeCheckmark animated:YES];
        self.networkPreviousStateActive = YES;
    }
    else if(![ReachabilityManager isReachable] && self.networkPreviousStateActive){
        
        [MRProgressOverlayView showOverlayAddedTo:self.window title:NSLocalizedString(@"You are offline now.", @"Alert for network status.") mode:MRProgressOverlayViewModeCross animated:YES];
        self.networkPreviousStateActive = NO;
    }
    
    // Delay execution of my block for 2 seconds.
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        [MRProgressOverlayView dismissOverlayForView:self.window animated:NO];
    });
}

#pragma mark - IQKeyboardManager

- (void)intializeKeyboardManager {
    //Enabling keyboard manager
    [[IQKeyboardManager sharedManager] setEnable:YES];
    
    [[IQKeyboardManager sharedManager] setKeyboardDistanceFromTextField:25];
    //Enabling autoToolbar behaviour. If It is set to NO. You have to manually create UIToolbar for keyboard.
    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:YES];
    
    //Setting toolbar behavious to IQAutoToolbarBySubviews. Set it to IQAutoToolbarByTag to manage previous/next according to UITextField's tag property in increasing order.
    [[IQKeyboardManager sharedManager] setToolbarManageBehaviour:IQAutoToolbarBySubviews];
    
    //Resign textField if touched outside of UITextField/UITextView.
    [[IQKeyboardManager sharedManager] setShouldResignOnTouchOutside:YES];
    
    //Giving permission to modify TextView's frame
    [[IQKeyboardManager sharedManager] setCanAdjustTextView:NO];
}


#pragma mark - createBottomTabBar Methods

- (void)createBottomTabBar
{
    if (!self.bottomTabbarView) {
        self.bottomTabbarView = [[BottomTabbarView alloc] initWithFrame:CGRectMake(0, self.window.frame.size.height-55, self.window.frame.size.width, 55)];
        [self.applicationNavController.view addSubview:self.bottomTabbarView];
    }
}

- (void)popToSpecificView:(Class)targetClass
{
    NSArray *viewContrlls = [self.applicationNavController viewControllers];
    
    for (int i=0;i<[viewContrlls count];i++){
        UIViewController *obj=[viewContrlls objectAtIndex:i];
        
        if([obj isKindOfClass:targetClass]){
            [obj.navigationController popToViewController:obj animated:NO];
            viewContrlls = nil;
            return;
        }
    }
}

- (UIViewController *)intializeViewController:(NSString *)viewControllerIdentifier {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:Constants.STORYBOARD_MAIN bundle:nil];
    return [storyboard instantiateViewControllerWithIdentifier:viewControllerIdentifier];
}

#pragma mark - createHeaderControlView

- (void)createHeaderView{
    if (!self.headerView) {
        self.headerView = [[HeaderView alloc] initWithFrame:CGRectMake(0, 0, self.window.frame.size.width, 65)];
        [self.applicationNavController.view addSubview:self.headerView];
    }
}

- (void)tabsButtonActionWithTabID:(NSString *)tabID {
    
//    [self popToSpecificView:[DashboardViewController class]];

    if([tabID isEqualToString:Constants.FN_MOB_HOME_DASHBOARD]) {
        [self.applicationNavController pushViewController:[self intializeViewController:@"DashboardViewController"] animated:NO];
    }
    else if([tabID isEqualToString:Constants.FN_MOB_MORE]) {
        [self.applicationNavController pushViewController:[self intializeViewController:@"MoreViewController"] animated:NO];
    }
    else if ([tabID isEqualToString:Constants.FN_MOB_CALC]) {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:Constants.STORYBOARD_EMI_CALCULATOR       bundle:nil];
        [self.applicationNavController pushViewController:[storyboard instantiateInitialViewController] animated:NO];
    }
    else if ([tabID isEqualToString:Constants.FN_MOB_RATE_INITIATION]) {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:Constants.STORYBOARD_RATE_INITIATE       bundle:nil];
        [self.applicationNavController pushViewController:[storyboard instantiateInitialViewController] animated:NO];
    }
    else if ([tabID isEqualToString:Constants.FN_MOB_RATE_APPROVAL]) {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:Constants.STORYBOARD_RATE_APPROVE       bundle:nil];
        [self.applicationNavController pushViewController:[storyboard instantiateInitialViewController] animated:NO];
    }
    else if ([tabID isEqualToString:Constants.FN_MOB_CHANGE_PASSWORD]) {
        [self.applicationNavController pushViewController:[self intializeViewController:@"ChangePasswordViewController"] animated:NO];
    }
}


@end
