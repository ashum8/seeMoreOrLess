#import "CDUserRoles.h"

@interface CDUserRoles ()

// Private interface goes here.

@end

@implementation CDUserRoles

// Custom logic goes here.

@end
