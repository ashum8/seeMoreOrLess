#import "_CDUserDetails.h"

@interface CDUserDetails : _CDUserDetails
// Custom logic goes here.
@end
