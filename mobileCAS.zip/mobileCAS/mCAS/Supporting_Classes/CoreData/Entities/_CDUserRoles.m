// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to CDUserRoles.m instead.

#import "_CDUserRoles.h"

@implementation CDUserRolesID
@end

@implementation _CDUserRoles

+ (instancetype)insertInManagedObjectContext:(NSManagedObjectContext *)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription insertNewObjectForEntityForName:@"CDUserRoles" inManagedObjectContext:moc_];
}

+ (NSString*)entityName {
	return @"CDUserRoles";
}

+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription entityForName:@"CDUserRoles" inManagedObjectContext:moc_];
}

- (CDUserRolesID*)objectID {
	return (CDUserRolesID*)[super objectID];
}

+ (NSSet*)keyPathsForValuesAffectingValueForKey:(NSString*)key {
	NSSet *keyPaths = [super keyPathsForValuesAffectingValueForKey:key];

	return keyPaths;
}

@dynamic roleID;

@dynamic rolesForUser;

@end

@implementation CDUserRolesAttributes 
+ (NSString *)roleID {
	return @"roleID";
}
@end

@implementation CDUserRolesRelationships 
+ (NSString *)rolesForUser {
	return @"rolesForUser";
}
@end

