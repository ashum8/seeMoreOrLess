// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to CDUserRoles.h instead.

#if __has_feature(modules)
    @import Foundation;
    @import CoreData;
#else
    #import <Foundation/Foundation.h>
    #import <CoreData/CoreData.h>
#endif

NS_ASSUME_NONNULL_BEGIN

@class CDUserDetails;

@interface CDUserRolesID : NSManagedObjectID {}
@end

@interface _CDUserRoles : NSManagedObject
+ (instancetype)insertInManagedObjectContext:(NSManagedObjectContext *)moc_;
+ (NSString*)entityName;
+ (nullable NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_;
@property (nonatomic, readonly, strong) CDUserRolesID *objectID;

@property (nonatomic, strong, nullable) NSString* roleID;

@property (nonatomic, strong, nullable) CDUserDetails *rolesForUser;

@end

@interface _CDUserRoles (CoreDataGeneratedPrimitiveAccessors)

- (nullable NSString*)primitiveRoleID;
- (void)setPrimitiveRoleID:(nullable NSString*)value;

- (nullable CDUserDetails*)primitiveRolesForUser;
- (void)setPrimitiveRolesForUser:(nullable CDUserDetails*)value;

@end

@interface CDUserRolesAttributes: NSObject 
+ (NSString *)roleID;
@end

@interface CDUserRolesRelationships: NSObject
+ (NSString *)rolesForUser;
@end

NS_ASSUME_NONNULL_END
