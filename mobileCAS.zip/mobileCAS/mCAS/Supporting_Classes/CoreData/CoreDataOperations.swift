//
//  CoreDataOperations.swift
//  mCAS
//
//  Created by Mac on 26/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

// //https://medium.com/@ankurvekariya/core-data-crud-with-swift-4-2-for-beginners-40efe4e7d1cc


import UIKit

class CoreDataOperations {
    
    private static var instance: CoreDataOperations?
    
    static func sharedInstance() -> CoreDataOperations{
        if instance == nil {
            instance = CoreDataOperations()
        }
        return instance!
    }
    
    func updateRecord(predicate: NSPredicate, entityName: String, success:@escaping (_ responseObject: NSManagedObject) -> Void) {
        
        if let context = AppDelegate.instance()?.managedObjectContext {
            
            let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: entityName)
            fetchRequest.predicate = predicate
            
            do {
                let records = try context.fetch(fetchRequest)
                let userData: NSManagedObject
                
                if records.count > 0 {
                    userData = records[0] as! NSManagedObject
                }
                else {
                    let entity = NSEntityDescription.entity(forEntityName: entityName, in: context)
                    userData = NSManagedObject(entity: entity!, insertInto: context)
                }
                
                success(userData)
            }
            catch { }
        }
        else { }
    }
    
    func fetchSingleRecord(predicate: NSPredicate, entityName: String, success:@escaping (_ responseObject: NSManagedObject?) -> Void) {
        
        if let context = AppDelegate.instance()?.managedObjectContext {
            
            let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: entityName)
            fetchRequest.predicate = predicate
            
            do {
                let records = try context.fetch(fetchRequest)
                let userData: NSManagedObject
                
                if records.count > 0 {
                    userData = records[0] as! NSManagedObject
                    success(userData)
                }
                else { success(nil) }
            }
            catch { success(nil) }
        }
        else { success(nil) }
    }
    
    
}
