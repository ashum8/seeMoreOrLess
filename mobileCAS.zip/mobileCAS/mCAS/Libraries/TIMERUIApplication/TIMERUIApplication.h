//
//  TIMERUIApplication.h
//  mCAS
//
//  Created by Mac on 13/05/15.
//  Copyright (c) 2015 Nucleus. All rights reserved.
// http://stackoverflow.com/questions/8085188/ios-perform-action-after-period-of-inactivity-no-user-interaction


#import <UIKit/UIKit.h>

//the length of time before your application "times out". This number actually represents seconds, so we'll have to multiple it by 60 in the .m file
#define kApplicationTimeoutInMinutes 15

//the notification your AppDelegate needs to watch for in order to know that it has indeed "timed out"
#define kApplicationDidTimeoutNotification @"AppTimeOut"

@interface TIMERUIApplication : UIApplication
{
    NSTimer     *myidleTimer;
}

-(void)resetIdleTimer;

@end
