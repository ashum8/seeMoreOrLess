//
//  GenericTableViewCell.h
//  mCAS
//
//  Created by amit.swami on 23/10/14.
//  Copyright (c) 2014 Nucleus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GenericTableViewCell : UITableViewCell
- (UIViewController *)getViewController;
@end
