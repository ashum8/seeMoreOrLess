//
//  CameraOverlayView.m
//  mCAS
//
//  Created by Mac on 23/10/15.
//  Copyright © 2015 Nucleus. All rights reserved.
//

#import "CameraOverlayView.h"

@implementation CameraOverlayView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self = [[[NSBundle mainBundle] loadNibNamed:@"CameraOverlayView" owner:self options:nil] firstObject];
        self.frame = frame;
        [FIApplicationUtils setButtonProperties:self.finishButton];
    }
    return self;
}

- (void)setTakePictureButtonEnabled:(BOOL)isEnabled {
    if (isEnabled) {
        [self.takePictureButton setAlpha:1.0];
    }
    else {
        [self.takePictureButton setAlpha:0.4];
    }
    [self.takePictureButton setEnabled:isEnabled];
}

- (void)setFinishButtonEnabled:(BOOL)isEnabled {
    if (isEnabled) {
        [self.finishButton setAlpha:1.0];
    }
    else {
        [self.finishButton setAlpha:0.4];
    }
    [self.finishButton setEnabled:isEnabled];
}

- (IBAction)finishButtonAction:(id)sender {
    [self.delegate finishButtonAction];
}

- (IBAction)takePictureButtonAction:(id)sender {
    
    UIButton *senderButton = (UIButton *)sender;
    
    [UIView animateWithDuration:0.2 delay:0.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        self.backgroundColor = [UIColor whiteColor];
        self.alpha = 0.2;
        senderButton.transform = CGAffineTransformMakeScale(1.5,1.5);
    } completion:^(BOOL finished) {
        self.backgroundColor = [UIColor clearColor];
        self.alpha = 1.0;
        [UIView animateWithDuration:0.1 delay:0.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
            senderButton.transform = CGAffineTransformMakeScale(1,1);
        } completion:nil];
    }];
    
    [self.delegate takePictureButtonAction];
}

- (IBAction)closeCameraButtonAction:(id)sender {
    [self.delegate closeButtonAction];
}

@end
