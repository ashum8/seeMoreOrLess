//
//  PhotoManager.m
//  mServe
//
//  Created by Mac on 03/07/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

#import "PhotoManager.h"
#import <Photos/Photos.h>


@implementation PhotoManager


- (void)showImageUploadDialogWithViewController:(UIViewController *)vc {
    self.baseVC  = vc;

    if (Constants.SHOW_GALLERY_WITH_CAMERA) {
        [self.baseVC.view endEditing:YES];
        
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"", nil)
                                                                       message:NSLocalizedString(@"Capture Photo",@"")
                                                                preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* okAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Gallery",@"") style:UIAlertActionStyleDefault
                                                         handler:^(UIAlertAction *action) {
                                                             [self checkPhotoLibraryPermission];
                                                         }];
        
        UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Camera",@"") style:UIAlertActionStyleDefault
                                                             handler:^(UIAlertAction *action) {
                                                                 [self imageUsingCameraWithViewController:self.baseVC];
                                                             }];
        
        UIAlertAction* dismissAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel",@"") style:UIAlertActionStyleDefault
                                                              handler:^(UIAlertAction * _Nonnull action) {}];
        
        [alert addAction:okAction];
        [alert addAction:cancelAction];
        [alert addAction:dismissAction];
        [vc presentViewController:alert animated:YES completion:nil];
    }
    else {
        [self imageUsingCameraWithViewController:vc];
    }
}

#pragma mark - Taking Image Using Photo Library

- (void)imageUsingPhotoLibraryWithViewController:(UIViewController *)vc {
    self.baseVC  = vc;
    
    ELCImagePickerController *elcPicker = [[ELCImagePickerController alloc] initImagePicker];
    elcPicker.maximumImagesCount = (self.isMultiUploading ? 5 : 1); //Set the maximum number of images to select
    elcPicker.returnsOriginalImage = YES; //Only return the fullScreenImage, not the fullResolutionImage
    elcPicker.returnsImage = YES; //Return UIimage if YES. If NO, only return asset location information
    elcPicker.onOrder = YES; //For multiple image selection, display and return order of selected images
    elcPicker.mediaTypes = @[(NSString *)kUTTypeImage]; //Supports image
    elcPicker.imagePickerDelegate = self;
    [self.baseVC presentViewController:elcPicker animated:YES completion:nil];
}


#pragma mark - ELCImagePickerControllerDelegate Methods

- (void)elcImagePickerController:(ELCImagePickerController *)picker didFinishPickingMediaWithInfo:(NSArray *)info
{
    if (self.isMultiUploading) {
        [self.delegate didFinishPickingMediaArray:info];
    }
    else {
        for (NSDictionary *dict in info)
        {
            if ([dict objectForKey:UIImagePickerControllerMediaType] == ALAssetTypePhoto && [dict objectForKey:UIImagePickerControllerOriginalImage])
            {
                [self.delegate didFinishPickingImage:[dict objectForKey:UIImagePickerControllerOriginalImage]];
                break;
            }
        }
    }
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)elcImagePickerControllerDidCancel:(ELCImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Taking Image Using Camera

- (void)imageUsingCameraWithViewController:(UIViewController *)vc {
    self.baseVC  = vc;

    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        [FIApplicationUtils showAlertWithTitle:@"" andMessage:NSLocalizedString(@"Sorry camera not available on device", nil)];
    }
    else {
        [self checkCameraPermission];
    }
}

- (void)checkCameraPermission {
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if(authStatus == AVAuthorizationStatusAuthorized) {
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            //load your data here.
            dispatch_async(dispatch_get_main_queue(), ^{
                [self openCameraAnimated:YES];
            });
        });
    }
    else {
        [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
            if(granted){
                dispatch_async(dispatch_get_global_queue(0, 0), ^{
                    //load your data here.
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self openCameraAnimated:YES];
                    });
                });
            }
            else {
                dispatch_async(dispatch_get_global_queue(0, 0), ^{
                    //load your data here.
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self showCameraPermissionAlert];
                    });
                });
            }
        }];
    }
}

- (void)checkPhotoLibraryPermission {
    PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
    
    switch (status)
    {
        case PHAuthorizationStatusAuthorized: {
            [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                [self imageUsingPhotoLibraryWithViewController:self.baseVC];
            }];
        }
            break;
        case PHAuthorizationStatusNotDetermined:
        {
            [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus authorizationStatus)
             {
                 if (authorizationStatus == PHAuthorizationStatusAuthorized)
                 {
                     [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                         [self imageUsingPhotoLibraryWithViewController:self.baseVC];
                     }];
                 }
                 else
                 {
                     dispatch_async(dispatch_get_global_queue(0, 0), ^{
                         //load your data here.
                         dispatch_async(dispatch_get_main_queue(), ^{
                             [self showPhotosPermissionAlert];
                         });
                     });
                 }
             }];
            break;
        }
        default:
        {
            dispatch_async(dispatch_get_global_queue(0, 0), ^{
                //load your data here.
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self showPhotosPermissionAlert];
                });
            });
        }
            break;
    }
}

- (void)openCameraAnimated:(BOOL)animated {
    
    self.totalCount = 0;

    self.imagePickerController = [[UIImagePickerController alloc] init];
    self.imagePickerController.delegate = self;
    self.imagePickerController.allowsEditing = YES;
    self.imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
    self.imagePickerController.showsCameraControls = YES;

    if (self.isMultiUploading) {
        self.overlayView = [[CameraOverlayView alloc] initWithFrame:self.baseVC.view.frame];
        self.overlayView.delegate = self;
        self.imagePickerController.cameraOverlayView = self.overlayView;
        self.imagePickerController.showsCameraControls = NO;

        CGSize screenSize = [[UIScreen mainScreen] bounds].size;
        float cameraAspectRatio = 4.0 / 3.0;
        float imageWidth = floorf(screenSize.width * cameraAspectRatio);
        float scale = ceilf((screenSize.height / imageWidth) * 10.0) / 10.0;
        self.imagePickerController.cameraViewTransform = CGAffineTransformMakeScale(scale, scale);
    }
    
    [self.baseVC presentViewController:self.imagePickerController animated:animated completion:nil];
}

#pragma mark - CameraOverlayView Delegate

- (void)finishButtonAction {
    [self imagePickerControllerDidCancel:self.imagePickerController];
}

- (void)takePictureButtonAction {
    [self.overlayView setTakePictureButtonEnabled:NO];
    [self.imagePickerController takePicture];
}

- (void)closeButtonAction {
    self.totalCount = 0;
    [self imagePickerControllerDidCancel:self.imagePickerController];
}

#pragma mark - ImagePickerController Delegate Methods

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<UIImagePickerControllerInfoKey, id> *)info {
    UIImage *image;
    
    if (picker.isEditing)   { image = [info objectForKey:UIImagePickerControllerEditedImage]; }
    else                    { image = [info objectForKey:UIImagePickerControllerOriginalImage]; }

    if (self.isMultiUploading) {
        [UIView animateWithDuration:0.05 delay:0.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
            self.overlayView.capturedImageView.alpha = 0.2;
        } completion:^(BOOL finished) {
            self.overlayView.totalDocumentsCount.text = [NSString stringWithFormat:@"%lu",(unsigned long)++self.totalCount];
            self.overlayView.capturedImageView.alpha = 1.0;
            [self.overlayView.capturedImageView setImage:image];
        }];
        
        dispatch_time_t delayTime = dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC);
        dispatch_after(delayTime, dispatch_get_main_queue(), ^{
            [self.overlayView setTakePictureButtonEnabled:YES];
        });
        
        [self.delegate didFinishPickingImage:image];
    }
    else {
        [picker dismissViewControllerAnimated:YES completion:^{
            [self.delegate didFinishPickingImage:image];
        }];
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)showCameraPermissionAlert {
    [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"Permission Error", nil) andMessage:NSLocalizedString(@"Please allow application to access camera in privacy settings.", nil)];
}

- (void)showPhotosPermissionAlert {
    [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"Permission Error", nil) andMessage:NSLocalizedString(@"Please allow application to access photos in privacy settings.", nil)];
}


@end
