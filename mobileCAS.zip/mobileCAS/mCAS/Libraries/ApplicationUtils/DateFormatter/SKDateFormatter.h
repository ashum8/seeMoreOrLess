//
//  SKDateFormatter.h
//  mCAS
//
//  Created by Mac on 27/06/19.
//  Copyright (c) 2019 Mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SKDateFormatter: NSObject

+ (NSString *)getRespectiveDateFromStringDate:(NSString*)dateString withOutputFormat:(NSString *)outputFormat;
+ (NSString *)getRespectiveStringDate:(NSDate *)inputdate withOutputFormat:(NSString *)outputFormat;
+ (NSDate *)getRespectiveDateFromStringDate:(NSString *)dateString;
+ (int)dateDifferenceFromDate:(NSDate *)fromDate andToDate:(NSDate *)toDate;
+ (void)setDOBMinMaxValue:(UIDatePicker *)datePicker;

@end
