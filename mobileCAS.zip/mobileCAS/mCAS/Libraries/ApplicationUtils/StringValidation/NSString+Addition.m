//
//  NSString+Addition.m
//  mCAS
//
//  Created by Mac on 27/06/19.
//  Copyright (c) 2019 Mac. All rights reserved.
//

#import "NSString+Addition.h"


@implementation NSString (Addition)

- (BOOL)isNilOrEmpty {
	return !self || [self isEmpty] || ([[self class] isSubclassOfClass:[NSNull class]]);
}

- (BOOL)isEmail {
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:self];
}

- (BOOL)isPhoneNumber {
    NSDataDetector *detector = [NSDataDetector dataDetectorWithTypes:NSTextCheckingTypeLink|NSTextCheckingTypePhoneNumber error:nil];
    return [detector numberOfMatchesInString:self options:0 range:NSMakeRange(0, [self length])];
}

- (BOOL)isDigit {
    NSCharacterSet *alphaNums = [NSCharacterSet decimalDigitCharacterSet];
    NSCharacterSet *inStringSet = [NSCharacterSet characterSetWithCharactersInString:self];
    return [alphaNums isSupersetOfSet:inStringSet];
}

- (BOOL)isNumeric {
    NSString *regex = @"^[0-9]*((\\.|,)[0-9]{0,2})?$";
    NSPredicate *regExPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [regExPredicate evaluateWithObject:self];
}

- (BOOL)isAlphanumeric {
    NSString *regex = @"^[a-zA-Z0-9]*$";
    NSPredicate *regExPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [regExPredicate evaluateWithObject:self];
}

- (BOOL)validatePAN {
    return [NSString validateInputWithString:self andRegex:@"^[A-Za-z]{5}[0-9]{4}[A-Za-z]$"];
}

- (BOOL)validateTAN {
    return [NSString validateInputWithString:self andRegex:@"^[A-Z]{4}[0-9]{5}[A-Z]$"];
}

- (BOOL)isCapsAlphabetic {
    NSString *regex = @"^[A-Z ]*$";
    NSPredicate *regExPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [regExPredicate evaluateWithObject:self];
}

- (BOOL)isAlphabetic {
    NSString *regex = @"^[a-zA-Z]*$";
    NSPredicate *regExPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [regExPredicate evaluateWithObject:self];
}

- (BOOL)isAlphabeticAndSpace {
    NSString *regex = @"^[a-zA-Z ]*$";
    NSPredicate *regExPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [regExPredicate evaluateWithObject:self];
}

//Note - If you want to allow - put it in last as it represents range while used in middle
- (BOOL)isCharSpecial {
    NSString *regex = @"^[a-zA-Z ,/()@*^%$#.!_=+{}\[]:;'?&amp;-]*$";
    NSPredicate *regExPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [regExPredicate evaluateWithObject:self];
}

- (BOOL)isAlphanumericAndSpace {
    NSString *regex = @"^[a-zA-Z0-9 ]*$";
    NSPredicate *regExPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [regExPredicate evaluateWithObject:self];
}

- (BOOL)isAlphanumericSpecial {
    NSString *regex = @"^[\\ _.a-zA-Z0-9-]*$";
    NSPredicate *regExPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [regExPredicate evaluateWithObject:self];
}

- (BOOL)hasBothCases {
    NSString *regex = @"^.*(?=.*?[a-z])(?=.*?[A-Z]).+$";
    NSPredicate *regExPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [regExPredicate evaluateWithObject:self];
}

- (BOOL)isUrl {
    NSString *regex = @"https?:\\/\\/[\\S]+";
    NSPredicate *regExPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [regExPredicate evaluateWithObject:self];
}

- (BOOL)isMinLength:(NSUInteger)length {
    return (self.length >= length);
}

- (BOOL)isMaxLength:(NSUInteger)length {
    return (self.length <= length);
}

- (BOOL)isMinLength:(NSUInteger)min andMaxLength:(NSUInteger)max {
    return ([self isMinLength:min] && [self isMaxLength:max]);
}

- (BOOL)isEmpty {
    return (!self.length);
}

+ (NSString *)formatString:(double)value {
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    [formatter setNumberStyle:NSNumberFormatterCurrencyStyle];
    NSString *groupingSeparator = [[NSLocale currentLocale] objectForKey:NSLocaleGroupingSeparator];
    [formatter setGroupingSeparator:groupingSeparator];
    [formatter setGroupingSize:3];
    [formatter setAlwaysShowsDecimalSeparator:NO];
    [formatter setUsesGroupingSeparator:YES];
    return [formatter stringFromNumber:[NSNumber numberWithDouble:value]];
}

+ (NSString *)formatCurrency:(NSString *)amount
{
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setNumberStyle: NSNumberFormatterCurrencyStyle];
    [numberFormatter setCurrencySymbol:@"₹"];
    return [numberFormatter stringFromNumber:[NSNumber numberWithDouble:[amount doubleValue]]];
}

+ (BOOL)validateInputWithString:(NSString *)aString andRegex:(NSString *)regexString;
{
    NSString * const regularExpression = regexString;
    NSError *error = NULL;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:regularExpression
                                                                           options:NSRegularExpressionCaseInsensitive
                                                                             error:&error];
    if (error) {
        NSLog(@"error %@", error);
    }
    
    NSUInteger numberOfMatches = [regex numberOfMatchesInString:aString
                                                        options:0
                                                          range:NSMakeRange(0, [aString length])];
    return numberOfMatches > 0;
}

+ (NSString *)getReverseString:(NSString *)str {
    NSMutableString *reversedString = [NSMutableString string];
    NSInteger charIndex = [str length];
    while (charIndex > 0) {
        charIndex--;
        NSRange subStrRange = NSMakeRange(charIndex, 1);
        [reversedString appendString:[str substringWithRange:subStrRange]];
    }
    return reversedString;
}

+ (NSString *)validateStringData:(id)data
{
    if ([data isKindOfClass:[NSNull class]] || data == nil || ([data isKindOfClass:[NSString class]] && ([data isEqualToString:@"<null>"] || [data isEqualToString:@"null"]))) {
        return @"";
    }
    else if ([data isKindOfClass:[NSNumber class]]) {
        return [data stringValue];
    }
    return data;
}

- (BOOL)validateAmountString
{
    return [NSString validateInputWithString:self andRegex:@"^[0-9]*((\\.|,)[0-9]{0,2})?$"];
}

@end
