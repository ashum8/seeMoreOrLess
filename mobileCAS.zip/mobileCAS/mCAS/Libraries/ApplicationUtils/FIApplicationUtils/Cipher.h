//
//  Cipher.h
//  mCAS
//
//  Created by Mac on 20/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Cipher : NSObject

+ (NSString *)getEncryptedPassword:(NSString *)password withUsername: (NSString *)username withToken:(NSString *)token;
+ (NSString *)encryptString:(NSString*)plaintext withKey:(NSString*)key;
+ (NSString *)decryptData:(NSData *)ciphertext withKey:(NSString*)key;
+ (NSString *)sha256:(NSString *)input;
+ (NSString *)md5:(NSString *)input;
+ (NSData *)base64DataFromString:(NSString *)string;
+ (NSData *)decodeBase64String:(NSString *)base64String;
+ (NSString *)base12ConversionWithUsername:(NSString *)username andPassword:(NSString *)password;
+ (NSString *)encrypt:(NSString *)plainText withToken:(NSString *)token;


@end

NS_ASSUME_NONNULL_END
