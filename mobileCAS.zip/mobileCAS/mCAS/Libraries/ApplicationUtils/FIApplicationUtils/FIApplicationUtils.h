//
//  FIApplicationUtils.h
//  mCAS
//
//  Created by amit.swami on 04/09/14.
//  Copyright (c) 2014 Nucleus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FIApplicationUtils : NSObject

+ (BOOL)isApplicationLanguageArabic;
+ (BOOL)textfieldIsEmpty:(UITextField *)textField;
+ (BOOL)checkForReachabilityMode;
+ (float)calculateCellTextHeight:(NSString *)text RectSize:(CGSize)rect font:(UIFont *)font standardHeight:(float)height;


+ (void)saveDataInSecretUserDefault:(id)value withKey:(NSString *)key;
+ (id)getDataFromSecretUserDefaultWithKey:(NSString *)key;

#pragma mark - Alert Section

+ (void)showAlertForInvalidSession;
+ (void)showCameraPermissionAlert;
+ (void)showPhotosPermissionAlert;
+ (void)showAlertWithTitle:(NSString *)title andMessage:(NSString *)message;
+ (void)showAlertWithTitle:(NSString *)title message:(NSString *)msg withOkAction:(void (^)(UIAlertAction *action))handler;
+ (void)showAlertWithMessage:(NSString *)msg withOkTitle:(NSString *)okTitle withCancelTitle:(NSString *)cancelTitle withOkAction:(void (^)(UIAlertAction *action))handler;
+ (void)showAlertWithMessage:(NSString *)msg withOkTitle:(NSString *)okTitle withCancelTitle:(NSString *)cancelTitle withOkAction:(void (^)(UIAlertAction *action))okhandler withCancelAction:(void (^)(UIAlertAction *action))cancelHandler;
+ (void)showAlertWithMessage:(NSString *)msg withOkTitle:(NSString *)okTitle withCancelTitle:(NSString *)cancelTitle withOkAction:(void (^)(UIAlertAction *action))okhandler withCancelAction:(void (^)(UIAlertAction *action))cancelHandler dismissTitle:(NSString *)dismissTitle;
+ (void)showOfflineAlert;

#pragma mark - UI Controls Section

+ (UIImage *)createDropDownImageForSize:(CGSize)newSize;
+ (void)setAlignmentOfButton:(UIButton *)button isTabButton:(BOOL)isTab;
+ (void)setTextFieldViewProperties:(UIView *)view;
+ (void)setButtonColorWithButton:(UIButton *)button enabled:(BOOL)isEnable;
+ (void)setButtonProperties:(UIButton *)button;
+ (void)setLOVButtonProperties:(UIButton *)lovButton withBgImage:(UIImage *)dropDownImage;
+ (void)setFormTextFieldProperties:(UITextField *)textField withRowType:(NSString *)rowType placeHolder:(NSString *)placeholderText rowDisabled:(NSString *)isRowDisabled;
+ (void)setFormMandatoryLabelProperties:(UILabel *)mandatoryLabel rowRequired:(NSString *)isRowRequired;
+ (void)setFormTitleLabelProperties:(UILabel *)titleLabel withTitle:(NSString *)title;
+ (void)setMandatoryRedStarOnLabel:(UILabel *)lbl;

@end
