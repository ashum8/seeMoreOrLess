//
//  FIApplicationUtils.m
//  mCAS
//
//  Created by amit.swami on 04/09/14.
//  Copyright (c) 2014 Nucleus. All rights reserved.
//

#import "FIApplicationUtils.h"


@class AppDelegate;

@implementation FIApplicationUtils


#pragma mark - Utility Methods


+ (float)calculateCellTextHeight:(NSString *)text RectSize:(CGSize)rect font:(UIFont *)font standardHeight:(float)height {
    CGRect frame = [text boundingRectWithSize:rect  options:(NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading) attributes:@{NSFontAttributeName:font} context:nil];
    return MAX(frame.size.height, height);
}

+(BOOL)textfieldIsEmpty:(UITextField *)textField
{
    NSString *text = textField.text;
    text= [text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    if (!text.length) {
        return YES;
    }
    return NO;
}

+ (BOOL)checkForReachabilityMode
{
    if (![ReachabilityManager isReachable]) {
        [self showOfflineAlert];
        return NO;
    }
    return YES;
}

+ (BOOL)isApplicationLanguageArabic {
    return [[[NSLocale preferredLanguages] objectAtIndex:0] hasPrefix:@"ar"];
}

+ (void)saveDataInSecretUserDefault:(id)value withKey:(NSString *)key {
    [[NSUserDefaults standardUserDefaults] setSecretObject:value forKey:key];
}

+ (id)getDataFromSecretUserDefaultWithKey:(NSString *)key {
    return [[NSUserDefaults standardUserDefaults] secretObjectForKey:key];
}

#pragma mark - Alert Section

+ (void)showAlertForInvalidSession
{
    if (![AppDelegate instance].isLoggedin) {
        [self showAlertWithTitle:NSLocalizedString(@"INVALID SESSION", nil) message:NSLocalizedString(@"Your session has been expired. Kindly login again.", nil) withOkAction:^(UIAlertAction *action) {
            [[AppDelegate instance] presentLoginViewController];
        }];
    }
}

+ (void)showAlertWithTitle:(NSString *)title message:(NSString *)msg withOkAction:(void (^)(UIAlertAction *action))handler{
    UIViewController *vc = [[AppDelegate instance].applicationNavController.viewControllers lastObject];
    [vc.view endEditing:YES];

    UIAlertController* alert = [UIAlertController alertControllerWithTitle:title == nil ? NSLocalizedString(@"", nil) : title
                                                                   message:msg
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* okAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleDefault
                                                     handler:handler];
    
    [alert addAction:okAction];
    [vc presentViewController:alert animated:YES completion:nil];
}

+ (void)showAlertWithMessage:(NSString *)msg withOkTitle:(NSString *)okTitle withCancelTitle:(NSString *)cancelTitle withOkAction:(void (^)(UIAlertAction *action))handler{
    UIViewController *vc = [[AppDelegate instance].applicationNavController.viewControllers lastObject];
    [vc.view endEditing:YES];

    UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"", nil)
                                                                   message:msg
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* okAction = [UIAlertAction actionWithTitle:okTitle style:UIAlertActionStyleDefault
                                                     handler:handler];
    
    UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:cancelTitle style:UIAlertActionStyleDefault
                                                         handler:^(UIAlertAction * action) {}];
    
    [alert addAction:okAction];
    [alert addAction:cancelAction];
    [vc presentViewController:alert animated:YES completion:nil];
}

+ (void)showAlertWithMessage:(NSString *)msg withOkTitle:(NSString *)okTitle withCancelTitle:(NSString *)cancelTitle withOkAction:(void (^)(UIAlertAction *action))okhandler withCancelAction:(void (^)(UIAlertAction *action))cancelHandler{
    UIViewController *vc = [[AppDelegate instance].applicationNavController.viewControllers lastObject];
    [vc.view endEditing:YES];

    UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"", nil)
                                                                   message:msg
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* okAction = [UIAlertAction actionWithTitle:okTitle style:UIAlertActionStyleDefault
                                                     handler:okhandler];
    
    UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:cancelTitle style:UIAlertActionStyleDefault
                                                         handler:cancelHandler];
    
    [alert addAction:okAction];
    [alert addAction:cancelAction];
    [vc presentViewController:alert animated:YES completion:nil];
}

+ (void)showAlertWithMessage:(NSString *)msg withOkTitle:(NSString *)okTitle withCancelTitle:(NSString *)cancelTitle withOkAction:(void (^)(UIAlertAction *action))okhandler withCancelAction:(void (^)(UIAlertAction *action))cancelHandler dismissTitle:(NSString *)dismissTitle{
    UIViewController *vc = [[AppDelegate instance].applicationNavController.viewControllers lastObject];
    [vc.view endEditing:YES];

    UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"", nil)
                                                                   message:msg
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* okAction = [UIAlertAction actionWithTitle:okTitle style:UIAlertActionStyleDefault
                                                     handler:okhandler];
    
    UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:cancelTitle style:UIAlertActionStyleDefault
                                                         handler:cancelHandler];
    
    UIAlertAction* dismissAction = [UIAlertAction actionWithTitle:dismissTitle style:UIAlertActionStyleDefault
                                                          handler:^(UIAlertAction * _Nonnull action) {}];

    [alert addAction:okAction];
    [alert addAction:cancelAction];
    [alert addAction:dismissAction];
    [vc presentViewController:alert animated:YES completion:nil];
}

+ (void)showCameraPermissionAlert {
    [self showAlertWithTitle:NSLocalizedString(@"Permission Error", nil) andMessage:NSLocalizedString(@"Please allow mCAS application to access camera in privacy settings.", nil)];
}

+ (void)showPhotosPermissionAlert {
    [self showAlertWithTitle:NSLocalizedString(@"Permission Error", nil) andMessage:NSLocalizedString(@"Please allow mCAS application to access photos in privacy settings.", nil)];
}

+ (void)showAlertWithTitle:(NSString *)title andMessage:(NSString *)message
{
    if (![[NSString validateStringData:message] length]) {
        message = NSLocalizedString(@"There is some problem while serving your request. Please try again later", nil);
    }
    
    [self showAlertWithTitle:nil message:message withOkAction:^(UIAlertAction *action) {}];
}

+ (void)showOfflineAlert {
    [self showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"This functionality is not available in offline mode. Please try when internet is working", nil)];
}

#pragma mark - UI Controls Section

+ (UIImage *)createDropDownImageForSize:(CGSize)newSize {
    UIImage *image  = [UIImage imageNamed:@"P-PreDropDown.png"];
    UIImage *image1 = [UIImage imageNamed:@"P-MidDropDown.png"];
    UIImage *image2 = [UIImage imageNamed:@"P-PostDropDown.png"];
    
    UIGraphicsBeginImageContext(newSize);
    
    float image1Width = newSize.width - (image.size.width/2) - (image2.size.width/2);
    
    // Apply supplied opacity if applicable
    [image drawInRect:CGRectMake(0,0,image.size.width/2,newSize.height) blendMode:kCGBlendModeNormal alpha:1];
    [image1 drawInRect:CGRectMake(image.size.width/2,0,image1Width,newSize.height) blendMode:kCGBlendModeNormal alpha:1];
    [image2 drawInRect:CGRectMake((image1Width+image.size.width/2),0,image2.size.width/2,newSize.height) blendMode:kCGBlendModeNormal alpha:1];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    return newImage;
}

+ (void)setAlignmentOfButton:(UIButton *)button isTabButton:(BOOL)isTab {
    // the space between the image and text
    CGFloat spacing = 2.0;
    if (!isTab) {
      spacing = 10.0;
    }
    
    // lower the text and push it left so it appears centered below the image
    CGSize imageSize = button.imageView.image.size;
    button.titleEdgeInsets = UIEdgeInsetsMake(0.0, - imageSize.width, - (imageSize.height + spacing), 0.0);
    
    // raise the image and push it right so it appears centered above the text
    CGSize titleSize = [button.titleLabel.text sizeWithAttributes:@{NSFontAttributeName: button.titleLabel.font}];
    button.imageEdgeInsets = UIEdgeInsetsMake(- (titleSize.height + spacing), 0.0, 0.0, - titleSize.width);
}

+ (void)setButtonColorWithButton:(UIButton *)button enabled:(BOOL)isEnable {
    if (!isEnable) {
        button.enabled = isEnable;
        button.backgroundColor = [UIColor lightGrayColor];
    }
    else {
        button.enabled = isEnable;
        button.backgroundColor = Constants.BLUE_COLOR;
    }
}

+ (void)setTextFieldViewProperties:(UIView *)view {
    [view.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    view.layer.borderWidth = 1.0;
    view.layer.cornerRadius = 3;
    
    UITextField *tf = (UITextField *)[view viewWithTag:100];
    tf.font = [CustomFont GETFONT_REGULAR:17];
}

+ (void)setButtonProperties:(UIButton *)button {
    button.layer.cornerRadius = 3;
    button.layer.borderWidth = 1;
    [button.titleLabel setFont:[CustomFont GETFONT_REGULAR:18]];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [button.layer setBorderColor:[UIColor clearColor].CGColor];
    [button setBackgroundColor:Constants.BLUE_COLOR];
}

+ (void)setLOVButtonProperties:(UIButton *)lovButton withBgImage:(UIImage *)dropDownImage {
    [lovButton setTitle:Constants.LOV_DEFAULT_TITLE forState:UIControlStateNormal];
    lovButton.backgroundColor = [UIColor clearColor];
    lovButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [lovButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [lovButton setTitleColor:[UIColor lightGrayColor] forState:UIControlStateDisabled];
    [lovButton.titleLabel setFont:[CustomFont GETFONT_REGULAR:15]];
    [lovButton setTitleEdgeInsets:UIEdgeInsetsMake(0, 8, 0, 0)];
    [lovButton setBackgroundImage:dropDownImage forState:UIControlStateNormal];
}

+ (void)setFormTextFieldProperties:(UITextField *)textField withRowType:(NSString *)rowType placeHolder:(NSString *)placeholderText rowDisabled:(NSString *)isRowDisabled {
    textField.borderStyle = UITextBorderStyleRoundedRect;
    textField.font = [CustomFont GETFONT_REGULAR:15];
    textField.textColor = [UIColor blackColor];
    textField.autocorrectionType = UITextAutocorrectionTypeNo;
    textField.returnKeyType = UIReturnKeyDefault;
    textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    textField.placeholder = placeholderText;

    if ([rowType isEqualToString:Constants.FIELD_TYPE_NUMBER]) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
    }
    else if ([rowType isEqualToString:Constants.FIELD_TYPE_DECIMAL]) {
        textField.keyboardType = UIKeyboardTypeDecimalPad;
    }
    else {
        textField.keyboardType = UIKeyboardTypeDefault;
    }
    
    if ([isRowDisabled isEqualToString:@"Y"]) {
        textField.textColor = [UIColor lightGrayColor];
        textField.enabled = NO;
    }
}

+ (void)setFormMandatoryLabelProperties:(UILabel *)mandatoryLabel rowRequired:(NSString *)isRowRequired {
    mandatoryLabel.font = [CustomFont GETFONT_BOLD:15];
    mandatoryLabel.numberOfLines = 1;
    mandatoryLabel.baselineAdjustment = UIBaselineAdjustmentAlignBaselines;
    mandatoryLabel.adjustsFontSizeToFitWidth = YES;
    mandatoryLabel.minimumScaleFactor = 10.0f/12.0f;
    mandatoryLabel.clipsToBounds = YES;
    mandatoryLabel.backgroundColor = [UIColor clearColor];
    mandatoryLabel.textColor = [UIColor redColor];
    if ([isRowRequired isEqualToString:@"Y"]) {
        mandatoryLabel.text = @"*";
    }
    else {
        mandatoryLabel.text = @"";
    }
}

+ (void)setFormTitleLabelProperties:(UILabel *)titleLabel withTitle:(NSString *)title {
    titleLabel.font = [CustomFont GETFONT_BOLD:15];
    titleLabel.numberOfLines = 1;
    titleLabel.baselineAdjustment = UIBaselineAdjustmentAlignBaselines;
    titleLabel.adjustsFontSizeToFitWidth = YES;
    titleLabel.minimumScaleFactor = 10.0f/12.0f;
    titleLabel.clipsToBounds = YES;
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.textColor = [UIColor blackColor];
    titleLabel.text = title;
}

+ (void)setMandatoryRedStarOnLabel:(UILabel *)lbl {
    NSMutableAttributedString *selectedString = [[NSMutableAttributedString alloc] initWithString:lbl.text];
    [selectedString addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(selectedString.length - 1, 1)];
    lbl.attributedText = selectedString;
}


@end
