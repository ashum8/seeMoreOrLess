//
//  CustomFont.h
//  mCAS
//
//  Created by Mac on 27/06/19.
//  Copyright (c) 2019 Mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CustomFont: NSObject

#pragma - Fonts
+(UIFont *)GETFONT_EXTRA_BOLD_ITALIC:(int)SizeOfFont;
+(UIFont *)GETFONT_CONDENSED_BOLD:(int)SizeOfFont;
+(UIFont *)GETFONT_LIGHT :(int)SizeOfFont;
+(UIFont *)GETFONT_MEDIUM :(int)SizeOfFont;
+(UIFont *)GETFONT_REGULAR :(int)SizeOfFont;
+(UIFont *)GETFONT_BOLD :(int)SizeOfFont;
+(UIFont *)GETFONT_ITALIC :(int)SizeOfFont;
+(UIFont *)GETFONT_LIGHT_ITALIC :(int)SizeOfFont;
+(UIFont *)GETFONT_MEDIUM_ITALIC :(int)SizeOfFont;
+(UIFont *)GETFONT_BOLD_ITALIC :(int)SizeOfFont;

@end
