//
//  NSUserDefaults+EncryptNSUserDefaults.m
//  mServe
//
//  Created by Amit K. Swami on 22/08/14.
//  Copyright (c) 2014 Nucleus. All rights reserved.

// Inspired From Niels Mouthaan (SecureNSUserDefaults)

#import "NSUserDefaults+EncryptNSUserDefaults.h"
#import "RNEncryptor.h"
#import "RNDecryptor.h"

#define kStoredObjectKey @"storedObject"

@implementation NSUserDefaults (EncryptNSUserDefaults)

static NSString *_secret = nil;

#pragma mark - Getter methods

- (BOOL)secretBoolForKey:(NSString *)defaultName
{
    id object = [self secretObjectForKey:defaultName];
	if([object isKindOfClass:[NSNumber class]]) {
		return [object boolValue];
	} else {
		return NO;
	}
}

- (NSData*)secretDataForKey:(NSString *)defaultName
{
    id object = [self secretObjectForKey:defaultName];
	if([object isKindOfClass:[NSData class]]) {
		return object;
	} else {
		return nil;
	}
}

- (NSDictionary*)secretDictionaryForKey:(NSString *)defaultName
{
    id object = [self secretObjectForKey:defaultName];
	if([object isKindOfClass:[NSDictionary class]]) {
		return object;
	} else {
		return nil;
	}
}

- (float)secretFloatForKey:(NSString *)defaultName
{
    id object = [self secretObjectForKey:defaultName];
	if([object isKindOfClass:[NSNumber class]]) {
		return [object floatValue];
	} else {
		return 0.f;
	}
}

- (NSInteger)secretIntegerForKey:(NSString *)defaultName
{
    id object = [self secretObjectForKey:defaultName];
	if([object isKindOfClass:[NSNumber class]]) {
		return [object integerValue];
	} else {
		return 0;
	}
}

- (NSArray *)secretStringArrayForKey:(NSString *)defaultName
{
	id objects = [self secretObjectForKey:defaultName];
	if([objects isKindOfClass:[NSArray class]]) {
		for(id object in objects) {
			if(![object isKindOfClass:[NSString class]]) {
				return nil;
			}
		}
		return objects;
	} else {
		return nil;
	}
}

- (NSString *)secretStringForKey:(NSString *)defaultName
{
    id object = [self secretObjectForKey:defaultName];
	if([object isKindOfClass:[NSString class]]) {
		return object;
	} else {
		return nil;
	}
}

- (double)secretDoubleForKey:(NSString *)defaultName
{
    id object = [self secretObjectForKey:defaultName];
	if([object isKindOfClass:[NSNumber class]]) {
		return [object doubleValue];
	} else {
		return 0;
	}
}

- (NSURL*)secretURLForKey:(NSString *)defaultName
{
    id object = [self secretObjectForKey:defaultName];
	if([object isKindOfClass:[NSURL class]]) {
		return object;
	} else {
		return nil;
	}
}

- (id)secretObjectForKey:(NSString *)defaultName
{
    // Check if we have a (valid) key needed to decrypt
    NSAssert(_secret, @"Secret may not be nil when storing an object securely");
    
    // Fetch data from user defaults
    NSData *data = [self objectForKey:defaultName];
    NSError *error = nil;
    
    // Check if we have some data to decrypt, return nil if no
    if(data == nil) {
        return nil;
    }
    
    // Try to decrypt data
    @try {
        
        NSData *decryptedData = [RNDecryptor decryptData:data
                                            withPassword:_secret
                                                   error:&error];
        if(nil == error){
            NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:decryptedData];
            id object = [unarchiver decodeObjectForKey:kStoredObjectKey];
            [unarchiver finishDecoding];
            return object;
        }
        else{
            //NSLog(@"Cannot receive object from encrypted data storage: %@", error);
            return nil;
            
        }
    }
    @catch (NSException *exception) {
        
        // Whoops!
        //NSLog(@"Cannot receive object from encrypted data storage: %@", exception.reason);
        return nil;
        
    }
    @finally {}
}

#pragma mark - Setter methods

- (void)setSecret:(NSString*)secret
{
    _secret = secret;
}

- (void)setSecretBool:(BOOL)value forKey:(NSString *)defaultName
{
    [self setSecretObject:[NSNumber numberWithBool:value] forKey:defaultName];
}

- (void)setSecretFloat:(float)value forKey:(NSString *)defaultName
{
    [self setSecretObject:[NSNumber numberWithFloat:value] forKey:defaultName];
}

- (void)setSecretInteger:(NSInteger)value forKey:(NSString *)defaultName
{
    [self setSecretObject:[NSNumber numberWithInteger:value] forKey:defaultName];
}

- (void)setSecretDouble:(double)value forKey:(NSString *)defaultName
{
    [self setSecretObject:[NSNumber numberWithDouble:value] forKey:defaultName];
}

- (void)setSecretURL:(NSURL *)url forKey:(NSString *)defaultName
{
    [self setSecretObject:url forKey:defaultName];
}

- (void)setSecretObject:(id)value forKey:(NSString *)defaultName
{
    // Check if we have a (valid) key needed to encrypt
    NSAssert(_secret, @"Secret may not be nil when storing an object securely");
    
    @try {
        
        // Create data object from dictionary
        NSMutableData *data = [[NSMutableData alloc] init];
        NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];
        [archiver encodeObject:value forKey:kStoredObjectKey];
        [archiver finishEncoding];
        
        //Encrypt Data
        NSError *error = nil;
        NSData *encryptedData = [RNEncryptor encryptData:data
                                            withSettings:kRNCryptorAES256Settings
                                                password:_secret
                                                   error:&error];
        if(nil == error){
            // Save data in user defaults
            [self setObject:encryptedData forKey:defaultName];
        }else{
             //NSLog(@"Cannot store object securely: %@", error);
        }
    }
    @catch (NSException *exception) {
        
        // Whoops!
        //NSLog(@"Cannot store object securely: %@", exception.reason);
        
    }
    @finally {}
}

@end
