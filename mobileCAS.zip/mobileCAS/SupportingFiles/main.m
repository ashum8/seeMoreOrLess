//
//  main.m
//  mCAS
//
//  Created by amit.swami on 28/08/14.
//  Copyright (c) 2014 Nucleus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "TIMERUIApplication.h"


int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, NSStringFromClass([TIMERUIApplication class]), NSStringFromClass([AppDelegate class]));
    }
}
