//
//  ViewController.swift
//  seeMoreSeeLess
//
//  Created by Ashutosh Mishra on 02/05/19.
//  Copyright © 2019 Ashutosh Mishra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var expandAbout: Bool = false
    @IBOutlet weak var txtSeeMoreView: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        setupText()
    }
    func setupText() {
        let aboutStr = "Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda."
        txtSeeMoreView.delegate = self
        if aboutStr.count > 182 {
            let index = aboutStr.index(aboutStr.startIndex, offsetBy: 180)
            //                    let mySubstring = aboutStr[..<index]
            let substring = aboutStr[aboutStr.startIndex..<index]
        
            if self.expandAbout {
                let answerAttributed = NSMutableAttributedString(string: String(aboutStr), attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 14)])
                let readLessAttributed = NSMutableAttributedString(string: " ...Less", attributes: [NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 14), NSAttributedString.Key.foregroundColor: UIColor.black])
                let linkAttributesLess = [
                    NSAttributedString.Key.link.rawValue: NSURL(string: "https://Less.com"),
                    NSAttributedString.Key.foregroundColor: UIColor.gray,
                    NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 14)
                    ] as? [NSAttributedString.Key: Any] ?? [: ]
                readLessAttributed.setAttributes(linkAttributesLess, range: NSRange(location: 0, length: readLessAttributed.length))
                answerAttributed.append(readLessAttributed)
                txtSeeMoreView.attributedText = answerAttributed
            } else {
                let answerAttributed = NSMutableAttributedString(string: String(substring), attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 14)])
                let readMoreAttributed = NSMutableAttributedString(string: " ...More", attributes: [NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 14), NSAttributedString.Key.foregroundColor: UIColor.black])
                let linkAttributes = [
                    NSAttributedString.Key.link.rawValue: NSURL(string: "https://More.com"),
                    NSAttributedString.Key.foregroundColor: UIColor.gray,
                    NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 14)
                    ] as? [NSAttributedString.Key: Any] ?? [: ]
                readMoreAttributed.setAttributes(linkAttributes, range: NSRange(location: 0, length: readMoreAttributed.length))
                answerAttributed.append(readMoreAttributed)
                txtSeeMoreView.attributedText = answerAttributed
                txtSeeMoreView.linkTextAttributes = [
                    NSAttributedString.Key.foregroundColor: UIColor.black
                ]
            }
            
        } else {
            txtSeeMoreView.text = aboutStr
        }
    }

}

extension ViewController: UITextViewDelegate {
    func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool {
        if URL.absoluteString.contains("More") {
             self.expandAbout = true
            self.setupText()
        } else {
             self.expandAbout = false
            self.setupText()
        }
        return false
    }
}
