//
//  Constants.swift
//  mCAS
//
//  Created by Mac on 27/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation

//Dashboard TableView Grid
public let CREATE_LEAD                 = "CREATE_LEAD"
public let CREATE_APPLICATION          = "CREATE_APPLICATION"
public let CHECK_ELIGIBILITY           = "CHECK_ELIGIBILITY"
public let RAISE_QUERY                 = "RAISE_QUERY"
public let RATE_TYPE_APPROVAL          = "RATE_TYPE_APPROVAL"


//Dashboard CollectionView Grid
public let DRAFT_APPLICATIONS          = "DRAFT_APPLICATIONS"
public let ASSIGNED_LEADS              = "ASSIGNED_LEADS"
public let ASSIGNED_FI                 = "ASSIGNED_FI"
public let ASSIGNED_QUERY              = "ASSIGNED_QUERY"
public let APPLICATIONS_PUNCHED        = "APPLICATIONS_PUNCHED"
public let RAISED_QUERY                = "RAISED_QUERY"


public let OTP_TIMER    = 30
public let OTP_LENGTH   = 6


@objcMembers
public class Constants: NSObject {
    
    //Module/Functionality - Enable/Disable
    public static let SHOW_GALLERY_WITH_CAMERA      = true
    public static let ENABLE_LOCATION_UPDATE_IN_BG  = false
    public static let ENABLE_FORGOT_PWD_VIA_OTP     = true

    public static let bottomTabsCount: CGFloat      = 4

    //Colors
    public static let LIGHTER_BLUE_COLOR            = UIColor(red: 157.0/255.0, green: 201.0/255.0, blue: 241.0/255.0, alpha: 1)
    public static let LIGHT_BLUE_COLOR              = UIColor(red: 71.0/255.0, green: 109.0/255.0, blue: 220.0/255.0, alpha: 1)
    public static let LIGHT_BLUE_PINK               = UIColor(red: 235.0/255.0, green: 235.0/255.0, blue: 246.0/255.0, alpha: 1)
    public static let SKY_BLUE_COLOR                = UIColor(red: 85.0/255.0, green: 138.0/255.0, blue: 243.0/255.0, alpha: 1)
    public static let BLUE_COLOR                    = UIColor(red: 52.0/255.0, green: 122.0/255.0, blue: 184.0/255.0, alpha: 1)
    public static let GREEN_COLOR                   = UIColor(red: 103.0/255.0, green: 186.0/255.0, blue: 47.0/255.0, alpha: 1)
    public static let RED_COLOR                     = UIColor(red: 255.0/255.0, green: 59.0/255.0, blue: 48.0/255.0, alpha: 1)
    public static let LIGHTER_GRAY_COLOR            = UIColor(red: 237.0/255.0, green: 237.0/255.0, blue: 237.0/255.0, alpha: 1)
    public static let EXTREME_LIGHT_GRAY_COLOR      = UIColor(red: 249.0/255.0, green: 249.0/255.0, blue: 249.0/255.0, alpha: 1)
    
    
    //User Roles
    public static let FN_MOB_CAPTURE_LEAD           = "FN_MOB_CAPTURE_LEAD"
    public static let FN_MOB_VIEW_LEAD              = "FN_MOB_VIEW_LEAD"
    public static let FN_MOB_HOME_DASHBOARD         = "FN_MOB_HOME_DASHBOARD"
    public static let FN_MOB_MORE                   = "FN_MOB_MORE"
    public static let FN_MOB_SOURCING               = "FN_MOB_SOURCING"
    public static let FN_MOB_QUERY_MODULE           = "FN_MOB_QUERY_MODULE"
    public static let FN_MOB_FIELD_VERIFY           = "FN_MOB_FIELD_VERIFY"
    public static let FN_MOB_CALC                   = "FN_MOB_CALC"
    public static let FN_MOB_RATE_INITIATION        = "FN_MOB_RA_INITIATE"
    public static let FN_MOB_RATE_APPROVAL          = "FN_MOB_RA_APPROVE"
    public static let FN_MOB_CHANGE_PASSWORD        = "FN_MOB_CHANGE_PASSWORD"

    
    //StoryBoard Names Constant
    public static let STORYBOARD_MAIN               = "Main"
    public static let STORYBOARD_LOV_LIST           = "LovList"
    public static let STORYBOARD_EMI_CALCULATOR     = "EmiCalculator"
    public static let STORYBOARD_RATE_INITIATE      = "RateInitiate"
    public static let STORYBOARD_RATE_APPROVE       = "RateApprove"
    public static let STORYBOARD_ONLINE_SEARCH      = "OnlineSearch"

    
    //User Defaults Variable Names
    public static let UD_USER_ID                    = "MCAS.USER_ID"
    public static let UD_REMEMBER_USER_ID           = "MCAS.REMEMBER_USER_ID"

    
    //Date Formats
    public static let DATE_FORMATTER                = "dd-MM-yyyy"
    public static let DATE_SEARCH                   = "dd/MM/yyyy"

    
    public static let FIELD_TYPE_NUMBER             = "NUMBER"
    public static let FIELD_TYPE_DECIMAL            = "DECIMAL"

    public static let LOV_KEY                       = "key"
    public static let LOV_VALUE                     = "value"
    public static let LOV_DISPLAY_VALUE             = "display_value"
    public static let IS_SELECTED_FLAG              = "isSelected"
    public static let LOV_DEFAULT_TITLE             = NSLocalizedString("Select", comment: "")

}

