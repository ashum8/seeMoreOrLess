//
//  ServiceUrl.swift
//  mCAS
//
//  Created by Mac on 27/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation


@objcMembers
public class ServiceUrl: NSObject {
    
    public static let ALERT_SERVICE_ERROR               = "Service Error"
    public static let ALERT_NO_DATA                     = "No Data Found"

    
    
    public static let CREATE_TOKEN_URL                  = "/handshake"
    public static let LOGIN_URL                         = "/login/submit/formbased"
    public static let LOGOUT_URL                        = "/logout/submit"
    public static let CHANGE_PASSWORD_URL               = "/change-password"
    public static let FORGOT_PASSWORD_URL               = "/rest/password/forgot"
    public static let RESET_PASSWORD_GET_OTP_URL        = "/forgot-password/generate-otp"
    public static let RESET_PASSWORD_VERIFY_OTP_URL     = "/forgot-password/verify-otp"
    public static let RESET_PASSWORD_URL                = "/forgot-password/reset-password"
    public static let EMAIL_AMORTIZATION_SCHEDULE_URL   = "/rest/amortizationcalculator/emailAmortizationSchedule"
    public static let GET_AUTHORITIES_URL               = "/getcurrentuserauthorities"
    public static let GET_DECISION_REASONS_URL          = "/getdecisionreasonbystage"
    public static let GET_USERS_URL                     = "/user/searchusersbyrole"
    public static let SEARCH_APPLICATION_URL            = "/rate-approval/search-applications"
    public static let GET_CASE_DETAIL_URL               = "/rate-approval/get-application-details"
    public static let SUBMIT_APPLICATION_URL            = "/rate-approval/submit-application"
    public static let BULK_ACTION_URL                   = "/rate-approval/bulk-action"

    
}

