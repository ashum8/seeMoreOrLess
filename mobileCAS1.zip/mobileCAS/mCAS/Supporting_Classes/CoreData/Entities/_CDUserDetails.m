// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to CDUserDetails.m instead.

#import "_CDUserDetails.h"

@implementation CDUserDetailsID
@end

@implementation _CDUserDetails

+ (instancetype)insertInManagedObjectContext:(NSManagedObjectContext *)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription insertNewObjectForEntityForName:@"CDUserDetails" inManagedObjectContext:moc_];
}

+ (NSString*)entityName {
	return @"CDUserDetails";
}

+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription entityForName:@"CDUserDetails" inManagedObjectContext:moc_];
}

- (CDUserDetailsID*)objectID {
	return (CDUserDetailsID*)[super objectID];
}

+ (NSSet*)keyPathsForValuesAffectingValueForKey:(NSString*)key {
	NSSet *keyPaths = [super keyPathsForValuesAffectingValueForKey:key];

	return keyPaths;
}

@dynamic encryptedpassword;

@dynamic name;

@dynamic token;

@dynamic username;

@dynamic userRoles;

- (NSMutableSet<CDUserRoles*>*)userRolesSet {
	[self willAccessValueForKey:@"userRoles"];

	NSMutableSet<CDUserRoles*> *result = (NSMutableSet<CDUserRoles*>*)[self mutableSetValueForKey:@"userRoles"];

	[self didAccessValueForKey:@"userRoles"];
	return result;
}

@end

@implementation CDUserDetailsAttributes 
+ (NSString *)encryptedpassword {
	return @"encryptedpassword";
}
+ (NSString *)name {
	return @"name";
}
+ (NSString *)token {
	return @"token";
}
+ (NSString *)username {
	return @"username";
}
@end

@implementation CDUserDetailsRelationships 
+ (NSString *)userRoles {
	return @"userRoles";
}
@end

