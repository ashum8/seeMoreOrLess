// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to CDUserDetails.h instead.

#if __has_feature(modules)
    @import Foundation;
    @import CoreData;
#else
    #import <Foundation/Foundation.h>
    #import <CoreData/CoreData.h>
#endif

NS_ASSUME_NONNULL_BEGIN

@class CDUserRoles;

@interface CDUserDetailsID : NSManagedObjectID {}
@end

@interface _CDUserDetails : NSManagedObject
+ (instancetype)insertInManagedObjectContext:(NSManagedObjectContext *)moc_;
+ (NSString*)entityName;
+ (nullable NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_;
@property (nonatomic, readonly, strong) CDUserDetailsID *objectID;

@property (nonatomic, strong, nullable) NSString* encryptedpassword;

@property (nonatomic, strong, nullable) NSString* name;

@property (nonatomic, strong, nullable) NSString* token;

@property (nonatomic, strong, nullable) NSString* username;

@property (nonatomic, strong, nullable) NSSet<CDUserRoles*> *userRoles;
- (nullable NSMutableSet<CDUserRoles*>*)userRolesSet;

@end

@interface _CDUserDetails (UserRolesCoreDataGeneratedAccessors)
- (void)addUserRoles:(NSSet<CDUserRoles*>*)value_;
- (void)removeUserRoles:(NSSet<CDUserRoles*>*)value_;
- (void)addUserRolesObject:(CDUserRoles*)value_;
- (void)removeUserRolesObject:(CDUserRoles*)value_;

@end

@interface _CDUserDetails (CoreDataGeneratedPrimitiveAccessors)

- (nullable NSString*)primitiveEncryptedpassword;
- (void)setPrimitiveEncryptedpassword:(nullable NSString*)value;

- (nullable NSString*)primitiveName;
- (void)setPrimitiveName:(nullable NSString*)value;

- (nullable NSString*)primitiveToken;
- (void)setPrimitiveToken:(nullable NSString*)value;

- (nullable NSString*)primitiveUsername;
- (void)setPrimitiveUsername:(nullable NSString*)value;

- (NSMutableSet<CDUserRoles*>*)primitiveUserRoles;
- (void)setPrimitiveUserRoles:(NSMutableSet<CDUserRoles*>*)value;

@end

@interface CDUserDetailsAttributes: NSObject 
+ (NSString *)encryptedpassword;
+ (NSString *)name;
+ (NSString *)token;
+ (NSString *)username;
@end

@interface CDUserDetailsRelationships: NSObject
+ (NSString *)userRoles;
@end

NS_ASSUME_NONNULL_END
