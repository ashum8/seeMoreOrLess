#import "CDUserDetails.h"

@interface CDUserDetails ()

// Private interface goes here.

@end

@implementation CDUserDetails

// Custom logic goes here.

@end
