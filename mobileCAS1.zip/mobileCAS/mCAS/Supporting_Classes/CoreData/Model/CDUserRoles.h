#import "_CDUserRoles.h"

@interface CDUserRoles : _CDUserRoles
// Custom logic goes here.
@end
