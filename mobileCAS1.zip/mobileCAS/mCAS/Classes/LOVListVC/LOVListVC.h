//
//  LOVListVC.h
//  mCAS
//
//  Created by Mac on 29/12/15.
//  Copyright © 2015 Nucleus. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol LOVListDelegate <NSObject>

@optional
-(void)selectedLOV:(id)sender withSelectedButton:(UIButton *)btn;
-(void)selectedLOV:(id)sender withSelectedButtonTag:(NSUInteger)btntag;

@end


@interface LOVListVC : UIViewController {
    IBOutlet UISearchBar *applicationSearchBar;
}

@property(nonatomic, weak) id<LOVListDelegate> delegate;
@property(nonatomic, strong) NSMutableArray *optionArray;
@property (assign, nonatomic) NSUInteger selectedLOVTag;
@property(nonatomic, strong) NSArray *searchOptionArray;
@property(nonatomic, strong) UIButton *selectedButton;

@property(nonatomic, weak) IBOutlet UITableView *tableView;

@end
