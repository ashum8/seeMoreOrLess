//
//  CommonData.swift
//  mCAS
//
//  Created by Mac on 16/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation

class CommonData{
    
    static let shared = CommonData()
    var reasonMasterArray: [[String : String]] = []

    var approverMasterModelArray: [User] = []
    var recommenderMasterModelArray: [User] = []
    
    //Initializer access level change now
    private init(){}
    
    
    
}
