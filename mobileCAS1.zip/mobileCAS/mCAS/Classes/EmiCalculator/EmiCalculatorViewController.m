//
//  EmiCalculatorViewController.m
//  mCAS
//
//  Created by Sony.Rautela on 29/08/16.
//  Copyright © 2016 Nucleus. All rights reserved.
//

#import "EmiCalculatorViewController.h"


#define MaxLimitLoanAmount      10000000
#define MinLimitLoanAmount      10000
#define MinRateLimit            1
#define RateLimit               50
#define MinLimitTenure          12
#define MaxLimitTenure          360
#define MaxLimitEMI             100000000
#define MinLimitEMI             100

#define RATE_TYPE_EFFECTIVE     NSLocalizedString(@"Effective               ", nil)
#define RATE_TYPE_FLAT          NSLocalizedString(@"Flat                             ", nil)
#define CALCULATE_FOR_EMI       NSLocalizedString(@"EMI", nil)
#define CALCULATE_FOR_ROI       NSLocalizedString(@"Rate of Interest", nil)
#define CALCULATE_FOR_TENURE    NSLocalizedString(@"Tenure", nil)
#define FREQ_TYPE_MONTHLY       NSLocalizedString(@"Monthly", nil)
#define FREQ_TYPE_WEEKLY        NSLocalizedString(@"Weekly", nil)
#define FREQ_TYPE_BI_WEEKLY     NSLocalizedString(@"Fortnightly", nil)
#define FREQ_TYPE_YEARLY        NSLocalizedString(@"Yearly", nil)
#define FREQ_TYPE_DAILY         NSLocalizedString(@"Daily", nil)




typedef enum
{
   rateTypeEffective,
   rateTypeFlat
}rateType;

typedef enum
{
    calculateRate,
    calculateTenure,
    calculateEmi
}calculate;

typedef enum
{
    daily,
    weekly,
    biWeekly,
    monthly,
    yearly
}freqType;

@interface EmiCalculatorViewController ()
{
    IBOutlet UITextField            *txtCalculateFor;
    IBOutlet UITextField            *txtRateType;
    IBOutlet UITextField            *txtFrequencyType;
    IBOutlet UITextField            *txtRatePerAnnum;
    IBOutlet UITextField            *txtLoanAmount;
    IBOutlet UITextField            *txtTenure;
    IBOutlet UITextField            *txtEmi;
    
    IBOutlet UISlider               *sliderRatePerAnnum;
    IBOutlet UISlider               *sliderLoanAmount;
    IBOutlet UISlider               *sliderTenure;
    IBOutlet UISlider               *sliderEmi;
    
    IBOutlet UIButton               *btnCalculate;
    __weak IBOutlet UIButton        *viewChartButton;
    
    NSArray                         *dropDowns;
    NSArray                         *calculateForArray;
    NSArray                         *frequencyTypesArray;
    NSArray                         *rateTypeArray;
    
    rateType                        selectedRate;
    calculate                       calculationParameter;
    freqType                        frequencyType;

    NSNumberFormatter               *formatter;
}

@end

@implementation EmiCalculatorViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];

    sliderRatePerAnnum.tintColor = Constants.BLUE_COLOR;
    sliderLoanAmount.tintColor = Constants.BLUE_COLOR;
    sliderTenure.tintColor = Constants.BLUE_COLOR;
    sliderEmi.tintColor = Constants.BLUE_COLOR;

    sliderRatePerAnnum.thumbTintColor = Constants.BLUE_COLOR;
    sliderLoanAmount.thumbTintColor = Constants.BLUE_COLOR;
    sliderTenure.thumbTintColor = Constants.BLUE_COLOR;
    sliderEmi.thumbTintColor = Constants.BLUE_COLOR;

    sliderRatePerAnnum.maximumTrackTintColor = [UIColor lightGrayColor];
    sliderLoanAmount.maximumTrackTintColor = [UIColor lightGrayColor];
    sliderTenure.maximumTrackTintColor = [UIColor lightGrayColor];
    sliderEmi.maximumTrackTintColor = [UIColor lightGrayColor];

    calculateForArray = [NSArray arrayWithObjects:CALCULATE_FOR_EMI, CALCULATE_FOR_ROI, CALCULATE_FOR_TENURE, nil];
    rateTypeArray = [NSArray arrayWithObjects:FREQ_TYPE_MONTHLY, FREQ_TYPE_YEARLY, FREQ_TYPE_WEEKLY, FREQ_TYPE_BI_WEEKLY, FREQ_TYPE_DAILY, nil];
    frequencyTypesArray = [NSArray arrayWithObjects:RATE_TYPE_EFFECTIVE, RATE_TYPE_FLAT, nil];
    
    [self setDataOnAppear];

    sliderRatePerAnnum.minimumValue = MinRateLimit;
    sliderRatePerAnnum.maximumValue = RateLimit;

    sliderLoanAmount.minimumValue = MinLimitLoanAmount;
    sliderLoanAmount.maximumValue = MaxLimitLoanAmount;

    sliderTenure.minimumValue = MinLimitTenure;
    sliderTenure.maximumValue = MaxLimitTenure;

    sliderEmi.minimumValue = MinLimitEMI;
    sliderEmi.maximumValue = MaxLimitEMI;

    [viewChartButton setTitleColor:Constants.BLUE_COLOR forState:UIControlStateNormal];
    [viewChartButton.titleLabel setFont:[CustomFont GETFONT_MEDIUM:16]];
    
    formatter = [[NSNumberFormatter alloc] init];
    [formatter setMaximumFractionDigits:2];
    [FIApplicationUtils setButtonProperties:btnCalculate];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [AppDelegate instance].bottomTabbarView.hidden = YES;
    [[AppDelegate instance].headerView setTitleWithShowBackButtonWithTitle:@"EMI Calculator" showBackButton:YES];
}

- (void)setDataOnAppear {
    selectedRate = rateTypeEffective;
    calculationParameter = calculateEmi;
    
    txtCalculateFor.text = calculateForArray[0];
    txtRateType.text = frequencyTypesArray[0];
    [self resetFrequencyType];
}

- (void)resetFrequencyType {
    frequencyType = monthly;
    txtFrequencyType.text = rateTypeArray[0];
}

#pragma mark - IBActions

- (IBAction)ratePerAnnumSelected:(id)sender
{
    txtRatePerAnnum.text = [NSString stringWithFormat:@"%0.2f",sliderRatePerAnnum.value];
}

- (IBAction)loanAmountSelected:(id)sender
{
    NSInteger loanAmount = roundl(sliderLoanAmount.value);
    txtLoanAmount.text = [NSString stringWithFormat:@"%ld",(long)loanAmount];
}

- (IBAction)tenureSelected:(id)sender
{
    NSInteger tenure = roundl(sliderTenure.value);
    txtTenure.text = [NSString stringWithFormat:@"%ld",(long)tenure];
}

- (IBAction)emiSelected:(id)sender
{
    NSInteger emi = roundl(sliderEmi.value);
    txtEmi.text = [NSString stringWithFormat:@"%ld",(long)emi];
}

- (IBAction)viewChartButtonAction:(id)sender {
    
    if (![txtEmi.text length] || ![txtLoanAmount.text length] || ![txtTenure.text length] || ![txtRatePerAnnum.text length]) {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:[NSString stringWithFormat:NSLocalizedString(@"Please calculate %@ first",nil),txtCalculateFor.text]];
    }
    else {
        [self calucate:nil];
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:Constants.STORYBOARD_EMI_CALCULATOR bundle:nil];
        AmortizationChartVC* vc = [storyboard instantiateViewControllerWithIdentifier:@"AmortizationChartVC"];
        vc.emiAmount = [txtEmi.text doubleValue];
        vc.principalAmount = [txtLoanAmount.text doubleValue];
        vc.tenure = [self getTenureForFrequencyType];
        vc.periodicInterest = [self getRateForFrequencyType];
        vc.ratePerAnnum = [txtRatePerAnnum.text doubleValue];
        vc.tenureInYears = [txtTenure.text doubleValue]/12;
        vc.tenureLoanType = [NSString stringWithFormat:@"%d",[self getTenureLoanTypeForFrequencyType]];
        vc.installmentLabelName = [self getLabelNameForFrequencyType];
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (IBAction)calucate:(id)sender
{
    if (txtCalculateFor.text.length == 0) {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"Please select calculate for",nil)];
        return;
    }
    else if (txtRateType.text.length == 0) {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"Please select rate type",nil)];
        return;
    }
    
    switch (calculationParameter) {
        case calculateRate:
        {
            if ([self validateDataForRateCalculation]) {
                if (selectedRate == rateTypeEffective) {
                    [self calculateROIForEffective];
                }
                else if (selectedRate == rateTypeFlat) {
                      [self calculateROIForFlat];
                }
            }
        }
            break;
        case calculateTenure:
        {
            if ([self validateDataForTenureCalculation]) {
                if (selectedRate == rateTypeEffective) {
                    [self calculateTenureForEffectiveRate];
                }
                else if (selectedRate == rateTypeFlat) {
                    [self calculateTenureForFlatRate];
                }
            }
        }
            break;
        case calculateEmi:
        {
            if ([self validateDataForEmiCalculation]) {
                if (selectedRate == rateTypeEffective) {
                    [self calculateEmiForEffectiveRate];
                }
                else if (selectedRate == rateTypeFlat) {
                    [self calculateEmiForFlatRate];
                }
            }
        }
            break;
        default:
            break;
    }
}


#pragma mark - Drop Down Method

- (void)showDropDown:(UITextField *)field
{
    NSString *alertTitle;
   
    if (field == txtCalculateFor) {
        dropDowns = calculateForArray;
        alertTitle = NSLocalizedString(@"Calculate For", nil);
    }
    else if (field == txtFrequencyType) {
        dropDowns = rateTypeArray;
        alertTitle = NSLocalizedString(@"Frequency Type", nil);
    }
    else {
        dropDowns = frequencyTypesArray;
        alertTitle = NSLocalizedString(@"Rate Type", nil);
    }
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:alertTitle  message:NSLocalizedString(@"", nil) preferredStyle:UIAlertControllerStyleAlert];
    
    if ([dropDowns isKindOfClass:[NSArray class]]) {
        
        for (NSString *dropDown in dropDowns) {
            
            UIAlertAction *action = [UIAlertAction actionWithTitle:dropDown
                                                             style:UIAlertActionStyleDefault
                                                           handler:^(UIAlertAction * action) {
                                                               if (field == self->txtCalculateFor) {
                                                                   if ([dropDown isEqualToString:CALCULATE_FOR_EMI]) {
                                                                       self->calculationParameter = calculateEmi;
                                                                       [self->txtEmi setText:@""];
                                                                       [self->sliderEmi setValue:0];
                                                                       [self->txtFrequencyType setEnabled:YES];
                                                                   }
                                                                   else if ([dropDown isEqualToString:CALCULATE_FOR_ROI])
                                                                   {
                                                                       self->calculationParameter = calculateRate;
                                                                       [self->txtRatePerAnnum setText:@""];
                                                                       [self->sliderRatePerAnnum setValue:0];
                                                                       [self->txtFrequencyType setEnabled:NO];
                                                                       [self resetFrequencyType];
                                                                   }
                                                                   else if ([dropDown isEqualToString:CALCULATE_FOR_TENURE])
                                                                   {
                                                                       self->calculationParameter = calculateTenure;
                                                                       [self->txtTenure setText:@""];
                                                                       [self->sliderTenure setValue:0];
                                                                       [self->txtFrequencyType setEnabled:NO];
                                                                       [self resetFrequencyType];
                                                                   }
                                                                   
                                                                   self->txtCalculateFor.text = dropDown;
                                                               }
                                                               else if (field == self->txtFrequencyType) {
                                                                   if ([dropDown isEqualToString:FREQ_TYPE_YEARLY]) {
                                                                       self->frequencyType = yearly;
                                                                   }
                                                                   else if ([dropDown isEqualToString:FREQ_TYPE_MONTHLY]) {
                                                                       self->frequencyType = monthly;
                                                                   }
                                                                   else if ([dropDown isEqualToString:FREQ_TYPE_WEEKLY]) {
                                                                       self->frequencyType = weekly;
                                                                   }
                                                                   else if ([dropDown isEqualToString:FREQ_TYPE_BI_WEEKLY]) {
                                                                       self->frequencyType = biWeekly;
                                                                   }
                                                                   else if ([dropDown isEqualToString:FREQ_TYPE_DAILY]) {
                                                                       self->frequencyType = daily;
                                                                   }
                                                                   
                                                                   self->txtFrequencyType.text = dropDown;
                                                               }
                                                               else {
                                                                   if ([dropDown isEqualToString:RATE_TYPE_EFFECTIVE]) {
                                                                       self->selectedRate = rateTypeEffective;
                                                                   }
                                                                   else if ([dropDown isEqualToString:RATE_TYPE_FLAT]) {
                                                                       self->selectedRate = rateTypeFlat;
                                                                   }
                                                                   self->txtRateType.text = dropDown;
                                                               }
                                                           }];
            
            [alert addAction:action];
        }
    }
    
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - Validations

- (BOOL)validateDataForRateCalculation
{
    if ([self loanAmountValdiations]) {
        
        if ([self tenureValdiations]) {
            
            if ([self emiValdiations]) {
                return YES;
            }
        }
    }
    return NO;
}

- (BOOL)validateDataForTenureCalculation
{
    if ([self rateOfInterestValdiations]) {
        
        if ([self loanAmountValdiations]) {
            
            if ([self emiValdiations]) {
                return YES;
            }
        }
    }
    return NO;
}

- (BOOL)validateDataForEmiCalculation
{
    if ([self rateOfInterestValdiations]) {
        
        if ([self loanAmountValdiations]) {
            
            if ([self tenureValdiations]) {
                return YES;
            }
        }
    }
    return NO;
}

- (BOOL)loanAmountValdiations
{
    // Loan Amount Validation
    
    if ([FIApplicationUtils textfieldIsEmpty:txtLoanAmount]) {
        
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"Please enter Loan Amount",nil)];
        return NO;
    }
    else if (![NSString validateInputWithString:txtLoanAmount.text andRegex:@"^[0-9]+(\\.[0-9]{1,2})?$"])
    {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"Please enter a valid loan amount",nil)];
        return NO;
    }
    else if ([txtLoanAmount.text floatValue] == 0)
    {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"Loan Amount cannot be zero",nil)];
        return NO;
    }
    else if ([txtLoanAmount.text floatValue] < MinLimitLoanAmount)
    {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:[NSString stringWithFormat:NSLocalizedString(@"Loan Amount cannot be less than %d.",nil), MinLimitLoanAmount]];
        return NO;
    }
    else if ([txtLoanAmount.text floatValue] > MaxLimitLoanAmount)
    {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:[NSString stringWithFormat:NSLocalizedString(@"Loan amount cannot be greater than %d.",nil), MaxLimitLoanAmount]];
        return NO;
    }
    return YES;
}

- (BOOL)rateOfInterestValdiations
{
    // Loan Amount Validation
    
    if ([FIApplicationUtils textfieldIsEmpty:txtRatePerAnnum]) {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"Please enter rate of Interest",nil)];
        return NO;
    }
    else if (![NSString validateInputWithString:txtRatePerAnnum.text andRegex:@"^[0-9]+(\\.[0-9]{1,2})?$"])
    {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"Rate of Interest entered by you is invalid.",nil)];
         return NO;
    }
    else if ([txtRatePerAnnum.text floatValue] == 0)
    {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"Rate of Interest cannot be zero.",nil)];
         return NO;
    }
    else if ([txtRatePerAnnum.text floatValue] < MinRateLimit)
    {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:[NSString stringWithFormat:NSLocalizedString(@"Rate of Interest cannot be less than %d",nil), MinRateLimit]];
        return NO;
    }
    else if ([txtRatePerAnnum.text floatValue] > RateLimit)
    {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:[NSString stringWithFormat:NSLocalizedString(@"Rate of Interest cannot be greater than %d",nil), RateLimit]];
         return NO;
    }

    return YES;
}

- (BOOL)emiValdiations
{
    //EMI validation
    
    if ([FIApplicationUtils textfieldIsEmpty:txtEmi]) {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"Please enter EMI",nil)];
         return NO;
    }
    else if (![NSString validateInputWithString:txtEmi.text andRegex:@"^[0-9]+(\\.[0-9]{1,2})?$"])
    {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"Please enter a valid EMI",nil)];
         return NO;
    }
    else if ([txtEmi.text floatValue] == 0)
    {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"EMI cannot be zero",nil)];
         return NO;
    }
    else if ([txtEmi.text floatValue] < MinLimitEMI)
    {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:[NSString stringWithFormat:NSLocalizedString(@"EMI cannot be less than %d.",nil), MinLimitEMI]];
        return NO;
    }
    else if ([txtEmi.text floatValue] > MaxLimitEMI)
    {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:[NSString stringWithFormat:NSLocalizedString(@"EMI cannot be greater than %d.",nil), MaxLimitEMI]];
        return NO;
    }
    else if ([txtEmi.text floatValue] > [txtLoanAmount.text floatValue])
    {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"EMI Cannot be greater than Loan Amount",nil)];
         return NO;
    }

     return YES;
}

- (BOOL)tenureValdiations
{
    // Tenure Validation
    if ([FIApplicationUtils textfieldIsEmpty:txtTenure]) {
        
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"Please enter tenure",nil)];
         return NO;
    }
    else if (![NSString validateInputWithString:txtTenure.text andRegex:@"^[0-9]{1,3}$"])
    {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"Please enter a valid tenure",nil)];
         return NO;
    }
    else if ([txtTenure.text floatValue] == 0)
    {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"Tenure can not be zero",nil)];
         return NO;
    }
    else if ([txtTenure.text floatValue] < MinLimitTenure)
    {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:[NSString stringWithFormat:NSLocalizedString(@"Tenure cannot be less than %d",nil), MinLimitTenure]];
        return NO;
    }
    else if ([txtTenure.text floatValue] > MaxLimitTenure)
    {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:[NSString stringWithFormat:NSLocalizedString(@"Tenure can not be greater than %d",nil),MaxLimitTenure]];
         return NO;
    }
    return YES;
}

#pragma mark - Frequency Based Calculations

- (NSString *)getLabelNameForFrequencyType {
    
    switch (frequencyType) {
        case monthly:
            return @"EMI";
            break;
        case yearly:
            return @"Yearly Installment";
            break;
        case weekly:
            return @"Weekly Installment";
            break;
        case biWeekly:
            return @"Fortnightly Installment";
            break;
        case daily:
            return @"Daily Installment";
            break;
            
        default:
            return @"EMI";
            break;
    }
}

- (int)getTenureLoanTypeForFrequencyType {
    
    switch (frequencyType) {
        case monthly:
            return 12;
            break;
        case yearly:
            return 1;
            break;
        case weekly:
            return 52;
            break;
        case biWeekly:
            return 26;
            break;
        case daily:
            return 365;
            break;
            
        default:
            return 12;
            break;
    }
}

- (float)getRateForFrequencyType {
    return [txtRatePerAnnum.text doubleValue]/[self getTenureLoanTypeForFrequencyType];
}

- (float)getTenureForFrequencyType {
    return [txtTenure.text doubleValue]*[self getTenureLoanTypeForFrequencyType]/12;
}

#pragma mark - EMI Calculations

- (void)calculateEmiForEffectiveRate
{
    //if Rate type effective & calculate EMI
    double loanAmount = [txtLoanAmount.text doubleValue];
    
    double finalRate = [self getRateForFrequencyType]/100;
    double finalTenure = [self getTenureForFrequencyType];

    double  mp = loanAmount * finalRate * pow(1 + finalRate, finalTenure) /(pow(1 + finalRate, finalTenure) - 1);
    NSString *emiVal = [formatter stringFromNumber:[NSNumber numberWithDouble:mp]];
    
//    if ([emiVal floatValue] <= MaxLimitEMI) {
        [sliderEmi setValue:[emiVal doubleValue]];
        [txtEmi setText:emiVal];
//    }
//    else {
//        [sliderEmi setValue:MaxLimitEMI];
//        [txtEmi setText:[NSString stringWithFormat:@"%d",MaxLimitEMI]];
//    }
}

- (void)calculateEmiForFlatRate
{
    //if Rate type Flat & Calculate EMI
    double amount = [txtLoanAmount.text doubleValue];
    
    double finalRate = [self getRateForFrequencyType]/100;
    double finalTenure = [self getTenureForFrequencyType];

    NSString *emiVal = [formatter stringFromNumber:[NSNumber numberWithDouble:(amount*(1+ finalTenure*finalRate))/finalTenure]];
    
//    if ([emiVal  floatValue] <= MaxLimitEMI) {
        [sliderEmi setValue:[emiVal floatValue]];
        [txtEmi setText:emiVal];
//    }
//    else {
//        [sliderEmi setValue:MaxLimitEMI];
//        [txtEmi setText:[NSString stringWithFormat:@"%d",MaxLimitEMI]];
//    }
}

#pragma mark - Rate of Interest Calculations

- (void)calculateROIForEffective
{
    //if Rate type Effective & Calculate Rate Of Interest
    
    CGFloat emi = [txtEmi.text floatValue];
    CGFloat loanAmount = [txtLoanAmount.text floatValue];
    CGFloat tenure = [txtTenure.text floatValue];
    
    if ((tenure < 1) || (loanAmount/tenure) > emi) {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"Loan amount must be less than or equal to (tenure * emi)",nil)];
        return ;
    }
    
    CGFloat roiPart1 = 10;
    CGFloat roiPart2 = 1200 *(emi/loanAmount) * (1- pow(1200 / (1200+roiPart1), tenure));
    
    NSInteger counter = 1;
    
    while (counter != -1) {
        counter++;
        roiPart1 = roiPart2;
        roiPart2 = 1200 * (emi/loanAmount)  * (1- pow(1200 / (1200+roiPart1), tenure));
        
        if (roundf(1000 * roiPart1) == roundf(1000 * roiPart2)) {
            break;
        }
    }
    roiPart1 = (roundf(roiPart1 * 100)) / 100;
  
    DebugLog(@"ROI  - %f",roiPart1);
    
    if (roiPart1 > RateLimit) {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:[NSString stringWithFormat:NSLocalizedString(@"Rate of interest is %.2f which is greater than max supported rate %d",nil),roiPart1, RateLimit]];

        [txtRatePerAnnum setText:@""];
        [sliderRatePerAnnum setValue:MinRateLimit];
    }
    else {
        [txtRatePerAnnum setText:[NSString stringWithFormat:@"%0.2f",roiPart1]];
        [sliderRatePerAnnum setValue:roiPart1];
    }
}

- (void)calculateROIForFlat
{
    //if Rate type Flat & Calculate Rate Of Interest
    
    CGFloat emi = [txtEmi.text floatValue];
    CGFloat loanAmount = [txtLoanAmount.text floatValue];
    CGFloat tenure = [txtTenure.text floatValue];
    
    if ((tenure < 1) || (loanAmount/tenure) > emi) {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"Loan amount must be less than or equal to (tenure * emi)",nil)];
        return;
    }
    
    CGFloat roiPart1 = emi/loanAmount;
    CGFloat roiPart2 = 1/tenure;
    CGFloat roi = 1200 * (roiPart1 - roiPart2);
    
    CGFloat  rateOfInterest = (roundf(roi * 100)) / 100;
    
    DebugLog(@"ROI  - %f",rateOfInterest);
   
    if (rateOfInterest > RateLimit) {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:[NSString stringWithFormat:NSLocalizedString(@"Rate of interest is %.2f which is greater than max supported rate %d",nil),roiPart1, RateLimit]];
        
        [txtRatePerAnnum setText:@""];
        [sliderRatePerAnnum setValue:MinRateLimit];
    }
    else{
        [txtRatePerAnnum setText:[NSString stringWithFormat:@"%0.2f",rateOfInterest]];
        [sliderRatePerAnnum setValue:rateOfInterest];
    }
}


#pragma mark - Tenure Calculations

- (void)calculateTenureForEffectiveRate
{
    //if Rate type Effective & Tenure
    
    CGFloat rate = [txtRatePerAnnum.text floatValue];
    CGFloat loanAmount = [txtLoanAmount.text floatValue];
    CGFloat emi = [txtEmi.text floatValue];
    CGFloat numPortion1 = log(1200 * emi);
    
    CGFloat intermediateValue = (1200 *emi) - (loanAmount * rate);
    
    if (intermediateValue < 0) {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"EMI is too low",nil)];
    }
    else {
        CGFloat numPortion2 = log(intermediateValue);
        CGFloat demoniPortion1 = log(1200+rate);
        CGFloat demoniPortion2 = log(1200);
        CGFloat tenure = roundf((numPortion1 - numPortion2) / (demoniPortion1 - demoniPortion2));
        NSInteger finalTenure = [[NSNumber numberWithFloat:tenure] integerValue];
        
        DebugLog(@"Tenure  - %ld",(long)finalTenure);
        
        if (finalTenure > MaxLimitTenure) {
            [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:[NSString stringWithFormat:NSLocalizedString(@"Tenure is %d which is greater than max supported tenure %d",nil),finalTenure, MaxLimitTenure]];
            
            [txtTenure setText:@""];
            [sliderTenure setValue:MinLimitTenure];
        }
        else {
            [txtTenure setText:[NSString stringWithFormat:@"%ld",(long)finalTenure]];
            [sliderTenure setValue:finalTenure];
        }
    }
}

- (void)calculateTenureForFlatRate
{
    //if Rate type flat & Tenure
    
    CGFloat rate = [txtRatePerAnnum.text floatValue];
    CGFloat loanAmount = [txtLoanAmount.text floatValue];
    CGFloat emi = [txtEmi.text floatValue];
    CGFloat demoninator = ((emi *1200) - (loanAmount * rate));
    
    if (demoninator < 0) {
        [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:NSLocalizedString(@"EMI is too low",nil)];
    }
    else {
        CGFloat numerator = (loanAmount *1200);
        CGFloat tenure = roundf(numerator/demoninator);
        NSInteger finalTenure = [[NSNumber numberWithFloat:tenure] integerValue];
        
        DebugLog(@"Tenure  - %ld",(long)finalTenure);
        if (finalTenure > MaxLimitTenure) {
            [FIApplicationUtils showAlertWithTitle:NSLocalizedString(@"", nil) andMessage:[NSString stringWithFormat:NSLocalizedString(@"Tenure is %d which is greater than max supported tenure %d",nil),finalTenure, MaxLimitTenure]];
            
            [txtTenure setText:@""];
            [sliderTenure setValue:MinLimitTenure];
        }
        else {
            [txtTenure setText:[NSString stringWithFormat:@"%ld",(long)finalTenure]];
            [sliderTenure setValue:finalTenure];
        }
    }
}

#pragma mark - UITextfield Delegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField == txtCalculateFor || textField == txtRateType || textField == txtFrequencyType) {
        [self showDropDown:textField];
        return NO;
    }
    [textField setKeyboardType:UIKeyboardTypeDecimalPad];
    return YES;
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([string isEqualToString:@""]) return YES;

    if (textField == txtTenure) {
        NSString *proposedNewString = [[textField text] stringByReplacingCharactersInRange:range withString:string];

        if (![NSString validateInputWithString:proposedNewString andRegex:@"^[0-9]{1,3}$"]) {
            return NO;
        }
    }
    else {
        NSString *proposedNewString = [[textField text] stringByReplacingCharactersInRange:range withString:string];

        if ([string isEqualToString:@"."]) {
            NSUInteger numOfDecimals = [[textField.text componentsSeparatedByString:@"."] count] - 1;
           
            if (numOfDecimals >= 1) {
                return NO;
            }
        }
        else if(![proposedNewString isNumeric]) {
            return NO;
        }
    }
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField == txtRatePerAnnum) {
        if ([txtRatePerAnnum.text floatValue] > RateLimit) {
            sliderRatePerAnnum.value = RateLimit;
            [txtRatePerAnnum setText:[NSString stringWithFormat:@"%d.00",RateLimit]];
        }
        else if ([txtRatePerAnnum.text floatValue] < MinRateLimit) {
            sliderRatePerAnnum.value = MinRateLimit;
            [txtRatePerAnnum setText:[NSString stringWithFormat:@"%d.00",MinRateLimit]];
        }
        else {
            sliderRatePerAnnum.value = [txtRatePerAnnum.text floatValue];
        }
    }
    else if (textField == txtLoanAmount) {
        if ([txtLoanAmount.text floatValue] > MaxLimitLoanAmount) {
            sliderLoanAmount.value = MaxLimitLoanAmount;
            [txtLoanAmount setText:[NSString stringWithFormat:@"%d",MaxLimitLoanAmount]];
        }
        else if ([txtLoanAmount.text floatValue] < MinLimitLoanAmount) {
            sliderLoanAmount.value = MinLimitLoanAmount;
            [txtLoanAmount setText:[NSString stringWithFormat:@"%d",MinLimitLoanAmount]];
        }
        else {
            sliderLoanAmount.value = [txtLoanAmount.text floatValue];
        }
    }
    else if (textField == txtTenure) {
        if ([txtTenure.text floatValue] > MaxLimitTenure) {
            sliderTenure.value = MaxLimitTenure;
            [txtTenure setText:[NSString stringWithFormat:@"%d",MaxLimitTenure]];
        }
        else if ([txtTenure.text floatValue] < MinLimitTenure) {
            sliderTenure.value = MinLimitTenure;
            [txtTenure setText:[NSString stringWithFormat:@"%d",MinLimitTenure]];
        }
        else {
           sliderTenure.value = [txtTenure.text floatValue];
        }
    }
    else if (textField == txtEmi) {
        if ([txtEmi.text floatValue] > MaxLimitEMI) {
            [txtEmi setText:[NSString stringWithFormat:@"%d",MaxLimitEMI]];
            sliderEmi.value = MaxLimitEMI;
        }
        else if ([txtEmi.text floatValue] < MinLimitEMI) {
            [txtEmi setText:[NSString stringWithFormat:@"%d",MinLimitEMI]];
            sliderEmi.value = MinLimitEMI;
        }
        else {
           sliderEmi.value = [txtEmi.text floatValue];
        }
    }
}

@end
