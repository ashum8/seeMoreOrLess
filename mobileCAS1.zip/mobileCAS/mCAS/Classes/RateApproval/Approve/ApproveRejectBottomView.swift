//
//  ApproveRejectBottomView.swift
//  mCAS
//
//  Created by Mac on 10/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

public protocol ARBottomViewDelegate: class {
    func editCaseAction()
    func approveCaseAction()
    func rejectCaseAction()
    func forwardCaseAction()
}

class ApproveRejectBottomView: UIView {

    open weak var delegate: ARBottomViewDelegate?

    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var approveButton: UIButton!
    @IBOutlet weak var rejectButton: UIButton!
    @IBOutlet weak var forwardButton: UIButton!
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var editButtonWidth: NSLayoutConstraint!
    @IBOutlet weak var editButtonTrailing: NSLayoutConstraint!
    
    @IBAction func approveAction(_ sender: Any) {
        if let delegate = delegate {
            delegate.approveCaseAction()
        }
    }
    
    @IBAction func rejectAction(_ sender: Any) {
        if let delegate = delegate {
            delegate.rejectCaseAction()
        }
    }

    @IBAction func forwardAction(_ sender: Any) {
        if let delegate = delegate {
            delegate.forwardCaseAction()
        }
    }

    @IBAction func editAction(_ sender: Any) {
        if let delegate = delegate {
            delegate.editCaseAction()
        }
    }
    
    func setProperties(showEdit: Bool, showForword: Bool) {
        // Do any additional setup after loading the view.
        bgView.layer.cornerRadius = 10
        forwardButton.isHidden = !showForword
        editButton.isHidden = !showEdit
        approveButton.layer.cornerRadius = 25
        rejectButton.layer.cornerRadius = 25
        forwardButton.layer.cornerRadius = 20
        editButton.layer.cornerRadius = 20

        if !showEdit {
            editButtonWidth.constant = 0
            editButtonTrailing.constant = 0
        }
        else {
            editButtonWidth.constant = 40
            editButtonTrailing.constant = 20
        }
        
        bgView.setShadow()
        approveButton.setButtonShadow()
        rejectButton.setButtonShadow()
        forwardButton.setButtonShadow()
        editButton.setButtonShadow()
    }

}
