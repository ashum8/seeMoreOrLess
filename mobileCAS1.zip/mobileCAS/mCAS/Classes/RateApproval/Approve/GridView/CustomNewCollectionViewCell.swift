//
//  GridCollectionCell.swift
//  CollectionViewCustom
//
//  Created by iMac on 20/11/19.
//

import UIKit

class GridCollectionCell: UICollectionViewCell {
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var lblRequestedRate: UILabel!
    @IBOutlet weak var btnLoanType: UIButton!
    @IBOutlet weak var vw1: UIView!
    @IBOutlet weak var vw2: UIView!
    @IBOutlet weak var vw3: UIView!
    
    @IBOutlet weak var lblLoanAmtName: UILabel!
    @IBOutlet weak var lblChangesCode: UILabel!
    @IBOutlet weak var lblCurrentRate: UILabel!
    @IBOutlet weak var topBgView: UIView!
    
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var tableView: UITableView!
    
    var rateCharges: [Rate]?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.backgroundColor = Constants.LIGHTER_GRAY_COLOR
        self.tableView.register(UINib(nibName:  String(describing: InterestRateTableViewCell.self), bundle: Bundle.main), forCellReuseIdentifier: "InterestRateTableViewCell")
    }
    
    func setProperties() {
        
        lblLoanAmtName.textColor = UIColor.darkGray
        vw1.backgroundColor = Constants.LIGHTER_GRAY_COLOR
        vw2.backgroundColor = Constants.LIGHTER_GRAY_COLOR
        
        titleLabel.font = CustomFont.getfont_MEDIUM(18)
        lblLoanAmtName.font = CustomFont.getfont_REGULAR(16)
        
        btnLoanType.layer.cornerRadius = 23
        btnLoanType.layer.borderWidth = 1
        btnLoanType.layer.borderColor = UIColor.gray.cgColor
        
        topBgView.backgroundColor = Constants.LIGHTER_GRAY_COLOR
        bgView.layer.cornerRadius = 3.0
        bgView.setShadow()
        self.tableView.tableFooterView = UIView()
    }
    
    func setData(item: RateApprovalRecord) {
        lblLoanAmtName.text = "\(item.loanAmount!) • \(item.application.applicant.fullName.uppercased())"
        titleLabel.text = item.application.externalRefNumber
        
        if var rateArray = item.rates, !rateArray.isEmpty  {
            if let chargesArray = item.charges, !chargesArray.isEmpty  {
                for itemCharges in chargesArray {
                    if let inititalRate = itemCharges.initialValue , let code = itemCharges.unitType?.code , let proposedRate = itemCharges.proposedValue {
                        let obj = Rate(type: Type(code: code), initialRate: inititalRate, proposedRate: proposedRate, approvedRate: 0.00, waiverRate: 0.00)
                        rateArray.append(obj)
                    }
                }
            }
            rateCharges = rateArray
            tableView.reloadData()
        }
    }
    
}

extension GridCollectionCell: UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return rateCharges?.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "InterestRateTableViewCell", for: indexPath) as! InterestRateTableViewCell
        
        if let obj = rateCharges?[indexPath.row]  {

                    let calculatedVal: Double = obj.initialRate! - obj.proposedRate!
                    let formattedString = NSMutableAttributedString()
                    if calculatedVal > 0 {
                        formattedString
                            .normal("\(obj.proposedRate!)%\n")
                            .bold("(\(String(format: "%.2f", calculatedVal))%)", color: .red)
                    }
                    else {
                        formattedString
                            .normal("\(obj.proposedRate!)%\n")
                            .bold("(\(String(format: "%.2f", calculatedVal))%) ", color: Constants.GREEN_COLOR)
                    }
                    cell.lblRequestedRate.attributedText = formattedString
                    cell.lblCurrentRate.text = "\(obj.initialRate!)%"
                    cell.lblChargesCode.text = obj.type?.code
                }
        cell.setupView()
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
}
