//
//  RateApproveHomeVC.swift
//  mCAS
//
//  Created by Mac on 21/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


class RateApproveHomeVC: UIViewController {
    
    @IBOutlet weak var gridLayoutView: CustomCollection!
    @IBOutlet weak var btnList: UIButton!
    @IBOutlet weak var btnGrid: UIButton!
    @IBOutlet weak var layoutSwitchView: UIView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var bottomViewHeightConstraints: NSLayoutConstraint!
    @IBOutlet weak var lblNoDataFound: UILabel!
    @IBOutlet weak var selectAllButton: UIButton!
    @IBOutlet weak var layoutContainerView: UIView!
    
    
    @IBOutlet weak var layoutViewHeightConst: NSLayoutConstraint!
    
    private var arBottomView: ApproveRejectBottomView!
    
    var refreshControl: UIRefreshControl!
    var listModelArray = [RateApprovalRecord]()
    var filteredListModelArray = [RateApprovalRecord]()
    var selectedTaskId:[String] = []
    var offset = 0
    var reachedEndOfItems = false

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = Constants.LIGHTER_GRAY_COLOR
        
        tableView.tableFooterView = UIView()
        tableView.register(UINib(nibName: String(describing: ApproverCell.self), bundle: Bundle.main), forCellReuseIdentifier: "ApproverCell")
        
        layoutContainerView.layer.masksToBounds = true
        
        setupView()
    }
    
    private func setupView() {
        arBottomView = .fromNib()
        arBottomView.delegate = self
        arBottomView.frame = CGRect(x: 0, y: self.view.frame.size.height - 80, width: self.view.frame.size.width, height: 80)
        view.addSubview(arBottomView)
        arBottomView.isHidden = true
        
        lblNoDataFound.font = CustomFont.getfont_MEDIUM(19)
        lblNoDataFound.textColor = .lightGray
        
        selectAllButton.titleLabel?.font = CustomFont.getfont_REGULAR(18)
        selectAllButton.addTarget(self, action:#selector(selectAllAction(_:)), for: .touchUpInside)
        
        layoutSwitchView.layer.masksToBounds = true
        layoutSwitchView.layer.cornerRadius = 3
        layoutSwitchView.layer.borderWidth = 1
        layoutSwitchView.layer.borderColor = UIColor.lightGray.cgColor
        
        refreshControl = UIRefreshControl()
        refreshControl.tintColor = .darkGray;
        refreshControl.addTarget(self, action: #selector(refreshList), for: .valueChanged)
        tableView.addSubview(refreshControl)
        
        self.btnList.sendActions(for: .touchUpInside)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let bottomView = AppDelegate.instance()?.bottomTabbarView, let headerView = AppDelegate.instance()?.headerView {
            bottomView.isHidden = true
            
            headerView.delegate = self
            headerView.showHideSearchMikeOption(show: true)
            searchOnOff(isSearching: false)
        }
        
        manageHeaderView()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if let headerView = AppDelegate.instance()?.headerView {
            headerView.setTitleWithShowBackButton(title: "", showBackButton: false)
            headerView.showHideSearchMikeOption(show: false)
        }
    }

    @objc private func selectAllAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        selectedTaskId.removeAll()
        
        if sender.isSelected {
            selectedTaskId  = filteredListModelArray.map({ (item) -> String in
                return item.taskId!
            })
        }
        manageBottomView()
    }
    
    private func manageBottomView() {
        self.tableView.isHidden = self.btnGrid.isSelected
        self.gridLayoutView.isHidden = self.btnList.isSelected || filteredListModelArray.isEmpty
        self.lblNoDataFound.isHidden = !self.filteredListModelArray.isEmpty
        self.arBottomView.setProperties(showEdit: btnGrid.isSelected, showForword: btnGrid.isSelected)
        self.arBottomView.isHidden = ((btnGrid.isSelected && filteredListModelArray.isEmpty) || (btnList.isSelected && selectedTaskId.isEmpty))
        self.selectAllButton.isSelected = (selectedTaskId.count == filteredListModelArray.count)
        
        if btnGrid.isSelected {
            self.gridLayoutView.listArrayModel = self.filteredListModelArray
            self.gridLayoutView.collectionViewReloadData()
        }
        else {
            self.tableView.reloadData()
            self.bottomViewHeightConstraints.constant = selectedTaskId.isEmpty ? 0.0 : 80.0
        }
        
        self.refreshControl.endRefreshing()
        self.manageHeaderView()
    }
    
    private func manageHeaderView() {
        
        if let headerView = AppDelegate.instance()?.headerView {
            if btnList.isSelected, !selectedTaskId.isEmpty {
                selectAllButton.isHidden = false
                headerView.setTitleWithShowBackButton(title: "\(selectedTaskId.count) selected", showBackButton: true)
            }
            else {
                selectAllButton.isHidden = (btnList.isSelected && filteredListModelArray.isEmpty) || btnGrid.isSelected ? true : false
                headerView.setTitleWithShowBackButton(title: "Rate Approval", showBackButton: true)
            }
            
            headerView.showHideSearchMikeOption(show: btnList.isSelected)
        }
    }
    
    @IBAction func btnGridViewClicked(_ sender: UIButton) {
        
        if !btnGrid.isSelected {
            btnGrid.isSelected = true
            btnList.isSelected = false
            btnList.backgroundColor = .clear
            btnGrid.backgroundColor = Constants.BLUE_COLOR
            self.manageBottomView()
        }
    }
    
    @IBAction func btnListViewClicked(_ sender: UIButton) {
        
        if !btnList.isSelected {
            btnList.isSelected = true
            btnGrid.isSelected = false
            btnList.backgroundColor = Constants.BLUE_COLOR
            btnGrid.backgroundColor = .clear
            self.refreshList()
        }
    }
    
    @IBAction func longPressAction(_ sender: UILongPressGestureRecognizer) {
        if sender.state == .began {
            let touchPoint = sender.location(in: tableView)
            if let indexPath = tableView.indexPathForRow(at: touchPoint) {
                let cell: ApproverCell = tableView.cellForRow(at: indexPath) as! ApproverCell
                cell.loanTypeButton.sendActions(for: .touchUpInside)
            }
        }
    }
    
    @objc func refreshList() {
        if FIApplicationUtils.checkForReachabilityMode() {
            offset = 0
            reachedEndOfItems = false
            listModelArray.removeAll()
            filteredListModelArray.removeAll()
            fetchCases()
        }
        else {
            listModelArray.removeAll()
            filteredListModelArray.removeAll()
            selectedTaskId.removeAll()
            manageBottomView()
        }
    }
    
    private func fetchCases() {
        
        guard !reachedEndOfItems else {
            return
        }
        
        let param : [String:[String:Any]] = ["status"   : ["code" : ""],
                                             "stage"    : ["code" : "APPROVAL"],
                                             "pageInfo" : ["requestStartIndex" : offset]]
        
        Webservices.sharedInstance().POST(urlString: ServiceUrl.SEARCH_APPLICATION_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any]
            {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject:response, options:[])
                    let list = try JSONDecoder().decode(RateApproverModel.self, from: jsonData)
                    var recordCount = 0
                    
                    if let records = list.rateApprovalRecords {
                        self.listModelArray.append(contentsOf: records)
                        self.filteredListModelArray = self.listModelArray
                        recordCount = records.count
                        
                        if !self.selectedTaskId.isEmpty {
                            let allTaskIds: [String] = self.filteredListModelArray.map({ $0.taskId! })
                            self.selectedTaskId = allTaskIds.filter(self.selectedTaskId.contains)
                        }
                    }
                    
                    if let pageSize = list.pageInfo?.requestPageSize
                    {
                        if recordCount < pageSize {
                            self.reachedEndOfItems = true
                        }
                        self.offset += pageSize
                    }
                }
                catch { debugPrint(error) }
            }
            
            self.manageBottomView()
                        
        }, failure: { (error) in
            if error == ServiceUrl.ALERT_NO_DATA {
                self.reachedEndOfItems = true
            }
            
            self.manageBottomView()
            
        }, noNetwork: { (error) in
            self.manageBottomView()
        })
    }
}

extension RateApproveHomeVC: ARBottomViewDelegate {
    
    func editCaseAction() {
        let currentIndex = self.gridLayoutView.currentPage
        
        let st = UIStoryboard.init(name: Constants.STORYBOARD_RATE_INITIATE, bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "CaseDetailVC") as! CaseDetailVC
        vc.caseType = .Approval
        vc.caseData = self.filteredListModelArray[currentIndex]
        self.navigationController?.pushViewController(vc, animated: false)
    }
    
    func approveCaseAction() {
        FIApplicationUtils.showAlert(withMessage: "Are you sure want to approve the case", withOkTitle: "Yes", withCancelTitle: "No", withOkAction: { (action) in
            self.approveRejectServiceCall(action: "APPROVE")
        })
    }
    
    func rejectCaseAction() {
        FIApplicationUtils.showAlert(withMessage: "Are you sure want to reject the case", withOkTitle: "Yes", withCancelTitle: "No", withOkAction: { (action) in
            self.approveRejectServiceCall(action: "REJECT")
        })
    }
    
    func forwardCaseAction() {
        let currentIndex = self.gridLayoutView.currentPage

        let popview: PopupView!
        popview = .fromNib()
        popview.viewType = .ForRefer
        popview.setProperties(width: self.view.frame.size.width, height: self.view.frame.size.height)
        popview.setData(item: self.filteredListModelArray[currentIndex])
        self.view.addSubview(popview)
        popview.alpha = 1
    }
    
    private func approveRejectServiceCall(action: String) {
        var bulkApps: [[String : String]] = []
        
        if self.btnList.isSelected {
            bulkApps = self.filteredListModelArray
                .filter { selectedTaskId.contains("\($0.taskId!)") }
                .map { ["taskId" : $0.taskId!, "applicationNumber" : $0.application.externalRefNumber] }
        }
        else {
            let currentIndex = self.gridLayoutView.currentPage
            let item = self.filteredListModelArray[currentIndex]
            bulkApps = [["taskId" : item.taskId!, "applicationNumber" : item.application.externalRefNumber]]
        }
        
        let param : [String:[String:Any]] = ["rateApprovalAction" : ["actionType"       : action,
                                                                     "bulkApplications" : bulkApps]]
        
        Webservices.sharedInstance().POST(urlString: ServiceUrl.BULK_ACTION_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            self.refreshList()
            
        }, failure: { (error) in
            self.refreshList()
            
            if error != nil {
                FIApplicationUtils.showAlert(withTitle: "", andMessage: error)
            }
            
        }, noNetwork: { (error) in
        })
    }
}


extension RateApproveHomeVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.filteredListModelArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: ApproverCell = tableView.dequeueReusableCell(withIdentifier: "ApproverCell") as! ApproverCell
        
        let items = self.filteredListModelArray[indexPath.row]
        cell.label1.text = items.application.applicant.fullName.uppercased()
        cell.label2.text = items.application.externalRefNumber
        cell.label3.text = items.loanAmount!
        
        if let rate = items.rates?[0]  {
            let calculatedVal: Double = rate.initialRate! - rate.proposedRate!
            let formattedString = NSMutableAttributedString()
            if calculatedVal > 0 {
                formattedString
                    .normal("\(items.loanAmount!) • \(rate.type?.code ?? "") \(rate.proposedRate!) ")
                    .bold("(\(String(format: "%.2f", calculatedVal))%) ", color: .red)
            }
            else {
                formattedString
                    .normal("\(items.loanAmount!) • \(rate.type?.code ?? "") \(rate.proposedRate!) ")
                    .bold("(\(String(format: "%.2f", calculatedVal))%) ", color: Constants.GREEN_COLOR)
            }
            cell.label3.attributedText = formattedString
            
        }
        
        if selectedTaskId.contains("\(items.taskId!)") {
            cell.loanTypeButton.isSelected = true
        }
        else {
            cell.loanTypeButton.isSelected = false
        }
        
        cell.loanTypeButton.tag = indexPath.row
        cell.loanTypeButton.addTarget(self, action: #selector(loanButtonTapped), for: .touchUpInside)
        cell.setProperties()
        
        // Check if the last row number is the same as the last current data element
        
        if indexPath.row == self.listModelArray.count - 1 {
            self.fetchCases()
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        //if any row is selected than on single click user can select another
        if !selectedTaskId.isEmpty {
            let cell: ApproverCell = tableView.cellForRow(at: indexPath) as! ApproverCell
            cell.loanTypeButton.sendActions(for: .touchUpInside)
        }
        else {
            if !self.filteredListModelArray.isEmpty {
                let st = UIStoryboard.init(name: Constants.STORYBOARD_RATE_INITIATE, bundle: nil)
                let vc = st.instantiateViewController(withIdentifier: "CaseDetailVC") as! CaseDetailVC
                vc.caseType = .Approval
                vc.caseData = self.filteredListModelArray[indexPath.row]
                self.navigationController?.pushViewController(vc, animated: false)
            }
        }
    }
    
    @objc func loanButtonTapped(sender: UIButton) {
        let index = sender.tag
        let taskID = "\(self.filteredListModelArray[index].taskId!)"
        
        if selectedTaskId.contains(taskID) {
            selectedTaskId = selectedTaskId.filter({ $0 != taskID})
        }
        else {
            selectedTaskId.append(taskID)
        }
        self.manageBottomView()
        selectAllButton.isSelected = (selectedTaskId.count == filteredListModelArray.count)
    }
}


extension RateApproveHomeVC: searchOptionsDelegates {
    
    func searchOnOff(isSearching: Bool) {
        layoutViewHeightConst.constant = isSearching ? 0 : 45
        
        if isSearching {
            refreshControl.removeFromSuperview()
        }
        else {
            handleSearch(text: "")
            tableView.addSubview(refreshControl)
        }
    }
    
    func handleSearch(text : String) {
        
        if !text.isEmpty {
            filteredListModelArray = listModelArray.filter { ($0.application.applicant.fullName.lowercased().contains(text.lowercased())) }
        }
        else {
            filteredListModelArray = listModelArray
        }
        
        tableView.reloadData()
    }
    
}


