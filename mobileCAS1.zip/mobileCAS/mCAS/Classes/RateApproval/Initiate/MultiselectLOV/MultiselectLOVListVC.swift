//
//  MultiselectLOVListVC.swift
//  mCAS
//
//  Created by Mac on 02/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

protocol MultiselectLOVDelegate : class {
    func setRespectiveCodeArray(list : [DropDown], masterType: MASTERTYPE?)
}

class MultiselectLOVListVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var doneButton: UIButton!

    private var lovHeaderView: LOVHeaderView!

    var headerTitle = ""
    var searchOptionArray: [DropDown] = []
    var optionsArray: [DropDown] = []
    var preSelectedArray: [String] = []
    var masterType: MASTERTYPE?
    var delegate: MultiselectLOVDelegate?
    var isMultiSelectionEnabled = true
    
    var offset = 0
    var reachedEndOfItems = false

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        tableView.tableFooterView = UIView()
        
        searchBar.setProperties()

        createHeaderControls()

        if isMultiSelectionEnabled {
            FIApplicationUtils.setButtonProperties(cancelButton)
            FIApplicationUtils.setButtonProperties(doneButton)
            
            cancelButton.backgroundColor = .clear
            cancelButton.layer.borderColor = Constants.BLUE_COLOR.cgColor
            cancelButton.setTitleColor(Constants.BLUE_COLOR, for: .normal)
        }
        else {
            doneButton.isHidden = true
            cancelButton.isHidden = true
        }
        
        if masterType == .Approver || masterType == .Recommender {
            
            if masterType == .Approver {
                offset = CommonData.shared.approverMasterModelArray.count
            }
            else {
                offset = CommonData.shared.recommenderMasterModelArray.count
            }
            
            if offset == 0 { fetchUsersByCriteria() }
            else { lazyLoadTableDataOffline() }
        }
        else if masterType == .Reason {
            self.setTableData()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        lovHeaderView.isHidden = false
        
        if let bottomView = AppDelegate.instance()?.bottomTabbarView {
            bottomView.isHidden = true
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        searchBar.resignFirstResponder()
        lovHeaderView.isHidden = true
    }
    
    private func lazyLoadTableDataOffline() {
        
        MRProgressOverlayView.showOverlayAdded(to: self.view, animated: true)

        var list: [User] = []
        let count = 30

        if masterType == .Approver {
            list = CommonData.shared.approverMasterModelArray
            CommonData.shared.approverMasterModelArray = Array(list[0..<min(count,list.count)])
        }
        else {
            list = CommonData.shared.recommenderMasterModelArray
            CommonData.shared.recommenderMasterModelArray = Array(list[0..<min(count,list.count)])
        }
        setTableData()
        
        if count < list.count {
            //Lazy load table data
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
                guard let self = self else {
                  return
                }
                
                DispatchQueue.main.async {
                    if self.masterType == .Approver {
                        list.removeSubrange(0...count)
                        CommonData.shared.approverMasterModelArray.append(contentsOf: list)
                    }
                    else {
                        list.removeSubrange(0...count)
                        CommonData.shared.recommenderMasterModelArray.append(contentsOf: list)
                    }
                    self.setTableData()
                }
            }
        }
        
        MRProgressOverlayView.dismissOverlay(for: self.view, animated: true)
    }
    
    private func fetchUsersByCriteria() {
        
        guard !reachedEndOfItems && (masterType == .Approver || masterType == .Recommender) else {
            return
        }
        
        var code = ""
        
        if masterType == .Approver {
            code = "MOB_WAIVER_APPROVER"
        }
        else if masterType == .Recommender {
            code = "MOB_WAIVER_RECOMMENDER"
        }
        
        let param = [["role" : code,
                      "pageInfo"  : ["requestPageSize"  : 50,
                                     "requestStartIndex" : offset]
                    ]]
        
        Webservices.sharedInstance().POST(urlString: ServiceUrl.GET_USERS_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let mainObj = responseObj as? [[String : Any]] , let firstObj = mainObj.first {
                
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject:firstObj, options:[])
                    let list = try JSONDecoder().decode(MultiselectLOVUserModel.self, from: jsonData)
                    
                    let masters = list.users ?? []
                    
                    if self.masterType == .Approver {
                        CommonData.shared.approverMasterModelArray.append(contentsOf: masters)
                    }
                    else if self.masterType == .Recommender {
                        CommonData.shared.recommenderMasterModelArray.append(contentsOf: masters)
                    }
                    
                    if let pageInfo = list.pageInfoVO , let pageSize = pageInfo.requestPageSize {
                        if masters.count < pageSize {
                            self.reachedEndOfItems = true
                        }
                        self.offset += pageSize
                    }
                    self.setTableData()
                }
                catch { debugPrint(error) }
            }
            
        }, failure: { (error) in
            
            if error == ServiceUrl.ALERT_NO_DATA {
                self.reachedEndOfItems = true
            }
            
        },
           noNetwork: { (error) in })
    }
    
    @objc private func setTableData() {
           
        if masterType == .Approver || masterType == .Recommender {
            var list: [User] = []
            
            if masterType == .Approver {
                list = CommonData.shared.approverMasterModelArray
            }
            else {
                list = CommonData.shared.recommenderMasterModelArray
            }
            
            if !optionsArray.isEmpty {
                list.removeSubrange(0...optionsArray.count)
            }

            for item in list {
                
                if let code = item.code, let fullName = item.fullName, let userName = AppDelegate.instance()?.getSavedUserID(), code.lowercased() != userName.lowercased() {

                    let dd = DropDown()
                    dd.key = code
                    dd.value = fullName
                    dd.displayValue = "\(fullName) (\(code))"
                    dd.isSelectedFlag = preSelectedArray.contains(code)

                    optionsArray.append(dd)
                }
            }
        }
        else if masterType == .Reason {
            for item in CommonData.shared.reasonMasterArray {
                
                if let code = item["code"], let name = item["name"], let masterType = item["masterType"] {
                    
                    if (masterType == "Waiver Initiation") || (masterType == "Other") {
                        let dd = DropDown()
                        dd.key = code
                        dd.value = name
                        dd.displayValue = name
                        dd.isSelectedFlag = preSelectedArray.contains(code)
                        
                        optionsArray.append(dd)
                    }
                }
            }
        }
        else {
           optionsArray = []
        }
        
        handleSearch(searchBar)
        enableDoneButton()
    }

    private func createHeaderControls() {
        
        if let headerView = AppDelegate.instance()?.headerView {
            lovHeaderView = LOVHeaderView(frame: CGRect(x: 0, y: 0, width: headerView.frame.size.width, height: headerView.frame.size.height))
            headerView.addSubview(lovHeaderView)
            lovHeaderView.closeButton.isHidden = isMultiSelectionEnabled
        }
        
        if let title = masterType?.rawValue {
            headerTitle = title
        }
    }

    @IBAction func cancelButtonAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
    @IBAction func doneButtonAction(_ sender: Any) {
                
        let filteredArray = optionsArray.filter { $0.isSelectedFlag == true }

        delegate?.setRespectiveCodeArray(list: filteredArray, masterType: masterType)
        
        self.navigationController?.popViewController(animated: false)
    }
    
    private func enableDoneButton() {
        let filteredArray = optionsArray.filter { $0.isSelectedFlag == true }

        if filteredArray.isEmpty {
            lovHeaderView.setAttributedTitle(line1: "Select \(headerTitle)(s)", line2: "")
        }
        else {
            lovHeaderView.setAttributedTitle(line1: "Select \(headerTitle)(s)", line2: "\(filteredArray.count) selected")
        }
        
        doneButton.isEnabled = !filteredArray.isEmpty
        FIApplicationUtils.setButtonColorWith(doneButton, enabled:doneButton.isEnabled)
    }
}

extension MultiselectLOVListVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchOptionArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: LOVOptionCell = tableView.dequeueReusableCell(withIdentifier: "LOVOptionCell") as! LOVOptionCell
        cell.setProperties()
        cell.tag = 1000+indexPath.row
        cell.delegate = self
        
        if isMultiSelectionEnabled {
            cell.checkButton.setImage(UIImage(named: "unchecked"), for: .normal)
            cell.checkButton.setImage(UIImage(named: "checked"), for: .selected)
        }
        else {
            cell.checkButton.setImage(UIImage(named: "uncheckedcircle"), for: .normal)
            cell.checkButton.setImage(UIImage(named: "checkedcircle"), for: .selected)
        }
        
        let dic = searchOptionArray[indexPath.row]
        cell.checkButton.isSelected = dic.isSelectedFlag
        cell.titleLabel.text = dic.displayValue

        // Check if the last row number is the same as the last current data element and user is not searching
        if indexPath.row == optionsArray.count - 1, searchBar.text?.count == 0 {
            fetchUsersByCriteria()
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
}

extension MultiselectLOVListVC: LOVOptionCellDelegate {
    
    func buttonSelectAction(tag: NSInteger, btn: UIButton) {
        
        if isMultiSelectionEnabled {
            let searchDic = searchOptionArray[tag-1000]
            searchDic.isSelectedFlag = btn.isSelected
            searchOptionArray[tag-1000] = searchDic
            
            let index = optionsArray.firstIndex {$0.key == searchDic.key}
            
            if let index = index  {
                optionsArray[index] = searchDic
            }
            enableDoneButton()
        }
        else {
            let searchDic = searchOptionArray[tag-1000]
            
            searchOptionArray = searchOptionArray.map { (dic) -> DropDown in
                dic.isSelectedFlag = (dic.key == searchDic.key)
                return dic
            }
            
            optionsArray = optionsArray.map { (dic) -> DropDown in
                dic.isSelectedFlag = (dic.key == searchDic.key)
                return dic
            }
            
            doneButtonAction(doneButton!)
        }
    }
}

extension MultiselectLOVListVC: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        handleSearch(searchBar)
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        handleSearch(searchBar)
    }
    
    //on keyboard clear button this method is called
    func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool {
        handleSearch(searchBar)
        return true
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        searchBar.resignFirstResponder()
        handleSearch(searchBar)
    }
    
    func handleSearch(_ searchBar : UISearchBar) {

        if let text = searchBar.text, text.count > 0 {
            searchOptionArray = optionsArray.filter { ($0.displayValue.lowercased().contains(text.lowercased())) }
        }
        else {
            searchOptionArray = optionsArray
        }
        
        tableView.reloadData()
    }
}
