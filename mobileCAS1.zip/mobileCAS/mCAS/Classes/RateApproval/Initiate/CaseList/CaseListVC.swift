//
//  CaseListVC.swift
//  mCAS
//
//  Created by Mac on 26/08/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


class CaseListVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var lblNoDataFound: UILabel!
    
    var listArrayModel = [RateApprovalRecord]()
    var filteredListArrayModel = [RateApprovalRecord]()
    var isServiceCalled: Bool = false
    var refreshControl: UIRefreshControl!
    
    var offset = 0
    var reachedEndOfItems = false
    var caseType: CASETYPE?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = caseType?.rawValue
        
        self.view.backgroundColor = Constants.LIGHTER_GRAY_COLOR
        tableView.tableFooterView = UIView()
        tableView.register(UINib.init(nibName: "CasesCell", bundle: Bundle.main), forCellReuseIdentifier: "CasesCell")
        tableView.alwaysBounceVertical = true
        
        refreshControl = UIRefreshControl()
        refreshControl.tintColor = .darkGray;
        refreshControl.addTarget(self, action: #selector(refreshList), for: .valueChanged)
        tableView.addSubview(refreshControl)
        
        lblNoDataFound.font = CustomFont.getfont_MEDIUM(19)
        lblNoDataFound.textColor = .lightGray
    }
    
    @objc func refreshList() {
        offset = 0
        reachedEndOfItems = false
        listArrayModel.removeAll()
        fetchCases()
    }
    
    func fetchCases() {
        
        guard !reachedEndOfItems else {
            return
        }
        
        var code = ""
        
        switch caseType {
        case .Initiated:    code = "IN PROGRESS"
        case .Approved:     code = "APPROVE"
        case .Rejected:     code = "REJECT"
        case .Cancelled:    code = "CANCEL"
        default:            code = "NOT INITIATED"
        }
        
        let param : [String:[String:Any]] = ["status"   : ["code" : code],
                                             "stage"    : ["code" : "INITIATION"],
                                             "pageInfo" : ["requestStartIndex" : offset]]
        
        Webservices.sharedInstance().POST(urlString: ServiceUrl.SEARCH_APPLICATION_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any]
            {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject:response, options:[])
                    let list = try JSONDecoder().decode(RateApproverModel.self, from: jsonData)
                    var recordCount = 0
                    
                    if let records = list.rateApprovalRecords {
                        self.listArrayModel.append(contentsOf: records)
                        self.filteredListArrayModel = self.listArrayModel
                        recordCount = records.count
                    }
                    
                    if let pageSize = list.pageInfo?.requestPageSize
                    {
                        if recordCount < pageSize {
                            self.reachedEndOfItems = true
                        }
                        self.offset += pageSize
                    }
                    
                    if recordCount > 0 {
                        self.tableView.reloadData()
                    }
                }
                catch { debugPrint(error) }
            }
            
            self.isServiceCalled = true
            self.refreshControl.endRefreshing()
            self.lblNoDataFound.isHidden = !self.listArrayModel.isEmpty
            
        }, failure: { (error) in
            
            self.isServiceCalled = true
            self.refreshControl.endRefreshing()
            self.lblNoDataFound.isHidden = !self.listArrayModel.isEmpty
            
            if error == ServiceUrl.ALERT_NO_DATA {
                self.reachedEndOfItems = true
            }
            
        }, noNetwork: { (error) in
            
            self.refreshControl.endRefreshing()
            self.lblNoDataFound.isHidden = !self.listArrayModel.isEmpty
            
        })
    }
    
    func handleSearch(searchTxt: String) {
        
        if !searchTxt.isEmpty {
            filteredListArrayModel = listArrayModel.filter{ ($0.application.applicant.fullName.lowercased().contains(searchTxt.lowercased())) }
        }
        else {
            filteredListArrayModel = listArrayModel
        }
        
        tableView.reloadData()
    }
}

extension CaseListVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.filteredListArrayModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: CasesCell = tableView.dequeueReusableCell(withIdentifier: "CasesCell") as! CasesCell
        
        if !self.filteredListArrayModel.isEmpty
        {
            let record = self.filteredListArrayModel[indexPath.row]
            
            cell.label1.text = record.application.applicant.fullName.uppercased()
            cell.label2.text = record.application.externalRefNumber
            cell.label3.text = record.loanAmount!
            
            if let productType = record.application.loanDetail?.productType?.code {
                cell.loanTypeLabel.text = productType
                
                if productType == "Consumer Vehicle" {
                    cell.imgView.image = UIImage(named: "auto_loan_icon")
                }
                else {
                    cell.imgView.image = UIImage(named: "personal_loan_icon")
                }
            }
        }
        cell.arrowIcon.isHidden = false
        cell.optionButton.isHidden = true
        cell.setProperties()
        
        // Check if the last row number is the same as the last current data element
        if indexPath.row == self.listArrayModel.count - 1 {
            self.fetchCases()
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        if !self.filteredListArrayModel.isEmpty {
            let st = UIStoryboard.init(name: Constants.STORYBOARD_RATE_INITIATE, bundle: nil)
            let vc = st.instantiateViewController(withIdentifier: "CaseDetailVC") as! CaseDetailVC
            vc.caseType = self.caseType
            vc.caseData = self.filteredListArrayModel[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
}
