//
//  AppDetailsListView.swift
//  mCAS
//
//  Created by Mac on 29/08/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

protocol AppDetailsListViewDelegate : class {
    func pullableViewStateChange(opened: Bool)
}


class AppDetailsListView: PullableView {

    let SECTION_APPLICATION = "SECTION_APPLICATION"
    let SECTION_APPLICANT = "SECTION_APPLICANT"
    let SECTION_SALES = "SECTION_SALES"
    let SECTION_ASSET = "SECTION_ASSET"
    
    let KEY = "KEY"
    let VALUE = "VALUE"


    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var arrowImageView: UIImageView!
    var appDtldelegate: AppDetailsListViewDelegate?

    var tableSectionArray: [MenuModel] = []
    var applicationDetailArray: [[String : String]] = []
    var applicantDetailArray: [[String : String]] = []
    var salesDetailArray: [[String : String]] = []
    var assetDetailArray: [[String : String]] = []
    var caseDetail: RateApprovalRecord!

    func setProperties(width: CGFloat, height: CGFloat) {
        self.frame = CGRect(x: 0, y: 0, width: width, height: height)
        self.backgroundColor = Constants.LIGHTER_GRAY_COLOR
         
        //PullableView settings
        self.initializeView(self.frame)
        self.openedCenter = CGPoint(x: width/2, y: height/2)
        self.closedCenter = CGPoint(x: width/2, y: -130)
        self.center = self.closedCenter
        self.delegate = self

        tableView.tableFooterView = UIView()
        tableView.register(UINib.init(nibName: "KeyValueCell", bundle: Bundle.main), forCellReuseIdentifier: "KeyValueCell")
        
        tableSectionArray.append(MenuModel(title: "Application Details", menuID: SECTION_APPLICATION))
        tableSectionArray.append(MenuModel(title: "Applicant Details", menuID: SECTION_APPLICANT))
//        tableSectionArray.append(MenuModel(title: "Sales Details", menuID: SECTION_SALES))
//        tableSectionArray.append(MenuModel(title: "Asset Details", menuID: SECTION_ASSET))

        setUpApplicationDetailsSection()
        setUpApplicantDetailsSection()
        setUpSalesDetailsSection()
        setUpAssetDetailsSection()

        DispatchQueue.main.async(execute: { () -> Void in
            self.tableView.reloadData()
        })
    }
    
    func setUpApplicationDetailsSection() {
        applicationDetailArray.append([KEY : "Application Number", VALUE : caseDetail.application.externalRefNumber])
        applicationDetailArray.append([KEY : "Product", VALUE : caseDetail.application.loanDetail?.product?.code ?? ""])
        applicationDetailArray.append([KEY : "Product Category", VALUE : caseDetail.application.loanDetail?.productType?.code ?? ""])
        applicationDetailArray.append([KEY : "Scheme", VALUE : caseDetail.application.loanDetail?.scheme?.code ?? ""])
        applicationDetailArray.append([KEY : "Loan Amount", VALUE : caseDetail.loanAmount!])
    }
    
    func setUpApplicantDetailsSection() {
        applicantDetailArray.append([KEY : "Customer Name", VALUE : caseDetail.application.applicant.fullName])
    }
    
    func setUpSalesDetailsSection() {
        salesDetailArray.append([KEY : "Relationship Manager", VALUE : caseDetail.application.relationshipManager?.code ?? ""])
    }
    
    func setUpAssetDetailsSection() {
        assetDetailArray.append([KEY : "Manufacturer", VALUE : "Honda Automobiles"])
        assetDetailArray.append([KEY : "Model", VALUE : "Honda Civic VXT"])

    }
}


extension AppDetailsListView: PullableViewDelegate {
    func pullableView(_ pView: PullableView!, didChangeState opened: Bool) {
        if opened {
            arrowImageView.image = UIImage(named: "list_arrow_up")
        }
        else {
            arrowImageView.image = UIImage(named: "list_arrow_down")
        }
        
        self.appDtldelegate?.pullableViewStateChange(opened: opened)
    }
}

extension AppDetailsListView: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return tableSectionArray.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let menu: MenuModel = tableSectionArray[section]
        
        if(menu.menuID == SECTION_APPLICATION) {
            return applicationDetailArray.count
        }
        else if(menu.menuID == SECTION_APPLICANT) {
            return applicantDetailArray.count
        }
        else if(menu.menuID == SECTION_SALES) {
            return salesDetailArray.count
        }
        else if(menu.menuID == SECTION_ASSET) {
            return assetDetailArray.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: KeyValueCell = tableView.dequeueReusableCell(withIdentifier: "KeyValueCell") as! KeyValueCell
        cell.backgroundColor = .clear
        cell.contentView.backgroundColor = .clear

        cell.keyLabel.textColor = .gray
        cell.valueLabel.textColor = .black

        cell.keyLabel.font = CustomFont.getfont_REGULAR(15)
        cell.valueLabel.font = CustomFont.getfont_REGULAR(15)
        
        let menu: MenuModel = tableSectionArray[indexPath.section]
        var dic: [String : String] = [:]
        
        if(menu.menuID == SECTION_APPLICATION) {
            dic = applicationDetailArray[indexPath.row]
        }
        else if(menu.menuID == SECTION_APPLICANT) {
            dic = applicantDetailArray[indexPath.row]
        }
        else if(menu.menuID == SECTION_SALES) {
            dic = salesDetailArray[indexPath.row]
        }
        else if(menu.menuID == SECTION_ASSET) {
            dic = assetDetailArray[indexPath.row]
        }
        
        cell.keyLabel.text = dic[KEY]
        cell.valueLabel.text = dic[VALUE]

        return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let menu: MenuModel = tableSectionArray[section]
        return menu.title
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        if let header = view as? UITableViewHeaderFooterView {

            header.textLabel?.font = CustomFont.getfont_MEDIUM(18)
            
            //set properties as we are using grouped table(to scroll section with rows) so that the title will not be shown in uppercase by default
            header.textLabel?.textColor = .black
            header.textLabel?.text = self.tableView(tableView, titleForHeaderInSection: section)

            if section != 0 {
                let line = UILabel(frame: CGRect(x: 0, y: 0, width: header.frame.size.width, height: 0.5))
                line.tag = 101
                line.backgroundColor = .lightGray
                header.addSubview(line)
            }
            else {
                if let line = header.viewWithTag(101) {
                    line.removeFromSuperview()
                }
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 35
    }
    
}
