//
//  CaseDetailCell.swift
//  mCAS
//
//  Created by Mac on 07/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation

class CaseDetailCell: UICollectionViewCell {

    @IBOutlet weak var keyLabel: UILabel!
    @IBOutlet weak var valueLabel: UILabel!

}
