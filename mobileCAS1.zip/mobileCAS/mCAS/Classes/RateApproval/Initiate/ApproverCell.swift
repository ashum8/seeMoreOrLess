//
//  ApproverCell.swift
//  mCAS
//
//  Created by Mac on 06/09/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class ApproverCell: UITableViewCell {
    
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label3: UILabel!
    @IBOutlet weak var loanTypeButton: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    @objc func setProperties() {
        self.contentView.backgroundColor = .clear
        self.backgroundColor = .clear
        
        bgView.layer.cornerRadius = 3.0
        bgView.setShadow()
        
        label1.font = CustomFont.getfont_MEDIUM(19)
        label2.font = CustomFont.getfont_REGULAR(16)
        label3.font = CustomFont.getfont_REGULAR(16)
        
        loanTypeButton.layer.cornerRadius = 23
        loanTypeButton.layer.borderWidth = 1
        loanTypeButton.layer.borderColor = UIColor.gray.cgColor
    }
    
    @IBAction func loanTypeButtonAction(_ sender: UIButton) {
        
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationTransition(UIView.AnimationTransition.flipFromLeft, for: sender, cache: true)
        sender.isSelected = !sender.isSelected
        UIView.commitAnimations()
    }

}
