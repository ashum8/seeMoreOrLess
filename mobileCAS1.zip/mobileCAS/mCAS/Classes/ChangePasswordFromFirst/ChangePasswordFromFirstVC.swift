//
//  ChangePasswordFromFirstVC.swift
//  mCAS
//
//  Created by iMac on 06/12/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class ChangePasswordFromFirstVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

}
