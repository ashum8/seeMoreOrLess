//
//  ResetPasswordVC.swift
//  mCollect
//
//  Created by Mac on 24/06/19.
//  Copyright © 2019 Mac. All rights reserved.
//

import UIKit

class ResetPasswordVC: UIViewController {

    @IBOutlet weak var staticLavel1: UILabel!
    @IBOutlet weak var staticLavel2: UILabel!

    @IBOutlet weak var userNameTextField: JVFloatLabeledTextField!
    @IBOutlet weak var userNameView: UIView!
    @IBOutlet weak var resetButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        self.navigationController?.navigationBar.isHidden = true
        
        setProperties()
    }
    
    private func setProperties() {
        
        staticLavel1.font = CustomFont.getfont_MEDIUM(24)
        staticLavel2.font = CustomFont.getfont_REGULAR(16)
        
        staticLavel2.text = "Please enter user name below, we'll send \(OTP_LENGTH)-digit OTP to mobile number registered with this user name."

        userNameTextField.autocapitalizationType = .allCharacters
        
        //set color of username view
        FIApplicationUtils.setTextFieldViewProperties(userNameView)
        
        FIApplicationUtils.setButtonProperties(resetButton)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        userNameTextField.text = ""
//        userNameTextField.text = "SHLOK1"
        
        if let userName = userNameTextField.text {
            setButtonColoring(userName: userName)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       
        if segue.identifier == "VerifyOTPVC" {
            if let controller = segue.destination as? VerifyOTPVC {
                controller.userID = sender as? String
            }
        }
    }
    
    @IBAction func resetButtonClicked(_ sender: Any) {
        let userName = userNameTextField.text! as String
        
        if(userName.isEmpty()) {
            FIApplicationUtils.showAlert(withTitle: "", andMessage: NSLocalizedString("Please enter username", comment: ""))
        }
        else {
            self.view.endEditing(true)
            resetPasswordFromServerWith(userName: userName)
        }
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func resetPasswordFromServerWith(userName: String) {
        
        let param : [String:String] = ["userId" : userName]
        
        Webservices.sharedInstance().POST(urlString: ServiceUrl.RESET_PASSWORD_GET_OTP_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            self.performSegue(withIdentifier: "VerifyOTPVC", sender: nil)

        }, failure: { (error) in
            if error != nil {
                FIApplicationUtils.showAlert(withTitle: "", andMessage: error)
            }
            
        }, noNetwork: { (error) in })
    }
    
    func setButtonColoring(userName: String) {
        
        var isEnabled: Bool = true
        if (userName.isEmpty()) {
            isEnabled = false
        }
        FIApplicationUtils.setButtonColorWith(resetButton, enabled:isEnabled)
    }
}



extension ResetPasswordVC: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == userNameTextField {
            userNameView.layer.borderColor = Constants.BLUE_COLOR.cgColor
        }
        
        self.setButtonColoring(userName: "")
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
                
        if textField == userNameTextField {
            userNameView.layer.borderColor = UIColor.lightGray.cgColor
        }
        
        if let userName = userNameTextField.text {
            setButtonColoring(userName: userName)
        }
        
        return true
    }
}
