//
//  NewPasswordVC.swift
//  mCollect
//
//  Created by Mac on 24/06/19.
//  Copyright © 2019 Mac. All rights reserved.
//

import UIKit

class NewPasswordVC: UIViewController {

    @IBOutlet weak var staticLavel1: UILabel!
    @IBOutlet weak var staticLavel2: UILabel!
    
    @IBOutlet weak var nwPasswordView: UIView!
    @IBOutlet weak var confirmPasswordView: UIView!
    
    @IBOutlet weak var nwPasswordTextField: JVFloatLabeledTextField!
    @IBOutlet weak var confirmPasswordTextField: JVFloatLabeledTextField!
    @IBOutlet weak var saveButton: UIButton!
    
    var userID: String?
    var resetToken: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        setProperties()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let field1 = nwPasswordTextField.text! as String
        let field2 = confirmPasswordTextField.text! as String
        
        self.setButtonColoring(field1: field1, field2:field2)
    }
    
    private func setProperties() {
        
        staticLavel1.font = CustomFont.getfont_MEDIUM(24)
        staticLavel2.font = CustomFont.getfont_REGULAR(16)
        
        //set color of textfield view
        FIApplicationUtils.setTextFieldViewProperties(nwPasswordView)
        FIApplicationUtils.setTextFieldViewProperties(confirmPasswordView)

        FIApplicationUtils.setButtonProperties(saveButton)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches ,with: event)
        self.view.endEditing(true)
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func saveButtonAction(_ sender: Any) {
        
        let nwPassword = nwPasswordTextField.text! as String
        let confirmPassword = confirmPasswordTextField.text! as String
        
        if nwPassword == confirmPassword {
            createTokenFromServerWith(password: nwPassword)
        }
        else {
            FIApplicationUtils.showAlert(withTitle: "", andMessage: "Password does not match")
        }
    }
    
    func setButtonColoring(field1: String, field2: String) {
        
        var isEnabled: Bool = true
        if (field1.isEmpty() || field2.isEmpty() || field1 != field2) {
            isEnabled = false
        }
        FIApplicationUtils.setButtonColorWith(saveButton, enabled:isEnabled)
    }
    
    func resetPasswordWith(securityToken : String, password : String) {
        
        let passwordOne = Cipher.sha256(userID! + password + securityToken)
        let checkSumSHA256 = Cipher.sha256(userID! + resetToken! + passwordOne + securityToken)
        
        let param : [String:String] = ["userId"       : userID!,
                                       "passwordOne"  : passwordOne,
                                       "resetToken"   : resetToken!,
                                       "userDetails"  : checkSumSHA256]
        
        Webservices.sharedInstance().POST(urlString: ServiceUrl.RESET_PASSWORD_URL, paramaters: param, success: { (header ,responseObj) in
            
            MRProgressOverlayView.dismissAllOverlays(for: self.view, animated: true)
            self.performSegue(withIdentifier: "NewPasswordVC", sender: nil)
            
        }, failure: { (error) in
            MRProgressOverlayView.dismissAllOverlays(for: self.view, animated: true)
            if error != nil {
                FIApplicationUtils.showAlert(withTitle: "", andMessage: error)
            }
            
        }, noNetwork: { (error) in
            MRProgressOverlayView.dismissAllOverlays(for: self.view, animated: true)
            
        })
    }
    
    func createTokenFromServerWith(password : String) {
        
        MRProgressOverlayView.showOverlayAdded(to: self.view, animated: true)

        Webservices.sharedInstance().getTokenFromServer(withSession: false) { (token) in
            if let token = token {
                self.resetPasswordWith(securityToken: token, password: password)
            }
            else {
                MRProgressOverlayView.dismissAllOverlays(for: self.view, animated: true)
            }
        }
    }
}


extension NewPasswordVC: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == nwPasswordTextField {
            nwPasswordView.layer.borderColor = Constants.BLUE_COLOR.cgColor
        }
        else {
            confirmPasswordView.layer.borderColor = Constants.BLUE_COLOR.cgColor
        }
        
        self.setButtonColoring(field1: "", field2: "")
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        let field1 = nwPasswordTextField.text! as String
        let field2 = confirmPasswordTextField.text! as String

        if textField == nwPasswordTextField {
            nwPasswordView.layer.borderColor = UIColor.lightGray.cgColor
        }
        else {
            confirmPasswordView.layer.borderColor = UIColor.lightGray.cgColor
        }
        
        self.setButtonColoring(field1: field1, field2:field2)
        
        return true
    }
}
