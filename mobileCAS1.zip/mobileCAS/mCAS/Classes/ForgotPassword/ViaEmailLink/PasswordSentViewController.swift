//
//  PasswordSentViewController.swift
//  mCAS
//
//  Created by Mac on 18/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class PasswordSentViewController: UIViewController {

    @IBOutlet weak var staticLavel1: UILabel!
    @IBOutlet weak var staticLavel2: UILabel!
    @IBOutlet weak var staticLavel3: UILabel!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var iconView: UIImageView!

    var fromChangePassword: Bool!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true

        // Do any additional setup after loading the view.
        setProperties()
        
        if fromChangePassword {
            staticLavel1.text = "Password Changed Successfully!"
            staticLavel2.text = "You have been logged out of the application.\nPlease login again."
            staticLavel3.text = ""
            
            iconView.image = UIImage(named: "tick_success")
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance()?.headerView {
            headerView.isHidden = true
        }
    }
    
    private func setProperties() {
        
        staticLavel1.font = CustomFont.getfont_MEDIUM(24)
        staticLavel2.font = CustomFont.getfont_REGULAR(16)
        staticLavel3.font = CustomFont.getfont_REGULAR(16)

        FIApplicationUtils.setButtonProperties(loginButton)
    }
    
    @IBAction func loginButtonClicked(_ sender: Any) {
        AppDelegate.instance().presentLoginViewController()
    }
    
}
