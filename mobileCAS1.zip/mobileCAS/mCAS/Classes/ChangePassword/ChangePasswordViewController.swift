//
//  ChangePasswordViewController.swift
//  mCAS
//
//  Created by Mac on 17/07/18.
//  Copyright © 2018 Nucleus. All rights reserved.
//

import UIKit

class ChangePasswordViewController: UIViewController {

    @IBOutlet weak var staticLavel1: UILabel!
    @IBOutlet weak var staticLavel2: UILabel!

    @IBOutlet weak var oldPasswordTextField: JVFloatLabeledTextField!
    @IBOutlet weak var nwPasswordTextField: JVFloatLabeledTextField!
    @IBOutlet weak var confirmPasswordTextField: JVFloatLabeledTextField!
    
    @IBOutlet weak var saveButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        staticLavel1.font = CustomFont.getfont_MEDIUM(24)
        staticLavel2.font = CustomFont.getfont_REGULAR(16)

        oldPasswordTextField.font = CustomFont.getfont_REGULAR(17)
        nwPasswordTextField.font = CustomFont.getfont_REGULAR(17)
        confirmPasswordTextField.font = CustomFont.getfont_REGULAR(17)

        FIApplicationUtils.setButtonProperties(saveButton)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance()?.headerView, let bottomView = AppDelegate.instance()?.bottomTabbarView {
            bottomView.isHidden = true
            headerView.setTitleWithShowBackButton(title: "Change Password", showBackButton: true)
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "PasswordSentViewController" {
            if let controller = segue.destination as? PasswordSentViewController {
                controller.fromChangePassword = true
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches ,with: event)
        self.view.endEditing(true)
    }
    
    @IBAction func saveButtonAction(_ sender: Any) {
        
        if(FIApplicationUtils.checkForReachabilityMode()) {            
            let oldPassword = oldPasswordTextField.text! as String
            let nwPassword = nwPasswordTextField.text! as String
            let confirmPassword = confirmPasswordTextField.text! as String
            
            if oldPassword.isEmpty() {
                FIApplicationUtils.showAlert(withTitle:"", andMessage: "Please enter old password")
                return
            }
            
            let username: String = (AppDelegate.instance()?.getSavedUserID())!
            let predicate = NSPredicate(format: "%K = %@",CDUserDetailsAttributes.username(), username)
            let entityName = String(describing: CDUserDetails.self)
            
            CoreDataOperations.sharedInstance().fetchSingleRecord(predicate: predicate, entityName: entityName, success: { (record) in
                
                if let userData = record as? CDUserDetails, let token = userData.token {
                    let encryptedPassword = Cipher.encrypt(oldPassword, withToken: token)

                    if userData.encryptedpassword != encryptedPassword {
                        FIApplicationUtils.showAlert(withTitle:"", andMessage: "Invalid old password")
                    }
                    else if nwPassword.isEmpty() {
                        FIApplicationUtils.showAlert(withTitle:"", andMessage: "Please enter new password")
                    }
                    else if nwPassword == oldPassword {
                        FIApplicationUtils.showAlert(withTitle:"", andMessage: "New password and old password can not be same")
                    }
                    else if confirmPassword.isEmpty() {
                        FIApplicationUtils.showAlert(withTitle:"", andMessage: "Please enter confirm new password")
                    }
                    else if nwPassword != confirmPassword {
                        FIApplicationUtils.showAlert(withTitle:"", andMessage: "New password and confirm new password do not match")
                    }
                    else {
                        self.getTokenService()
                    }
                }
                else {
                    FIApplicationUtils.showAlert(withTitle: "", andMessage: NSLocalizedString("Please login again to change password", comment: ""))
                }
            })
        }
    }
    
    func getTokenService()  {
        
        MRProgressOverlayView.showOverlayAdded(to: self.view, animated: true)

        Webservices.sharedInstance().getTokenFromServer(withSession: true) { (token) in
            if let token = token {
                self.callChangePasswordService(token: token)
            }
            else {
                MRProgressOverlayView.dismissAllOverlays(for: self.view, animated: true)
            }
        }
    }

    func callChangePasswordService(token: String) {
        
        let oldPassword = oldPasswordTextField.text! as String
        let nwPassword = nwPasswordTextField.text! as String
        
        let encryptedPassword = Cipher.encrypt(oldPassword, withToken: token)
        let encryptednwPassword = Cipher.encrypt(nwPassword, withToken: token)
        let username: String = (AppDelegate.instance()?.getSavedUserID())!

        let param : [String:String] = ["username"       : username,
                                       "oldPassword"    : encryptedPassword,
                                       "password"       : encryptednwPassword]
        
        Webservices.sharedInstance().POST(urlString: ServiceUrl.CHANGE_PASSWORD_URL, paramaters: param, success: { (header ,responseObj) in
                        
            Webservices.sharedInstance().logoutFromServer(username: username) { (success) in }
            self.updateOfflineData(token: token, encryptedPassword: encryptednwPassword)

            MRProgressOverlayView.dismissAllOverlays(for: self.view, animated: true)

            self.performSegue(withIdentifier: "PasswordSentViewController", sender: nil)
            
        }, failure: { (error) in
            MRProgressOverlayView.dismissAllOverlays(for: self.view, animated: true)
            if error != nil {
                FIApplicationUtils.showAlert(withTitle: "", andMessage: error)
            }
            
        }, noNetwork: { (error) in
            MRProgressOverlayView.dismissAllOverlays(for: self.view, animated: true)
            
        })
    }
    
    func updateOfflineData(token: String, encryptedPassword: String) {
        let username: String = (AppDelegate.instance()?.getSavedUserID())!
        let predicate = NSPredicate(format: "%K = %@",CDUserDetailsAttributes.username(), username)
        let entityName = String(describing: CDUserDetails.self)
        
        //update old password and token for offline login
        CoreDataOperations.sharedInstance().updateRecord(predicate: predicate, entityName: entityName, success: { (record) in
            
            if let userData = record as? CDUserDetails, let context = AppDelegate.instance()?.managedObjectContext {
                                
                userData.encryptedpassword = encryptedPassword
                userData.token = token
                
                do { try context.save() }
                catch { }
            }
        })
    }
}
