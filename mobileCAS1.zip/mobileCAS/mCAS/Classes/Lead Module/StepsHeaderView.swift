//
//  StepsHeaderView.swift
//  mCAS
//
//  Created by iss on 26/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


class StepsHeaderView: UIView {
    private var titleLabel: UILabel!

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let height = self.frame.size.height-20
        let view: UIView = UIView(frame: CGRect(x: 0, y: 20, width: self.frame.size.width, height: height))
        view.backgroundColor = .clear
        self.addSubview(view)
        
        let margin: CGFloat = 5
        
        let arrowButton = UIButton(frame: CGRect(x: margin, y: 0, width: height, height: height))
        arrowButton.setImage(UIImage(named: "down_arrow_white_icon"), for: .normal)
        arrowButton.addTarget(self, action:#selector(arrowButtonAction(_:)), for: .touchUpInside)
        view.addSubview(arrowButton)
        
        let closeButton = UIButton(frame: CGRect(x:  self.frame.size.width - (height+margin), y: 0, width: height, height: height))
        closeButton.setImage(UIImage(named: "close_white_icon"), for: .normal)
        closeButton.addTarget(self, action:#selector(closeButtonAction(_:)), for: .touchUpInside)
        view.addSubview(closeButton)
        
        let xCord = arrowButton.frame.origin.x+arrowButton.frame.size.width+10
        
        titleLabel = UILabel(frame: CGRect(x: xCord, y: 0, width: closeButton.frame.origin.x-xCord-margin, height: height))
        titleLabel.font = CustomFont.getfont_REGULAR(19)
        titleLabel.textColor = .white
        view.addSubview(titleLabel)
    }
    
    func setTitleAndStep(title: String, step: String) {
        
        let text = title + " " + step
        let range = (text as NSString).range(of: step, options: .caseInsensitive)

        let myMutableString = NSMutableAttributedString(string: text)
        myMutableString.addAttribute(NSAttributedString.Key.font, value: CustomFont.getfont_REGULAR(13) as UIFont, range: range)
        myMutableString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor(red: 157.0/255.0, green: 201.0/255.0, blue: 241.0/255.0, alpha: 1.0), range: range)
        titleLabel.attributedText = myMutableString

    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func arrowButtonAction(_ sender: UIButton) {
        
    }

    @objc private func closeButtonAction(_ sender: UIButton) {
        self.removeFromSuperview()
        AppDelegate.instance().applicationNavController.popViewController(animated: false)
    }

}
