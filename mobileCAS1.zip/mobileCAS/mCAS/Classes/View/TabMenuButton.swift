//
//  TabMenuButton.swift
//  mCAS
//
//  Created by Mac on 20/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


@objc protocol TabMenuButtonDelegate : class {
    func changeTabButtonSelection(selectedButton: TabMenuButton)
}


class TabMenuButton: UIButton {

    var btnModel: ButtonModel!
    weak var delegate: TabMenuButtonDelegate?

    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    init(frame: CGRect, btnModel: ButtonModel, delegate: TabMenuButtonDelegate) {
        // set other operations after super.init, if required
        super.init(frame: frame)
        
        self.btnModel = btnModel
        self.delegate = delegate

//        self.setImage(image1?.maskWithColor(color: Constant.getGreenColor()), for: .selected)
        self.setImage(UIImage(named: btnModel.activeIcon), for: .selected)
        self.setImage(UIImage(named: btnModel.buttonImage), for: .normal)
        self.setTitle(btnModel.buttonText, for: .normal)
        self.titleLabel?.font = CustomFont.getfont_MEDIUM(13)
        self.setTitleColor(.black, for: .normal)
        self.setTitleColor(Constants.GREEN_COLOR, for: .selected)
        self.addTarget(self, action:#selector(tabsButtonAction(_:)), for: .touchUpInside)
        FIApplicationUtils.setAlignmentOf(self, isTabButton: true)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        // set other operations after super.init if required
    }

    @objc func tabsButtonAction(_ sender: TabMenuButton) {

        if (!sender.isSelected) {
            self.delegate?.changeTabButtonSelection(selectedButton: sender)
            
            if AppDelegate.instance() != nil {
                AppDelegate.instance()?.tabsButtonAction(withTabID: btnModel.buttonID)
            }
        }
    }
}
