//
//  ImageExtension.swift
//  mCAS
//
//  Created by Mac on 21/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation

extension UIView {
    class func fromNib<T: UIView>() -> T {
        return Bundle.main.loadNibNamed(String(describing: T.self), owner: nil, options: nil)![0] as! T
    }
    
    func fixInView(_ container: UIView!) -> Void {
        self.translatesAutoresizingMaskIntoConstraints = false;
        self.frame = container.frame;
        container.addSubview(self);
        NSLayoutConstraint(item: self, attribute: .leading, relatedBy: .equal, toItem: container, attribute: .leading, multiplier: 1.0, constant: 0).isActive = true
        NSLayoutConstraint(item: self, attribute: .trailing, relatedBy: .equal, toItem: container, attribute: .trailing, multiplier: 1.0, constant: 0).isActive = true
        NSLayoutConstraint(item: self, attribute: .top, relatedBy: .equal, toItem: container, attribute: .top, multiplier: 1.0, constant: 0).isActive = true
        NSLayoutConstraint(item: self, attribute: .bottom, relatedBy: .equal, toItem: container, attribute: .bottom, multiplier: 1.0, constant: 0).isActive = true
    }
    
    func fadeInOut(duration: TimeInterval = 0.45, alpha: CGFloat) {
        UIView.animate(withDuration: duration, animations: {
            self.alpha = alpha
        })
    }
    
    func setShadow() {
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOpacity = 0.5
        self.layer.shadowRadius = 3
        self.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
    }
    
    func setMainViewProperties() {
        self.layer.cornerRadius = 2
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor.lightGray.cgColor
    }
}

extension UISearchBar {
    
    func setProperties() {
        let textFieldInsideUISearchBar = self.value(forKey: "searchField") as? UITextField
        textFieldInsideUISearchBar?.font = CustomFont.getfont_REGULAR(19)
//        textFieldInsideUISearchBar?.leftViewMode = .never
        
        let textFieldInsideUISearchBarLabel = textFieldInsideUISearchBar!.value(forKey: "placeholderLabel") as? UILabel
        textFieldInsideUISearchBarLabel?.font = CustomFont.getfont_REGULAR(17)
    }
}

extension UITextView {
    
    func setRemarksTextView() {
        self.textColor = .darkGray
        self.font = CustomFont.getfont_REGULAR(20)
    }
}

extension UIButton {
    
    func setButtonShadow() {
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOpacity = 0.5
        self.layer.shadowRadius = 3
        self.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
    }
}

extension UILabel {

    func setMultiSelectLOVLabelProperties() {
        self.textColor = .darkGray
        self.font = CustomFont.getfont_REGULAR(20)
    }
    
    func setRemarks(title: String) {
        self.text = title
        self.textColor = .darkGray
        self.font = CustomFont.getfont_REGULAR(15)
    }

    func resetSingleSelectLOV(line1 : String) {
        let line2 = "Select"
        self.attributedText = attributedString(from: "\(line1)\n\(line2)",
                                                range2: NSMakeRange(line1.count, line2.count+1),
                                                line1Color: UIColor.darkGray,
                                                line2Color: UIColor.lightGray,
                                                line1Font: CustomFont.getfont_REGULAR(15),
                                                line2Font: CustomFont.getfont_REGULAR(20))
    }
    
    func setSingleSelectLOV(line1 : String, line2: String) {
        self.attributedText = attributedString(from: "\(line1)\n\(line2)",
                                                range2: NSMakeRange(line1.count, line2.count+1),
                                                line1Color: UIColor.darkGray,
                                                line2Color: UIColor.darkGray,
                                                line1Font: CustomFont.getfont_REGULAR(15),
                                                line2Font: CustomFont.getfont_REGULAR(20))
    }
    
    func setHeaderTitleOnWhiteBG(line1: String, line2: String) {
        self.attributedText = attributedString(from: "\(line1)\n\(line2)",
                                                range2: NSMakeRange(line1.count, line2.count+1),
                                                line1Color: UIColor.black,
                                                line2Color: UIColor.darkGray,
                                                line1Font: CustomFont.getfont_MEDIUM(19),
                                                line2Font: CustomFont.getfont_REGULAR(15))
    }
    
    func setHeaderTitleOnBlueBG(line1: String, line2: String) {
        self.attributedText = attributedString(from: "\(line1)\n\(line2)",
                                                range2: NSMakeRange(line1.count, line2.count+1),
                                                line1Color: UIColor.white,
                                                line2Color: Constants.LIGHTER_BLUE_COLOR,
                                                line1Font: CustomFont.getfont_REGULAR(19),
                                                line2Font: CustomFont.getfont_REGULAR(15))
    }
    
    private func attributedString(from string: String, range2: NSRange?, line1Color: UIColor, line2Color: UIColor, line1Font: UIFont, line2Font: UIFont) -> NSAttributedString {
        
        let attrs1 = [
            NSAttributedString.Key.font: line1Font,
            NSAttributedString.Key.foregroundColor: line1Color
        ]
        let attrs2 = [
            NSAttributedString.Key.font: line2Font,
            NSAttributedString.Key.foregroundColor: line2Color
        ]
        let attrStr = NSMutableAttributedString(string: string, attributes: attrs1 as [NSAttributedString.Key : Any])
        if let range = range2 {
            attrStr.setAttributes(attrs2 as [NSAttributedString.Key : Any], range: range)
        }
        return attrStr
    }
}


extension UIImage {
    
    func maskWithColor(color: UIColor) -> UIImage? {
        let maskImage = cgImage!
        
        let width = size.width
        let height = size.height
        let bounds = CGRect(x: 0, y: 0, width: width, height: height)
        
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let bitmapInfo = CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue)
        let context = CGContext(data: nil, width: Int(width), height: Int(height), bitsPerComponent: 8, bytesPerRow: 0, space: colorSpace, bitmapInfo: bitmapInfo.rawValue)!
        
        context.clip(to: bounds, mask: maskImage)
        context.setFillColor(color.cgColor)
        context.fill(bounds)
        
        if let cgImage = context.makeImage() {
            let coloredImage = UIImage(cgImage: cgImage)
            return coloredImage
        } else {
            return self
        }
    }
}
