//
//  AttributedStringExtension.swift
//  mCAS
//
//  Created by Mac on 29/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import Foundation


extension NSMutableAttributedString {
    @discardableResult func bold(_ text: String, color: UIColor) -> NSMutableAttributedString {

        let attrs: [NSAttributedString.Key: Any] = [.foregroundColor: color]
        let boldString = NSMutableAttributedString(string:text, attributes: attrs)
        append(boldString)
        
        return self
    }
    
    @discardableResult func normal(_ text: String) -> NSMutableAttributedString {
        append(NSAttributedString(string: text))
        
        return self
    }
}
