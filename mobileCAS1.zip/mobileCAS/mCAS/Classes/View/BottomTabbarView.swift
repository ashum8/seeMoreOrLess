//
//  BottomTabbarView.swift
//  mCAS
//
//  Created by Mac on 19/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class BottomTabbarView: UIView, TabMenuButtonDelegate {
        
    var lastSelectedTab: TabMenuButton!
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let tabsData = [
            Constants.FN_MOB_HOME_DASHBOARD   : ButtonModel(buttonText: "Home", buttonID: Constants.FN_MOB_HOME_DASHBOARD, buttonImage: "home_icon", order: 1),
//            Constants.FN_MOB_SOURCING         : ButtonModel(buttonText: "Applications", buttonID: Constants.FN_MOB_SOURCING, buttonImage: "applications_icon", order: 2),
//            Constants.FN_MOB_CAPTURE_LEAD     : ButtonModel(buttonText: "Leads", buttonID: Constants.FN_MOB_VIEW_LEAD, buttonImage: "leads_icon", order: 3),
//            Constants.FN_MOB_FIELD_VERIFY     : ButtonModel(buttonText: "FI", buttonID: Constants.FN_MOB_FIELD_VERIFY, buttonImage: "fi_icon", order: 4),
            Constants.FN_MOB_MORE             : ButtonModel(buttonText: "More", buttonID: Constants.FN_MOB_MORE, buttonImage: "more_options_icon", order: 5),
//            Constants.FN_MOB_QUERY_MODULE     : ButtonModel(buttonText: "Query", buttonID: Constants.FN_MOB_QUERY_MODULE, buttonImage: "reports_icon", order: 6),
            Constants.FN_MOB_CALC             : ButtonModel(buttonText: "EMI Calculator", buttonID: Constants.FN_MOB_CALC, buttonImage: "emi_calculator_icon", order: 7),
            Constants.FN_MOB_RATE_INITIATION  : ButtonModel(buttonText: "Rate Initiation", buttonID: Constants.FN_MOB_RATE_INITIATION, buttonImage: "status_enquiry_icon", order: 8),
            Constants.FN_MOB_RATE_APPROVAL    : ButtonModel(buttonText: "Rate Approval", buttonID: Constants.FN_MOB_RATE_APPROVAL, buttonImage: "status_enquiry_icon", order: 9),
            Constants.FN_MOB_CHANGE_PASSWORD  : ButtonModel(buttonText: "Change Password", buttonID: Constants.FN_MOB_CHANGE_PASSWORD, buttonImage: "change_password_icon", order: 10)]
        
        AppDelegate.instance().mainMenuArray = []        
        AppDelegate.instance().mainMenuArray.addObjects(from: getTabs(tabsData: tabsData))

        var width = frame.size.width/Constants.bottomTabsCount
        let tabcount = AppDelegate.instance().mainMenuArray.count
        
        if tabcount < Int(Constants.bottomTabsCount) {
            width = frame.size.width/CGFloat(tabcount)
        }
        
        let lineView: UIView = UIView(frame: CGRect(x: 0, y: 0, width: self.frame.size.width, height: 0.5))

        var i = 1
        for obj in AppDelegate.instance().mainMenuArray {
            if let btnModel = obj as? ButtonModel, i <= Int(Constants.bottomTabsCount) {
                let tabButtonFrame = CGRect(x: CGFloat((Float(width))*(Float(i-1))), y: lineView.frame.size.height, width: width, height: self.frame.size.height-lineView.frame.size.height)
                
                let tabButton = TabMenuButton(frame: tabButtonFrame, btnModel: btnModel, delegate: self)
                self.addSubview(tabButton)

                if i == 1 {
                    self.lastSelectedTab = tabButton
                }
                
                i += 1
            }
        }
        
        if self.lastSelectedTab != nil {
            self.backgroundColor = .white
            
            lineView.backgroundColor = .lightGray
            self.addSubview(lineView)

            AppDelegate.instance().createHeaderView()
            self.lastSelectedTab.tabsButtonAction(self.lastSelectedTab)
        }
        else {
            FIApplicationUtils.showAlert(withTitle: "", andMessage: "Please login first in GPRS zone to validate login credentials.")
        }
    }
    
    private func getTabs(tabsData: [String: ButtonModel]) -> [ButtonModel] {
        var tabsArray : [ButtonModel] = []
        
        let username: String = (AppDelegate.instance()?.getSavedUserID())!
        let predicate = NSPredicate(format: "%K = %@",CDUserDetailsAttributes.username(), username)
        let entityName = String(describing: CDUserDetails.self)
        
        CoreDataOperations.sharedInstance().fetchSingleRecord(predicate: predicate, entityName: entityName, success: { (record) in
            
            if let userData = record as? CDUserDetails
            {
                if let rolesInDB = userData.userRoles {
                    for role in rolesInDB {
                        if let roleID = role.roleID, let btnModel = tabsData[roleID] {
                            tabsArray.append(btnModel)
                        }
                    }
                }
            }
        })
        
        tabsArray.insert(tabsData[Constants.FN_MOB_HOME_DASHBOARD]!, at: 0)
        tabsArray.append(tabsData[Constants.FN_MOB_CHANGE_PASSWORD]!)
        
        tabsArray.sort { (tab1, tab2) -> Bool in
            if let order1 = tab1.order, let order2 = tab2.order, order1 < order2 {
                return true
            }
            return false
        }
        
        if tabsArray.count > Int(Constants.bottomTabsCount) {
            tabsArray.insert(tabsData[Constants.FN_MOB_MORE]!, at: Int(Constants.bottomTabsCount)-1)
        }

        return tabsArray
    }
    
    func changeTabButtonSelection(selectedButton: TabMenuButton) {
        if self.lastSelectedTab != nil {
            self.lastSelectedTab.isSelected = false
        }
        
        self.lastSelectedTab = selectedButton

        if selectedButton.btnModel.buttonID == Constants.FN_MOB_HOME_DASHBOARD || selectedButton.btnModel.buttonID == Constants.FN_MOB_MORE {
            selectedButton.isSelected = true
        }
    }
}
