//
//  OSDOBTableCell.swift
//  mCAS
//
//  Created by iMac on 28/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class OSDOBTableCell: GenericTableViewCell, UITextFieldDelegate  {

    @IBOutlet weak var customerNameTextField: JVFloatLabeledTextField!
    @IBOutlet weak var dateOfBirthTextField: JVFloatLabeledTextField!
    @IBOutlet weak var searchButton: UIButton!
    
    var selectedDate: Date?
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
        self.selectedDate = Date()

        self.customerNameTextField.layer.cornerRadius = 5.0
        self.customerNameTextField.layer.borderColor = UIColor.lightGray.cgColor
        self.customerNameTextField.layer.borderWidth = 1.0

        self.dateOfBirthTextField.layer.cornerRadius = 5.0
        self.dateOfBirthTextField.layer.borderColor = UIColor.lightGray.cgColor
        self.dateOfBirthTextField.layer.borderWidth = 1.0

        self.customerNameTextField.placeholder = NSLocalizedString("Customer/Company Name", comment: "")
        self.dateOfBirthTextField.placeholder = NSLocalizedString("DOB/DOI", comment: "")
        
        FIApplicationUtils.setButtonProperties(self.searchButton)
    }

    @IBAction func searchButtonClicked(_ sender: Any) {
        
        var alertMessage = "";
        
        if !self.customerNameTextField.text!.isAlphabeticAndSpace() {
            alertMessage = NSLocalizedString("Please enter valid \(self.customerNameTextField.placeholder!)", comment: "")
        }
        
        if self.customerNameTextField.text!.count < 3 {
            alertMessage = NSLocalizedString("Please enter at least 3 character in \(self.customerNameTextField.placeholder!)", comment: "")
        }
        
        if self.dateOfBirthTextField.text == "" {
            alertMessage = NSLocalizedString("Please enter \(self.dateOfBirthTextField.placeholder!)", comment: "")
        }
        
        if !alertMessage.isEmpty {
            FIApplicationUtils.showAlert(withTitle: NSLocalizedString("", comment: ""), andMessage: NSLocalizedString(alertMessage, comment: ""))
        }
        else {
            self.customerNameTextField.resignFirstResponder()
        }

    }
    
    @IBAction func selectDateOfBirth(_ sender: Any) {

        let actionSheetPicker = ActionSheetDatePicker.init(title: NSLocalizedString("Choose DOB/DOI", comment: ""), datePickerMode: .date, selectedDate: self.selectedDate, minimumDate: nil, maximumDate: Date(), target: self, action: #selector(dateOfBirthWasSelected(selectedDate:)), origin: sender)
        
        actionSheetPicker?.hideCancel = false
        actionSheetPicker?.show()
    }
    
    @objc func dateOfBirthWasSelected(selectedDate: Date) {
        self.selectedDate = selectedDate
        self.dateOfBirthTextField.text = SKDateFormatter.getRespectiveStringDate(self.selectedDate, withOutputFormat: Constants.DATE_SEARCH)
    }
     
//   MARK: - UITextField delegate methods

    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        if textField == self.customerNameTextField {
            return true
        }
        return false
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField == self.customerNameTextField && !string.isAlphabeticAndSpace() {
            return false
        }
        return true
        
    }
}
