//
//  OnlineSearchResultVC.swift
//  mCAS
//
//  Created by iMac on 29/11/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class OnlineSearchResultVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var lblNoDataFound: UILabel!
    @IBOutlet weak var lblSelectMsg: UILabel!
    
    var searchType: OSSearchType?
    var listArrayModel = [RateApprovalRecord]()
    var offset = 0
    var reachedEndOfItems = false
    var searchText: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        setupView()
        refreshList()
    }
    
    private func setupView() {
        
        self.view.backgroundColor = Constants.LIGHTER_GRAY_COLOR
        tableView.register(UINib(nibName: String(describing: CasesCell.self), bundle: Bundle.main), forCellReuseIdentifier: "CasesCell")
        
        lblSelectMsg.font = CustomFont.getfont_MEDIUM(19)
        lblSelectMsg.isHidden = true
        
        lblNoDataFound.font = CustomFont.getfont_MEDIUM(19)
        lblNoDataFound.textColor = .lightGray
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let headerView = AppDelegate.instance()?.headerView, let bottomView = AppDelegate.instance()?.bottomTabbarView {
            bottomView.isHidden = true
            headerView.setTitleWithShowBackButton(title: "Rate Approval Request", showBackButton: true)
        }
    }
    
    @objc func refreshList() {
        offset = 0
        reachedEndOfItems = false
        listArrayModel.removeAll()
        
        fetchCases()
    }
    
    private func manageHeaderView() {
        
        if let headerView = AppDelegate.instance()?.headerView {
            if !self.listArrayModel.isEmpty {
                headerView.setTitleWithShowBackButton(title: "\(self.listArrayModel.count) results found", showBackButton: true)
            }
            else {
                headerView.setTitleWithShowBackButton(title: "Rate Approval Request", showBackButton: true)
            }
        }
    }
    
    private func fetchCases() {
        
        guard !reachedEndOfItems else {
            return
        }
            
        let param : [String:[String:Any]] = ["status"                       : ["code" : "NOT INITIATED"],
                                             "stage"                        : ["code" : "INITIATION"],
                                             "applicationSearchCriteria"    : ["applicationNumber" :self.searchText ?? ""],
                                             "pageInfo"                     : ["requestStartIndex" : offset]]
        
        Webservices.sharedInstance().POST(urlString: ServiceUrl.SEARCH_APPLICATION_URL, paramaters: param, autoHandleLoader: true, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any]
            {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject:response, options:[])
                    let list = try JSONDecoder().decode(RateApproverModel.self, from: jsonData)
                    var recordCount = 0

                    if let records = list.rateApprovalRecords {
                        self.listArrayModel.append(contentsOf: records)
                        recordCount = records.count
                    }
                    
                    if let pageSize = list.pageInfo?.requestPageSize
                    {
                        if recordCount < pageSize {
                            self.reachedEndOfItems = true
                        }
                        self.offset += pageSize
                    }
                    
                    if recordCount > 0 {
                        self.tableView.reloadData()
                    }
                    
                    self.tableView.isHidden = self.listArrayModel.isEmpty
                    self.lblNoDataFound.isHidden = !self.listArrayModel.isEmpty
                    self.lblSelectMsg.isHidden = self.listArrayModel.isEmpty
                }
                catch { debugPrint(error) }
                
                self.manageHeaderView()
            }
            
        }, failure: { (error) in
            
            self.manageHeaderView()
            
            if error == ServiceUrl.ALERT_NO_DATA {
                self.tableView.isHidden = self.listArrayModel.isEmpty
                self.lblNoDataFound.isHidden = !self.listArrayModel.isEmpty
                self.lblSelectMsg.isHidden = self.listArrayModel.isEmpty
                
                self.reachedEndOfItems = true
            }
            
        }, noNetwork: { (error) in
            self.manageHeaderView()
        })
    }
}

extension OnlineSearchResultVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.listArrayModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: CasesCell = tableView.dequeueReusableCell(withIdentifier: "CasesCell") as! CasesCell
        
        let record = self.listArrayModel[indexPath.row]
        
        cell.label1.text = record.application.applicant.fullName.uppercased()
        cell.label2.text = record.application.externalRefNumber
        cell.label3.text = record.loanAmount!
        
        if let productType = record.application.loanDetail?.productType?.code {
            cell.loanTypeLabel.text = productType
            
            if productType == "Consumer Vehicle" {
                cell.imgView.image = UIImage(named: "auto_loan_icon")
            }
            else {
                cell.imgView.image = UIImage(named: "personal_loan_icon")
            }
        }
        cell.arrowIcon.isHidden = false
        cell.optionButton.isHidden = true
        cell.setProperties()
        
        // Check if the last row number is the same as the last current data element
        if indexPath.row == self.listArrayModel.count - 1 {
            self.fetchCases()
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        if (self.searchType == .RateApproval) {
            let st = UIStoryboard.init(name: Constants.STORYBOARD_RATE_INITIATE, bundle: nil)
            let vc = st.instantiateViewController(withIdentifier: "CaseDetailVC") as! CaseDetailVC
            vc.caseType = .ToInitiate
            vc.caseData = self.listArrayModel[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
    
}
