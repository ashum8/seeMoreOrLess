//
//  EmailSendView.swift
//  mCAS
//
//  Created by iss on 08/03/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit


@objc protocol EmailSendViewDelegate : class {
    func callEmailService(toEmail: String, ccEmail: String)
}

class EmailSendView: UIView {

    @IBOutlet weak var toEmailView: UIView!
    @IBOutlet weak var ccEmailView: UIView!
    @IBOutlet weak var toEmailTF: UITextField!
    @IBOutlet weak var ccEmailTF: UITextField!
    @IBOutlet weak var sendEmailButton: UIButton!

    weak var delegate: EmailSendViewDelegate?
    
    
    func setProperties() {
        self.frame = CGRect(x: 0, y: 0, width: (AppDelegate.instance()?.window.frame.size.width)!, height: (AppDelegate.instance()?.window.frame.size.height)!)

        FIApplicationUtils.setTextFieldViewProperties(toEmailView)
        FIApplicationUtils.setTextFieldViewProperties(ccEmailView)
        FIApplicationUtils.setButtonProperties(sendEmailButton)
        
        setEmailButtonProperties(toEmail: "", ccEmail: "")
    }
    
    func setEmailButtonProperties(toEmail: String, ccEmail: String) {
        var isEnabled: Bool = true
        if ((toEmail.isEmpty() || !toEmail.isEmail()) || (!ccEmail.isEmpty() && !ccEmail.isEmail())) {
            isEnabled = false
        }
        FIApplicationUtils.setButtonColorWith(sendEmailButton, enabled:isEnabled)
    }
    
    @IBAction func touchAction(_ sender: Any) {
        self.endEditing(true)
        self.alpha = 0
    }
    
    @IBAction func sendEmailAction(_ sender: Any) {
        if FIApplicationUtils.checkForReachabilityMode() {
            self.delegate?.callEmailService(toEmail: toEmailTF.text! as String, ccEmail: ccEmailTF.text! as String)
        }
    }
}

extension EmailSendView: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == toEmailTF {
            toEmailView.layer.borderColor = Constants.BLUE_COLOR.cgColor
        }
        else {
            ccEmailView.layer.borderColor = Constants.BLUE_COLOR.cgColor
        }
        
        self.setEmailButtonProperties(toEmail: "", ccEmail: "")
    }
    
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        if textField == toEmailTF {
            toEmailView.layer.borderColor = UIColor.lightGray.cgColor
        }
        else {
            ccEmailView.layer.borderColor = UIColor.lightGray.cgColor
        }
        
        self.setEmailButtonProperties(toEmail: toEmailTF.text! as String, ccEmail: ccEmailTF.text! as String)
        
        return true
    }
}



