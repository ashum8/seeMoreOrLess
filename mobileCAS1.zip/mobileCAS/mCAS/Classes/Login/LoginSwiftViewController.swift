//
//  LoginSwiftViewController.swift
//  mCAS
//
//  Created by Mac on 08/02/17.
//  Copyright © 2017 Nucleus. All rights reserved.
//

import Foundation
import UIKit


@objc class LoginSwiftViewController: UIViewController {
    var tempArray: [Any] = []
    var loginDict: NSDictionary = [:]
    var activeToken: String = ""
    var loginOverlay: MRProgressOverlayView!
    
    @IBOutlet weak var staticLavel1: UILabel!
    @IBOutlet weak var staticLavel2: UILabel!
    @IBOutlet weak var staticLavel3: UILabel!
    
    @IBOutlet weak var userNameLogoImage: UIImageView!
    @IBOutlet weak var userNameTextField: JVFloatLabeledTextField!
    @IBOutlet weak var passWordTextField: JVFloatLabeledTextField!
    @IBOutlet weak var userNameView: UIView!
    @IBOutlet weak var passWordView: UIView!
    @IBOutlet weak var lblVersionNo: UILabel!
    @IBOutlet weak var hideShowPasswordButton: UIButton!
    @IBOutlet weak var fPassButton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var poweredByverticalConstraint: NSLayoutConstraint!
    @IBOutlet weak var fpassHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var rememberButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let dictionary = Bundle.main.infoDictionary!
        let version = dictionary["CFBundleShortVersionString"] as! String
        let build = dictionary["CFBundleVersion"] as! String
        lblVersionNo.text = String(format: NSLocalizedString("Version: %@ (%@)", comment: ""), version, build)
        lblVersionNo.isHidden = true
        
//        if (FIApplicationUtils.getApplicationLanguage() == "ar") {
        hideShowPasswordButton.isHidden = true
//        }
        
        setProperties()
    }
    
    private func setProperties() {
        
        staticLavel1.font = CustomFont.getfont_MEDIUM(24)
        staticLavel2.font = CustomFont.getfont_REGULAR(16)
        staticLavel3.font = CustomFont.getfont_REGULAR(13)
        
        userNameTextField.autocapitalizationType = .allCharacters
        
        //set color of username and password view
        FIApplicationUtils.setTextFieldViewProperties(userNameView)
        FIApplicationUtils.setTextFieldViewProperties(passWordView)
        
        fPassButton.setTitleColor(Constants.BLUE_COLOR, for: .normal)
        fPassButton.titleLabel?.font = CustomFont.getfont_MEDIUM(16)
        
        rememberButton.titleLabel?.font = CustomFont.getfont_MEDIUM(16)

        FIApplicationUtils.setButtonProperties(loginButton)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        userNameTextField.text=""
        passWordTextField.text=""
                
        if let isRemember = FIApplicationUtils.getDataFromSecretUserDefault(withKey: Constants.UD_REMEMBER_USER_ID) as? Int, isRemember == 1 {
            rememberButton.isSelected = true
            userNameTextField.text = AppDelegate.instance()?.getSavedUserID()
        }
        else {
            rememberButton.isSelected = false
        }
        
//        userNameTextField.text="NITIN1"
//        passWordTextField.text="Nsel@001"

//        userNameTextField.text="NEHA"
//        passWordTextField.text="Admin@1122"
        
        userNameTextField.text="arvind"
        passWordTextField.text="Admin@11"
        
        self.navigationController?.isNavigationBarHidden = true
        AppDelegate.instance().isLoggedin = true
        
        let verticalSpace = UIScreen.main.bounds.height - (fPassButton.frame.origin.y + fpassHeightConstraint.constant + 60)

        poweredByverticalConstraint.constant = max(verticalSpace, 60)
        
        let username = userNameTextField.text! as String
        let password = passWordTextField.text! as String
        
        setloginButtonProperties(username: username, password: password)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if JBroken.isDeviceCompromised() || JBroken.isAppBroken() {
            FIApplicationUtils.showAlert(withTitle: "", message: "Sorry! your device is jail breaked. You can no longer use this application.") { (action) in
                exit(-1)
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        AppDelegate.instance().isLoggedin = false
    }
    
    @IBAction func rememberButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }
    
    @IBAction func hideShowPassword(_ sender: UIButton) {
        passWordTextField.isSecureTextEntry = !passWordTextField.isSecureTextEntry
        sender.isSelected = !sender.isSelected
    }
    
    @IBAction func loginButtonClicked(_ sender: UIButton) {
        
        let st = UIStoryboard.init(name: Constants.STORYBOARD_MAIN, bundle: nil)
                   if let vc = st.instantiateViewController(withIdentifier: "ChangePasswordFromFirstVC") as? ChangePasswordFromFirstVC {
                       self.navigationController?.pushViewController(vc, animated: false)
                   }
        
        
        return
        
        if let username = userNameTextField.text, let password = passWordTextField.text, username.count > 0, password.count > 0 {
            self.view.endEditing(true)
            
            //If Online Reachable
            if(ReachabilityManager.isReachable()){
                loginOverlay =  MRProgressOverlayView.showOverlayAdded(to: self.view, animated: true)
                loginOverlay.titleLabelText = NSLocalizedString("Please wait authenticating...", comment:"")
                
                getTokenFromService(username: username, password: password)
            }
            else {
                let predicate = NSPredicate(format: "%K = %@",CDUserDetailsAttributes.username(), username)
                let entityName = String(describing: CDUserDetails.self)
                
                CoreDataOperations.sharedInstance().fetchSingleRecord(predicate: predicate, entityName: entityName, success: { (record) in
                    
                    if let userData = record as? CDUserDetails {
                        self.checkOfflineUserCredential(password: password, userData: userData)
                    }
                    else {
                        FIApplicationUtils.showAlert(withTitle: "", andMessage: NSLocalizedString("Offline login not available\nPlease login first in online mode to validate login credentials.", comment: ""))
                    }
                })
            }
        }
        else {
            FIApplicationUtils.showAlert(withTitle: "", andMessage: NSLocalizedString("Please enter login credentials", comment: ""))
        }
    }
    
    @IBAction func forgotButtonAction(_ sender: Any) {
        if Constants.ENABLE_FORGOT_PWD_VIA_OTP {
            self.performSegue(withIdentifier: "ResetPasswordVC", sender: nil)
        }
        else {
            self.performSegue(withIdentifier: "ForgotPasswordVC", sender: nil)
        }
    }
    
    func getTokenFromService(username: String, password: String) {
        Webservices.sharedInstance().getTokenFromServer(withSession: false) { (token) in
            if let token = token {
                self.callOnlineLoginWebService(username:username, password: password, token:token)
            }
            else {
                self.loginOverlay.dismiss(true)
            }
        }
    }
    
    func checkOfflineUserCredential(password: String, userData: CDUserDetails){
        let alertView = UIAlertController(title: "", message: NSLocalizedString("Network not available. Do you want to login in offline mode?", comment: ""), preferredStyle: UIAlertController.Style.alert)
        
        let action1 = UIAlertAction(title: "Yes", style: UIAlertAction.Style.default) { (dd) -> Void in
            
            let encryptedPassword = Cipher.encrypt(password, withToken: userData.token!)
            
            if encryptedPassword == userData.encryptedpassword {
                self.navigateToDashboard(username: userData.username!)
            }
            else {
                FIApplicationUtils.showAlert(withTitle: "", andMessage: NSLocalizedString("Please enter correct login credentials", comment: ""))
            }
        }
        
        let action2 = UIAlertAction(title: "No", style: UIAlertAction.Style.cancel) { (dd) -> Void in }
        
        alertView.addAction(action1)
        alertView.addAction(action2)
        self.present(alertView, animated: true, completion: nil)
    }
    
    func callOnlineLoginWebService(username: String, password: String, token: String){
        
        let encryptedPassword = Cipher.encrypt(password, withToken: token)

        let param = ["username"     : username,
                     "password"     : encryptedPassword,
                     "deviceId"     : AppDelegate.instance()?.getDeviceID(),
                     "moduleCode"   : "mCAS"] as! [String : String]
        
        Webservices.sharedInstance().POST(urlString: ServiceUrl.LOGIN_URL, paramaters: param, success: { (header ,responseObj) in
                        
            if let dictionary = responseObj as? [String : Any], let alreadyLogIn = dictionary["alreadyLoggedIn"] as? Bool, alreadyLogIn {
                self.loginOverlay.dismiss(true)
                
                let alertView = UIAlertController(title: "", message: "You are already logged in. Do you want to kill the previous session?", preferredStyle: UIAlertController.Style.alert)
                
                let action1 = UIAlertAction(title: "Continue", style: UIAlertAction.Style.default) { (dd) -> Void in
                                        
                    self.loginOverlay = MRProgressOverlayView.showOverlayAdded(to: self.view, animated: true)
                    self.loginOverlay.titleLabelText = NSLocalizedString("Signing out...", comment:"")
                    
                    Webservices.sharedInstance().logoutFromServer(username: username) { (success) in
                        
                        if success == true {
                            self.loginOverlay.titleLabelText = NSLocalizedString("Please wait authenticating...", comment:"")
                            self.getTokenFromService(username: username, password: password)
                        }
                        else {
                            self.loginOverlay.dismiss(true)
                            FIApplicationUtils.showAlert(withTitle: "", andMessage: ServiceUrl.ALERT_SERVICE_ERROR)
                        }
                    }
                }
                
                let action2 = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel) { (dd) -> Void in }
                alertView.addAction(action1)
                alertView.addAction(action2)
                self.present(alertView, animated: true, completion: nil)
            }
            else {
                self.navigateToDashboard(username: username, password: password, token: token)
            }
            
        }, failure: { (error) in
            if self.loginOverlay != nil {
                self.loginOverlay.dismiss(true)
            }
            if error != nil {
                FIApplicationUtils.showAlert(withTitle: "", andMessage: error)
            }
            
        }, noNetwork: { (error) in
            if self.loginOverlay != nil {
                self.loginOverlay.dismiss(true)
            }
        })
    }
    
    func navigateToDashboard(username: String, password: String? = nil, token: String? = nil) {
                   
        if let password = password, let token = token {
            let encryptedPassword = Cipher.encrypt(password, withToken: token)
            let predicate = NSPredicate(format: "%K = %@",CDUserDetailsAttributes.username(), username)
            let entityName = String(describing: CDUserDetails.self)
            
            CoreDataOperations.sharedInstance().updateRecord(predicate: predicate, entityName: entityName, success: { (record) in
                
                if let userData = record as? CDUserDetails, let context = AppDelegate.instance()?.managedObjectContext {
                                    
                    userData.username = username
                    userData.encryptedpassword = encryptedPassword
                    userData.name = "Test"
                    userData.token = token
                    
                    do { try context.save() }
                    catch { }
                }
            })
        }
        
        //Flag to remember userid or not
        FIApplicationUtils.saveData(inSecretUserDefault:self.rememberButton.isSelected, withKey: Constants.UD_REMEMBER_USER_ID)
        FIApplicationUtils.saveData(inSecretUserDefault: username, withKey: Constants.UD_USER_ID)
        
        fetchAuthorities(username: username)
        
        fetchDecisionReasonMaster()
    }
    
    func fetchDecisionReasonMaster() {
        let param = ["stage" : "Waiver"]
        
        Webservices.sharedInstance().POST(urlString: ServiceUrl.GET_DECISION_REASONS_URL, paramaters: param, success: { (header ,responseObj) in
            if let masters = responseObj as? [[String : String]] {
                CommonData.shared.reasonMasterArray = masters
                CommonData.shared.reasonMasterArray.insert(["code"        : "Other",
                                                            "name"        : "other",
                                                            "masterType"  : "Other"], at: 0)
            }
            
        }, failure: { (error) in },
           noNetwork: { (error) in })
    }
    
    func fetchAuthorities(username: String) {
        
        Webservices.sharedInstance().POST(urlString: ServiceUrl.GET_AUTHORITIES_URL, success: { (header ,responseObj) in
            
            if let response = responseObj as? [String : Any], let rolesFromServer = response["authorities"] as? [String], let extraParam = response["extraParam"] as? String
            {
                var checksum = username.uppercased() + rolesFromServer.joined()
                checksum = Cipher.sha256(checksum)
                
                if checksum == extraParam {
                    let predicate = NSPredicate(format: "%K = %@",CDUserDetailsAttributes.username(), username)
                    let entityName = String(describing: CDUserDetails.self)
                    
                    CoreDataOperations.sharedInstance().fetchSingleRecord(predicate: predicate, entityName: entityName, success: { (record) in
                        
                        if let userData = record as? CDUserDetails
                        {
                            if let rolesInDB = userData.userRoles, let context = AppDelegate.instance()?.managedObjectContext
                            {
                                for role in rolesInDB {
                                    context.delete(role)
                                }
                                
                                let entityName = String(describing: CDUserRoles.self)
                                var roleArray: [CDUserRoles] = []
                                
                                for role in rolesFromServer {
                                    let entity = NSEntityDescription.entity(forEntityName: entityName, in: context)
                                    let userRoles = NSManagedObject(entity: entity!, insertInto: context) as! CDUserRoles
                                    userRoles.roleID = role
                                    roleArray.append(userRoles)
                                }
                                
                                userData.userRoles = Set(roleArray)
                                
                                do { try context.save() }
                                catch { }
                            }
                        }
                    })
                    
                    AppDelegate.instance().createBottomTabBar()
                }
                else {
                    FIApplicationUtils.showAlert(withTitle: "", andMessage: ServiceUrl.ALERT_SERVICE_ERROR)
                }
            }
            
            self.loginOverlay.dismiss(true)

            
        }, failure: { (error) in
            if self.loginOverlay != nil {
                self.loginOverlay.dismiss(true)
            }
        },
           noNetwork: { (error) in
            if self.loginOverlay != nil {
                self.loginOverlay.dismiss(true)
            }
        })
    }
    
    func setloginButtonProperties(username: String, password: String) {
        
        var isEnabled: Bool = true
        if (username.isEmpty() || password.isEmpty()) {
            isEnabled = false
        }
        FIApplicationUtils.setButtonColorWith(loginButton, enabled:isEnabled)
    }
}

extension LoginSwiftViewController: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {

        if textField == userNameTextField {
            userNameView.layer.borderColor = Constants.BLUE_COLOR.cgColor
        }
        else {
            passWordView.layer.borderColor = Constants.BLUE_COLOR.cgColor
        }
        
        self.setloginButtonProperties(username: "", password: "")
    }
    
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        let username = userNameTextField.text! as String
        let password = passWordTextField.text! as String
        
        if textField == userNameTextField {
            userNameView.layer.borderColor = UIColor.lightGray.cgColor
        }
        else {
            passWordView.layer.borderColor = UIColor.lightGray.cgColor
        }

        self.setloginButtonProperties(username: username, password: password)
        
        return true
    }
}


