//
//  DashboardViewController.swift
//  mCAS
//
//  Created by Mac on 20/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class DashboardViewController: UIViewController {

    private var headerControlsView: DashboardHeaderView!
    fileprivate var collectionArray: [ButtonModel]!
    fileprivate var tableArray: [ButtonModel]!

    @IBOutlet weak var primaryActionLabel: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var collectionViewHeight: NSLayoutConstraint!
    @IBOutlet weak var topTableView: UIView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.view.backgroundColor = Constants.LIGHTER_GRAY_COLOR
        self.primaryActionLabel.font = CustomFont.getfont_MEDIUM(17)

//        showCollectionGrid()
        setTableViewData()
        createDashboardControls()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        let insetMargin: CGFloat = 15.0
        let spaceMargin: CGFloat = 8.0

        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        self.collectionView.collectionViewLayout = layout
        self.collectionView.contentInset = UIEdgeInsets(top: 0, left: insetMargin, bottom:0, right: insetMargin)
        
        if let layout = self.collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.minimumInteritemSpacing = spaceMargin
            layout.minimumLineSpacing = spaceMargin
            layout.itemSize = CGSize(width: (self.collectionView.frame.size.width-(insetMargin*2+spaceMargin))/2, height: (self.collectionView.frame.size.height-spaceMargin)/2)
            layout.invalidateLayout()
        }
    }
    
    private func showCollectionGrid() {
        collectionViewHeight.constant = 200
        
        var frame = self.topTableView.frame
        frame.size.height = 250
        self.topTableView.frame = frame
        
        setCollectionViewData()
        collectionView.delegate = self
        collectionView.dataSource = self
    }
    
    private func setCollectionViewData() {
        let collectionCellData = [DRAFT_APPLICATIONS      : ButtonModel(buttonText: "Draft Applications", buttonID: DRAFT_APPLICATIONS, buttonImage: "draft_applications_icon", order: 1),
                                  ASSIGNED_LEADS          : ButtonModel(buttonText: "Assigned Leads", buttonID: ASSIGNED_LEADS, buttonImage: "assigned_leads_icon", order: 2),
                                  ASSIGNED_FI             : ButtonModel(buttonText: "Assigned FI", buttonID: ASSIGNED_FI, buttonImage: "assigned_fi_icon", order: 3),
                                  ASSIGNED_QUERY          : ButtonModel(buttonText: "Assigned Queries", buttonID: ASSIGNED_QUERY, buttonImage: "assigned_query_icon", order: 4),
                                  APPLICATIONS_PUNCHED    : ButtonModel(buttonText: "Applications Punched", buttonID: APPLICATIONS_PUNCHED,  buttonImage: "applications_punched_icon", order: 5),
                                  RAISED_QUERY            : ButtonModel(buttonText: "Raised Query", buttonID: RAISED_QUERY, buttonImage: "raised_query_icon", order: 6)]
        
        collectionArray = []
        
        if let array = AppDelegate.instance().mainMenuArray as? [ButtonModel] {
            for btnModel in array {
                if btnModel.buttonID == Constants.FN_MOB_SOURCING, let btnModel = collectionCellData[DRAFT_APPLICATIONS] {
                    collectionArray.append(btnModel)
                    
                    if let btnModel1 = collectionCellData[APPLICATIONS_PUNCHED] {
                        collectionArray.append(btnModel1)
                    }
                }
                else if btnModel.buttonID == Constants.FN_MOB_VIEW_LEAD, let btnModel = collectionCellData[ASSIGNED_LEADS] {
                    collectionArray.append(btnModel)
                }
                else if btnModel.buttonID == Constants.FN_MOB_FIELD_VERIFY, let btnModel = collectionCellData[ASSIGNED_FI] {
                    collectionArray.append(btnModel)
                }
                else if btnModel.buttonID == Constants.FN_MOB_QUERY_MODULE, let btnModel = collectionCellData[ASSIGNED_QUERY] {
                    collectionArray.append(btnModel)
                    
                    if let btnModel1 = collectionCellData[RAISED_QUERY] {
                        collectionArray.append(btnModel1)
                    }
                }
            }
        }
    }
    
    private func setTableViewData() {
        let collectionCellData = [CREATE_APPLICATION    : ButtonModel(buttonText: "Create Application", buttonID: CREATE_APPLICATION, buttonImage: "create_application_icon", order: 1),
                                  CREATE_LEAD           : ButtonModel(buttonText: "Create Lead", buttonID: CREATE_LEAD, buttonImage: "create_lead_icon", order: 2),
//                                  CHECK_ELIGIBILITY     : ButtonModel(buttonText: "Check Eligibility", buttonID: CHECK_ELIGIBILITY, buttonImage: "check_eligibility_icon", order: 3),
                                  RAISE_QUERY           : ButtonModel(buttonText: "Raise Query", buttonID: RAISE_QUERY, buttonImage: "raise_query_icon", order: 4),
//                                  RATE_TYPE_APPROVAL    : ButtonModel(buttonText: "Rate Type Approval", buttonID: RATE_TYPE_APPROVAL, buttonImage: "rate_type_approval_icon", order: 5)
                                 ]
        
        tableArray = []
        
        if let array = AppDelegate.instance().mainMenuArray as? [ButtonModel] {
            for btnModel in array {
                if btnModel.buttonID == Constants.FN_MOB_SOURCING, let btnModel = collectionCellData[CREATE_APPLICATION] {
                    tableArray.append(btnModel)
                    
                    if let btnModel1 = collectionCellData[CHECK_ELIGIBILITY] {
                        tableArray.append(btnModel1)
                    }
                    if let btnModel1 = collectionCellData[RATE_TYPE_APPROVAL] {
                        tableArray.append(btnModel1)
                    }
                }
                else if btnModel.buttonID == Constants.FN_MOB_VIEW_LEAD, let btnModel = collectionCellData[CREATE_LEAD] {
                    tableArray.append(btnModel)
                }
                else if btnModel.buttonID == Constants.FN_MOB_QUERY_MODULE, let btnModel = collectionCellData[RAISE_QUERY] {
                    tableArray.append(btnModel)
                }
            }
        }
        
        tableArray.sort { (tab1, tab2) -> Bool in
            if let order1 = tab1.order, let order2 = tab2.order, order1 < order2 {
                return true
            }
            return false
        }
    }
    
    private func createDashboardControls() {
        
        if let headerView = AppDelegate.instance()?.headerView {
            headerControlsView = DashboardHeaderView(frame: CGRect(x: 0, y: 0, width: headerView.frame.size.width, height: headerView.frame.size.height))
            headerView.addSubview(headerControlsView)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        headerControlsView.isHidden = false
        
        if let headerView = AppDelegate.instance()?.headerView, let bottomView = AppDelegate.instance()?.bottomTabbarView {
            bottomView.isHidden = false
            headerView.setTitleWithShowBackButton(title: "", showBackButton: false)
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        headerControlsView.isHidden = true
    }
    
    
}


extension DashboardViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return collectionArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DashboardCell", for: indexPath) as! DashboardCell
        cell.setCellProperties(btnModel: collectionArray[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
//        AppDelegate.instance().applicationNavController.pushViewController(AppDelegate.instance().intializeViewController("CustomerTypeViewController"), animated: false)
    }
}

extension DashboardViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DashboardTableCell", for: indexPath) as! DashboardTableCell
        cell.setCellProperties(btnModel: tableArray[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let btnModel = tableArray[indexPath.row]
        
        switch btnModel.buttonID {
        case CREATE_APPLICATION:
            nwApplicationButtonAction()
            break
            
        case CREATE_LEAD:
            if AppDelegate.instance() != nil {
                AppDelegate.instance()?.tabsButtonAction(withTabID: Constants.FN_MOB_CAPTURE_LEAD)
            }
            break
            
        case RAISE_QUERY:
            if AppDelegate.instance() != nil {
                AppDelegate.instance()?.tabsButtonAction(withTabID: RAISE_QUERY)
            }
            break
            
        default:
            break
        }
    }
    
    func nwApplicationButtonAction() {
        
       
    }
    
}
