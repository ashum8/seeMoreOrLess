//
//  DashboardCell.swift
//  mCAS
//
//  Created by iss on 25/02/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

import UIKit

class DashboardCell: UICollectionViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var iconView: UIImageView!

    func setCellProperties(btnModel: ButtonModel) {
    
        self.backgroundColor = .white
        self.layer.cornerRadius = 2.0
        self.layer.borderWidth = 0.5
        self.layer.borderColor = UIColor.lightGray.cgColor
        
        titleLabel.textColor = .darkGray
        countLabel.textColor = .darkGray

        titleLabel.font = CustomFont.getfont_REGULAR(15)
        countLabel.font = CustomFont.getfont_MEDIUM(32)

        titleLabel.text = btnModel.buttonText
        countLabel.text = "02"
        iconView.image = UIImage(named: btnModel.buttonImage)
    }
}
