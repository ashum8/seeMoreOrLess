//
//  CameraOverlayView.h
//  mCAS
//
//  Created by Mac on 23/10/15.
//  Copyright © 2015 Nucleus. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CameraOverlayViewDelegate <NSObject>
- (void)closeButtonAction;
- (void)finishButtonAction;
- (void)takePictureButtonAction;
@end

@interface CameraOverlayView : UIView


@property(nonatomic, strong) id<CameraOverlayViewDelegate> delegate;
@property(nonatomic, weak) IBOutlet UIImageView *capturedImageView;
@property(nonatomic, weak) IBOutlet UILabel *totalDocumentsCount;
@property(nonatomic, weak) IBOutlet UIButton *finishButton;
@property(nonatomic, weak) IBOutlet UIButton *takePictureButton;

- (void)setFinishButtonEnabled:(BOOL)isEnabled;
- (void)setTakePictureButtonEnabled:(BOOL)isEnabled;

- (IBAction)finishButtonAction:(id)sender;
- (IBAction)takePictureButtonAction:(id)sender;
- (IBAction)closeCameraButtonAction:(id)sender;

@end
