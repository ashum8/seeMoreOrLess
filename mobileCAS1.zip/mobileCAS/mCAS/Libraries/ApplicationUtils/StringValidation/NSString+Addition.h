//
//  NSString+Addition.h
//  mCAS
//
//  Created by Mac on 27/06/19.
//  Copyright (c) 2019 Mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Addition)

- (BOOL)isNilOrEmpty;
- (BOOL)isEmail;
- (BOOL)isPhoneNumber;
- (BOOL)isDigit;
- (BOOL)isNumeric;
- (BOOL)isAlphanumeric;
- (BOOL)hasBothCases;
- (BOOL)isUrl;
- (BOOL)isMinLength:(NSUInteger)length;
- (BOOL)isMaxLength:(NSUInteger)length;
- (BOOL)isMinLength:(NSUInteger)min andMaxLength:(NSUInteger)max;
- (BOOL)isEmpty;
- (BOOL)isAlphanumericAndSpace;
- (BOOL)isAlphabetic;
- (BOOL)validatePAN;
- (BOOL)validateTAN;
- (BOOL)isAlphanumericSpecial;
- (BOOL)isCapsAlphabetic;
- (BOOL)isAlphabeticAndSpace;
- (BOOL)isCharSpecial;
+ (BOOL)validateInputWithString:(NSString *)aString andRegex:(NSString *)regexString;
- (BOOL)validateAmountString;
+ (NSString *)getReverseString:(NSString *)str;
+ (NSString *)formatString:(double)value;
+ (NSString *)formatCurrency:(NSString *)amount;
+ (NSString *)validateStringData:(id)data;


@end
