//
//  SKDateFormatter.h
//  mCAS
//
//  Created by Mac on 27/06/19.
//  Copyright (c) 2019 Mac. All rights reserved.
//

#import "SKDateFormatter.h"

@implementation SKDateFormatter

+ (NSString *)getRespectiveStringDate:(NSDate *)inputdate withOutputFormat:(NSString *)outputFormat
{
    NSDateFormatter *dateformatter = [[NSDateFormatter alloc] init];
    [dateformatter setDateFormat:outputFormat];
    return [dateformatter stringFromDate:inputdate];
}

+ (NSString *)getRespectiveDateFromStringDate:(NSString *)dateString withOutputFormat:(NSString *)outputFormat
{
    NSDate *date = [self getRespectiveDateFromStringDate:dateString];
    
    if (date) {
        return [self getRespectiveStringDate:date withOutputFormat:outputFormat];
    }
    else {
        return dateString;
    }
}

+ (NSDate *)getRespectiveDateFromStringDate:(NSString *)dateString
{
    NSDate *date = nil;
    
    if (dateString) {
        NSError *error = nil;
        NSDataDetector *detector = [NSDataDetector dataDetectorWithTypes:NSTextCheckingTypeDate error:&error];
        NSArray *matches = [detector matchesInString:dateString options:0 range:NSMakeRange(0, [dateString length])];
        for (NSTextCheckingResult *match in matches) {
            if (match.date) {
                date = match.date;
                break;
            }
        }
    }
    
    return date;
}

+ (int)dateDifferenceFromDate:(NSDate *)fromDate andToDate:(NSDate *)toDate {
    unsigned int unitFlags = NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitDay | NSCalendarUnitSecond;
    
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *conversionInfo = [gregorian components:unitFlags fromDate:fromDate   toDate:toDate  options:0];
    
    int hours = (int)[conversionInfo hour];
    return hours;
}

+ (void)setDOBMinMaxValue:(UIDatePicker *)datePicker {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = Constants.DATE_FORMATTER;
    
    [datePicker setMinimumDate:[dateFormatter dateFromString:@"01-Jan-1900"]];
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *addComponents = [[NSDateComponents alloc] init];
    addComponents.year = - 18;
    [datePicker setMaximumDate:[calendar dateByAddingComponents:addComponents toDate:[NSDate date] options:0]];
    dateFormatter = nil;
}

@end
