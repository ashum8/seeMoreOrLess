//
//  CustomFont.m
//  mCAS
//
//  Created by Mac on 27/06/19.
//  Copyright (c) 2019 Mac. All rights reserved.
//

#import "CustomFont.h"

@implementation CustomFont

+(CGFloat)GETFONTSIZE:(CGFloat)fontSize {
    switch((NSInteger)UIScreen.mainScreen.bounds.size.height) {
        case 480:
            return fontSize-4;
            
        case 568:
            return fontSize-3;
            
        case 667:
            return fontSize-3;
            
        case 736:
            return fontSize-2;
            
        case 812:
            return fontSize-2;
            
        case 1024:
            return fontSize;
            
        case 1366:
            return fontSize+1;
            
        default:
            return fontSize;
    }
}

+(UIFont *)GETFONT_EXTRA_BOLD_ITALIC:(int)SizeOfFont {
    return [UIFont fontWithName:@"OpenSans-ExtraboldItalic" size:[self GETFONTSIZE:SizeOfFont]];
}

+(UIFont *)GETFONT_CONDENSED_BOLD:(int)SizeOfFont {
    return [UIFont fontWithName:@"OpenSans-ExtraBold" size:[self GETFONTSIZE:SizeOfFont]];
}

+(UIFont *)GETFONT_LIGHT:(int)SizeOfFont {
    return [UIFont fontWithName:@"OpenSans-Light" size:[self GETFONTSIZE:SizeOfFont]];
}

+(UIFont *)GETFONT_MEDIUM:(int)SizeOfFont {
    return [UIFont fontWithName:@"OpenSans-Semibold" size:[self GETFONTSIZE:SizeOfFont]];
}

+(UIFont *)GETFONT_REGULAR:(int)SizeOfFont {
    return [UIFont fontWithName:@"OpenSans" size:[self GETFONTSIZE:SizeOfFont]];
}

+(UIFont *)GETFONT_BOLD:(int)SizeOfFont {
    return [UIFont fontWithName:@"OpenSans-Bold" size:[self GETFONTSIZE:SizeOfFont]];
}

+(UIFont *)GETFONT_LIGHT_ITALIC:(int)SizeOfFont {
    return [UIFont fontWithName:@"OpenSansLight-Italic" size:[self GETFONTSIZE:SizeOfFont]];
}

+(UIFont *)GETFONT_MEDIUM_ITALIC:(int)SizeOfFont {
    return [UIFont fontWithName:@"OpenSans-SemiboldItalic" size:[self GETFONTSIZE:SizeOfFont]];
}

+(UIFont *)GETFONT_BOLD_ITALIC:(int)SizeOfFont {
    return [UIFont fontWithName:@"OpenSans-BoldItalic" size:[self GETFONTSIZE:SizeOfFont]];
}

+(UIFont *)GETFONT_ITALIC:(int)SizeOfFont {
    return [UIFont fontWithName:@"OpenSans-Italic" size:[self GETFONTSIZE:SizeOfFont]];
}

@end
