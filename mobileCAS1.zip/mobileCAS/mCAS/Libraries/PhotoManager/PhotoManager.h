//
//  PhotoManager.h
//  mServe
//
//  Created by Mac on 03/07/19.
//  Copyright © 2019 Nucleus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CameraOverlayView.h"
#import "ELCImagePickerHeader.h"

NS_ASSUME_NONNULL_BEGIN

@protocol PhotoManagerDelegate <NSObject>

@required
- (void)didFinishPickingImage:(UIImage *)image;

@optional
- (void)didFinishPickingMediaArray:(NSArray *)mediaArray;

@end


@interface PhotoManager : NSObject <UIImagePickerControllerDelegate, UINavigationControllerDelegate, CameraOverlayViewDelegate, ELCImagePickerControllerDelegate>

- (void)showImageUploadDialogWithViewController:(UIViewController *)vc;
- (void)imageUsingCameraWithViewController:(UIViewController *)vc;
- (void)imageUsingPhotoLibraryWithViewController:(UIViewController *)vc;


@property(nonatomic, weak) id<PhotoManagerDelegate> delegate;

@property(nonatomic, assign) BOOL isMultiUploading;
@property(nonatomic, assign) BOOL fromCamera;
@property(nonatomic, assign) NSUInteger totalCount;
@property(nonatomic, strong) UIViewController *baseVC;
@property(nonatomic, strong) UIImagePickerController *imagePickerController;
@property(nonatomic, strong) CameraOverlayView *overlayView;

@end

NS_ASSUME_NONNULL_END
